/*     */ package net.harawata.mybatipse;
/*     */ 
/*     */ import net.harawata.mybatipse.mybatis.TypeAliasCache;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.ProjectScope;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.ILog;
/*     */ import org.eclipse.core.runtime.Status;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.eclipse.jface.preference.IPreferenceStore;
/*     */ import org.eclipse.jface.resource.ImageDescriptor;
/*     */ import org.eclipse.jface.util.IPropertyChangeListener;
/*     */ import org.eclipse.jface.util.PropertyChangeEvent;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.ui.plugin.AbstractUIPlugin;
/*     */ import org.eclipse.ui.preferences.ScopedPreferenceStore;
/*     */ import org.osgi.framework.BundleContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Activator
/*     */   extends AbstractUIPlugin
/*     */ {
/*     */   private static Activator plugin;
/*     */   private IResourceChangeListener resourceChangeListener;
/*     */   
/*     */   public void start(BundleContext context)
/*     */     throws Exception
/*     */   {
/*  52 */     super.start(context);
/*     */     
/*  54 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/*  55 */     this.resourceChangeListener = new MybatipseResourceChangeListener();
/*  56 */     workspace.addResourceChangeListener(this.resourceChangeListener, 
/*  57 */       9);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */     IPreferenceStore store = getPreferenceStore();
/*  64 */     String mapperNames = store.getString("prefCustomMapperNames");
/*  65 */     if (("".equals(mapperNames)) || ("\t".equals(mapperNames))) {
/*  66 */       store.setValue("prefCustomMapperNames", "Mapper\t");
/*     */     }
/*     */     
/*  69 */     plugin = this;
/*     */   }
/*     */   
/*     */   public void stop(BundleContext context) throws Exception
/*     */   {
/*  74 */     plugin = null;
/*     */     
/*  76 */     IWorkspace workspace = ResourcesPlugin.getWorkspace();
/*  77 */     if ((workspace != null) && (this.resourceChangeListener != null))
/*     */     {
/*  79 */       workspace.removeResourceChangeListener(this.resourceChangeListener);
/*     */     }
/*     */     
/*  82 */     super.stop(context);
/*     */   }
/*     */   
/*     */   public static Activator getDefault()
/*     */   {
/*  87 */     return plugin;
/*     */   }
/*     */   
/*     */   public static IPreferenceStore getPreferenceStore(IProject project)
/*     */   {
/*  92 */     ScopedPreferenceStore store = null;
/*  93 */     if (project != null)
/*     */     {
/*  95 */       store = new ScopedPreferenceStore(new ProjectScope(project), "com.yougou.mybatis.plugin");
/*     */     }
/*  97 */     if ((store == null) || 
/*  98 */       (!store.getBoolean("useProjectSettings")))
/*     */     {
/* 100 */       store = new ScopedPreferenceStore(InstanceScope.INSTANCE, "com.yougou.mybatis.plugin");
/*     */     }
/* 102 */     store.addPropertyChangeListener(new IPropertyChangeListener()
/*     */     {
/*     */ 
/*     */       public void propertyChange(PropertyChangeEvent event)
/*     */       {
/* 107 */         if (Activator.this == null) {
/* 108 */           TypeAliasCache.getInstance().clear();
/*     */         } else
/* 110 */           TypeAliasCache.getInstance().remove(Activator.this);
/*     */       }
/* 112 */     });
/* 113 */     return store;
/*     */   }
/*     */   
/*     */   public static ImageDescriptor getImageDescriptor(String path)
/*     */   {
/* 118 */     return imageDescriptorFromPlugin("com.yougou.mybatis.plugin", path);
/*     */   }
/*     */   
/*     */   public static Image getIcon()
/*     */   {
/* 123 */     return getImageDescriptor("/icons/mybatis.png").createImage();
/*     */   }
/*     */   
/*     */   public static Image getIcon(String path)
/*     */   {
/* 128 */     return getImageDescriptor(path).createImage();
/*     */   }
/*     */   
/*     */   public static void log(Status status)
/*     */   {
/* 133 */     if ((getDefault() != null) && (getDefault().getLog() != null)) {
/* 134 */       getDefault().getLog().log(status);
/*     */     }
/*     */   }
/*     */   
/*     */   public static void log(int severity, String message) {
/* 139 */     log(new Status(severity, "com.yougou.mybatis.plugin", message));
/*     */   }
/*     */   
/*     */   public static void log(int severity, String message, Throwable t)
/*     */   {
/* 144 */     log(severity, 0, message, t);
/*     */   }
/*     */   
/*     */   public static void log(int severity, int code, String message, Throwable t)
/*     */   {
/* 149 */     log(new Status(severity, "com.yougou.mybatis.plugin", code, message, t));
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\Activator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */