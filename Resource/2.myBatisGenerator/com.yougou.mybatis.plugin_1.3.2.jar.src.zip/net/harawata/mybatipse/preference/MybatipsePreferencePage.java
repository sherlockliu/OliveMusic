/*     */ package net.harawata.mybatipse.preference;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import org.eclipse.core.runtime.preferences.InstanceScope;
/*     */ import org.eclipse.jface.preference.IPreferenceStore;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.ui.IWorkbench;
/*     */ import org.eclipse.ui.IWorkbenchPreferencePage;
/*     */ import org.eclipse.ui.preferences.ScopedPreferenceStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MybatipsePreferencePage
/*     */   extends ScopedFieldEditorPreferencePage
/*     */   implements IWorkbenchPreferencePage
/*     */ {
/*     */   public static final String SPLIT = "\t";
/*     */   private CustomTypeAliasListEditor customTypeAliases;
/*     */   private CustomTypeAliasListEditor customMapperNames;
/*     */   
/*     */   public MybatipsePreferencePage()
/*     */   {
/*  45 */     super(1);
/*     */   }
/*     */   
/*     */ 
/*     */   protected IPreferenceStore doGetPreferenceStore()
/*     */   {
/*  51 */     return new ScopedPreferenceStore(InstanceScope.INSTANCE, "com.yougou.mybatis.plugin");
/*     */   }
/*     */   
/*     */ 
/*     */   public void init(IWorkbench workbench)
/*     */   {
/*  57 */     setDescription("MyBatipse Settings");
/*     */   }
/*     */   
/*     */ 
/*     */   protected void createFieldEditors()
/*     */   {
/*  63 */     Composite parent = getFieldEditorParent();
/*  64 */     this.customTypeAliases = new CustomTypeAliasListEditor("prefCustomTypeAliases", 
/*  65 */       "Custom type aliases", parent);
/*  66 */     addField(this.customTypeAliases);
/*     */     
/*  68 */     this.customMapperNames = new CustomTypeAliasListEditor("prefCustomMapperNames", "Custom mapper of suffix names", parent);
/*  69 */     addField(this.customMapperNames);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean performOk()
/*     */   {
/*  81 */     String mapperNames = this.customMapperNames.getItemsAsString();
/*  82 */     if (mapperNames != null) {
/*  83 */       String[] strArr = mapperNames.split("\t");
/*  84 */       List<String> list = Arrays.asList(strArr);
/*  85 */       Vector<String> v = new Vector();
/*  86 */       for (String s : list) {
/*  87 */         if (s.trim().length() != 0)
/*     */         {
/*  89 */           v.add(s.trim()); }
/*     */       }
/*  91 */       if (!v.contains("Mapper")) {
/*  92 */         v.add("Mapper");
/*     */       }
/*  94 */       String tmp = "";
/*  95 */       for (int i = 0; i < v.size(); i++) {
/*  96 */         tmp = tmp + (String)v.get(i) + "\t";
/*     */       }
/*  98 */       this.customMapperNames.setItemsAsString(tmp);
/*     */     }
/*     */     
/* 101 */     if (isProjectPropertyPage())
/*     */     {
/* 103 */       IPreferenceStore store = getPreferenceStore();
/* 104 */       store.setValue("prefCustomTypeAliases", this.customTypeAliases.getItemsAsString());
/* 105 */       store.setValue("prefCustomMapperNames", this.customMapperNames.getItemsAsString());
/*     */     }
/* 107 */     return super.performOk();
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getPluginId()
/*     */   {
/* 113 */     return "com.yougou.mybatis.plugin";
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\preference\MybatipsePreferencePage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */