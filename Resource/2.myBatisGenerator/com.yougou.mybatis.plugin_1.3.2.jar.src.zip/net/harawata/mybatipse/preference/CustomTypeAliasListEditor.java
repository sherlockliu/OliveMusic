/*     */ package net.harawata.mybatipse.preference;
/*     */ 
/*     */ import org.eclipse.jface.dialogs.TitleAreaDialog;
/*     */ import org.eclipse.jface.preference.ListEditor;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.List;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CustomTypeAliasListEditor
/*     */   extends ListEditor
/*     */ {
/*     */   protected CustomTypeAliasListEditor() {}
/*     */   
/*     */   public CustomTypeAliasListEditor(String name, String labelText, Composite parent)
/*     */   {
/*  37 */     init(name, labelText);
/*  38 */     createControl(parent);
/*     */   }
/*     */   
/*     */ 
/*     */   protected String createList(String[] items)
/*     */   {
/*  44 */     StringBuilder sb = new StringBuilder();
/*  45 */     String[] arrayOfString; int j = (arrayOfString = items).length; for (int i = 0; i < j; i++) { String item = arrayOfString[i];
/*     */       
/*  47 */       sb.append(item).append('\t');
/*     */     }
/*  49 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */   protected String getNewInputObject()
/*     */   {
/*  55 */     NewTypeAliasDialog dialog = new NewTypeAliasDialog(getShell());
/*  56 */     if (dialog.open() == 0)
/*     */     {
/*  58 */       return dialog.getEntry();
/*     */     }
/*  60 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   protected String[] parseString(String stringList)
/*     */   {
/*  66 */     return stringList.split("\t");
/*     */   }
/*     */   
/*     */   public void setItemsAsString(String str)
/*     */   {
/*  71 */     getList().setItems(parseString(str));
/*     */   }
/*     */   
/*     */   public String getItemsAsString()
/*     */   {
/*  76 */     return createList(getList().getItems());
/*     */   }
/*     */   
/*     */   class NewTypeAliasDialog
/*     */     extends TitleAreaDialog
/*     */   {
/*     */     private Text entryText;
/*     */     private String entry;
/*     */     
/*     */     public NewTypeAliasDialog(Shell parentShell)
/*     */     {
/*  87 */       super();
/*     */     }
/*     */     
/*     */ 
/*     */     protected Control createDialogArea(Composite parent)
/*     */     {
/*  93 */       Composite area = (Composite)super.createDialogArea(parent);
/*  94 */       Composite container = new Composite(area, 0);
/*  95 */       container.setLayoutData(new GridData(1, 1, true, true));
/*  96 */       GridLayout layout = new GridLayout(2, false);
/*  97 */       container.setLayoutData(new GridData(4, 4, true, true));
/*  98 */       container.setLayout(layout);
/*  99 */       createTypeAliasEntry(container);
/* 100 */       setTitle("Enter fully qualified name of a package or a class.");
/* 101 */       setMessage("To assign a custom alias for a class, append the alias name with prefix ':'\n (e.g. com.domain.PersonBean:Person).");
/*     */       
/* 103 */       return area;
/*     */     }
/*     */     
/*     */ 
/*     */     protected void okPressed()
/*     */     {
/* 109 */       this.entry = this.entryText.getText();
/* 110 */       super.okPressed();
/*     */     }
/*     */     
/*     */ 
/*     */     protected boolean isResizable()
/*     */     {
/* 116 */       return true;
/*     */     }
/*     */     
/*     */     private void createTypeAliasEntry(Composite container)
/*     */     {
/* 121 */       Label entryLabel = new Label(container, 0);
/* 122 */       entryLabel.setText("Package or Class");
/*     */       
/* 124 */       GridData entryData = new GridData();
/* 125 */       entryData.grabExcessHorizontalSpace = true;
/* 126 */       entryData.horizontalAlignment = 4;
/*     */       
/* 128 */       this.entryText = new Text(container, 2048);
/* 129 */       this.entryText.setLayoutData(entryData);
/*     */     }
/*     */     
/*     */     public String getEntry()
/*     */     {
/* 134 */       return this.entry;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\preference\CustomTypeAliasListEditor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */