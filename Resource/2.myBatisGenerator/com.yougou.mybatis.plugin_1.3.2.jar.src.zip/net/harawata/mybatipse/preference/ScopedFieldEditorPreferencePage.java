/*     */ package net.harawata.mybatipse.preference;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.ProjectScope;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jface.preference.FieldEditor;
/*     */ import org.eclipse.jface.preference.FieldEditorPreferencePage;
/*     */ import org.eclipse.jface.preference.IPreferenceStore;
/*     */ import org.eclipse.swt.events.SelectionAdapter;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.layout.GridLayout;
/*     */ import org.eclipse.swt.widgets.Button;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.ui.IWorkbenchPropertyPage;
/*     */ import org.eclipse.ui.preferences.ScopedPreferenceStore;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ScopedFieldEditorPreferencePage
/*     */   extends FieldEditorPreferencePage
/*     */   implements IWorkbenchPropertyPage
/*     */ {
/*     */   public static final String USE_PROJECT_SETTINGS = "useProjectSettings";
/*     */   private Button useWorkspaceSettingsButton;
/*     */   private Button useProjectSettingsButton;
/*  47 */   private List<FieldEditor> editors = new ArrayList();
/*     */   
/*     */   private IAdaptable element;
/*     */   
/*     */   protected Control createContents(Composite parent)
/*     */   {
/*  53 */     if (isProjectPropertyPage())
/*     */     {
/*  55 */       createProjectSpecificControls(parent);
/*     */     }
/*  57 */     return super.createContents(parent);
/*     */   }
/*     */   
/*     */   private void createProjectSpecificControls(Composite parent)
/*     */   {
/*  62 */     Composite comp = new Composite(parent, 0);
/*  63 */     GridLayout layout = new GridLayout(2, false);
/*  64 */     layout.marginHeight = 0;
/*  65 */     layout.marginWidth = 0;
/*  66 */     comp.setLayout(layout);
/*  67 */     comp.setLayoutData(new GridData(768));
/*  68 */     Composite radioGroup = new Composite(comp, 0);
/*  69 */     radioGroup.setLayout(new GridLayout());
/*  70 */     radioGroup.setLayoutData(new GridData(768));
/*  71 */     this.useWorkspaceSettingsButton = createRadioButton(radioGroup, "Use workspace settings");
/*  72 */     this.useProjectSettingsButton = createRadioButton(radioGroup, "Use project settings");
/*     */     
/*  74 */     if (getPreferenceStore().getBoolean("useProjectSettings"))
/*     */     {
/*  76 */       this.useProjectSettingsButton.setSelection(true);
/*     */     }
/*     */     else
/*     */     {
/*  80 */       this.useWorkspaceSettingsButton.setSelection(true);
/*     */     }
/*     */   }
/*     */   
/*     */   private Button createRadioButton(Composite parent, String label)
/*     */   {
/*  86 */     Button button = new Button(parent, 16);
/*  87 */     button.setText(label);
/*  88 */     button.addSelectionListener(new SelectionAdapter()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e)
/*     */       {
/*  92 */         ScopedFieldEditorPreferencePage.this.updateFieldEditors();
/*     */       }
/*  94 */     });
/*  95 */     return button;
/*     */   }
/*     */   
/*     */   private void updateFieldEditors()
/*     */   {
/* 100 */     boolean enabled = this.useProjectSettingsButton.getSelection();
/* 101 */     updateFieldEditors(enabled);
/*     */   }
/*     */   
/*     */   protected void updateFieldEditors(boolean enabled)
/*     */   {
/* 106 */     Composite parent = getFieldEditorParent();
/* 107 */     for (FieldEditor editor : this.editors)
/*     */     {
/* 109 */       editor.setEnabled(enabled, parent);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void createControl(Composite parent)
/*     */   {
/* 116 */     super.createControl(parent);
/* 117 */     if (isProjectPropertyPage())
/*     */     {
/* 119 */       updateFieldEditors();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean performOk()
/*     */   {
/* 126 */     boolean result = super.performOk();
/* 127 */     if ((result) && (isProjectPropertyPage()))
/*     */     {
/*     */ 
/*     */ 
/* 131 */       ScopedPreferenceStore store = (ScopedPreferenceStore)getPreferenceStore();
/* 132 */       store.setValue("useProjectSettings", this.useProjectSettingsButton.getSelection());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 140 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void performDefaults()
/*     */   {
/* 146 */     if (isProjectPropertyPage())
/*     */     {
/* 148 */       this.useWorkspaceSettingsButton.setSelection(true);
/* 149 */       this.useProjectSettingsButton.setSelection(false);
/* 150 */       updateFieldEditors();
/*     */     }
/* 152 */     super.performDefaults();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addField(FieldEditor editor)
/*     */   {
/* 158 */     this.editors.add(editor);
/* 159 */     super.addField(editor);
/*     */   }
/*     */   
/*     */ 
/*     */   public IAdaptable getElement()
/*     */   {
/* 165 */     return this.element;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setElement(IAdaptable element)
/*     */   {
/* 171 */     this.element = element;
/* 172 */     setPreferenceStore(new ScopedPreferenceStore(new ProjectScope(getProject()), getPluginId()));
/*     */   }
/*     */   
/*     */   protected IProject getProject()
/*     */   {
/* 177 */     return (this.element instanceof IJavaProject) ? ((IJavaProject)this.element).getProject() : 
/* 178 */       (IProject)this.element;
/*     */   }
/*     */   
/*     */   public boolean isProjectPropertyPage()
/*     */   {
/* 183 */     return this.element != null;
/*     */   }
/*     */   
/*     */   public ScopedFieldEditorPreferencePage(int style)
/*     */   {
/* 188 */     super(style);
/*     */   }
/*     */   
/*     */   public ScopedFieldEditorPreferencePage(String title, int style)
/*     */   {
/* 193 */     super(title, style);
/*     */   }
/*     */   
/*     */   protected abstract String getPluginId();
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\preference\ScopedFieldEditorPreferencePage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */