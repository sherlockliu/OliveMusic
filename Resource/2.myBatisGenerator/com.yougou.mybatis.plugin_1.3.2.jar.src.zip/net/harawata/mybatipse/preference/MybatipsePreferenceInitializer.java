/*    */ package net.harawata.mybatipse.preference;
/*    */ 
/*    */ import org.eclipse.core.runtime.preferences.AbstractPreferenceInitializer;
/*    */ import org.eclipse.core.runtime.preferences.DefaultScope;
/*    */ import org.eclipse.core.runtime.preferences.IScopeContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MybatipsePreferenceInitializer
/*    */   extends AbstractPreferenceInitializer
/*    */ {
/*    */   public void initializeDefaultPreferences()
/*    */   {
/* 30 */     DefaultScope.INSTANCE.getNode("com.yougou.mybatis.plugin");
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\preference\MybatipsePreferenceInitializer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */