/*     */ package net.harawata.mybatipse.bean;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.xml.crypto.Data;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.jdt.core.Flags;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IField;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IMethod;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.core.Signature;
/*     */ import org.eclipse.jdt.core.dom.ASTParser;
/*     */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*     */ import org.eclipse.jface.text.contentassist.ICompletionProposal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanPropertyCache
/*     */ {
/*  57 */   private static boolean DEBUG = (Activator.getDefault().isDebugging()) && 
/*  58 */     (Boolean.parseBoolean(Platform.getDebugOption("com.yougou.mybatis.plugin/debug/beanPropertyCache")));
/*     */   
/*  60 */   private static final Map<IProject, Map<String, BeanPropertyInfo>> projectCache = new ConcurrentHashMap();
/*     */   
/*  62 */   private static final Map<IProject, Map<String, Set<String>>> subclassCache = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   private static final List<String> ignoredTypes = Arrays.asList(new String[] { String.class.getName(), Byte.class.getName(), Long.class.getName(), Short.class.getName(), Integer.class.getName(), Double.class.getName(), Float.class.getName(), Boolean.class.getName(), Data.class.getName(), BigInteger.class.getName(), BigDecimal.class.getName(), Object.class.getName(), Map.class.getName(), HashMap.class.getName(), List.class.getName(), ArrayList.class.getName(), Collection.class.getName(), Iterator.class.getName() });
/*     */   
/*     */   public static void clearBeanPropertyCache()
/*     */   {
/*  73 */     if (DEBUG)
/*  74 */       Activator.log(1, "Remove bean property caches.");
/*  75 */     projectCache.clear();
/*  76 */     subclassCache.clear();
/*     */   }
/*     */   
/*     */   public static void clearBeanPropertyCache(IProject project)
/*     */   {
/*  81 */     if (DEBUG)
/*  82 */       Activator.log(1, "Remove bean property cache for project " + project.getName());
/*  83 */     projectCache.remove(project);
/*  84 */     subclassCache.remove(project);
/*     */   }
/*     */   
/*     */   public static void clearBeanPropertyCache(IProject project, String qualifiedName)
/*     */   {
/*  89 */     Map<String, BeanPropertyInfo> beans = (Map)projectCache.get(project);
/*  90 */     if (beans != null)
/*     */     {
/*  92 */       String topLevelClass = removeExtension(qualifiedName);
/*  93 */       beans.remove(topLevelClass);
/*  94 */       if (DEBUG) {
/*  95 */         Activator.log(1, "Remove bean property cache for class " + qualifiedName);
/*     */       }
/*  97 */       String innerClassPrefix = topLevelClass + ".";
/*  98 */       for (Iterator<Map.Entry<String, BeanPropertyInfo>> it = beans.entrySet().iterator(); it.hasNext();)
/*     */       {
/* 100 */         Map.Entry<String, BeanPropertyInfo> entry = (Map.Entry)it.next();
/* 101 */         String fqn = (String)entry.getKey();
/* 102 */         if (fqn.startsWith(innerClassPrefix))
/*     */         {
/* 104 */           if (DEBUG)
/* 105 */             Activator.log(1, "Remove bean property cache for inner class " + fqn);
/* 106 */           it.remove();
/* 107 */           clearSubclassCache(project, fqn);
/*     */         }
/*     */       }
/* 110 */       clearSubclassCache(project, topLevelClass);
/*     */     }
/*     */   }
/*     */   
/*     */   private static void clearSubclassCache(IProject project, String qualifiedName)
/*     */   {
/* 116 */     Map<String, Set<String>> subclassMap = subclassMapForProject(project);
/* 117 */     Set<String> subclasses = (Set)subclassMap.remove(qualifiedName);
/* 118 */     if (subclasses != null)
/*     */     {
/* 120 */       for (String subclass : subclasses)
/*     */       {
/* 122 */         clearBeanPropertyCache(project, subclass);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static BeanPropertyInfo getBeanPropertyInfo(IJavaProject javaProject, String fqn)
/*     */   {
/* 129 */     if ((fqn == null) || (ignoredTypes.contains(fqn)))
/*     */     {
/* 131 */       return null;
/*     */     }
/* 133 */     String qualifiedName = removeExtension(fqn);
/* 134 */     IProject project = javaProject.getProject();
/* 135 */     Map<String, BeanPropertyInfo> beans = (Map)projectCache.get(project);
/* 136 */     if (beans == null)
/*     */     {
/* 138 */       beans = new ConcurrentHashMap();
/* 139 */       projectCache.put(project, beans);
/*     */     }
/* 141 */     Map<String, Set<String>> subclassMap = subclassMapForProject(project);
/* 142 */     BeanPropertyInfo beanProps = (BeanPropertyInfo)beans.get(qualifiedName);
/* 143 */     if (beanProps == null)
/*     */     {
/* 145 */       Map<String, String> readableFields = new LinkedHashMap();
/* 146 */       Map<String, String> writableFields = new LinkedHashMap();
/* 147 */       parseBean(javaProject, qualifiedName, readableFields, writableFields, subclassMap);
/* 148 */       beanProps = new BeanPropertyInfo(readableFields, writableFields);
/*     */     }
/* 150 */     beans.put(qualifiedName, beanProps);
/* 151 */     return beanProps;
/*     */   }
/*     */   
/*     */   private static Map<String, Set<String>> subclassMapForProject(IProject project)
/*     */   {
/* 156 */     Map<String, Set<String>> subclassMap = (Map)subclassCache.get(project.getProject());
/* 157 */     if (subclassMap == null)
/*     */     {
/* 159 */       subclassMap = new ConcurrentHashMap();
/* 160 */       subclassCache.put(project.getProject(), subclassMap);
/*     */     }
/* 162 */     return subclassMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected static void parseBean(IJavaProject project, String qualifiedName, Map<String, String> readableFields, Map<String, String> writableFields, Map<String, Set<String>> subclassMap)
/*     */   {
/*     */     try
/*     */     {
/* 171 */       IType type = project.findType(qualifiedName);
/* 172 */       if (type != null)
/*     */       {
/* 174 */         if (type.isBinary())
/*     */         {
/* 176 */           if (DEBUG)
/* 177 */             Activator.log(1, "Parsing properties of a binary class " + qualifiedName);
/* 178 */           parseBinary(project, type, readableFields, writableFields, subclassMap);
/*     */         }
/*     */         else
/*     */         {
/* 182 */           if (DEBUG)
/* 183 */             Activator.log(1, "Parsing properties of a source class " + qualifiedName);
/* 184 */           parseSource(project, type, qualifiedName, readableFields, writableFields, subclassMap);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (JavaModelException e)
/*     */     {
/* 190 */       Activator.log(4, "Failed to find type " + qualifiedName, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected static void parseBinary(IJavaProject project, IType type, Map<String, String> readableFields, Map<String, String> writableFields, Map<String, Set<String>> subclassMap)
/*     */     throws JavaModelException
/*     */   {
/* 198 */     parseBinaryFields(type, readableFields, writableFields);
/*     */     
/* 200 */     parseBinaryMethods(type, readableFields, writableFields);
/*     */     
/* 202 */     String superclass = Signature.toString(type.getSuperclassTypeSignature());
/* 203 */     if (!Object.class.getName().equals(superclass))
/*     */     {
/* 205 */       Set<String> subclasses = (Set)subclassMap.get(superclass);
/* 206 */       if (subclasses == null)
/*     */       {
/* 208 */         subclasses = Collections.newSetFromMap(new ConcurrentHashMap());
/* 209 */         subclassMap.put(superclass, subclasses);
/*     */       }
/* 211 */       subclasses.add(type.getFullyQualifiedName());
/* 212 */       parseBean(project, superclass, readableFields, writableFields, subclassMap);
/*     */     }
/*     */   }
/*     */   
/*     */   protected static void parseBinaryMethods(IType type, Map<String, String> readableFields, Map<String, String> writableFields)
/*     */     throws JavaModelException
/*     */   {
/*     */     IMethod[] arrayOfIMethod;
/* 220 */     int j = (arrayOfIMethod = type.getMethods()).length; for (int i = 0; i < j; i++) { IMethod method = arrayOfIMethod[i];
/*     */       
/* 222 */       int flags = method.getFlags();
/* 223 */       if (Flags.isPublic(flags))
/*     */       {
/* 225 */         String methodName = method.getElementName();
/* 226 */         int parameterCount = method.getParameters().length;
/* 227 */         String returnType = method.getReturnType();
/* 228 */         if ('V' == returnType.charAt(0))
/*     */         {
/* 230 */           if (BeanPropertyVisitor.isSetter(methodName, parameterCount))
/*     */           {
/* 232 */             String fieldName = BeanPropertyVisitor.getFieldNameFromAccessor(methodName);
/* 233 */             String paramType = method.getParameterTypes()[0];
/* 234 */             writableFields.put(fieldName, Signature.toString(paramType));
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 239 */         else if (BeanPropertyVisitor.isGetter(methodName, parameterCount))
/*     */         {
/* 241 */           String fieldName = BeanPropertyVisitor.getFieldNameFromAccessor(methodName);
/* 242 */           readableFields.put(fieldName, Signature.toString(returnType));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected static void parseBinaryFields(IType type, Map<String, String> readableFields, Map<String, String> writableFields)
/*     */     throws JavaModelException
/*     */   {
/*     */     IField[] arrayOfIField;
/* 253 */     int j = (arrayOfIField = type.getFields()).length; for (int i = 0; i < j; i++) { IField field = arrayOfIField[i];
/*     */       
/* 255 */       int flags = field.getFlags();
/* 256 */       String fieldName = field.getElementName();
/* 257 */       String qualifiedType = Signature.toString(field.getTypeSignature());
/* 258 */       if (!Flags.isFinal(flags))
/*     */       {
/*     */ 
/* 261 */         writableFields.put(fieldName, qualifiedType);
/*     */       }
/* 263 */       if (Flags.isPublic(flags))
/*     */       {
/* 265 */         readableFields.put(fieldName, qualifiedType);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected static void parseSource(IJavaProject project, IType type, String qualifiedName, Map<String, String> readableFields, Map<String, String> writableFields, Map<String, Set<String>> subclassMap)
/*     */     throws JavaModelException
/*     */   {
/* 275 */     ICompilationUnit compilationUnit = (ICompilationUnit)type.getAncestor(5);
/* 276 */     ASTParser parser = ASTParser.newParser(4);
/* 277 */     parser.setKind(8);
/* 278 */     parser.setSource(compilationUnit);
/* 279 */     parser.setResolveBindings(true);
/*     */     
/* 281 */     CompilationUnit astUnit = (CompilationUnit)parser.createAST(null);
/* 282 */     astUnit.accept(new BeanPropertyVisitor(project, qualifiedName, readableFields, 
/* 283 */       writableFields, subclassMap));
/*     */   }
/*     */   
/*     */ 
/*     */   public static Map<String, String> searchFields(IJavaProject project, String qualifiedName, String matchStr, boolean searchReadable, int currentIdx, boolean isValidation)
/*     */   {
/* 289 */     Map<String, String> results = new LinkedHashMap();
/*     */     
/* 291 */     int startIdx = currentIdx + 1;
/* 292 */     int dotIdx = getDotIndex(matchStr, startIdx);
/* 293 */     String searchStr; if (dotIdx == -1) {
/* 294 */       searchStr = matchStr.substring(startIdx);
/*     */     } else
/* 296 */       searchStr = matchStr.substring(startIdx, dotIdx);
/* 297 */     int bracePos = searchStr.indexOf("[");
/* 298 */     String searchStr = bracePos > -1 ? searchStr.substring(0, bracePos) : searchStr;
/* 299 */     boolean isPrefixMatch = (!isValidation) && (dotIdx == -1);
/*     */     
/* 301 */     BeanPropertyInfo beanProperty = getBeanPropertyInfo(project, qualifiedName);
/* 302 */     if (beanProperty != null)
/*     */     {
/* 304 */       Map<String, String> fields = searchReadable ? beanProperty.getReadableFields() : 
/* 305 */         beanProperty.getWritableFields();
/*     */       
/* 307 */       for (Map.Entry<String, String> entry : fields.entrySet())
/*     */       {
/* 309 */         String fieldName = (String)entry.getKey();
/* 310 */         String fieldQualifiedName = (String)entry.getValue();
/*     */         
/* 312 */         if (matched(fieldName, searchStr, isPrefixMatch))
/*     */         {
/* 314 */           if (dotIdx > -1)
/*     */           {
/* 316 */             return searchFields(project, fieldQualifiedName, matchStr, searchReadable, dotIdx, 
/* 317 */               isValidation);
/*     */           }
/*     */           
/*     */ 
/* 321 */           results.put(fieldName, fieldQualifiedName);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 326 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */   public static List<ICompletionProposal> buildFieldNameProposal(Map<String, String> fields, String input, int offset, int replacementLength)
/*     */   {
/* 332 */     List<ICompletionProposal> proposalList = new ArrayList();
/* 333 */     int lastDot = input.lastIndexOf(".");
/* 334 */     String prefix = lastDot > -1 ? input.substring(0, lastDot) : "";
/* 335 */     int relevance = fields.size();
/* 336 */     for (Map.Entry<String, String> fieldEntry : fields.entrySet())
/*     */     {
/* 338 */       String fieldName = (String)fieldEntry.getKey();
/* 339 */       String qualifiedName = (String)fieldEntry.getValue();
/* 340 */       StringBuilder replaceStr = new StringBuilder();
/* 341 */       if (lastDot > -1)
/* 342 */         replaceStr.append(prefix).append('.');
/* 343 */       replaceStr.append(fieldName);
/* 344 */       StringBuilder displayStr = new StringBuilder();
/* 345 */       displayStr.append(fieldName).append(" - ").append(qualifiedName);
/* 346 */       ICompletionProposal proposal = new JavaCompletionProposal(replaceStr.toString(), offset, 
/* 347 */         replacementLength, replaceStr.length(), Activator.getIcon(), displayStr.toString(), 
/* 348 */         null, null, relevance--);
/* 349 */       proposalList.add(proposal);
/*     */     }
/* 351 */     return proposalList;
/*     */   }
/*     */   
/*     */   private static String removeExtension(String src)
/*     */   {
/* 356 */     if ((src != null) && (src.endsWith(".java"))) {
/* 357 */       return src.substring(0, src.length() - 5);
/*     */     }
/* 359 */     return src;
/*     */   }
/*     */   
/*     */   private static int getDotIndex(String str, int startIdx)
/*     */   {
/* 364 */     boolean isIndexedProperty = false;
/* 365 */     for (int i = startIdx; i < str.length(); i++)
/*     */     {
/* 367 */       char c = str.charAt(i);
/* 368 */       if ((!isIndexedProperty) && (c == '.'))
/* 369 */         return i;
/* 370 */       if ((!isIndexedProperty) && (c == '[')) {
/* 371 */         isIndexedProperty = true;
/* 372 */       } else if (c == ']')
/* 373 */         isIndexedProperty = false;
/*     */     }
/* 375 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static boolean matched(String fieldName, String searchStr, boolean prefixMatch)
/*     */   {
/* 382 */     return (searchStr == null) || (searchStr.length() == 0) || (prefixMatch ? fieldName.toLowerCase().startsWith(searchStr.toLowerCase()) : fieldName.equals(searchStr));
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\bean\BeanPropertyCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */