/*     */ package net.harawata.mybatipse.bean;
/*     */ 
/*     */ import org.eclipse.core.runtime.Assert;
/*     */ import org.eclipse.jdt.ui.text.java.IJavaCompletionProposal;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.contentassist.IContextInformation;
/*     */ import org.eclipse.swt.graphics.Image;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaCompletionProposal
/*     */   implements IJavaCompletionProposal
/*     */ {
/*     */   private String fDisplayString;
/*     */   private String fReplacementString;
/*     */   private int fReplacementOffset;
/*     */   private int fReplacementLength;
/*     */   private int fCursorPosition;
/*     */   private Image fImage;
/*     */   private IContextInformation fContextInformation;
/*     */   private String fAdditionalProposalInfo;
/*     */   private int fRelevance;
/*     */   
/*     */   public JavaCompletionProposal(String replacementString, int replacementOffset, int replacementLength, int cursorPosition, int relevance)
/*     */   {
/*  73 */     this(replacementString, replacementOffset, replacementLength, cursorPosition, null, null, null, null, relevance);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JavaCompletionProposal(String replacementString, int replacementOffset, int replacementLength, int cursorPosition, Image image, String displayString, IContextInformation contextInformation, String additionalProposalInfo, int relevance)
/*     */   {
/* 101 */     Assert.isNotNull(replacementString);
/* 102 */     Assert.isTrue(replacementOffset >= 0);
/* 103 */     Assert.isTrue(replacementLength >= 0);
/* 104 */     Assert.isTrue(cursorPosition >= 0);
/*     */     
/* 106 */     this.fReplacementString = replacementString;
/* 107 */     this.fReplacementOffset = replacementOffset;
/* 108 */     this.fReplacementLength = replacementLength;
/* 109 */     this.fCursorPosition = cursorPosition;
/* 110 */     this.fImage = image;
/* 111 */     this.fDisplayString = displayString;
/* 112 */     this.fContextInformation = contextInformation;
/* 113 */     this.fAdditionalProposalInfo = additionalProposalInfo;
/* 114 */     this.fRelevance = relevance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void apply(IDocument document)
/*     */   {
/*     */     try
/*     */     {
/* 124 */       document.replace(this.fReplacementOffset, this.fReplacementLength, this.fReplacementString);
/*     */     }
/*     */     catch (BadLocationException localBadLocationException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Point getSelection(IDocument document)
/*     */   {
/* 137 */     return new Point(this.fReplacementOffset + this.fCursorPosition, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public IContextInformation getContextInformation()
/*     */   {
/* 145 */     return this.fContextInformation;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Image getImage()
/*     */   {
/* 153 */     return this.fImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDisplayString()
/*     */   {
/* 161 */     if (this.fDisplayString != null)
/* 162 */       return this.fDisplayString;
/* 163 */     return this.fReplacementString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAdditionalProposalInfo()
/*     */   {
/* 171 */     return this.fAdditionalProposalInfo;
/*     */   }
/*     */   
/*     */   public int getRelevance()
/*     */   {
/* 176 */     return this.fRelevance;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\bean\JavaCompletionProposal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */