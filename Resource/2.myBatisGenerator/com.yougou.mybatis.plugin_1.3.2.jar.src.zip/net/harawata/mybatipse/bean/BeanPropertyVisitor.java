/*     */ package net.harawata.mybatipse.bean;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.dom.ASTVisitor;
/*     */ import org.eclipse.jdt.core.dom.AnonymousClassDeclaration;
/*     */ import org.eclipse.jdt.core.dom.FieldDeclaration;
/*     */ import org.eclipse.jdt.core.dom.IMethodBinding;
/*     */ import org.eclipse.jdt.core.dom.ITypeBinding;
/*     */ import org.eclipse.jdt.core.dom.MethodDeclaration;
/*     */ import org.eclipse.jdt.core.dom.Modifier;
/*     */ import org.eclipse.jdt.core.dom.PrimitiveType;
/*     */ import org.eclipse.jdt.core.dom.SimpleName;
/*     */ import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
/*     */ import org.eclipse.jdt.core.dom.Type;
/*     */ import org.eclipse.jdt.core.dom.TypeDeclaration;
/*     */ import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanPropertyVisitor
/*     */   extends ASTVisitor
/*     */ {
/*     */   private IJavaProject project;
/*     */   private final String qualifiedName;
/*     */   private final Map<String, String> readableFields;
/*     */   private final Map<String, String> writableFields;
/*     */   private final Map<String, Set<String>> subclassMap;
/*     */   private int nestLevel;
/*     */   
/*     */   public BeanPropertyVisitor(IJavaProject project, String qualifiedName, Map<String, String> readableFields, Map<String, String> writableFields, Map<String, Set<String>> subclassMap)
/*     */   {
/*  60 */     this.project = project;
/*  61 */     this.qualifiedName = qualifiedName;
/*  62 */     this.readableFields = readableFields;
/*  63 */     this.writableFields = writableFields;
/*  64 */     this.subclassMap = subclassMap;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean visit(TypeDeclaration node)
/*     */   {
/*  70 */     ITypeBinding binding = node.resolveBinding();
/*  71 */     if (binding == null) {
/*  72 */       return false;
/*     */     }
/*  74 */     if (this.qualifiedName.equals(binding.getQualifiedName())) {
/*  75 */       this.nestLevel = 1;
/*  76 */     } else if (this.nestLevel > 0) {
/*  77 */       this.nestLevel += 1;
/*     */     }
/*  79 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean visit(AnonymousClassDeclaration node)
/*     */   {
/*  85 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean visit(FieldDeclaration node)
/*     */   {
/*  91 */     if (this.nestLevel != 1)
/*  92 */       return false;
/*  93 */     int modifiers = node.getModifiers();
/*     */     
/*  95 */     if ((Modifier.isPublic(modifiers)) || (!Modifier.isFinal(modifiers)))
/*     */     {
/*     */ 
/*  98 */       List<VariableDeclarationFragment> fragments = node.fragments();
/*  99 */       for (VariableDeclarationFragment fragment : fragments)
/*     */       {
/* 101 */         String fieldName = fragment.getName().toString();
/* 102 */         String qualifiedName = getQualifiedNameFromType(node.getType());
/* 103 */         if (qualifiedName != null)
/*     */         {
/* 105 */           if (Modifier.isPublic(modifiers))
/* 106 */             this.readableFields.put(fieldName, qualifiedName);
/* 107 */           if (!Modifier.isFinal(modifiers))
/* 108 */             this.writableFields.put(fieldName, qualifiedName);
/*     */         }
/*     */       }
/*     */     }
/* 112 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean visit(MethodDeclaration node)
/*     */   {
/* 118 */     if (this.nestLevel != 1) {
/* 119 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 123 */     IMethodBinding method = node.resolveBinding();
/* 124 */     if ((method != null) && (Modifier.isPublic(method.getModifiers())))
/*     */     {
/* 126 */       String methodName = node.getName().toString();
/* 127 */       int parameterCount = node.parameters().size();
/* 128 */       Type returnType = node.getReturnType2();
/* 129 */       if (returnType != null)
/*     */       {
/*     */ 
/*     */ 
/* 133 */         if (isReturnVoid(returnType))
/*     */         {
/* 135 */           if (isSetter(methodName, parameterCount))
/*     */           {
/* 137 */             SingleVariableDeclaration param = (SingleVariableDeclaration)node.parameters().get(0);
/* 138 */             String qualifiedName = getQualifiedNameFromType(param.getType());
/* 139 */             String fieldName = getFieldNameFromAccessor(methodName);
/* 140 */             this.writableFields.put(fieldName, qualifiedName);
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 145 */         else if (isGetter(methodName, parameterCount))
/*     */         {
/* 147 */           String fieldName = getFieldNameFromAccessor(methodName);
/* 148 */           String qualifiedName = getQualifiedNameFromType(returnType);
/* 149 */           this.readableFields.put(fieldName, qualifiedName);
/*     */         }
/*     */       }
/*     */     }
/* 153 */     return false;
/*     */   }
/*     */   
/*     */   private String getQualifiedNameFromType(Type type)
/*     */   {
/* 158 */     String qualifiedName = null;
/* 159 */     ITypeBinding binding = type.resolveBinding();
/* 160 */     if (binding != null)
/*     */     {
/* 162 */       if (binding.isParameterizedType())
/*     */       {
/* 164 */         ITypeBinding[] arguments = binding.getTypeArguments();
/*     */         
/* 166 */         qualifiedName = arguments[0].getQualifiedName();
/*     */       }
/*     */       else
/*     */       {
/* 170 */         qualifiedName = binding.getQualifiedName();
/*     */       }
/*     */     }
/* 173 */     return qualifiedName;
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean isGetter(String methodName, int parameterCount)
/*     */   {
/* 179 */     return ((methodName.startsWith("get")) && (methodName.length() > 3)) || ((methodName.startsWith("is")) && (methodName.length() > 2) && (parameterCount == 0));
/*     */   }
/*     */   
/*     */   public static boolean isSetter(String methodName, int parameterCount)
/*     */   {
/* 184 */     return (methodName.startsWith("set")) && (methodName.length() > 3) && (parameterCount == 1);
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isReturnVoid(Type type)
/*     */   {
/* 190 */     return (type.isPrimitiveType()) && (PrimitiveType.VOID.equals(((PrimitiveType)type).getPrimitiveTypeCode()));
/*     */   }
/*     */   
/*     */ 
/*     */   public void endVisit(TypeDeclaration node)
/*     */   {
/* 196 */     if (this.nestLevel == 1)
/*     */     {
/* 198 */       Type superclassType = node.getSuperclassType();
/* 199 */       if (superclassType != null)
/*     */       {
/* 201 */         ITypeBinding binding = superclassType.resolveBinding();
/* 202 */         if (binding != null)
/*     */         {
/* 204 */           String superclassFqn = binding.getQualifiedName();
/* 205 */           Set<String> subclasses = (Set)this.subclassMap.get(superclassFqn);
/* 206 */           if (subclasses == null)
/*     */           {
/* 208 */             subclasses = Collections.newSetFromMap(new ConcurrentHashMap());
/* 209 */             this.subclassMap.put(superclassFqn, subclasses);
/*     */           }
/* 211 */           subclasses.add(this.qualifiedName);
/* 212 */           BeanPropertyCache.parseBean(this.project, superclassFqn, this.readableFields, this.writableFields, 
/* 213 */             this.subclassMap);
/*     */         }
/*     */       }
/*     */     }
/* 217 */     this.nestLevel -= 1;
/*     */   }
/*     */   
/*     */   public static String getFieldNameFromAccessor(String methodName)
/*     */   {
/* 222 */     String fieldName = "";
/* 223 */     if (methodName != null)
/*     */     {
/* 225 */       if ((methodName.startsWith("set")) || (methodName.startsWith("get")))
/*     */       {
/* 227 */         fieldName = Introspector.decapitalize(methodName.substring(3));
/*     */       }
/* 229 */       else if (methodName.startsWith("is"))
/*     */       {
/* 231 */         fieldName = Introspector.decapitalize(methodName.substring(2));
/*     */       }
/*     */     }
/* 234 */     return fieldName;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\bean\BeanPropertyVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */