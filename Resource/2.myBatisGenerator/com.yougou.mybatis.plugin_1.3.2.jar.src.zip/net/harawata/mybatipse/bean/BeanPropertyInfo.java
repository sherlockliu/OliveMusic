/*    */ package net.harawata.mybatipse.bean;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BeanPropertyInfo
/*    */ {
/*    */   private Map<String, String> readableFields;
/*    */   private Map<String, String> writableFields;
/*    */   
/*    */   public BeanPropertyInfo(Map<String, String> readableFields, Map<String, String> writableFields)
/*    */   {
/* 28 */     this.readableFields = readableFields;
/* 29 */     this.writableFields = writableFields;
/*    */   }
/*    */   
/*    */   public Map<String, String> getReadableFields()
/*    */   {
/* 34 */     return this.readableFields;
/*    */   }
/*    */   
/*    */   public Map<String, String> getWritableFields()
/*    */   {
/* 39 */     return this.writableFields;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\bean\BeanPropertyInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */