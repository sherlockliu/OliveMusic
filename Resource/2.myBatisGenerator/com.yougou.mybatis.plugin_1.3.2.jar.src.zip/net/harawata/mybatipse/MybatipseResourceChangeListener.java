/*     */ package net.harawata.mybatipse;
/*     */ 
/*     */ import net.harawata.mybatipse.bean.BeanPropertyCache;
/*     */ import net.harawata.mybatipse.mybatis.ConfigRegistry;
/*     */ import net.harawata.mybatipse.mybatis.MapperNamespaceCache;
/*     */ import net.harawata.mybatipse.mybatis.TypeAliasCache;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceChangeEvent;
/*     */ import org.eclipse.core.resources.IResourceChangeListener;
/*     */ import org.eclipse.core.resources.IResourceDelta;
/*     */ import org.eclipse.core.resources.IResourceDeltaVisitor;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MybatipseResourceChangeListener
/*     */   implements IResourceChangeListener
/*     */ {
/*     */   public void resourceChanged(IResourceChangeEvent event)
/*     */   {
/*  45 */     if ((event.getType() == 8) && 
/*  46 */       (event.getBuildKind() == 15))
/*     */     {
/*  48 */       Object source = event.getSource();
/*  49 */       if ((source instanceof IWorkspace))
/*     */       {
/*  51 */         ConfigRegistry.getInstance().clear();
/*  52 */         MapperNamespaceCache.getInstance().clear();
/*  53 */         BeanPropertyCache.clearBeanPropertyCache();
/*     */       }
/*  55 */       else if ((source instanceof IProject))
/*     */       {
/*  57 */         IProject project = (IProject)source;
/*  58 */         ConfigRegistry.getInstance().remove(project);
/*  59 */         MapperNamespaceCache.getInstance().remove(project);
/*  60 */         BeanPropertyCache.clearBeanPropertyCache(project);
/*     */       }
/*     */     }
/*  63 */     else if (event.getType() != 1) {
/*  64 */       return;
/*     */     }
/*  66 */     IResourceDelta delta = event.getDelta();
/*  67 */     if ((delta.getKind() == 4) && (
/*  68 */       (delta.getFlags() == 1048576) || (delta.getFlags() == 131072))) {
/*  69 */       return;
/*     */     }
/*  71 */     IResourceDeltaVisitor visitor = new IResourceDeltaVisitor()
/*     */     {
/*     */       public boolean visit(IResourceDelta delta)
/*     */       {
/*  75 */         IResource resource = delta.getResource();
/*  76 */         if (resource.isDerived()) {
/*  77 */           return false;
/*     */         }
/*  79 */         if (resource.getType() == 1)
/*     */         {
/*  81 */           if ((delta.getKind() == 4) && (
/*  82 */             (delta.getFlags() == 1048576) || (delta.getFlags() == 131072))) {
/*  83 */             return false;
/*     */           }
/*  85 */           IProject project = resource.getProject();
/*  86 */           IFile file = (IFile)resource;
/*  87 */           if (!file.exists())
/*  88 */             return false;
/*  89 */           if ("xml".equals(file.getFileExtension()))
/*     */           {
/*  91 */             onXmlChange(delta, resource, project, file);
/*  92 */             return true;
/*     */           }
/*  94 */           if ("java".equals(file.getFileExtension()))
/*     */           {
/*  96 */             onJavaChange(delta, project, file);
/*  97 */             return true;
/*     */           }
/*     */         }
/* 100 */         else if (resource.getType() == 4)
/*     */         {
/* 102 */           if (delta.getKind() == 2)
/*     */           {
/* 104 */             ConfigRegistry.getInstance().remove((IProject)resource);
/* 105 */             MapperNamespaceCache.getInstance().remove((IProject)resource);
/*     */           }
/*     */         }
/* 108 */         return true;
/*     */       }
/*     */       
/*     */       protected void onJavaChange(IResourceDelta delta, IProject project, IFile file)
/*     */       {
/* 113 */         ICompilationUnit compilationUnit = (ICompilationUnit)JavaCore.create(file);
/* 114 */         String elementName = compilationUnit.getElementName();
/* 115 */         String simpleTypeName = elementName.substring(0, elementName.length() - 5);
/* 116 */         IType type = compilationUnit.getType(simpleTypeName);
/* 117 */         String qualifiedName = type.getFullyQualifiedName();
/*     */         
/* 119 */         BeanPropertyCache.clearBeanPropertyCache(project, qualifiedName);
/*     */         
/* 121 */         String superType = null;
/*     */         try
/*     */         {
/* 124 */           superType = type.getSuperclassName();
/*     */         }
/*     */         catch (JavaModelException e)
/*     */         {
/* 128 */           Activator.log(4, e.getMessage(), e);
/*     */         }
/* 130 */         if ((superType != null) && ("MyBatisModule".equals(superType)))
/*     */         {
/* 132 */           TypeAliasCache.getInstance().remove(project);
/*     */         }
/* 134 */         else if (delta.getKind() == 2)
/*     */         {
/* 136 */           TypeAliasCache.getInstance().removeType(project.getName(), qualifiedName);
/*     */ 
/*     */ 
/*     */         }
/* 140 */         else if (TypeAliasCache.getInstance().isInPackage(project.getName(), qualifiedName))
/*     */         {
/* 142 */           TypeAliasCache.getInstance().put(project.getName(), type, simpleTypeName);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */       protected void onXmlChange(IResourceDelta delta, IResource resource, IProject project, IFile file)
/*     */       {
/* 150 */         if ((delta.getKind() == 2) || (!file.exists()))
/*     */         {
/*     */ 
/* 153 */           ConfigRegistry.getInstance().remove(project, file);
/* 154 */           MapperNamespaceCache.getInstance().remove(project.getName(), file);
/*     */         }
/*     */         else
/*     */         {
/*     */           try
/*     */           {
/* 160 */             IContentDescription contentDesc = file.getContentDescription();
/* 161 */             if (contentDesc != null)
/*     */             {
/* 163 */               IContentType contentType = contentDesc.getContentType();
/* 164 */               if (contentType != null)
/*     */               {
/* 166 */                 if ((contentType.isKindOf(MybatipseConstants.configContentType)) || 
/* 167 */                   (contentType.isKindOf(MybatipseConstants.springConfigContentType)))
/*     */                 {
/*     */ 
/*     */ 
/* 171 */                   ConfigRegistry.getInstance().remove(project);
/*     */                 }
/* 173 */                 else if (contentType.isKindOf(MybatipseConstants.mapperContentType))
/*     */                 {
/* 175 */                   MapperNamespaceCache.getInstance().put(project.getName(), file);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (CoreException e)
/*     */           {
/* 182 */             Activator.log(4, e.getMessage(), e);
/*     */           }
/*     */         }
/*     */       }
/*     */     };
/*     */     try
/*     */     {
/* 189 */       delta.accept(visitor);
/*     */     }
/*     */     catch (CoreException e)
/*     */     {
/* 193 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\MybatipseResourceChangeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */