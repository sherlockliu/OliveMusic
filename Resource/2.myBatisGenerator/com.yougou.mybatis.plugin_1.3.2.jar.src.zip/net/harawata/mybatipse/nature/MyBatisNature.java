/*    */ package net.harawata.mybatipse.nature;
/*    */ 
/*    */ import org.eclipse.core.resources.ICommand;
/*    */ import org.eclipse.core.resources.IProject;
/*    */ import org.eclipse.core.resources.IProjectDescription;
/*    */ import org.eclipse.core.resources.IProjectNature;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MyBatisNature
/*    */   implements IProjectNature
/*    */ {
/*    */   public static final String NATURE_ID = "net.harawata.mybatipse.MyBatisNature";
/*    */   private IProject project;
/*    */   
/*    */   public void configure()
/*    */     throws CoreException
/*    */   {
/* 32 */     IProjectDescription description = this.project.getDescription();
/* 33 */     ICommand[] commands = description.getBuildSpec();
/* 34 */     ICommand[] arrayOfICommand1; int j = (arrayOfICommand1 = commands).length; for (int i = 0; i < j; i++) { ICommand command = arrayOfICommand1[i];
/*    */       
/* 36 */       if (command.getBuilderName().equals("net.harawata.mybatipse.MapperValidationBuilder")) {
/* 37 */         return;
/*    */       }
/*    */     }
/* 40 */     ICommand[] newCommands = new ICommand[commands.length + 1];
/* 41 */     System.arraycopy(commands, 0, newCommands, 0, commands.length);
/* 42 */     ICommand command = description.newCommand();
/* 43 */     command.setBuilderName("net.harawata.mybatipse.MapperValidationBuilder");
/* 44 */     newCommands[(newCommands.length - 1)] = command;
/* 45 */     description.setBuildSpec(newCommands);
/* 46 */     this.project.setDescription(description, null);
/*    */   }
/*    */   
/*    */   public void deconfigure()
/*    */     throws CoreException
/*    */   {
/* 52 */     IProjectDescription description = this.project.getDescription();
/* 53 */     ICommand[] commands = description.getBuildSpec();
/* 54 */     for (int i = 0; i < commands.length; i++)
/*    */     {
/* 56 */       if (commands[i].getBuilderName().equals("net.harawata.mybatipse.MapperValidationBuilder"))
/*    */       {
/*    */ 
/* 59 */         ICommand[] newCommands = new ICommand[commands.length - 1];
/* 60 */         System.arraycopy(commands, 0, newCommands, 0, i);
/* 61 */         System.arraycopy(commands, i + 1, newCommands, i, commands.length - i - 1);
/* 62 */         description.setBuildSpec(newCommands);
/* 63 */         this.project.setDescription(description, null);
/* 64 */         return;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public IProject getProject()
/*    */   {
/* 72 */     return this.project;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setProject(IProject project)
/*    */   {
/* 78 */     this.project = project;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\nature\MyBatisNature.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */