/*     */ package net.harawata.mybatipse.nature;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Map;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import net.harawata.mybatipse.MybatipseConstants;
/*     */ import net.harawata.mybatipse.bean.BeanPropertyCache;
/*     */ import net.harawata.mybatipse.mybatis.ConfigRegistry;
/*     */ import net.harawata.mybatipse.mybatis.MapperNamespaceCache;
/*     */ import net.harawata.mybatipse.mybatis.TypeAliasCache;
/*     */ import net.harawata.mybatipse.mybatis.XmlValidator;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResourceProxy;
/*     */ import org.eclipse.core.resources.IResourceProxyVisitor;
/*     */ import org.eclipse.core.resources.IncrementalProjectBuilder;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.wst.validation.ValidationState;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MybatipseIncrementalBuilder
/*     */   extends IncrementalProjectBuilder
/*     */ {
/*     */   public static final String BUILDER_ID = "net.harawata.mybatipse.MapperValidationBuilder";
/*     */   private int currentWork;
/*     */   
/*     */   protected IProject[] build(int kind, Map<String, String> args, IProgressMonitor monitor)
/*     */     throws CoreException
/*     */   {
/*  56 */     validateAllMappers(monitor);
/*  57 */     return null;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void validateAllMappers(final IProgressMonitor monitor)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial 39	net/harawata/mybatipse/nature/MybatipseIncrementalBuilder:countResources	()I
/*     */     //   4: istore_2
/*     */     //   5: aload_1
/*     */     //   6: ldc 43
/*     */     //   8: iload_2
/*     */     //   9: invokeinterface 45 3 0
/*     */     //   14: aload_0
/*     */     //   15: iconst_1
/*     */     //   16: putfield 51	net/harawata/mybatipse/nature/MybatipseIncrementalBuilder:currentWork	I
/*     */     //   19: new 53	net/harawata/mybatipse/mybatis/XmlValidator
/*     */     //   22: dup
/*     */     //   23: invokespecial 55	net/harawata/mybatipse/mybatis/XmlValidator:<init>	()V
/*     */     //   26: astore_3
/*     */     //   27: aload_0
/*     */     //   28: invokevirtual 56	net/harawata/mybatipse/nature/MybatipseIncrementalBuilder:getProject	()Lorg/eclipse/core/resources/IProject;
/*     */     //   31: new 60	net/harawata/mybatipse/nature/MybatipseIncrementalBuilder$1
/*     */     //   34: dup
/*     */     //   35: aload_0
/*     */     //   36: aload_1
/*     */     //   37: iload_2
/*     */     //   38: aload_3
/*     */     //   39: invokespecial 62	net/harawata/mybatipse/nature/MybatipseIncrementalBuilder$1:<init>	(Lnet/harawata/mybatipse/nature/MybatipseIncrementalBuilder;Lorg/eclipse/core/runtime/IProgressMonitor;ILnet/harawata/mybatipse/mybatis/XmlValidator;)V
/*     */     //   42: iconst_0
/*     */     //   43: invokeinterface 65 3 0
/*     */     //   48: goto +36 -> 84
/*     */     //   51: astore 4
/*     */     //   53: iconst_4
/*     */     //   54: aload 4
/*     */     //   56: invokevirtual 71	org/eclipse/core/runtime/CoreException:getMessage	()Ljava/lang/String;
/*     */     //   59: aload 4
/*     */     //   61: invokestatic 75	net/harawata/mybatipse/Activator:log	(ILjava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   64: aload_1
/*     */     //   65: invokeinterface 81 1 0
/*     */     //   70: goto +20 -> 90
/*     */     //   73: astore 5
/*     */     //   75: aload_1
/*     */     //   76: invokeinterface 81 1 0
/*     */     //   81: aload 5
/*     */     //   83: athrow
/*     */     //   84: aload_1
/*     */     //   85: invokeinterface 81 1 0
/*     */     //   90: return
/*     */     // Line number table:
/*     */     //   Java source line #62	-> byte code offset #0
/*     */     //   Java source line #63	-> byte code offset #5
/*     */     //   Java source line #64	-> byte code offset #14
/*     */     //   Java source line #66	-> byte code offset #19
/*     */     //   Java source line #69	-> byte code offset #27
/*     */     //   Java source line #109	-> byte code offset #42
/*     */     //   Java source line #69	-> byte code offset #43
/*     */     //   Java source line #111	-> byte code offset #51
/*     */     //   Java source line #113	-> byte code offset #53
/*     */     //   Java source line #117	-> byte code offset #64
/*     */     //   Java source line #116	-> byte code offset #73
/*     */     //   Java source line #117	-> byte code offset #75
/*     */     //   Java source line #118	-> byte code offset #81
/*     */     //   Java source line #117	-> byte code offset #84
/*     */     //   Java source line #119	-> byte code offset #90
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	91	0	this	MybatipseIncrementalBuilder
/*     */     //   0	91	1	monitor	IProgressMonitor
/*     */     //   4	34	2	totalWork	int
/*     */     //   26	13	3	validator	XmlValidator
/*     */     //   51	9	4	e	CoreException
/*     */     //   73	9	5	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   27	48	51	org/eclipse/core/runtime/CoreException
/*     */     //   27	64	73	finally
/*     */   }
/*     */   
/*     */   protected void clean(IProgressMonitor monitor)
/*     */     throws CoreException
/*     */   {
/*     */     try
/*     */     {
/* 126 */       IProject project = getProject();
/* 127 */       project.accept(new IResourceProxyVisitor()
/*     */       {
/*     */         public boolean visit(IResourceProxy proxy)
/*     */           throws CoreException
/*     */         {
/* 132 */           if (proxy.isDerived()) {
/* 133 */             return false;
/*     */           }
/* 135 */           if ((proxy.getType() == 1) && (proxy.getName().endsWith(".xml")))
/*     */           {
/* 137 */             IFile file = (IFile)proxy.requestResource();
/* 138 */             IContentDescription contentDesc = file.getContentDescription();
/* 139 */             if (contentDesc != null)
/*     */             {
/* 141 */               IContentType contentType = contentDesc.getContentType();
/* 142 */               if ((contentType != null) && (
/* 143 */                 (contentType.isKindOf(MybatipseConstants.configContentType)) || (contentType.isKindOf(MybatipseConstants.springConfigContentType))))
/*     */               {
/* 145 */                 file.deleteMarkers("net.harawata.mybatipse.XmlProblem", false, 0);
/*     */               }
/*     */             }
/*     */           }
/* 149 */           return true;
/*     */         }
/* 151 */       }, 0);
/*     */       
/* 153 */       TypeAliasCache.getInstance().remove(project);
/* 154 */       BeanPropertyCache.clearBeanPropertyCache(project);
/* 155 */       MapperNamespaceCache.getInstance().remove(project);
/* 156 */       ConfigRegistry.getInstance().remove(project);
/*     */     }
/*     */     catch (CoreException e)
/*     */     {
/* 160 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   private int countResources()
/*     */   {
/*     */     try
/*     */     {
/* 168 */       CountResourceVisitor visitor = new CountResourceVisitor(null);
/* 169 */       getProject().accept(visitor, 0);
/* 170 */       return visitor.count;
/*     */     }
/*     */     catch (CoreException e)
/*     */     {
/* 174 */       Activator.log(2, e.getMessage(), e); }
/* 175 */     return -1;
/*     */   }
/*     */   
/*     */   private class CountResourceVisitor implements IResourceProxyVisitor
/*     */   {
/*     */     int count;
/*     */     
/*     */     private CountResourceVisitor() {}
/*     */     
/*     */     public boolean visit(IResourceProxy proxy) throws CoreException
/*     */     {
/* 186 */       if (proxy.isDerived())
/* 187 */         return false;
/* 188 */       this.count += 1;
/* 189 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\nature\MybatipseIncrementalBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */