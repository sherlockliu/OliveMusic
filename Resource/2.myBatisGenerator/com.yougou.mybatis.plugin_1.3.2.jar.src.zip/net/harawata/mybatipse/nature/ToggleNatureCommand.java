/*     */ package net.harawata.mybatipse.nature;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import org.eclipse.core.commands.AbstractHandler;
/*     */ import org.eclipse.core.commands.ExecutionEvent;
/*     */ import org.eclipse.core.commands.ExecutionException;
/*     */ import org.eclipse.core.commands.IHandler;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IProjectDescription;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IAdaptable;
/*     */ import org.eclipse.jface.viewers.ISelection;
/*     */ import org.eclipse.jface.viewers.IStructuredSelection;
/*     */ import org.eclipse.ui.IWorkbenchPage;
/*     */ import org.eclipse.ui.IWorkbenchWindow;
/*     */ import org.eclipse.ui.handlers.HandlerUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToggleNatureCommand
/*     */   extends AbstractHandler
/*     */   implements IHandler
/*     */ {
/*     */   private static final String TOGGLE_NATURE_PARAM = "net.harawata.mybatipse.ToggleNatureParam";
/*     */   
/*     */   public Object execute(ExecutionEvent event)
/*     */     throws ExecutionException
/*     */   {
/*  43 */     String parameter = event.getParameter("net.harawata.mybatipse.ToggleNatureParam");
/*  44 */     boolean addNature = "true".equals(parameter);
/*  45 */     IWorkbenchWindow window = HandlerUtil.getActiveWorkbenchWindow(event);
/*  46 */     IWorkbenchPage activePage = window.getActivePage();
/*  47 */     ISelection selection = activePage.getSelection();
/*  48 */     if ((selection instanceof IStructuredSelection))
/*     */     {
/*     */ 
/*  51 */       Iterator it = ((IStructuredSelection)selection).iterator();
/*  50 */       while (
/*  51 */         it.hasNext())
/*     */       {
/*  53 */         Object element = it.next();
/*  54 */         IProject project = null;
/*  55 */         if ((element instanceof IProject))
/*     */         {
/*  57 */           project = (IProject)element;
/*     */         }
/*  59 */         else if ((element instanceof IAdaptable))
/*     */         {
/*  61 */           project = (IProject)((IAdaptable)element).getAdapter(IProject.class);
/*     */         }
/*  63 */         if (project != null)
/*     */         {
/*  65 */           toggleNature(project, addNature);
/*     */         }
/*     */       }
/*     */     }
/*  69 */     return null;
/*     */   }
/*     */   
/*     */   private void toggleNature(IProject project, boolean addNature)
/*     */   {
/*     */     try
/*     */     {
/*  76 */       IProjectDescription description = project.getDescription();
/*  77 */       String[] natures = description.getNatureIds();
/*  78 */       for (int i = 0; i < natures.length; i++)
/*     */       {
/*  80 */         if ("net.harawata.mybatipse.MyBatisNature".equals(natures[i]))
/*     */         {
/*  82 */           if (!addNature)
/*     */           {
/*  84 */             String[] newNatures = new String[natures.length - 1];
/*  85 */             System.arraycopy(natures, 0, newNatures, 0, i);
/*  86 */             System.arraycopy(natures, i + 1, newNatures, i, natures.length - i - 1);
/*  87 */             description.setNatureIds(newNatures);
/*  88 */             project.setDescription(description, null);
/*     */           }
/*  90 */           return;
/*     */         }
/*     */       }
/*  93 */       if (addNature)
/*     */       {
/*  95 */         String[] newNatures = new String[natures.length + 1];
/*  96 */         System.arraycopy(natures, 0, newNatures, 0, natures.length);
/*  97 */         newNatures[natures.length] = "net.harawata.mybatipse.MyBatisNature";
/*  98 */         description.setNatureIds(newNatures);
/*  99 */         project.setDescription(description, null);
/*     */       }
/*     */     }
/*     */     catch (CoreException e)
/*     */     {
/* 104 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\nature\ToggleNatureCommand.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */