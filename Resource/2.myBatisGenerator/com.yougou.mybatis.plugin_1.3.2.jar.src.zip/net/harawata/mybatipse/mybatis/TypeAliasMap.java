/*    */ package net.harawata.mybatipse.mybatis;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeAliasMap
/*    */   extends ConcurrentHashMap<String, TypeAliasInfo>
/*    */ {
/*    */   private static final long serialVersionUID = -7286252877431348258L;
/*    */   
/*    */   public void put(String qualifiedName)
/*    */   {
/* 28 */     put(null, qualifiedName);
/*    */   }
/*    */   
/*    */   public void put(String alias, String qualifiedName)
/*    */   {
/* 33 */     if ((qualifiedName == null) || (qualifiedName.length() == 0)) {
/* 34 */       return;
/*    */     }
/* 36 */     if ((alias == null) || (alias.length() == 0))
/*    */     {
/* 38 */       int lastDot = qualifiedName.lastIndexOf('.');
/* 39 */       alias = lastDot == -1 ? qualifiedName : qualifiedName.substring(lastDot + 1);
/*    */     }
/*    */     
/* 42 */     put(alias.toLowerCase(Locale.ENGLISH), new TypeAliasInfo(alias, qualifiedName, null));
/*    */   }
/*    */   
/*    */ 
/*    */   static class TypeAliasInfo
/*    */   {
/*    */     private String aliasToInsert;
/*    */     private String qualifiedName;
/*    */     
/*    */     public String getAliasToInsert()
/*    */     {
/* 53 */       return this.aliasToInsert;
/*    */     }
/*    */     
/*    */     public void setAliasToInsert(String aliasToInsert)
/*    */     {
/* 58 */       this.aliasToInsert = aliasToInsert;
/*    */     }
/*    */     
/*    */     public String getQualifiedName()
/*    */     {
/* 63 */       return this.qualifiedName;
/*    */     }
/*    */     
/*    */     public void setQualifiedName(String qualifiedName)
/*    */     {
/* 68 */       this.qualifiedName = qualifiedName;
/*    */     }
/*    */     
/*    */ 
/*    */     private TypeAliasInfo(String aliasToInsert, String qualifiedName)
/*    */     {
/* 74 */       this.aliasToInsert = aliasToInsert;
/* 75 */       this.qualifiedName = qualifiedName;
/*    */     }
/*    */     
/*    */ 
/*    */     public String toString()
/*    */     {
/* 81 */       return "[" + this.aliasToInsert + " : " + this.qualifiedName + "]";
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\TypeAliasMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */