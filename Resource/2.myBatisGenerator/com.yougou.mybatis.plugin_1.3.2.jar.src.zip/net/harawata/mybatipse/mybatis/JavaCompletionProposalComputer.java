/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.jdt.core.IAnnotatable;
/*     */ import org.eclipse.jdt.core.IAnnotation;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IMethod;
/*     */ import org.eclipse.jdt.core.ISourceRange;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*     */ import org.eclipse.jdt.ui.text.java.ContentAssistInvocationContext;
/*     */ import org.eclipse.jdt.ui.text.java.IJavaCompletionProposalComputer;
/*     */ import org.eclipse.jdt.ui.text.java.JavaContentAssistInvocationContext;
/*     */ import org.eclipse.jface.text.contentassist.ICompletionProposal;
/*     */ import org.eclipse.jface.text.contentassist.IContextInformation;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaCompletionProposalComputer
/*     */   implements IJavaCompletionProposalComputer
/*     */ {
/*  47 */   private static final List<String> statementAnnotations = Arrays.asList(new String[] { "Select", "Update", "Insert", "Delete" });
/*     */   
/*     */ 
/*     */ 
/*     */   public void sessionStarted() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public List<ICompletionProposal> computeCompletionProposals(ContentAssistInvocationContext context, IProgressMonitor monitor)
/*     */   {
/*  57 */     if ((context instanceof JavaContentAssistInvocationContext))
/*     */     {
/*  59 */       JavaContentAssistInvocationContext javaContext = (JavaContentAssistInvocationContext)context;
/*  60 */       ICompilationUnit unit = javaContext.getCompilationUnit();
/*     */       try
/*     */       {
/*  63 */         if ((unit == null) || (!unit.isStructureKnown()))
/*  64 */           return Collections.emptyList();
/*  65 */         IType primaryType = unit.findPrimaryType();
/*  66 */         if ((primaryType == null) || (!primaryType.isInterface())) {
/*  67 */           return Collections.emptyList();
/*     */         }
/*  69 */         int offset = javaContext.getInvocationOffset();
/*  70 */         IJavaElement element = unit.getElementAt(offset);
/*  71 */         if ((element == null) || (!(element instanceof IMethod))) {
/*  72 */           return Collections.emptyList();
/*     */         }
/*  74 */         IAnnotation annotation = getAnnotationAt((IAnnotatable)element, offset);
/*  75 */         if (annotation == null) {
/*  76 */           return Collections.emptyList();
/*     */         }
/*  78 */         IMethod method = (IMethod)element;
/*  79 */         if (isStatementAnnotation(annotation))
/*     */         {
/*  81 */           return proposeStatementText(javaContext, unit, offset, annotation, method);
/*     */         }
/*  83 */         if ("ResultMap".equals(annotation.getElementName()))
/*     */         {
/*  85 */           String text = annotation.getSource();
/*     */           
/*  87 */           if (text == null)
/*  88 */             return Collections.emptyList();
/*  89 */           SimpleParser parser = new SimpleParser(text, offset - 
/*  90 */             annotation.getSourceRange().getOffset() - 1, null);
/*  91 */           IJavaProject project = javaContext.getProject();
/*  92 */           IFile mapperFile = MapperNamespaceCache.getInstance().get(project, 
/*  93 */             primaryType.getFullyQualifiedName(), null);
/*  94 */           if (mapperFile != null)
/*     */           {
/*  96 */             Document mapperDoc = MybatipseXmlUtil.getMapperDocument(mapperFile);
/*  97 */             String matchString = parser.getMatchString();
/*  98 */             return ProposalComputorHelper.proposeReference(project, mapperDoc, matchString, 
/*  99 */               offset - matchString.length(), parser.getReplacementLength(), "resultMap");
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (JavaModelException e)
/*     */       {
/* 105 */         Activator.log(4, "Something went wrong.", e);
/*     */       }
/*     */     }
/* 108 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */ 
/*     */   private List<ICompletionProposal> proposeStatementText(JavaContentAssistInvocationContext javaContext, ICompilationUnit unit, int offset, IAnnotation annotation, IMethod method)
/*     */     throws JavaModelException
/*     */   {
/* 115 */     if (method.getParameters().length == 0) {
/* 116 */       return Collections.emptyList();
/*     */     }
/* 118 */     String text = annotation.getSource();
/* 119 */     int offsetInText = offset - annotation.getSourceRange().getOffset() - 1;
/* 120 */     ExpressionProposalParser parser = new ExpressionProposalParser(text, offsetInText);
/* 121 */     if (parser.isProposable())
/*     */     {
/* 123 */       String matchString = parser.getMatchString();
/* 124 */       offset -= matchString.length();
/* 125 */       int length = parser.getReplacementLength();
/* 126 */       IJavaProject project = javaContext.getProject();
/* 127 */       String proposalTarget = parser.getProposalTarget();
/* 128 */       if ((proposalTarget == null) || (proposalTarget.length() == 0))
/* 129 */         return ProposalComputorHelper.proposeOptionName(offset, length, matchString);
/* 130 */       if ("property".equals(proposalTarget))
/*     */       {
/* 132 */         CompilationUnit astNode = JavaMapperUtil.getAstNode(unit);
/* 133 */         Map<String, String> paramMap = JavaMapperUtil.getMethodParameters(astNode, method);
/* 134 */         return ProposalComputorHelper.proposeParameters(project, offset, length, paramMap, 
/* 135 */           true, matchString);
/*     */       }
/* 137 */       if ("jdbcType".equals(proposalTarget))
/* 138 */         return ProposalComputorHelper.proposeJdbcType(offset, length, matchString);
/* 139 */       if ("javaType".equals(proposalTarget))
/* 140 */         return ProposalComputorHelper.proposeJavaType(project, offset, length, true, 
/* 141 */           matchString);
/* 142 */       if ("typeHandler".equals(proposalTarget))
/* 143 */         return ProposalComputorHelper.proposeTypeHandler(project, offset, length, matchString);
/*     */     }
/* 145 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   private boolean isStatementAnnotation(IAnnotation annotation)
/*     */   {
/* 150 */     String annotationName = annotation.getElementName();
/* 151 */     return statementAnnotations.contains(annotationName);
/*     */   }
/*     */   
/*     */   private IAnnotation getAnnotationAt(IAnnotatable annotatable, int offset)
/*     */   {
/*     */     try
/*     */     {
/* 158 */       IAnnotation[] annotations = annotatable.getAnnotations();
/* 159 */       IAnnotation[] arrayOfIAnnotation1; int j = (arrayOfIAnnotation1 = annotations).length; for (int i = 0; i < j; i++) { IAnnotation annotation = arrayOfIAnnotation1[i];
/*     */         
/* 161 */         ISourceRange sourceRange = annotation.getSourceRange();
/* 162 */         if (isInRange(sourceRange, offset))
/*     */         {
/* 164 */           return annotation;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (JavaModelException e)
/*     */     {
/* 170 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/* 172 */     return null;
/*     */   }
/*     */   
/*     */   private boolean isInRange(ISourceRange sourceRange, int offset)
/*     */   {
/* 177 */     int start = sourceRange.getOffset();
/* 178 */     int end = start + sourceRange.getLength();
/* 179 */     return (start <= offset) && (offset <= end);
/*     */   }
/*     */   
/*     */ 
/*     */   public List<IContextInformation> computeContextInformation(ContentAssistInvocationContext context, IProgressMonitor monitor)
/*     */   {
/* 185 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */   public String getErrorMessage()
/*     */   {
/* 190 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void sessionEnded() {}
/*     */   
/*     */ 
/*     */   private class SimpleParser
/*     */   {
/*     */     private String text;
/*     */     
/*     */     private int offset;
/*     */     
/*     */     private String matchString;
/*     */     
/*     */ 
/*     */     private SimpleParser(String text, int offset)
/*     */     {
/* 209 */       this.text = text;
/* 210 */       this.offset = offset;
/* 211 */       parse();
/*     */     }
/*     */     
/*     */     private void parse()
/*     */     {
/* 216 */       int start = this.text.lastIndexOf('"', this.offset);
/* 217 */       this.matchString = this.text.substring(start + 1, this.offset + 1);
/*     */     }
/*     */     
/*     */     public int getReplacementLength()
/*     */     {
/* 222 */       for (int i = this.offset + 1; 
/* 223 */           i < this.text.length(); i++)
/*     */       {
/* 225 */         char c = this.text.charAt(i);
/* 226 */         if ((c == '\n') || (c == '\r'))
/*     */         {
/* 228 */           return i - this.offset - 1 + this.matchString.length();
/*     */         }
/* 230 */         if (c == '"')
/*     */         {
/* 232 */           return i - this.offset - 1 + this.matchString.length();
/*     */         }
/*     */       }
/* 235 */       return i - this.offset - 1 + this.matchString.length();
/*     */     }
/*     */     
/*     */     public String getMatchString()
/*     */     {
/* 240 */       return this.matchString;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\JavaCompletionProposalComputer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */