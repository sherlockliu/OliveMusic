/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import net.harawata.mybatipse.hyperlink.ToJavaHyperlink;
/*     */ import net.harawata.mybatipse.hyperlink.ToXmlHyperlink;
/*     */ import net.harawata.mybatipse.util.NameUtil;
/*     */ import net.harawata.mybatipse.util.XpathUtil;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.jdt.core.IField;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IMethod;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.jface.text.ITextViewer;
/*     */ import org.eclipse.jface.text.Region;
/*     */ import org.eclipse.jface.text.hyperlink.AbstractHyperlinkDetector;
/*     */ import org.eclipse.jface.text.hyperlink.IHyperlink;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.text.IStructuredDocument;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.text.IStructuredDocumentRegion;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.text.ITextRegion;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.text.ITextRegionList;
/*     */ import org.eclipse.wst.sse.core.utils.StringUtils;
/*     */ import org.eclipse.wst.xml.core.internal.document.ElementImpl;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMDocument;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMNode;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlHyperlinkDetector
/*     */   extends AbstractHyperlinkDetector
/*     */ {
/*     */   public IHyperlink[] detectHyperlinks(ITextViewer textViewer, IRegion region, boolean canShowMultipleHyperlinks)
/*     */   {
/*  65 */     IHyperlink[] hyperlinks = (IHyperlink[])null;
/*  66 */     if ((textViewer != null) && (region != null)) {
/*  67 */       IDocument document = textViewer.getDocument();
/*     */       
/*  69 */       if (document != null) {
/*  70 */         Node currentNode = getCurrentNode(document, region.getOffset());
/*  71 */         if ((currentNode != null) && 
/*  72 */           (currentNode.getNodeType() == 1)) {
/*  73 */           Element element = (Element)currentNode;
/*  74 */           IStructuredDocumentRegion documentRegion = ((IStructuredDocument)document)
/*  75 */             .getRegionAtCharacterOffset(region.getOffset());
/*  76 */           ITextRegion textRegion = documentRegion
/*  77 */             .getRegionAtCharacterOffset(region.getOffset());
/*  78 */           ITextRegion nameRegion = null;
/*  79 */           ITextRegion valueRegion = null;
/*  80 */           String tagName = element.getTagName();
/*  81 */           String attrName = null;
/*  82 */           String attrValue = null;
/*     */           
/*  84 */           if ("XML_TAG_ATTRIBUTE_VALUE".equals(textRegion.getType())) {
/*  85 */             ITextRegionList regions = documentRegion.getRegions();
/*  86 */             int index = regions.indexOf(textRegion);
/*  87 */             if (index >= 4) {
/*  88 */               nameRegion = regions.get(index - 2);
/*  89 */               valueRegion = textRegion;
/*  90 */               attrName = documentRegion.getText(nameRegion);
/*  91 */               attrValue = StringUtils.strip(documentRegion
/*  92 */                 .getText(valueRegion));
/*     */             }
/*     */           }
/*  95 */           if ((attrName != null) && (attrValue != null)) {
/*     */             try {
/*  97 */               if ("namespace".equals(attrName)) {
/*  98 */                 hyperlinks = linkToJavaMapperType(
/*  99 */                   document, 
/* 100 */                   getLinkRegion(documentRegion, 
/* 101 */                   valueRegion), currentNode);
/* 102 */               } else if (("id".equals(attrName)) && (
/* 103 */                 ("select".equals(tagName)) || 
/* 104 */                 ("update".equals(tagName)) || 
/* 105 */                 ("insert".equals(tagName)) || 
/* 106 */                 ("delete".equals(tagName)))) {
/* 107 */                 hyperlinks = linkToJavaMapperMethod(
/* 108 */                   document, 
/* 109 */                   attrValue, 
/* 110 */                   getLinkRegion(documentRegion, 
/* 111 */                   valueRegion), currentNode);
/* 112 */               } else if ("property".equals(attrName)) {
/* 113 */                 hyperlinks = linkToJavaProperty(
/* 114 */                   document, 
/* 115 */                   currentNode, 
/* 116 */                   attrValue, 
/* 117 */                   getLinkRegion(documentRegion, 
/* 118 */                   valueRegion));
/* 119 */               } else if (("type".equals(attrName)) || 
/* 120 */                 ("resultType".equals(attrName)) || 
/* 121 */                 ("parameterType".equals(attrName)) || 
/* 122 */                 ("ofType".equals(attrName))) {
/* 123 */                 hyperlinks = linkToJavaType(
/* 124 */                   document, 
/* 125 */                   attrValue, 
/* 126 */                   getLinkRegion(documentRegion, 
/* 127 */                   valueRegion));
/* 128 */               } else if ("refid".equals(attrName)) {
/* 129 */                 hyperlinks = linkToReference(
/* 130 */                   textViewer, 
/* 131 */                   document, 
/* 132 */                   element.getOwnerDocument(), 
/* 133 */                   attrName, 
/* 134 */                   attrValue, 
/* 135 */                   getLinkRegion(documentRegion, 
/* 136 */                   valueRegion), "sql");
/* 137 */               } else if ("select".equals(attrName)) {
/* 138 */                 hyperlinks = linkToReference(
/* 139 */                   textViewer, 
/* 140 */                   document, 
/* 141 */                   element.getOwnerDocument(), 
/* 142 */                   attrName, 
/* 143 */                   attrValue, 
/* 144 */                   getLinkRegion(documentRegion, 
/* 145 */                   valueRegion), "select");
/* 146 */               } else if (("extends".equals(attrName)) || 
/* 147 */                 ("resultMap".equals(attrName)))
/*     */               {
/* 149 */                 hyperlinks = linkToReference(
/* 150 */                   textViewer, 
/* 151 */                   document, 
/* 152 */                   element.getOwnerDocument(), 
/* 153 */                   attrName, 
/* 154 */                   attrValue, 
/* 155 */                   getLinkRegion(documentRegion, 
/* 156 */                   valueRegion), "resultMap");
/*     */               }
/*     */             } catch (Exception e) {
/* 159 */               Activator.log(4, 
/* 160 */                 "Failed to create hyperlinks.", e);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 166 */     return hyperlinks;
/*     */   }
/*     */   
/*     */ 
/*     */   private IHyperlink[] linkToReference(ITextViewer textViewer, IDocument document, Document domDoc, String attrName, String attrValue, Region linkRegion, String targetElement)
/*     */     throws XPathExpressionException, CoreException, IOException
/*     */   {
/* 173 */     int lastDot = attrValue.lastIndexOf('.');
/* 174 */     if (lastDot == -1)
/*     */     {
/* 176 */       Node node = XpathUtil.xpathNode(domDoc, "//" + targetElement + 
/* 177 */         "[@id='" + attrValue + "']");
/* 178 */       ElementImpl elem = (ElementImpl)node;
/* 179 */       if (elem != null) {
/* 180 */         IRegion destRegion = new Region(elem.getStartOffset(), 
/* 181 */           elem.getEndOffset() - elem.getStartOffset());
/* 182 */         return new IHyperlink[] { new ToXmlHyperlink(textViewer, 
/* 183 */           linkRegion, attrValue, destRegion) };
/*     */       }
/* 185 */     } else if (lastDot + 1 < attrValue.length())
/*     */     {
/* 187 */       IJavaProject project = MybatipseXmlUtil.getJavaProject(document);
/* 188 */       String namespace = attrValue.substring(0, lastDot);
/* 189 */       String elementId = attrValue.substring(lastDot + 1);
/* 190 */       IFile mapperFile = MapperNamespaceCache.getInstance().get(project, 
/* 191 */         namespace, null);
/*     */       
/* 193 */       IDOMDocument mapperDocument = 
/* 194 */         MybatipseXmlUtil.getMapperDocument(mapperFile);
/* 195 */       IDOMNode domNode = (IDOMNode)XpathUtil.xpathNode(mapperDocument, 
/* 196 */         "//" + targetElement + "[@id='" + elementId + "']");
/* 197 */       if (domNode != null) {
/* 198 */         IRegion destRegion = new Region(domNode.getStartOffset(), 
/* 199 */           domNode.getEndOffset() - domNode.getStartOffset());
/* 200 */         return new IHyperlink[] { new ToXmlHyperlink(mapperFile, 
/* 201 */           linkRegion, attrValue, destRegion) };
/*     */       }
/*     */     }
/* 204 */     return null;
/*     */   }
/*     */   
/*     */   private IHyperlink[] linkToJavaMapperType(IDocument document, Region linkRegion, Node node)
/*     */     throws JavaModelException, XPathExpressionException
/*     */   {
/* 210 */     String qualifiedName = MybatipseXmlUtil.getNamespace(node
/* 211 */       .getOwnerDocument());
/* 212 */     IJavaProject project = MybatipseXmlUtil.getJavaProject(document);
/* 213 */     IType javaType = project.findType(qualifiedName);
/* 214 */     if (javaType != null) {
/* 215 */       return new IHyperlink[] { new ToJavaHyperlink(javaType, linkRegion, 
/* 216 */         javaLinkLabel("Mapper interface")) };
/*     */     }
/* 218 */     return null;
/*     */   }
/*     */   
/*     */   private IHyperlink[] linkToJavaType(IDocument document, String typeName, Region linkRegion) throws JavaModelException
/*     */   {
/* 223 */     IJavaProject project = MybatipseXmlUtil.getJavaProject(document);
/* 224 */     IType javaType = project.findType(typeName);
/* 225 */     if (javaType == null) {
/* 226 */       String found = TypeAliasCache.getInstance().resolveAlias(project, 
/* 227 */         typeName, null);
/* 228 */       if (found != null) {
/* 229 */         javaType = project.findType(found);
/*     */       }
/*     */     }
/* 232 */     if (javaType != null) {
/* 233 */       return new IHyperlink[] { new ToJavaHyperlink(javaType, linkRegion, 
/* 234 */         javaLinkLabel("class")) };
/*     */     }
/* 236 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private IHyperlink[] linkToJavaMapperMethod(IDocument document, String methodName, Region linkRegion, Node node)
/*     */     throws JavaModelException, XPathExpressionException, ClassNotFoundException
/*     */   {
/* 243 */     String qualifiedName = MybatipseXmlUtil.getNamespace(node
/* 244 */       .getOwnerDocument());
/* 245 */     IJavaProject project = MybatipseXmlUtil.getJavaProject(document);
/* 246 */     IType javaType = project.findType(qualifiedName);
/* 247 */     if (javaType != null) { IMethod[] arrayOfIMethod;
/* 248 */       int j = (arrayOfIMethod = javaType.getMethods()).length; for (int i = 0; i < j; i++) { IMethod method = arrayOfIMethod[i];
/* 249 */         if (methodName.equals(method.getElementName())) {
/* 250 */           return new IHyperlink[] { new ToJavaHyperlink(method, 
/* 251 */             linkRegion, javaLinkLabel("Mapper method")) };
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 256 */     if (javaType != null) {
/* 257 */       for (IMethod method : NameUtil.getAllSuperMethods(null, project, javaType)) {
/* 258 */         if (methodName.equals(method.getElementName())) {
/* 259 */           return new IHyperlink[] { new ToJavaHyperlink(method, 
/* 260 */             linkRegion, javaLinkLabel("Mapper method")) };
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 265 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private IHyperlink[] linkToJavaProperty(IDocument document, Node currentNode, String propertyName, Region linkRegion)
/*     */     throws JavaModelException
/*     */   {
/* 296 */     String qualifiedName = MybatipseXmlUtil.findEnclosingType(currentNode);
/* 297 */     IJavaProject project = MybatipseXmlUtil.getJavaProject(document);
/* 298 */     IType javaMapperType = project.findType(qualifiedName);
/* 299 */     if (MybatipseXmlUtil.isDefaultTypeAlias(qualifiedName))
/* 300 */       return null;
/* 301 */     if (javaMapperType == null) {
/* 302 */       String resolvedAlias = TypeAliasCache.getInstance().resolveAlias(
/* 303 */         project, qualifiedName, null);
/* 304 */       if (resolvedAlias != null) {
/* 305 */         javaMapperType = project.findType(resolvedAlias);
/*     */       }
/*     */     }
/* 308 */     Map<String, IField> map = new HashMap();
/* 309 */     IField[] arrayOfIField; int j = (arrayOfIField = javaMapperType.getFields()).length; for (int i = 0; i < j; i++) { IField field = arrayOfIField[i];
/* 310 */       map.put(field.getElementName(), field);
/*     */     }
/* 312 */     if (map.get(propertyName) != null) {
/* 313 */       return new IHyperlink[] { new ToJavaHyperlink((IJavaElement)map.get(propertyName), 
/* 314 */         linkRegion, javaLinkLabel("property")) };
/*     */     }
/*     */     
/* 317 */     List<IField> fields = NameUtil.getAllSuperFields(null, project, javaMapperType);
/* 318 */     if ((fields == null) || (fields.size() == 0)) {
/* 319 */       return null;
/*     */     }
/* 321 */     map = new HashMap();
/* 322 */     for (IField field : fields) {
/* 323 */       map.put(field.getElementName(), field);
/*     */     }
/* 325 */     if (map.get(propertyName) != null) {
/* 326 */       return new IHyperlink[] { new ToJavaHyperlink((IJavaElement)map.get(propertyName), 
/* 327 */         linkRegion, javaLinkLabel("property")) };
/*     */     }
/* 329 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String javaLinkLabel(String target)
/*     */   {
/* 336 */     return MessageFormat.format("Open {0} in Java Editor", new Object[] { target });
/*     */   }
/*     */   
/*     */   private Region getLinkRegion(IStructuredDocumentRegion documentRegion, ITextRegion valueRegion)
/*     */   {
/* 341 */     int offset = documentRegion.getStartOffset() + valueRegion.getStart();
/* 342 */     int length = valueRegion.getTextLength();
/* 343 */     return new Region(offset, length);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private Node getCurrentNode(IDocument document, int offset)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_3
/*     */     //   2: aconst_null
/*     */     //   3: astore 4
/*     */     //   5: invokestatic 452	org/eclipse/wst/sse/core/StructuredModelManager:getModelManager	()Lorg/eclipse/wst/sse/core/internal/provisional/IModelManager;
/*     */     //   8: aload_1
/*     */     //   9: invokeinterface 458 2 0
/*     */     //   14: astore 4
/*     */     //   16: aload 4
/*     */     //   18: ifnull +47 -> 65
/*     */     //   21: aload 4
/*     */     //   23: iload_2
/*     */     //   24: invokeinterface 464 2 0
/*     */     //   29: astore_3
/*     */     //   30: aload_3
/*     */     //   31: ifnonnull +34 -> 65
/*     */     //   34: aload 4
/*     */     //   36: iload_2
/*     */     //   37: iconst_1
/*     */     //   38: isub
/*     */     //   39: invokeinterface 464 2 0
/*     */     //   44: astore_3
/*     */     //   45: goto +20 -> 65
/*     */     //   48: astore 5
/*     */     //   50: aload 4
/*     */     //   52: ifnull +10 -> 62
/*     */     //   55: aload 4
/*     */     //   57: invokeinterface 470 1 0
/*     */     //   62: aload 5
/*     */     //   64: athrow
/*     */     //   65: aload 4
/*     */     //   67: ifnull +10 -> 77
/*     */     //   70: aload 4
/*     */     //   72: invokeinterface 470 1 0
/*     */     //   77: aload_3
/*     */     //   78: instanceof 35
/*     */     //   81: ifeq +8 -> 89
/*     */     //   84: aload_3
/*     */     //   85: checkcast 35	org/w3c/dom/Node
/*     */     //   88: areturn
/*     */     //   89: aconst_null
/*     */     //   90: areturn
/*     */     // Line number table:
/*     */     //   Java source line #356	-> byte code offset #0
/*     */     //   Java source line #357	-> byte code offset #2
/*     */     //   Java source line #359	-> byte code offset #5
/*     */     //   Java source line #360	-> byte code offset #8
/*     */     //   Java source line #359	-> byte code offset #14
/*     */     //   Java source line #361	-> byte code offset #16
/*     */     //   Java source line #362	-> byte code offset #21
/*     */     //   Java source line #363	-> byte code offset #30
/*     */     //   Java source line #364	-> byte code offset #34
/*     */     //   Java source line #367	-> byte code offset #48
/*     */     //   Java source line #368	-> byte code offset #50
/*     */     //   Java source line #369	-> byte code offset #55
/*     */     //   Java source line #370	-> byte code offset #62
/*     */     //   Java source line #368	-> byte code offset #65
/*     */     //   Java source line #369	-> byte code offset #70
/*     */     //   Java source line #372	-> byte code offset #77
/*     */     //   Java source line #373	-> byte code offset #84
/*     */     //   Java source line #375	-> byte code offset #89
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	91	0	this	XmlHyperlinkDetector
/*     */     //   0	91	1	document	IDocument
/*     */     //   0	91	2	offset	int
/*     */     //   1	84	3	inode	org.eclipse.wst.sse.core.internal.provisional.IndexedRegion
/*     */     //   3	68	4	sModel	org.eclipse.wst.sse.core.internal.provisional.IStructuredModel
/*     */     //   48	15	5	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   5	48	48	finally
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\XmlHyperlinkDetector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */