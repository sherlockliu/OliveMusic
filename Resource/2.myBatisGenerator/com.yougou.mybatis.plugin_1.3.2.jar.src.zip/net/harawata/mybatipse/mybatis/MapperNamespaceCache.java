/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import net.harawata.mybatipse.util.XpathUtil;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceProxy;
/*     */ import org.eclipse.core.resources.IResourceProxyVisitor;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.Platform;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.wst.sse.core.StructuredModelManager;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.IModelManager;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.IStructuredModel;
/*     */ import org.eclipse.wst.validation.internal.provisional.core.IReporter;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMDocument;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMModel;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapperNamespaceCache
/*     */ {
/*  50 */   private static final MapperNamespaceCache INSTANCE = new MapperNamespaceCache();
/*     */   
/*  52 */   private IContentType mapperContentType = Platform.getContentTypeManager()
/*  53 */     .getContentType("net.harawata.mybatipse.Mapper");
/*     */   
/*  55 */   private final Map<String, Map<String, IFile>> cache = new ConcurrentHashMap();
/*     */   
/*     */   public IFile get(IJavaProject javaProject, String namespace, IReporter reporter)
/*     */   {
/*  59 */     Map<String, IFile> map = getCacheMap(javaProject, reporter);
/*  60 */     return (IFile)map.get(namespace);
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/*  65 */     this.cache.clear();
/*     */   }
/*     */   
/*     */   public void remove(IProject project)
/*     */   {
/*  70 */     this.cache.remove(project.getName());
/*     */   }
/*     */   
/*     */   public void remove(String projectName, IFile file)
/*     */   {
/*  75 */     Map<String, IFile> map = (Map)this.cache.get(projectName);
/*  76 */     if (map == null)
/*  77 */       return;
/*  78 */     Iterator<Map.Entry<String, IFile>> iterator = map.entrySet().iterator();
/*  79 */     while (iterator.hasNext())
/*     */     {
/*  81 */       Map.Entry<String, IFile> entry = (Map.Entry)iterator.next();
/*  82 */       if (file.equals(entry.getValue()))
/*     */       {
/*  84 */         iterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void put(String projectName, IFile file)
/*     */   {
/*  91 */     remove(projectName, file);
/*     */     
/*  93 */     Map<String, IFile> map = (Map)this.cache.get(projectName);
/*  94 */     if (map == null) {
/*  95 */       return;
/*     */     }
/*  97 */     String namespace = extractNamespace(file);
/*  98 */     if (namespace != null)
/*     */     {
/* 100 */       map.put(namespace, file);
/*     */     }
/*     */   }
/*     */   
/*     */   public Map<String, IFile> getCacheMap(IJavaProject javaProject, IReporter reporter)
/*     */   {
/* 106 */     String projectName = javaProject.getElementName();
/* 107 */     Map<String, IFile> map = (Map)this.cache.get(projectName);
/* 108 */     if (map == null)
/*     */     {
/* 110 */       map = new ConcurrentHashMap();
/* 111 */       this.cache.put(projectName, map);
/* 112 */       collectMappers(javaProject, map, reporter);
/*     */     }
/* 114 */     return map;
/*     */   }
/*     */   
/*     */   private void collectMappers(IJavaProject project, final Map<String, IFile> map, IReporter reporter)
/*     */   {
/*     */     try
/*     */     {
/*     */       IPackageFragmentRoot[] arrayOfIPackageFragmentRoot;
/* 122 */       int j = (arrayOfIPackageFragmentRoot = project.getAllPackageFragmentRoots()).length; for (int i = 0; i < j; i++) { IPackageFragmentRoot root = arrayOfIPackageFragmentRoot[i];
/*     */         
/* 124 */         if (root.getKind() == 1)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 129 */           root.getResource().accept(new IResourceProxyVisitor()
/*     */           {
/*     */             public boolean visit(IResourceProxy proxy)
/*     */               throws CoreException
/*     */             {
/* 134 */               if ((!proxy.isDerived()) && (proxy.getType() == 1) && 
/* 135 */                 (proxy.getName().endsWith(".xml")))
/*     */               {
/* 137 */                 IFile file = (IFile)proxy.requestResource();
/* 138 */                 IContentDescription contentDesc = file.getContentDescription();
/* 139 */                 if (contentDesc != null)
/*     */                 {
/* 141 */                   IContentType contentType = contentDesc.getContentType();
/* 142 */                   if ((contentType != null) && (contentType.isKindOf(MapperNamespaceCache.this.mapperContentType)))
/*     */                   {
/* 144 */                     String namespace = MapperNamespaceCache.this.extractNamespace(file);
/* 145 */                     if (namespace != null)
/*     */                     {
/* 147 */                       map.put(namespace, file);
/*     */                     }
/* 149 */                     return false;
/*     */                   }
/*     */                 }
/*     */               }
/* 153 */               return true;
/*     */             }
/* 155 */           }, 0);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (CoreException e) {
/* 160 */       Activator.log(4, "Searching MyBatis Mapper xml failed.", e);
/*     */     }
/*     */   }
/*     */   
/*     */   private String extractNamespace(IFile file)
/*     */   {
/* 166 */     IStructuredModel model = null;
/*     */     try
/*     */     {
/* 169 */       model = StructuredModelManager.getModelManager().getModelForRead(file);
/* 170 */       IDOMModel domModel = (IDOMModel)model;
/* 171 */       IDOMDocument domDoc = domModel.getDocument();
/*     */       
/* 173 */       Node node = XpathUtil.xpathNode(domDoc, "//mapper/@namespace");
/* 174 */       return node == null ? null : node.getNodeValue();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 178 */       Activator.log(4, "Error occurred during parsing mapper:" + file.getFullPath(), 
/* 179 */         e);
/*     */     }
/*     */     finally
/*     */     {
/* 183 */       if (model != null)
/*     */       {
/* 185 */         model.releaseFromRead();
/*     */       }
/*     */     }
/* 188 */     return null;
/*     */   }
/*     */   
/*     */   public static MapperNamespaceCache getInstance()
/*     */   {
/* 193 */     return INSTANCE;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\MapperNamespaceCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */