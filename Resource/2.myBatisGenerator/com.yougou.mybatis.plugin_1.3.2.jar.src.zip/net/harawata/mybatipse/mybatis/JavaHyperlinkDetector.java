/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import net.harawata.mybatipse.hyperlink.ToXmlHyperlink;
/*     */ import net.harawata.mybatipse.util.XpathUtil;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.ITypeRoot;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jface.preference.IPreferenceStore;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.jface.text.ITextViewer;
/*     */ import org.eclipse.jface.text.Region;
/*     */ import org.eclipse.jface.text.hyperlink.AbstractHyperlinkDetector;
/*     */ import org.eclipse.jface.text.hyperlink.IHyperlink;
/*     */ import org.eclipse.ui.IEditorInput;
/*     */ import org.eclipse.ui.texteditor.ITextEditor;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMDocument;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaHyperlinkDetector
/*     */   extends AbstractHyperlinkDetector
/*     */ {
/*     */   public IHyperlink[] detectHyperlinks(ITextViewer textViewer, IRegion region, boolean canShowMultipleHyperlinks)
/*     */   {
/*  52 */     IHyperlink[] links = (IHyperlink[])null;
/*  53 */     ITextEditor editor = (ITextEditor)getAdapter(ITextEditor.class);
/*  54 */     IEditorInput input = editor.getEditorInput();
/*  55 */     IJavaElement element = (IJavaElement)input
/*  56 */       .getAdapter(IJavaElement.class);
/*  57 */     if (element == null)
/*  58 */       return links;
/*  59 */     ITypeRoot typeRoot = (ITypeRoot)element.getAdapter(ITypeRoot.class);
/*     */     try {
/*  61 */       IJavaElement[] srcElements = typeRoot.codeSelect(
/*  62 */         region.getOffset(), region.getLength());
/*  63 */       if (srcElements.length == 1) {
/*  64 */         IJavaElement srcElement = srcElements[0];
/*  65 */         switch (srcElement.getElementType()) {
/*     */         case 9: 
/*  67 */           links = getLinks(typeRoot, null, 
/*  68 */             "//*[@id='" + srcElement.getElementName() + "']", 
/*  69 */             region);
/*  70 */           break;
/*     */         case 7: 
/*  72 */           links = getLinks(typeRoot, null, "//mapper", region);
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     catch (JavaModelException e)
/*     */     {
/*  79 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*  81 */     return links;
/*     */   }
/*     */   
/*     */   private IHyperlink[] getLinks(ITypeRoot typeRoot, IType triggerType, String expression, IRegion srcRegion) throws JavaModelException
/*     */   {
/*  86 */     IType primaryType = typeRoot.findPrimaryType();
/*  87 */     if ((primaryType.isInterface()) && (
/*  88 */       (triggerType == null) || (primaryType.equals(triggerType)))) {
/*  89 */       IJavaProject project = primaryType.getJavaProject();
/*  90 */       if (project != null) {
/*  91 */         IFile mapperFile = MapperNamespaceCache.getInstance().get(
/*  92 */           project, primaryType.getFullyQualifiedName(), null);
/*  93 */         if (mapperFile != null) {
/*  94 */           IDOMDocument mapperDocument = 
/*  95 */             MybatipseXmlUtil.getMapperDocument(mapperFile);
/*  96 */           if (mapperDocument != null) {
/*     */             try {
/*  98 */               IDOMNode domNode = (IDOMNode)XpathUtil.xpathNode(
/*  99 */                 mapperDocument, expression);
/* 100 */               if (domNode == null) break label299;
/* 101 */               Region destRegion = new Region(
/* 102 */                 domNode.getStartOffset(), 
/* 103 */                 domNode.getEndOffset() - 
/* 104 */                 domNode.getStartOffset());
/* 105 */               String label = "Open <" + domNode.getNodeName() + 
/* 106 */                 "/> in XML mapper.";
/* 107 */               return new IHyperlink[] { new ToXmlHyperlink(
/* 108 */                 mapperFile, srcRegion, label, 
/* 109 */                 destRegion) };
/*     */             }
/*     */             catch (XPathExpressionException e) {
/* 112 */               Activator.log(4, e.getMessage(), e);
/*     */             }
/*     */           }
/*     */         } else {
/* 116 */           IPreferenceStore store = 
/* 117 */             Activator.getPreferenceStore(project.getProject());
/* 118 */           String mapperNames = store.getString("prefCustomMapperNames");
/* 119 */           if ((primaryType.isInterface()) && (mapperNames.length() > 0) && (exitsSuffix(primaryType.getElementName(), Arrays.asList(mapperNames.split("\t")))))
/*     */           {
/*     */ 
/*     */ 
/* 123 */             ToXmlHyperlink link = new ToXmlHyperlink(mapperFile, 
/* 124 */               srcRegion, 
/* 125 */               "Not found XML mappers,Select subClasses", null);
/* 126 */             link.setType(primaryType);
/* 127 */             link.setExpression(expression);
/* 128 */             return new IHyperlink[] { link };
/*     */           }
/*     */         }
/*     */       } }
/*     */     label299:
/* 133 */     return null;
/*     */   }
/*     */   
/*     */   private boolean exitsSuffix(String interfaceName, List<String> mapperNames) {
/* 137 */     for (String s : mapperNames) {
/* 138 */       if (interfaceName.indexOf(s, interfaceName.length() - s.length()) != -1)
/* 139 */         return true;
/*     */     }
/* 141 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\JavaHyperlinkDetector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */