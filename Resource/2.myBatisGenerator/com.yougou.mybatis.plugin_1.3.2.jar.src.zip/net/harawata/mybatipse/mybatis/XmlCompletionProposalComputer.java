/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import net.harawata.mybatipse.bean.BeanPropertyCache;
/*     */ import net.harawata.mybatipse.bean.BeanPropertyInfo;
/*     */ import net.harawata.mybatipse.util.NameUtil;
/*     */ import net.harawata.mybatipse.util.XpathUtil;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.jdt.core.IAnnotation;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IMethod;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.core.dom.ASTParser;
/*     */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*     */ import org.eclipse.jdt.core.search.IJavaSearchScope;
/*     */ import org.eclipse.jdt.core.search.SearchEngine;
/*     */ import org.eclipse.jdt.core.search.SearchMatch;
/*     */ import org.eclipse.jdt.core.search.SearchParticipant;
/*     */ import org.eclipse.jdt.core.search.SearchPattern;
/*     */ import org.eclipse.jdt.core.search.SearchRequestor;
/*     */ import org.eclipse.jdt.internal.core.PackageFragment;
/*     */ import org.eclipse.jdt.ui.text.java.IJavaCompletionProposal;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.jface.text.ITextViewer;
/*     */ import org.eclipse.jface.text.contentassist.CompletionProposal;
/*     */ import org.eclipse.jface.text.contentassist.ICompletionProposal;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.text.IStructuredDocumentRegion;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.text.ITextRegion;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.text.ITextRegionList;
/*     */ import org.eclipse.wst.sse.core.utils.StringUtils;
/*     */ import org.eclipse.wst.sse.ui.contentassist.CompletionProposalInvocationContext;
/*     */ import org.eclipse.wst.sse.ui.internal.contentassist.ContentAssistUtils;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMNode;
/*     */ import org.eclipse.wst.xml.ui.internal.contentassist.ContentAssistRequest;
/*     */ import org.eclipse.wst.xml.ui.internal.contentassist.DefaultXMLCompletionProposalComputer;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlCompletionProposalComputer
/*     */   extends DefaultXMLCompletionProposalComputer
/*     */ {
/*     */   static enum ProposalType
/*     */   {
/*  81 */     None, 
/*  82 */     MapperNamespace, 
/*  83 */     ResultType, 
/*  84 */     ResultProperty, 
/*  85 */     StatementId, 
/*  86 */     TypeHandlerType, 
/*  87 */     CacheType, 
/*  88 */     ResultMap, 
/*  89 */     Include, 
/*  90 */     Package, 
/*  91 */     TypeAlias, 
/*  92 */     SelectId, 
/*  93 */     KeyProperty, 
/*  94 */     ParamProperty, 
/*  95 */     ParamPropertyPartial;
/*     */   }
/*     */   
/*     */ 
/*  99 */   private static final List<String> statementAnnotations = Arrays.asList(new String[] { "Select", "Insert", "Update", "Delete", "SelectProvider", "InsertProvider", "UpdateProvider", "DeleteProvider" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected ContentAssistRequest computeCompletionProposals(String matchString, ITextRegion completionRegion, IDOMNode treeNode, IDOMNode xmlnode, CompletionProposalInvocationContext context)
/*     */   {
/* 106 */     ContentAssistRequest contentAssistRequest = super.computeCompletionProposals(matchString, 
/* 107 */       completionRegion, treeNode, xmlnode, context);
/* 108 */     if (contentAssistRequest != null) {
/* 109 */       return contentAssistRequest;
/*     */     }
/* 111 */     String regionType = completionRegion.getType();
/* 112 */     if ("XML_CDATA_TEXT".equals(regionType))
/*     */     {
/* 114 */       Node parentNode = xmlnode.getParentNode();
/* 115 */       Node statementNode = findEnclosingStatementNode(parentNode);
/* 116 */       if (statementNode == null) {
/* 117 */         return null;
/*     */       }
/* 119 */       int offset = context.getInvocationOffset();
/* 120 */       ITextViewer viewer = context.getViewer();
/* 121 */       contentAssistRequest = new ContentAssistRequest(xmlnode, parentNode, 
/* 122 */         ContentAssistUtils.getStructuredDocumentRegion(viewer, offset), completionRegion, 
/* 123 */         offset, 0, matchString);
/* 124 */       proposeStatementText(contentAssistRequest, statementNode);
/*     */     }
/* 126 */     return contentAssistRequest;
/*     */   }
/*     */   
/*     */   private Node findEnclosingStatementNode(Node parentNode)
/*     */   {
/*     */     try
/*     */     {
/* 133 */       return XpathUtil.xpathNode(parentNode, 
/* 134 */         "ancestor-or-self::select|ancestor-or-self::update|ancestor-or-self::insert|ancestor-or-self::delete");
/*     */ 
/*     */     }
/*     */     catch (XPathExpressionException e)
/*     */     {
/* 139 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/* 141 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addTagInsertionProposals(ContentAssistRequest contentAssistRequest, int childPosition, CompletionProposalInvocationContext context)
/*     */   {
/* 148 */     int offset = contentAssistRequest.getReplacementBeginPosition();
/* 149 */     int length = contentAssistRequest.getReplacementLength();
/* 150 */     Node node = contentAssistRequest.getNode();
/*     */     
/* 152 */     Node parentNode = node.getNodeType() == 1 ? node : node.getParentNode();
/* 153 */     if (parentNode.getNodeType() != 1) {
/* 154 */       return;
/*     */     }
/* 156 */     String tagName = parentNode.getNodeName();
/* 157 */     NamedNodeMap tagAttrs = parentNode.getAttributes();
/*     */     
/* 159 */     if ("resultMap".equals(tagName)) {
/* 160 */       generateResults(contentAssistRequest, offset, length, parentNode, 
/* 161 */         tagAttrs.getNamedItem("type"));
/* 162 */     } else if ("collection".equals(tagName)) {
/* 163 */       generateResults(contentAssistRequest, offset, length, parentNode, 
/* 164 */         tagAttrs.getNamedItem("ofType"));
/* 165 */     } else if ("association".equals(tagName)) {
/* 166 */       generateResults(contentAssistRequest, offset, length, parentNode, 
/* 167 */         tagAttrs.getNamedItem("javaType"));
/*     */     }
/* 169 */     Node statementNode = findEnclosingStatementNode(parentNode);
/* 170 */     if (statementNode == null)
/* 171 */       return;
/* 172 */     proposeStatementText(contentAssistRequest, statementNode);
/*     */   }
/*     */   
/*     */ 
/*     */   private void proposeStatementText(ContentAssistRequest contentAssistRequest, Node statementNode)
/*     */   {
/* 178 */     int offset = contentAssistRequest.getReplacementBeginPosition();
/* 179 */     String text = contentAssistRequest.getText();
/* 180 */     int offsetInText = offset - contentAssistRequest.getStartOffset() - 1;
/* 181 */     ExpressionProposalParser parser = new ExpressionProposalParser(text, offsetInText);
/* 182 */     if (parser.isProposable())
/*     */     {
/* 184 */       String matchString = parser.getMatchString();
/* 185 */       offset -= matchString.length();
/* 186 */       int length = parser.getReplacementLength();
/* 187 */       IJavaProject project = getJavaProject(contentAssistRequest);
/* 188 */       String proposalTarget = parser.getProposalTarget();
/*     */       
/* 190 */       if ((proposalTarget == null) || (proposalTarget.length() == 0)) {
/* 191 */         addProposals(contentAssistRequest, 
/* 192 */           ProposalComputorHelper.proposeOptionName(offset, length, matchString));
/* 193 */       } else if ("property".equals(proposalTarget)) {
/* 194 */         addProposals(contentAssistRequest, 
/* 195 */           proposeParameter(project, offset, length, statementNode, true, matchString));
/* 196 */       } else if ("jdbcType".equals(proposalTarget)) {
/* 197 */         addProposals(contentAssistRequest, 
/* 198 */           ProposalComputorHelper.proposeJdbcType(offset, length, matchString));
/* 199 */       } else if ("javaType".equals(proposalTarget)) {
/* 200 */         addProposals(contentAssistRequest, 
/* 201 */           ProposalComputorHelper.proposeJavaType(project, offset, length, true, matchString));
/* 202 */       } else if ("typeHandler".equals(proposalTarget)) {
/* 203 */         addProposals(contentAssistRequest, 
/* 204 */           ProposalComputorHelper.proposeTypeHandler(project, offset, length, matchString));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private List<ICompletionProposal> proposeParameter(IJavaProject project, int offset, int length, Node statementNode, boolean searchReadable, String matchString)
/*     */   {
/* 211 */     List<ICompletionProposal> proposals = new ArrayList();
/* 212 */     if (statementNode == null)
/* 213 */       return proposals;
/* 214 */     String statementId = null;
/* 215 */     String paramType = null;
/* 216 */     NamedNodeMap statementAttrs = statementNode.getAttributes();
/* 217 */     for (int i = 0; i < statementAttrs.getLength(); i++)
/*     */     {
/* 219 */       Node attr = statementAttrs.item(i);
/* 220 */       String attrName = attr.getNodeName();
/* 221 */       if ("id".equals(attrName)) {
/* 222 */         statementId = attr.getNodeValue();
/* 223 */       } else if ("parameterType".equals(attrName))
/* 224 */         paramType = attr.getNodeValue();
/*     */     }
/* 226 */     if ((statementId == null) || (statementId.length() == 0)) {
/* 227 */       return proposals;
/*     */     }
/* 229 */     if (paramType != null)
/*     */     {
/* 231 */       String resolved = TypeAliasCache.getInstance().resolveAlias(project, paramType, null);
/* 232 */       proposals = ProposalComputorHelper.proposePropertyFor(project, offset, length, 
/* 233 */         resolved != null ? resolved : paramType, searchReadable, -1, matchString);
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 239 */         String mapperFqn = MybatipseXmlUtil.getNamespace(statementNode.getOwnerDocument());
/* 240 */         Map<String, String> paramMap = getParamsFromMapperMethod(project, mapperFqn, 
/* 241 */           statementId);
/* 242 */         proposals = ProposalComputorHelper.proposeParameters(project, offset, length, paramMap, 
/* 243 */           searchReadable, matchString);
/*     */       }
/*     */       catch (XPathExpressionException e)
/*     */       {
/* 247 */         Activator.log(4, e.getMessage(), e);
/*     */       }
/*     */     }
/* 250 */     return proposals;
/*     */   }
/*     */   
/*     */ 
/*     */   private Map<String, String> getParamsFromMapperMethod(IJavaProject project, String mapperFqn, String methodName)
/*     */   {
/*     */     try
/*     */     {
/* 258 */       IType type = project.findType(mapperFqn);
/* 259 */       if (type != null)
/*     */       {
/* 261 */         ASTParser parser = ASTParser.newParser(4);
/* 262 */         parser.setSource(type.getTypeRoot());
/* 263 */         parser.setResolveBindings(true);
/* 264 */         CompilationUnit astUnit = (CompilationUnit)parser.createAST(null);
/* 265 */         IMethod mapperMethod = findMethodByName(type, methodName);
/* 266 */         return JavaMapperUtil.getMethodParameters(astUnit, mapperMethod);
/*     */       }
/*     */     }
/*     */     catch (JavaModelException e)
/*     */     {
/* 271 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/* 273 */     return Collections.emptyMap();
/*     */   }
/*     */   
/*     */   private IMethod findMethodByName(IType type, String methodName) throws JavaModelException {
/*     */     IMethod[] arrayOfIMethod;
/* 278 */     int j = (arrayOfIMethod = type.getMethods()).length; for (int i = 0; i < j; i++) { IMethod method = arrayOfIMethod[i];
/*     */       
/* 280 */       if (methodName.equals(method.getElementName()))
/* 281 */         return method;
/*     */     }
/* 283 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private void generateResults(ContentAssistRequest contentAssistRequest, int offset, int length, Node parentNode, Node typeAttr)
/*     */   {
/* 289 */     if (typeAttr == null) {
/* 290 */       return;
/*     */     }
/* 292 */     String typeValue = typeAttr.getNodeValue();
/* 293 */     if ((typeValue == null) || (typeValue.length() == 0)) {
/* 294 */       return;
/*     */     }
/* 296 */     IJavaProject project = getJavaProject(contentAssistRequest);
/*     */     
/* 298 */     String qualifiedName = TypeAliasCache.getInstance().resolveAlias(project, typeValue, null);
/* 299 */     if (qualifiedName == null)
/*     */     {
/*     */ 
/* 302 */       qualifiedName = typeValue;
/*     */     }
/* 304 */     BeanPropertyInfo beanProps = BeanPropertyCache.getBeanPropertyInfo(project, qualifiedName);
/*     */     try
/*     */     {
/* 307 */       Set<String> existingProps = new HashSet();
/* 308 */       NodeList existingPropNodes = XpathUtil.xpathNodes(parentNode, "*[@property]/@property");
/* 309 */       for (int i = 0; i < existingPropNodes.getLength(); i++)
/*     */       {
/* 311 */         existingProps.add(existingPropNodes.item(i).getNodeValue());
/*     */       }
/* 313 */       StringBuilder resultTags = new StringBuilder();
/* 314 */       for (Map.Entry<String, String> prop : beanProps.getWritableFields().entrySet())
/*     */       {
/* 316 */         String propName = (String)prop.getKey();
/* 317 */         if (!existingProps.contains(propName))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 323 */           resultTags.append("<result property=\"").append(propName).append("\" column=\"").append(propName).append("\" />\n");
/*     */         }
/*     */       }
/* 326 */       contentAssistRequest.addProposal(new CompletionProposal(resultTags.toString(), offset, 
/* 327 */         length, resultTags.length(), Activator.getIcon(), "<result /> for properties", null, 
/* 328 */         null));
/*     */     }
/*     */     catch (XPathExpressionException e)
/*     */     {
/* 332 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addAttributeValueProposals(ContentAssistRequest contentAssistRequest, CompletionProposalInvocationContext context)
/*     */   {
/* 339 */     IDOMNode node = (IDOMNode)contentAssistRequest.getNode();
/* 340 */     String tagName = node.getNodeName();
/* 341 */     IStructuredDocumentRegion open = node.getFirstStructuredDocumentRegion();
/* 342 */     ITextRegionList openRegions = open.getRegions();
/* 343 */     int i = openRegions.indexOf(contentAssistRequest.getRegion());
/* 344 */     if (i < 0)
/* 345 */       return;
/* 346 */     ITextRegion nameRegion = null;
/* 347 */     while (i >= 0)
/*     */     {
/* 349 */       nameRegion = openRegions.get(i--);
/* 350 */       if (nameRegion.getType() == "XML_TAG_ATTRIBUTE_NAME") {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/* 355 */     String attributeName = null;
/* 356 */     if (nameRegion != null) {
/* 357 */       attributeName = open.getText(nameRegion);
/*     */     }
/* 359 */     ProposalType proposalType = resolveProposalType(tagName, attributeName);
/* 360 */     if (ProposalType.None.equals(proposalType))
/*     */     {
/* 362 */       return;
/*     */     }
/*     */     
/* 365 */     String currentValue = null;
/* 366 */     if (contentAssistRequest.getRegion().getType() == "XML_TAG_ATTRIBUTE_VALUE") {
/* 367 */       currentValue = contentAssistRequest.getText();
/*     */     } else {
/* 369 */       currentValue = "";
/*     */     }
/* 371 */     String matchString = null;
/* 372 */     int matchStrLen = contentAssistRequest.getMatchString().length();
/* 373 */     int start = contentAssistRequest.getReplacementBeginPosition();
/* 374 */     int length = contentAssistRequest.getReplacementLength();
/* 375 */     if ((currentValue.length() > StringUtils.strip(currentValue).length()) && 
/* 376 */       ((currentValue.startsWith("\"")) || (currentValue.startsWith("'"))) && (matchStrLen > 0))
/*     */     {
/*     */ 
/* 379 */       matchString = currentValue.substring(1, matchStrLen);
/* 380 */       start++;
/* 381 */       length = currentValue.length() - 2;
/* 382 */       currentValue = currentValue.substring(1, length + 1);
/*     */     }
/*     */     else
/*     */     {
/* 386 */       matchString = currentValue.substring(0, matchStrLen);
/*     */     }
/*     */     
/* 389 */     IJavaProject project = getJavaProject(contentAssistRequest);
/*     */     try
/*     */     {
/* 392 */       switch (proposalType)
/*     */       {
/*     */       case ResultProperty: 
/* 395 */         proposePackage(contentAssistRequest, project, matchString, start, length);
/* 396 */         break;
/*     */       case ResultType: 
/* 398 */         addProposals(contentAssistRequest, 
/* 399 */           ProposalComputorHelper.proposeJavaType(project, start, length, false, matchString));
/* 400 */         break;
/*     */       case KeyProperty: 
/* 402 */         addProposals(contentAssistRequest, 
/* 403 */           ProposalComputorHelper.proposeJavaType(project, start, length, true, matchString));
/* 404 */         break;
/*     */       case MapperNamespace: 
/* 406 */         proposeProperty(contentAssistRequest, matchString, start, length, node);
/* 407 */         break;
/*     */       case Package: 
/* 409 */         addProposals(contentAssistRequest, 
/* 410 */           ProposalComputorHelper.proposeTypeHandler(project, start, length, matchString));
/* 411 */         break;
/*     */       case ParamProperty: 
/* 413 */         addProposals(contentAssistRequest, 
/* 414 */           ProposalComputorHelper.proposeCacheType(project, start, length, matchString));
/* 415 */         break;
/*     */       case None: 
/* 417 */         proposeStatementId(contentAssistRequest, project, matchString, start, length, node);
/* 418 */         break;
/*     */       case Include: 
/* 420 */         proposeMapperNamespace(contentAssistRequest, project, start, length);
/* 421 */         break;
/*     */       
/*     */       case ParamPropertyPartial: 
/* 424 */         addProposals(
/* 425 */           contentAssistRequest, 
/* 426 */           proposeResultMapReference(project, node.getOwnerDocument(), start, currentValue, 
/* 427 */           matchString.length()));
/* 428 */         break;
/*     */       case ResultMap: 
/* 430 */         addProposals(contentAssistRequest, ProposalComputorHelper.proposeReference(project, 
/* 431 */           node.getOwnerDocument(), matchString, start, length, "sql"));
/* 432 */         break;
/*     */       
/*     */       case SelectId: 
/* 435 */         addProposals(contentAssistRequest, ProposalComputorHelper.proposeReference(project, 
/* 436 */           node.getOwnerDocument(), matchString, start, length, "select"));
/* 437 */         break;
/*     */       case StatementId: 
/* 439 */         String nodeName = node.getNodeName();
/* 440 */         Node statementNode = ("update".equals(nodeName)) || ("insert".equals(nodeName)) ? node : 
/* 441 */           findEnclosingStatementNode(node.getParentNode());
/* 442 */         addProposals(contentAssistRequest, 
/* 443 */           proposeParameter(project, start, length, statementNode, false, matchString));
/* 444 */         break;
/*     */       case TypeAlias: 
/* 446 */         addProposals(
/* 447 */           contentAssistRequest, 
/* 448 */           proposeParameter(project, start, length, findEnclosingStatementNode(node), true, 
/* 449 */           matchString));
/* 450 */         break;
/*     */       case TypeHandlerType: 
/* 452 */         AttrTextParser parser = new AttrTextParser(currentValue, matchString.length());
/* 453 */         addProposals(
/* 454 */           contentAssistRequest, 
/* 455 */           proposeParameter(project, start + parser.getMatchStringStart(), 
/* 456 */           parser.getReplacementLength(), findEnclosingStatementNode(node.getParentNode()), 
/* 457 */           true, parser.getMatchString()));
/*     */       
/*     */ 
/*     */       }
/*     */       
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 465 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private List<ICompletionProposal> proposeResultMapReference(IJavaProject project, Document domDoc, int start, String currentValue, int offsetInCurrentValue)
/*     */     throws XPathExpressionException, IOException, CoreException
/*     */   {
/* 473 */     int leftComma = currentValue.lastIndexOf(',', offsetInCurrentValue);
/* 474 */     int rightComma = currentValue.indexOf(',', offsetInCurrentValue);
/* 475 */     String newMatchString = currentValue.substring(leftComma + 1, offsetInCurrentValue).trim();
/* 476 */     int newStart = start + offsetInCurrentValue - newMatchString.length();
/* 477 */     int newLength = currentValue.length() - (offsetInCurrentValue - newMatchString.length()) - (
/* 478 */       rightComma > -1 ? currentValue.length() - rightComma : 0);
/* 479 */     return ProposalComputorHelper.proposeReference(project, domDoc, newMatchString, newStart, 
/* 480 */       newLength, "resultMap");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void proposeMapperNamespace(ContentAssistRequest contentAssistRequest, IJavaProject project, int start, int length)
/*     */   {
/* 487 */     String namespace = MybatipseXmlUtil.getJavaMapperType(project);
/* 488 */     ICompletionProposal proposal = new CompletionProposal(namespace, start, length, 
/* 489 */       namespace.length(), Activator.getIcon("/icons/mybatis-ns.png"), namespace, null, null);
/* 490 */     contentAssistRequest.addProposal(proposal);
/*     */   }
/*     */   
/*     */ 
/*     */   private void proposeStatementId(ContentAssistRequest contentAssistRequest, IJavaProject project, String matchString, int start, int length, IDOMNode node)
/*     */     throws JavaModelException, XPathExpressionException
/*     */   {
/* 497 */     List<ICompletionProposal> results = new ArrayList();
/*     */     
/* 499 */     String qualifiedName = MybatipseXmlUtil.getNamespace(node.getOwnerDocument());
/* 500 */     IType type = project.findType(qualifiedName);
/*     */     
/*     */ 
/* 503 */     List<IMethod> methods = NameUtil.getAllSuperMethods(null, project, type);
/*     */     
/* 505 */     IMethod[] subMethods = type.getMethods();
/* 506 */     if ((subMethods != null) && (subMethods.length > 0)) {
/* 507 */       methods.addAll(Arrays.asList(subMethods));
/*     */     }
/* 509 */     if ((methods != null) && (methods.size() > 0))
/*     */     {
/* 511 */       Map<String, IMethod> disMethods = new LinkedHashMap();
/* 512 */       for (IMethod method : methods) {
/* 513 */         disMethods.put(method.getElementName(), method);
/*     */       }
/* 515 */       for (IMethod method : disMethods.values())
/*     */       {
/* 517 */         if (!hasStatementAnnotation(method))
/*     */         {
/* 519 */           String statementId = method.getElementName();
/* 520 */           if ((matchString.length() == 0) || 
/* 521 */             (CharOperation.camelCaseMatch(matchString.toCharArray(), statementId.toCharArray())))
/*     */           {
/* 523 */             results.add(new CompletionProposal(statementId, start, length, statementId.length(), 
/* 524 */               Activator.getIcon(), statementId, null, null)); }
/*     */         }
/*     */       }
/*     */     }
/* 528 */     addProposals(contentAssistRequest, results);
/*     */   }
/*     */   
/*     */   private boolean hasStatementAnnotation(IMethod method) throws JavaModelException
/*     */   {
/* 533 */     IAnnotation[] annotations = method.getAnnotations();
/* 534 */     IAnnotation[] arrayOfIAnnotation1; int j = (arrayOfIAnnotation1 = annotations).length; for (int i = 0; i < j; i++) { IAnnotation annotation = arrayOfIAnnotation1[i];
/*     */       
/* 536 */       if (statementAnnotations.contains(annotation.getElementName()))
/* 537 */         return true;
/*     */     }
/* 539 */     return false;
/*     */   }
/*     */   
/*     */   private void proposeProperty(ContentAssistRequest contentAssistRequest, String matchString, int start, int length, IDOMNode node)
/*     */     throws JavaModelException
/*     */   {
/* 545 */     String javaType = MybatipseXmlUtil.findEnclosingType(node);
/* 546 */     if ((javaType != null) && (!MybatipseXmlUtil.isDefaultTypeAlias(javaType)))
/*     */     {
/* 548 */       IJavaProject project = getJavaProject(contentAssistRequest);
/* 549 */       IType type = project.findType(javaType);
/* 550 */       if (type == null)
/*     */       {
/* 552 */         javaType = TypeAliasCache.getInstance().resolveAlias(project, javaType, null);
/* 553 */         if (javaType == null)
/* 554 */           return;
/*     */       }
/* 556 */       addProposals(contentAssistRequest, ProposalComputorHelper.proposePropertyFor(project, 
/* 557 */         start, length, javaType, false, -1, matchString));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void proposePackage(ContentAssistRequest contentAssistRequest, IJavaProject project, String matchString, final int start, final int length)
/*     */     throws CoreException
/*     */   {
/* 565 */     final List<ICompletionProposal> results = new ArrayList();
/* 566 */     final Set<String> foundPkgs = new HashSet();
/* 567 */     int includeMask = 9;
/*     */     
/* 569 */     boolean pkgSpecified = (matchString != null) && (matchString.indexOf('.') > 0);
/* 570 */     if (pkgSpecified)
/* 571 */       includeMask |= 0x6;
/* 572 */     IJavaSearchScope scope = SearchEngine.createJavaSearchScope(new IJavaProject[] {
/* 573 */       project }, 
/* 574 */       includeMask);
/* 575 */     SearchRequestor requestor = new SearchRequestor()
/*     */     {
/*     */       public void acceptSearchMatch(SearchMatch match)
/*     */         throws CoreException
/*     */       {
/* 580 */         PackageFragment element = (PackageFragment)match.getElement();
/* 581 */         String pkg = element.getElementName();
/* 582 */         if ((pkg != null) && (pkg.length() > 0) && (!foundPkgs.contains(pkg)))
/*     */         {
/* 584 */           foundPkgs.add(pkg);
/* 585 */           results.add(new CompletionProposal(pkg, start, length, pkg.length(), 
/* 586 */             Activator.getIcon(), pkg, null, null));
/*     */         }
/*     */       }
/* 589 */     };
/* 590 */     searchPackage(matchString, scope, requestor);
/* 591 */     addProposals(contentAssistRequest, results);
/*     */   }
/*     */   
/*     */   private void searchPackage(String matchString, IJavaSearchScope scope, SearchRequestor requestor)
/*     */     throws CoreException
/*     */   {
/* 597 */     SearchPattern pattern = SearchPattern.createPattern(matchString + "*", 
/* 598 */       2, 0, 
/* 599 */       1);
/* 600 */     SearchEngine searchEngine = new SearchEngine();
/* 601 */     searchEngine.search(pattern, new SearchParticipant[] {
/* 602 */       SearchEngine.getDefaultSearchParticipant() }, 
/* 603 */       scope, requestor, null);
/*     */   }
/*     */   
/*     */ 
/*     */   private void addProposals(ContentAssistRequest contentAssistRequest, List<ICompletionProposal> proposals)
/*     */   {
/* 609 */     Collections.sort(proposals, new CompletionProposalComparator(null));
/* 610 */     for (ICompletionProposal proposal : proposals)
/*     */     {
/* 612 */       contentAssistRequest.addProposal(proposal);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private ProposalType resolveProposalType(String tag, String attr)
/*     */   {
/* 619 */     if (("mapper".equals(tag)) && ("namespace".equals(attr)))
/* 620 */       return ProposalType.MapperNamespace;
/* 621 */     if (("type".equals(attr)) && ("typeAlias".equals(tag)))
/* 622 */       return ProposalType.TypeAlias;
/* 623 */     if (("type".equals(attr)) && ("cache".equals(tag)))
/* 624 */       return ProposalType.CacheType;
/* 625 */     if (("type".equals(attr)) && ("objectFactory".equals(tag)))
/* 626 */       return ProposalType.None;
/* 627 */     if (("type".equals(attr)) && ("objectWrapperFactory".equals(tag)))
/* 628 */       return ProposalType.None;
/* 629 */     if (("type".equals(attr)) || ("resultType".equals(attr)) || ("parameterType".equals(attr)) || 
/* 630 */       ("ofType".equals(attr)) || ("javaType".equals(attr)))
/* 631 */       return ProposalType.ResultType;
/* 632 */     if ("property".equals(attr))
/* 633 */       return ProposalType.ResultProperty;
/* 634 */     if (("package".equals(tag)) && ("name".equals(attr)))
/* 635 */       return ProposalType.Package;
/* 636 */     if (("typeHandler".equals(attr)) || ("handler".equals(attr)))
/* 637 */       return ProposalType.TypeHandlerType;
/* 638 */     if (("resultMap".equals(attr)) || ("extends".equals(attr)))
/* 639 */       return ProposalType.ResultMap;
/* 640 */     if ("refid".equals(attr))
/* 641 */       return ProposalType.Include;
/* 642 */     if ("select".equals(attr))
/* 643 */       return ProposalType.SelectId;
/* 644 */     if ("keyProperty".equals(attr))
/* 645 */       return ProposalType.KeyProperty;
/* 646 */     if ("collection".equals(attr))
/* 647 */       return ProposalType.ParamProperty;
/* 648 */     if (("test".equals(attr)) || (("bind".equals(tag)) && ("value".equals(attr))))
/* 649 */       return ProposalType.ParamPropertyPartial;
/* 650 */     if (("id".equals(attr)) && (
/* 651 */       ("select".equals(tag)) || ("update".equals(tag)) || ("insert".equals(tag)) || ("delete".equals(tag))))
/* 652 */       return ProposalType.StatementId;
/* 653 */     return ProposalType.None;
/*     */   }
/*     */   
/*     */   private IJavaProject getJavaProject(ContentAssistRequest request)
/*     */   {
/* 658 */     if (request != null)
/*     */     {
/* 660 */       IStructuredDocumentRegion region = request.getDocumentRegion();
/* 661 */       if (region != null)
/*     */       {
/* 663 */         IDocument document = region.getParentDocument();
/* 664 */         return MybatipseXmlUtil.getJavaProject(document);
/*     */       }
/*     */     }
/* 667 */     return null;
/*     */   }
/*     */   
/*     */   private class CompletionProposalComparator implements Comparator<ICompletionProposal>
/*     */   {
/*     */     private CompletionProposalComparator() {}
/*     */     
/*     */     public int compare(ICompletionProposal p1, ICompletionProposal p2) {
/* 675 */       if (((p1 instanceof IJavaCompletionProposal)) && ((p2 instanceof IJavaCompletionProposal)))
/*     */       {
/* 677 */         int relevance1 = ((IJavaCompletionProposal)p1).getRelevance();
/* 678 */         int relevance2 = ((IJavaCompletionProposal)p2).getRelevance();
/* 679 */         int diff = relevance2 - relevance1;
/* 680 */         if (diff != 0)
/* 681 */           return diff;
/*     */       }
/* 683 */       return p1.getDisplayString().compareToIgnoreCase(p2.getDisplayString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class AttrTextParser
/*     */   {
/*     */     private String text;
/*     */     
/*     */     private int offset;
/*     */     
/*     */     private String matchString;
/*     */     
/*     */     public AttrTextParser(String text, int offset)
/*     */     {
/* 698 */       this.text = text;
/* 699 */       this.offset = offset;
/* 700 */       parse();
/*     */     }
/*     */     
/*     */     private void parse()
/*     */     {
/* 705 */       for (int i = this.offset - 1; i > 0; i--)
/*     */       {
/* 707 */         char c = this.text.charAt(i);
/* 708 */         if ((!Character.isJavaIdentifierPart(c)) && (c != '[') && (c != ']') && (c != '.'))
/*     */         {
/* 710 */           this.matchString = this.text.substring(i + 1, this.offset);
/* 711 */           return;
/*     */         }
/*     */       }
/* 714 */       this.matchString = this.text.substring(0, this.offset);
/*     */     }
/*     */     
/*     */     public int getMatchStringStart()
/*     */     {
/* 719 */       return this.offset - this.matchString.length();
/*     */     }
/*     */     
/*     */     public int getReplacementLength()
/*     */     {
/* 724 */       for (int i = this.offset; 
/* 725 */           i < this.text.length(); i++)
/*     */       {
/* 727 */         char c = this.text.charAt(i);
/* 728 */         if ((!Character.isJavaIdentifierPart(c)) && (c != '[') && (c != ']') && (c != '.')) {
/*     */           break;
/*     */         }
/*     */       }
/*     */       
/* 733 */       return i - this.offset + this.matchString.length();
/*     */     }
/*     */     
/*     */     public String getMatchString()
/*     */     {
/* 738 */       return this.matchString;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\XmlCompletionProposalComputer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */