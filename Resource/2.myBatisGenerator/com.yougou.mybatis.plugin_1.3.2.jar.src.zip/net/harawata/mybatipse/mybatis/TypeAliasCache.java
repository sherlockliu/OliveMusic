/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TreeSet;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.xml.namespace.NamespaceContext;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import net.harawata.mybatipse.util.NameUtil;
/*     */ import net.harawata.mybatipse.util.XpathUtil;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.jdt.core.Flags;
/*     */ import org.eclipse.jdt.core.IAnnotation;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IMemberValuePair;
/*     */ import org.eclipse.jdt.core.IMethod;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.ITypeHierarchy;
/*     */ import org.eclipse.jdt.core.ITypeRoot;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.core.dom.ASTParser;
/*     */ import org.eclipse.jdt.core.dom.ASTVisitor;
/*     */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*     */ import org.eclipse.jdt.core.dom.Expression;
/*     */ import org.eclipse.jdt.core.dom.IMethodBinding;
/*     */ import org.eclipse.jdt.core.dom.ITypeBinding;
/*     */ import org.eclipse.jdt.core.dom.MethodInvocation;
/*     */ import org.eclipse.jdt.core.dom.SimpleName;
/*     */ import org.eclipse.jdt.core.search.IJavaSearchScope;
/*     */ import org.eclipse.jdt.core.search.SearchEngine;
/*     */ import org.eclipse.jdt.core.search.SearchMatch;
/*     */ import org.eclipse.jdt.core.search.SearchParticipant;
/*     */ import org.eclipse.jdt.core.search.SearchPattern;
/*     */ import org.eclipse.jdt.core.search.SearchRequestor;
/*     */ import org.eclipse.jdt.core.search.TypeNameRequestor;
/*     */ import org.eclipse.jface.preference.IPreferenceStore;
/*     */ import org.eclipse.wst.validation.internal.provisional.core.IReporter;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMAttr;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMDocument;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeAliasCache
/*     */ {
/*  88 */   private static final TypeAliasCache INSTANCE = new TypeAliasCache();
/*     */   
/*     */ 
/*     */   private static final String GUICE_MODULE_FQN = "org.mybatis.guice.MyBatisModule";
/*     */   
/*     */   private static final String SPRING_BEAN_FQN = "org.mybatis.spring.SqlSessionFactoryBean";
/*     */   
/*  95 */   private static final List<String> declaredTypes = Arrays.asList(new String[] { "org.mybatis.guice.MyBatisModule", "org.mybatis.spring.SqlSessionFactoryBean" });
/*     */   
/*  97 */   private final Map<String, TypeAliasMap> projectCache = new ConcurrentHashMap();
/*     */   
/*  99 */   private final Map<String, Set<String>> packageCache = new ConcurrentHashMap();
/*     */   
/* 101 */   private final Map<String, Set<String>> superTypeCache = new ConcurrentHashMap();
/*     */   
/*     */   public String resolveAlias(IJavaProject javaProject, String alias, IReporter reporter)
/*     */   {
/* 105 */     Map<String, TypeAliasMap.TypeAliasInfo> aliasMap = getTypeAliasMap(javaProject, reporter);
/* 106 */     TypeAliasMap.TypeAliasInfo typeAliasInfo = (TypeAliasMap.TypeAliasInfo)aliasMap.get(alias.toLowerCase(Locale.ENGLISH));
/* 107 */     return typeAliasInfo == null ? null : 
/* 108 */       MybatipseXmlUtil.normalizeTypeName(typeAliasInfo.getQualifiedName());
/*     */   }
/*     */   
/*     */   public void removeType(String projectName, String qualifiedName)
/*     */   {
/* 113 */     TypeAliasMap aliasMap = (TypeAliasMap)this.projectCache.get(projectName);
/* 114 */     if (aliasMap == null)
/* 115 */       return;
/* 116 */     Iterator<Map.Entry<String, TypeAliasMap.TypeAliasInfo>> iterator = aliasMap.entrySet().iterator();
/* 117 */     while (iterator.hasNext())
/*     */     {
/* 119 */       Map.Entry<String, TypeAliasMap.TypeAliasInfo> entry = (Map.Entry)iterator.next();
/* 120 */       if (qualifiedName.equals(((TypeAliasMap.TypeAliasInfo)entry.getValue()).getQualifiedName()))
/*     */       {
/* 122 */         iterator.remove();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void put(String projectName, IType type, String simpleTypeName)
/*     */   {
/* 129 */     String qualifiedName = type.getFullyQualifiedName();
/* 130 */     removeType(projectName, qualifiedName);
/*     */     try
/*     */     {
/* 133 */       TypeAliasMap aliasMap = (TypeAliasMap)this.projectCache.get(projectName);
/* 134 */       if (aliasMap == null)
/* 135 */         return;
/* 136 */       String alias = getAliasAnnotationValue(type);
/* 137 */       if (alias == null)
/*     */       {
/* 139 */         alias = simpleTypeName;
/*     */       }
/* 141 */       aliasMap.put(alias, qualifiedName);
/*     */     }
/*     */     catch (JavaModelException e)
/*     */     {
/* 145 */       Activator.log(4, "Error while resolving alias for type " + qualifiedName, e);
/*     */     }
/*     */   }
/*     */   
/*     */   public void remove(IProject project)
/*     */   {
/* 151 */     String projectName = project.getName();
/* 152 */     this.projectCache.remove(projectName);
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/* 157 */     this.projectCache.clear();
/*     */   }
/*     */   
/*     */   public boolean isInPackage(String projectName, String packageName)
/*     */   {
/* 162 */     Set<String> packages = (Set)this.packageCache.get(projectName);
/* 163 */     if (packages == null)
/* 164 */       return false;
/* 165 */     for (String pkg : packages)
/*     */     {
/* 167 */       if (packageName.startsWith(pkg))
/*     */       {
/* 169 */         return true;
/*     */       }
/*     */     }
/* 172 */     return false;
/*     */   }
/*     */   
/*     */   public Map<String, String> searchTypeAliases(IJavaProject javaProject, String matchString)
/*     */   {
/* 177 */     Map<String, String> results = new HashMap();
/* 178 */     TypeAliasMap typeAliasMap = getTypeAliasMap(javaProject, null);
/* 179 */     for (TypeAliasMap.TypeAliasInfo typeAliasInfo : typeAliasMap.values())
/*     */     {
/* 181 */       String alias = typeAliasInfo.getAliasToInsert();
/* 182 */       String qualifiedName = typeAliasInfo.getQualifiedName();
/* 183 */       char[] aliasChrs = alias.toCharArray();
/* 184 */       char[] matchChrs = matchString.toCharArray();
/* 185 */       if ((matchString.length() == 0) || (CharOperation.camelCaseMatch(matchChrs, aliasChrs)) || 
/* 186 */         (CharOperation.prefixEquals(matchChrs, aliasChrs, false)))
/*     */       {
/* 188 */         results.put(qualifiedName, alias);
/*     */       }
/*     */     }
/* 191 */     return results;
/*     */   }
/*     */   
/*     */   private TypeAliasMap getTypeAliasMap(IJavaProject javaProject, IReporter reporter)
/*     */   {
/* 196 */     String projectName = javaProject.getElementName();
/* 197 */     TypeAliasMap aliasMap = (TypeAliasMap)this.projectCache.get(projectName);
/* 198 */     if (aliasMap == null)
/*     */     {
/* 200 */       Map<IFile, IContentType> configFiles = ConfigRegistry.getInstance().get(javaProject);
/* 201 */       aliasMap = new TypeAliasMap();
/* 202 */       this.projectCache.put(projectName, aliasMap);
/* 203 */       this.packageCache.remove(projectName);
/* 204 */       this.superTypeCache.remove(projectName);
/* 205 */       Set<String> packages = new TreeSet();
/* 206 */       this.packageCache.put(projectName, packages);
/* 207 */       Set<String> superTypes = new HashSet();
/* 208 */       this.superTypeCache.put(projectName, superTypes);
/*     */       
/*     */ 
/* 211 */       IPreferenceStore store = Activator.getPreferenceStore(javaProject.getProject());
/* 212 */       String storedValue = store.getString("prefCustomTypeAliases");
/* 213 */       StringTokenizer tokenizer = new StringTokenizer(storedValue, "\t");
/* 214 */       while (tokenizer.hasMoreElements())
/*     */       {
/* 216 */         String token = (String)tokenizer.nextElement();
/* 217 */         if (token != null)
/*     */         {
/* 219 */           token = token.trim();
/* 220 */           if (token.length() != 0)
/*     */           {
/*     */             try
/*     */             {
/* 224 */               int colonIdx = token.indexOf(':');
/* 225 */               if (colonIdx == -1)
/*     */               {
/* 227 */                 IType type = javaProject.findType(token);
/* 228 */                 if (type == null) {
/* 229 */                   packages.add(token);
/*     */                 }
/*     */                 else {
/* 232 */                   String alias = getAliasAnnotationValue(type);
/* 233 */                   aliasMap.put(alias, token);
/*     */                 }
/*     */               }
/* 236 */               else if ((colonIdx > 0) && (colonIdx < token.length() - 2))
/*     */               {
/* 238 */                 String qualifiedName = token.substring(0, colonIdx);
/* 239 */                 IType type = javaProject.findType(qualifiedName);
/* 240 */                 if (type == null)
/*     */                 {
/* 242 */                   Activator.log(2, "Missing '" + qualifiedName + 
/* 243 */                     "' specified in the custom type alias setting.");
/*     */ 
/*     */                 }
/*     */                 else
/*     */                 {
/* 248 */                   String alias = getAliasAnnotationValue(type);
/* 249 */                   if (alias == null)
/* 250 */                     alias = token.substring(colonIdx + 1);
/* 251 */                   aliasMap.put(alias, qualifiedName);
/*     */                 }
/*     */               }
/*     */             }
/*     */             catch (JavaModelException e)
/*     */             {
/* 257 */               Activator.log(4, e.getMessage(), e);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 262 */       for (Map.Entry<IFile, IContentType> configFile : configFiles.entrySet())
/*     */       {
/* 264 */         parseConfigFiles(javaProject, (IFile)configFile.getKey(), (IContentType)configFile.getValue(), aliasMap, 
/* 265 */           packages, superTypes, reporter);
/*     */       }
/*     */       
/*     */ 
/* 269 */       scanJavaConfig(javaProject, aliasMap, packages, reporter);
/*     */       
/*     */ 
/* 272 */       if (!packages.isEmpty())
/*     */       {
/* 274 */         collectTypesInPackages(javaProject, packages, aliasMap, superTypes, reporter);
/*     */       }
/*     */     }
/* 277 */     return aliasMap;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void scanJavaConfig(IJavaProject project, TypeAliasMap aliasMap, Set<String> packages, IReporter reporter)
/*     */   {
/*     */     try
/*     */     {
/* 291 */       IJavaSearchScope scope = SearchEngine.createJavaSearchScope(new IJavaProject[] {
/* 292 */         project }, 
/* 293 */         11);
/*     */       
/* 295 */       SearchParticipant[] participants = {
/* 296 */         SearchEngine.getDefaultSearchParticipant() };
/*     */       
/* 298 */       SearchEngine searchEngine = new SearchEngine();
/*     */       
/* 300 */       Set<ITypeRoot> typeRoots = new HashSet();
/*     */       
/*     */ 
/* 303 */       IType mybatisModuleType = project.findType("org.mybatis.guice.MyBatisModule");
/* 304 */       if ((mybatisModuleType == null) || (!mybatisModuleType.exists())) {
/* 305 */         return;
/*     */       }
/* 307 */       IMethod addSimpleAliasMethod = mybatisModuleType.getMethod("addSimpleAlias", 
/* 308 */         new String[] {
/* 309 */         "Ljava.lang.Class;" });
/*     */       
/* 311 */       SearchPattern pattern = SearchPattern.createPattern(addSimpleAliasMethod, 
/* 312 */         19);
/*     */       
/* 314 */       searchEngine.search(pattern, participants, scope, new MethodSearchRequestor(typeRoots, null), 
/* 315 */         null);
/*     */       
/* 317 */       IMethod addSimpleAliasesMethodWithPackage = mybatisModuleType.getMethod(
/* 318 */         "addSimpleAliases", new String[] {
/* 319 */         "Ljava.lang.String;" });
/*     */       
/* 321 */       pattern = SearchPattern.createPattern(addSimpleAliasesMethodWithPackage, 
/* 322 */         18);
/* 323 */       searchEngine.search(pattern, participants, scope, new MethodSearchRequestor(typeRoots, null), 
/* 324 */         null);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 353 */       for (ITypeRoot typeRoot : typeRoots)
/*     */       {
/* 355 */         ASTParser parser = ASTParser.newParser(4);
/* 356 */         parser.setSource(typeRoot);
/* 357 */         parser.setResolveBindings(true);
/* 358 */         CompilationUnit astUnit = (CompilationUnit)parser.createAST(null);
/* 359 */         astUnit.accept(new JavaConfigVisitor(aliasMap, packages, null));
/*     */       }
/*     */     }
/*     */     catch (JavaModelException e)
/*     */     {
/* 364 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*     */     catch (CoreException e)
/*     */     {
/* 368 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void parseConfigFiles(IJavaProject project, IFile configFile, IContentType configType, TypeAliasMap aliasMap, Set<String> packages, Set<String> superTypeList, IReporter reporter)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore 8
/*     */     //   3: invokestatic 474	org/eclipse/wst/sse/core/StructuredModelManager:getModelManager	()Lorg/eclipse/wst/sse/core/internal/provisional/IModelManager;
/*     */     //   6: aload_2
/*     */     //   7: invokeinterface 480 2 0
/*     */     //   12: astore 8
/*     */     //   14: aload 8
/*     */     //   16: checkcast 486	org/eclipse/wst/xml/core/internal/provisional/document/IDOMModel
/*     */     //   19: astore 9
/*     */     //   21: aload 9
/*     */     //   23: invokeinterface 488 1 0
/*     */     //   28: astore 10
/*     */     //   30: aload 7
/*     */     //   32: ifnull +21 -> 53
/*     */     //   35: aload 7
/*     */     //   37: invokeinterface 492 1 0
/*     */     //   42: ifeq +11 -> 53
/*     */     //   45: new 495	org/eclipse/core/runtime/OperationCanceledException
/*     */     //   48: dup
/*     */     //   49: invokespecial 497	org/eclipse/core/runtime/OperationCanceledException:<init>	()V
/*     */     //   52: athrow
/*     */     //   53: getstatic 498	net/harawata/mybatipse/MybatipseConstants:configContentType	Lorg/eclipse/core/runtime/content/IContentType;
/*     */     //   56: aload_3
/*     */     //   57: invokevirtual 504	java/lang/Object:equals	(Ljava/lang/Object;)Z
/*     */     //   60: ifeq +45 -> 105
/*     */     //   63: aload_0
/*     */     //   64: aload 10
/*     */     //   66: aload 4
/*     */     //   68: invokespecial 505	net/harawata/mybatipse/mybatis/TypeAliasCache:parseTypeAliasElements	(Lorg/eclipse/wst/xml/core/internal/provisional/document/IDOMDocument;Lnet/harawata/mybatipse/mybatis/TypeAliasMap;)V
/*     */     //   71: aload 7
/*     */     //   73: ifnull +21 -> 94
/*     */     //   76: aload 7
/*     */     //   78: invokeinterface 492 1 0
/*     */     //   83: ifeq +11 -> 94
/*     */     //   86: new 495	org/eclipse/core/runtime/OperationCanceledException
/*     */     //   89: dup
/*     */     //   90: invokespecial 497	org/eclipse/core/runtime/OperationCanceledException:<init>	()V
/*     */     //   93: athrow
/*     */     //   94: aload_0
/*     */     //   95: aload 10
/*     */     //   97: aload 5
/*     */     //   99: invokespecial 509	net/harawata/mybatipse/mybatis/TypeAliasCache:parsePackageElements	(Lorg/eclipse/wst/xml/core/internal/provisional/document/IDOMDocument;Ljava/util/Set;)V
/*     */     //   102: goto +156 -> 258
/*     */     //   105: getstatic 513	net/harawata/mybatipse/MybatipseConstants:springConfigContentType	Lorg/eclipse/core/runtime/content/IContentType;
/*     */     //   108: aload_3
/*     */     //   109: invokevirtual 504	java/lang/Object:equals	(Ljava/lang/Object;)Z
/*     */     //   112: ifeq +146 -> 258
/*     */     //   115: aload_0
/*     */     //   116: aload 5
/*     */     //   118: aload 10
/*     */     //   120: invokespecial 516	net/harawata/mybatipse/mybatis/TypeAliasCache:parseTypeAliasesPackage	(Ljava/util/Set;Lorg/eclipse/wst/xml/core/internal/provisional/document/IDOMDocument;)V
/*     */     //   123: aload 7
/*     */     //   125: ifnull +21 -> 146
/*     */     //   128: aload 7
/*     */     //   130: invokeinterface 492 1 0
/*     */     //   135: ifeq +11 -> 146
/*     */     //   138: new 495	org/eclipse/core/runtime/OperationCanceledException
/*     */     //   141: dup
/*     */     //   142: invokespecial 497	org/eclipse/core/runtime/OperationCanceledException:<init>	()V
/*     */     //   145: athrow
/*     */     //   146: aload_0
/*     */     //   147: aload 6
/*     */     //   149: aload 10
/*     */     //   151: invokespecial 520	net/harawata/mybatipse/mybatis/TypeAliasCache:parseTypeAliasesSuperType	(Ljava/util/Set;Lorg/eclipse/wst/xml/core/internal/provisional/document/IDOMDocument;)V
/*     */     //   154: goto +104 -> 258
/*     */     //   157: astore 9
/*     */     //   159: iconst_4
/*     */     //   160: aload 9
/*     */     //   162: invokevirtual 523	javax/xml/xpath/XPathExpressionException:getMessage	()Ljava/lang/String;
/*     */     //   165: aload 9
/*     */     //   167: invokestatic 166	net/harawata/mybatipse/Activator:log	(ILjava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   170: aload 8
/*     */     //   172: ifnull +98 -> 270
/*     */     //   175: aload 8
/*     */     //   177: invokeinterface 526 1 0
/*     */     //   182: goto +88 -> 270
/*     */     //   185: astore 9
/*     */     //   187: iconst_4
/*     */     //   188: aload 9
/*     */     //   190: invokevirtual 531	java/io/IOException:getMessage	()Ljava/lang/String;
/*     */     //   193: aload 9
/*     */     //   195: invokestatic 166	net/harawata/mybatipse/Activator:log	(ILjava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   198: aload 8
/*     */     //   200: ifnull +70 -> 270
/*     */     //   203: aload 8
/*     */     //   205: invokeinterface 526 1 0
/*     */     //   210: goto +60 -> 270
/*     */     //   213: astore 9
/*     */     //   215: iconst_4
/*     */     //   216: aload 9
/*     */     //   218: invokevirtual 444	org/eclipse/core/runtime/CoreException:getMessage	()Ljava/lang/String;
/*     */     //   221: aload 9
/*     */     //   223: invokestatic 166	net/harawata/mybatipse/Activator:log	(ILjava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   226: aload 8
/*     */     //   228: ifnull +42 -> 270
/*     */     //   231: aload 8
/*     */     //   233: invokeinterface 526 1 0
/*     */     //   238: goto +32 -> 270
/*     */     //   241: astore 11
/*     */     //   243: aload 8
/*     */     //   245: ifnull +10 -> 255
/*     */     //   248: aload 8
/*     */     //   250: invokeinterface 526 1 0
/*     */     //   255: aload 11
/*     */     //   257: athrow
/*     */     //   258: aload 8
/*     */     //   260: ifnull +10 -> 270
/*     */     //   263: aload 8
/*     */     //   265: invokeinterface 526 1 0
/*     */     //   270: return
/*     */     // Line number table:
/*     */     //   Java source line #376	-> byte code offset #0
/*     */     //   Java source line #379	-> byte code offset #3
/*     */     //   Java source line #380	-> byte code offset #14
/*     */     //   Java source line #381	-> byte code offset #21
/*     */     //   Java source line #383	-> byte code offset #30
/*     */     //   Java source line #385	-> byte code offset #45
/*     */     //   Java source line #388	-> byte code offset #53
/*     */     //   Java source line #391	-> byte code offset #63
/*     */     //   Java source line #393	-> byte code offset #71
/*     */     //   Java source line #395	-> byte code offset #86
/*     */     //   Java source line #399	-> byte code offset #94
/*     */     //   Java source line #401	-> byte code offset #105
/*     */     //   Java source line #403	-> byte code offset #115
/*     */     //   Java source line #405	-> byte code offset #123
/*     */     //   Java source line #407	-> byte code offset #138
/*     */     //   Java source line #410	-> byte code offset #146
/*     */     //   Java source line #413	-> byte code offset #157
/*     */     //   Java source line #415	-> byte code offset #159
/*     */     //   Java source line #428	-> byte code offset #170
/*     */     //   Java source line #430	-> byte code offset #175
/*     */     //   Java source line #417	-> byte code offset #185
/*     */     //   Java source line #419	-> byte code offset #187
/*     */     //   Java source line #428	-> byte code offset #198
/*     */     //   Java source line #430	-> byte code offset #203
/*     */     //   Java source line #421	-> byte code offset #213
/*     */     //   Java source line #423	-> byte code offset #215
/*     */     //   Java source line #428	-> byte code offset #226
/*     */     //   Java source line #430	-> byte code offset #231
/*     */     //   Java source line #426	-> byte code offset #241
/*     */     //   Java source line #428	-> byte code offset #243
/*     */     //   Java source line #430	-> byte code offset #248
/*     */     //   Java source line #432	-> byte code offset #255
/*     */     //   Java source line #428	-> byte code offset #258
/*     */     //   Java source line #430	-> byte code offset #263
/*     */     //   Java source line #433	-> byte code offset #270
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	271	0	this	TypeAliasCache
/*     */     //   0	271	1	project	IJavaProject
/*     */     //   0	271	2	configFile	IFile
/*     */     //   0	271	3	configType	IContentType
/*     */     //   0	271	4	aliasMap	TypeAliasMap
/*     */     //   0	271	5	packages	Set<String>
/*     */     //   0	271	6	superTypeList	Set<String>
/*     */     //   0	271	7	reporter	IReporter
/*     */     //   1	263	8	model	org.eclipse.wst.sse.core.internal.provisional.IStructuredModel
/*     */     //   19	3	9	domModel	org.eclipse.wst.xml.core.internal.provisional.document.IDOMModel
/*     */     //   157	9	9	e	XPathExpressionException
/*     */     //   185	9	9	e	java.io.IOException
/*     */     //   213	9	9	e	CoreException
/*     */     //   28	122	10	domDoc	IDOMDocument
/*     */     //   241	15	11	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   3	154	157	javax/xml/xpath/XPathExpressionException
/*     */     //   3	154	185	java/io/IOException
/*     */     //   3	154	213	org/eclipse/core/runtime/CoreException
/*     */     //   3	170	241	finally
/*     */     //   185	198	241	finally
/*     */     //   213	226	241	finally
/*     */   }
/*     */   
/*     */   private void parseTypeAliasesPackage(Set<String> packages, IDOMDocument domDoc)
/*     */     throws XPathExpressionException
/*     */   {
/* 439 */     NodeList nodes = XpathUtil.xpathNodes(domDoc, 
/* 440 */       "//beans:bean/beans:property[@name='typeAliasesPackage']/@value", 
/* 441 */       new SpringConfigNamespaceContext(null));
/*     */     
/*     */ 
/*     */ 
/* 445 */     int i = 0; if (i < nodes.getLength())
/*     */     {
/* 447 */       String value = nodes.item(i).getNodeValue();
/* 448 */       String[] arr = value.split(",; \t\n");
/* 449 */       String[] arrayOfString1; int j = (arrayOfString1 = arr).length; for (int i = 0; i < j; i++) { String pkg = arrayOfString1[i];
/*     */         
/* 451 */         if ((pkg != null) && (pkg.length() > 0)) {
/* 452 */           packages.add(pkg.trim());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parseTypeAliasesSuperType(Set<String> superTypes, IDOMDocument domDoc)
/*     */     throws XPathExpressionException
/*     */   {
/* 465 */     NodeList nodes = XpathUtil.xpathNodes(domDoc, 
/* 466 */       "//beans:bean/beans:property[@name='typeAliasesSuperType']/@value", 
/* 467 */       new SpringConfigNamespaceContext(null));
/*     */     
/*     */ 
/*     */ 
/* 471 */     int i = 0; if (i < nodes.getLength())
/*     */     {
/* 473 */       String value = nodes.item(i).getNodeValue();
/* 474 */       superTypes.add(value.trim());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void collectTypesInPackages(final IJavaProject project, Set<String> packages, final TypeAliasMap aliasMap, Set<String> superTypes, IReporter reporter)
/*     */   {
/* 485 */     final Set<IType> superTypeSet = new HashSet();
/*     */     try
/*     */     {
/* 488 */       for (String supType : superTypes)
/*     */       {
/* 490 */         superTypeSet.add(project.findType(supType));
/*     */       }
/*     */     }
/*     */     catch (JavaModelException e)
/*     */     {
/* 495 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*     */     
/* 498 */     int includeMask = 15;
/*     */     
/* 500 */     IJavaSearchScope scope = SearchEngine.createJavaSearchScope(new IJavaProject[] {
/* 501 */       project }, 
/* 502 */       includeMask);
/* 503 */     TypeNameRequestor requestor = new TypeNameRequestor()
/*     */     {
/*     */ 
/*     */ 
/*     */       public void acceptType(int modifiers, char[] packageName, char[] simpleTypeName, char[][] enclosingTypeNames, String path)
/*     */       {
/*     */ 
/* 510 */         if (Flags.isAbstract(modifiers)) {
/* 511 */           return;
/*     */         }
/* 513 */         String qualifiedName = NameUtil.buildQualifiedName(packageName, simpleTypeName, 
/* 514 */           enclosingTypeNames, false);
/*     */         try
/*     */         {
/* 517 */           IType foundType = project.findType(qualifiedName);
/* 518 */           if ((superTypeSet.isEmpty()) || (isSuperTypeMatched(foundType, superTypeSet)))
/*     */           {
/* 520 */             String alias = TypeAliasCache.this.getAliasAnnotationValue(foundType);
/* 521 */             if (alias == null)
/*     */             {
/* 523 */               alias = new String(simpleTypeName);
/*     */             }
/* 525 */             aliasMap.put(alias, qualifiedName);
/*     */           }
/*     */         }
/*     */         catch (JavaModelException e)
/*     */         {
/* 530 */           Activator.log(2, "Error occurred while searching type alias.", e);
/*     */         }
/*     */       }
/*     */       
/*     */       private boolean isSuperTypeMatched(IType foundType, Set<IType> superTypeSet)
/*     */         throws JavaModelException
/*     */       {
/* 537 */         for (IType superType : superTypeSet)
/*     */         {
/* 539 */           if (TypeAliasCache.this.isAssignable(foundType, superType))
/*     */           {
/* 541 */             return true;
/*     */           }
/*     */         }
/* 544 */         return false;
/*     */       }
/*     */       
/* 547 */     };
/* 548 */     SearchEngine searchEngine = new SearchEngine();
/* 549 */     for (String pkg : packages)
/*     */     {
/* 551 */       if ((reporter != null) && (reporter.isCancelled()))
/*     */       {
/* 553 */         throw new OperationCanceledException();
/*     */       }
/*     */       try
/*     */       {
/* 557 */         searchEngine.searchAllTypeNames(pkg.toCharArray(), 0, null, 
/* 558 */           128, 5, scope, requestor, 
/* 559 */           3, null);
/*     */       }
/*     */       catch (JavaModelException e)
/*     */       {
/* 563 */         Activator.log(4, e.getMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String getAliasAnnotationValue(IType foundType) throws JavaModelException
/*     */   {
/* 570 */     String alias = null;
/* 571 */     IAnnotation[] annotations = foundType.getAnnotations();
/* 572 */     IAnnotation[] arrayOfIAnnotation1; int j = (arrayOfIAnnotation1 = annotations).length; for (int i = 0; i < j; i++) { IAnnotation annotation = arrayOfIAnnotation1[i];
/*     */       
/* 574 */       if ("Alias".equals(annotation.getElementName()))
/*     */       {
/* 576 */         IMemberValuePair[] params = annotation.getMemberValuePairs();
/* 577 */         if (params.length > 0)
/*     */         {
/* 579 */           alias = (String)params[0].getValue();
/*     */         }
/*     */       }
/*     */     }
/* 583 */     return alias;
/*     */   }
/*     */   
/*     */   private void parsePackageElements(IDOMDocument domDoc, Set<String> packages)
/*     */     throws XPathExpressionException
/*     */   {
/* 589 */     NodeList pkgNameNodes = XpathUtil.xpathNodes(domDoc, "//typeAliases/package/@name");
/* 590 */     for (int i = 0; i < pkgNameNodes.getLength(); i++)
/*     */     {
/* 592 */       String pkg = pkgNameNodes.item(i).getNodeValue();
/* 593 */       packages.add(pkg);
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseTypeAliasElements(IDOMDocument domDoc, TypeAliasMap aliasMap)
/*     */     throws XPathExpressionException
/*     */   {
/* 600 */     NodeList nodes = XpathUtil.xpathNodes(domDoc, "//typeAliases/typeAlias");
/* 601 */     for (int i = 0; i < nodes.getLength(); i++)
/*     */     {
/* 603 */       String type = null;
/* 604 */       String alias = null;
/* 605 */       NamedNodeMap attrs = nodes.item(i).getAttributes();
/* 606 */       for (int j = 0; j < attrs.getLength(); j++)
/*     */       {
/* 608 */         IDOMAttr attr = (IDOMAttr)attrs.item(j);
/* 609 */         String attrName = attr.getName();
/* 610 */         if ("type".equals(attrName)) {
/* 611 */           type = attr.getValue();
/* 612 */         } else if ("alias".equals(attrName))
/* 613 */           alias = attr.getValue();
/*     */       }
/* 615 */       aliasMap.put(alias, type);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isAssignable(IType type, IType targetType)
/*     */     throws JavaModelException
/*     */   {
/* 622 */     ITypeHierarchy supertypes = type.newSupertypeHierarchy(new NullProgressMonitor());
/* 623 */     return supertypes.contains(targetType);
/*     */   }
/*     */   
/*     */   public static TypeAliasCache getInstance()
/*     */   {
/* 628 */     return INSTANCE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class JavaConfigVisitor
/*     */     extends ASTVisitor
/*     */   {
/*     */     private TypeAliasMap aliasMap;
/*     */     
/*     */ 
/*     */     private Set<String> packages;
/*     */     
/*     */ 
/*     */     private JavaConfigVisitor(Set<String> aliasMap)
/*     */     {
/* 644 */       this.aliasMap = aliasMap;
/* 645 */       this.packages = packages;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean visit(MethodInvocation node)
/*     */     {
/* 651 */       String invokedMethod = node.getName().getIdentifier();
/* 652 */       if ("addSimpleAlias".equals(invokedMethod))
/*     */       {
/* 654 */         if (!declaredIn(node, "org.mybatis.guice.MyBatisModule")) {
/* 655 */           return false;
/*     */         }
/*     */         
/* 658 */         List args = node.arguments();
/* 659 */         if (args.size() != 1)
/*     */         {
/* 661 */           Activator.log(2, "Unexpected parameter count (possible API change): " + 
/* 662 */             invokedMethod);
/*     */         }
/*     */         else
/*     */         {
/* 666 */           Expression expression = (Expression)args.get(0);
/* 667 */           ITypeBinding argType = expression.resolveTypeBinding();
/* 668 */           ITypeBinding[] classTypes = argType.getTypeArguments();
/* 669 */           String qualifiedName = classTypes[0].getQualifiedName();
/* 670 */           String simpleName = classTypes[0].getName();
/* 671 */           this.aliasMap.put(simpleName, qualifiedName);
/*     */         }
/*     */       }
/* 674 */       else if ("addSimpleAliases".equals(invokedMethod))
/*     */       {
/* 676 */         if (!declaredIn(node, "org.mybatis.guice.MyBatisModule")) {
/* 677 */           return false;
/*     */         }
/*     */         
/* 680 */         List args = node.arguments();
/* 681 */         if (args.size() == 1)
/*     */         {
/* 683 */           Expression expression = (Expression)args.get(0);
/* 684 */           ITypeBinding argType = expression.resolveTypeBinding();
/* 685 */           if ("java.lang.String".equals(argType.getQualifiedName()))
/*     */           {
/* 687 */             Object constantArg = expression.resolveConstantExpressionValue();
/* 688 */             if (constantArg != null)
/*     */             {
/* 690 */               this.packages.add((String)constantArg);
/*     */             }
/*     */             else
/*     */             {
/* 694 */               Activator.log(1, "TypeAlias detection failed: " + node.toString() + 
/* 695 */                 " Only a literal parameter is supported for addSimpleAliases(String).");
/*     */             }
/*     */           }
/* 698 */           else if ("java.util.Collection<java.lang.Class<?>>".equals(argType.getQualifiedName()))
/*     */           {
/* 700 */             Activator.log(1, "TypeAlias detection failed. addSimpleAliases(Collection<Class<?>>) is not supported.");
/*     */           }
/*     */           
/*     */         }
/* 704 */         else if (args.size() == 2)
/*     */         {
/* 706 */           Activator.log(1, "TypeAlias detection failed. addSimpleAliases(String, Test) is not supported.");
/*     */         }
/*     */       }
/*     */       
/* 710 */       return true;
/*     */     }
/*     */     
/*     */     private boolean declaredIn(MethodInvocation node, String qualifiedName)
/*     */     {
/* 715 */       IMethodBinding methodBinding = node.resolveMethodBinding();
/*     */       
/* 717 */       return (methodBinding != null) && (qualifiedName.equals(methodBinding.getDeclaringClass().getQualifiedName()));
/*     */     }
/*     */   }
/*     */   
/*     */   private class MethodSearchRequestor extends SearchRequestor
/*     */   {
/*     */     private Set<ITypeRoot> typeRoots;
/*     */     
/*     */     private MethodSearchRequestor()
/*     */     {
/* 727 */       this.typeRoots = typeRoots;
/*     */     }
/*     */     
/*     */     public void acceptSearchMatch(SearchMatch match)
/*     */       throws CoreException
/*     */     {
/* 733 */       if (match.getAccuracy() == 1) {
/* 734 */         return;
/*     */       }
/* 736 */       IMethod element = (IMethod)match.getElement();
/* 737 */       ITypeRoot typeRoot = element.isBinary() ? element.getClassFile() : 
/* 738 */         element.getCompilationUnit();
/* 739 */       if (TypeAliasCache.declaredTypes.contains(typeRoot.findPrimaryType().getFullyQualifiedName()))
/* 740 */         return;
/* 741 */       this.typeRoots.add(typeRoot);
/*     */     }
/*     */   }
/*     */   
/*     */   private class SpringConfigNamespaceContext implements NamespaceContext
/*     */   {
/*     */     private SpringConfigNamespaceContext() {}
/*     */     
/*     */     public String getNamespaceURI(String prefix) {
/* 750 */       if (prefix == null)
/* 751 */         throw new NullPointerException("Prefix cannot be null.");
/* 752 */       if ("beans".equals(prefix))
/* 753 */         return "http://www.springframework.org/schema/beans";
/* 754 */       if ("xml".equals(prefix))
/* 755 */         return "http://www.w3.org/XML/1998/namespace";
/* 756 */       return "";
/*     */     }
/*     */     
/*     */ 
/*     */     public String getPrefix(String namespaceURI)
/*     */     {
/* 762 */       throw new UnsupportedOperationException();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Iterator getPrefixes(String namespaceURI)
/*     */     {
/* 769 */       throw new UnsupportedOperationException();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\TypeAliasCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */