/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IMethod;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.dom.ASTNode;
/*     */ import org.eclipse.jdt.core.dom.ASTParser;
/*     */ import org.eclipse.jdt.core.dom.ASTVisitor;
/*     */ import org.eclipse.jdt.core.dom.AnonymousClassDeclaration;
/*     */ import org.eclipse.jdt.core.dom.ArrayInitializer;
/*     */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*     */ import org.eclipse.jdt.core.dom.Expression;
/*     */ import org.eclipse.jdt.core.dom.IAnnotationBinding;
/*     */ import org.eclipse.jdt.core.dom.IMemberValuePairBinding;
/*     */ import org.eclipse.jdt.core.dom.IMethodBinding;
/*     */ import org.eclipse.jdt.core.dom.ITypeBinding;
/*     */ import org.eclipse.jdt.core.dom.IVariableBinding;
/*     */ import org.eclipse.jdt.core.dom.InfixExpression;
/*     */ import org.eclipse.jdt.core.dom.MethodDeclaration;
/*     */ import org.eclipse.jdt.core.dom.SimpleName;
/*     */ import org.eclipse.jdt.core.dom.SingleMemberAnnotation;
/*     */ import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
/*     */ import org.eclipse.jdt.core.dom.StringLiteral;
/*     */ import org.eclipse.jdt.core.dom.TypeDeclaration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaMapperUtil
/*     */ {
/*     */   public static final String TYPE_ROW_BOUNDS = "org.apache.ibatis.session.RowBounds";
/*     */   private static final String ANNOTATION_PARAM = "org.apache.ibatis.annotations.Param";
/*     */   
/*     */   public static Map<String, String> getMethodParameters(ASTNode node, IMethod method)
/*     */   {
/*  50 */     Map<String, String> results = new HashMap();
/*     */     
/*  52 */     MapperMethod mapperMethod = getMapperMethod(node, method);
/*  53 */     if (mapperMethod == null) {
/*  54 */       return results;
/*     */     }
/*     */     
/*  57 */     List<SingleVariableDeclaration> params = mapperMethod.parameters();
/*  58 */     for (int i = 0; i < params.size(); i++)
/*     */     {
/*  60 */       IVariableBinding paramBinding = ((SingleVariableDeclaration)params.get(i)).resolveBinding();
/*  61 */       String paramFqn = paramBinding.getType().getQualifiedName();
/*  62 */       if (!"org.apache.ibatis.session.RowBounds".equals(paramFqn))
/*     */       {
/*  64 */         IAnnotationBinding[] annotations = paramBinding.getAnnotations();
/*  65 */         IAnnotationBinding[] arrayOfIAnnotationBinding1; int j = (arrayOfIAnnotationBinding1 = annotations).length; for (int i = 0; i < j; i++) { IAnnotationBinding annotation = arrayOfIAnnotationBinding1[i];
/*     */           
/*  67 */           if ("org.apache.ibatis.annotations.Param".equals(annotation.getAnnotationType().getQualifiedName()))
/*     */           {
/*  69 */             IMemberValuePairBinding[] valuePairs = annotation.getAllMemberValuePairs();
/*  70 */             if (valuePairs.length == 1)
/*     */             {
/*  72 */               IMemberValuePairBinding valuePairBinding = valuePairs[0];
/*  73 */               String paramValue = (String)valuePairBinding.getValue();
/*  74 */               results.put(paramValue, paramFqn);
/*     */             }
/*     */           }
/*     */         }
/*  78 */         results.put("param" + (i + 1), paramFqn);
/*     */       } }
/*  80 */     return results;
/*     */   }
/*     */   
/*     */   public static MapperMethod getMapperMethod(ASTNode node, IMethod method)
/*     */   {
/*  85 */     if (method == null) {
/*  86 */       return null;
/*     */     }
/*  88 */     StatementVisitor visitor = new StatementVisitor(method);
/*  89 */     node.accept(visitor);
/*  90 */     return visitor.getMapperMethod();
/*     */   }
/*     */   
/*     */ 
/*     */   private static class StatementVisitor
/*     */     extends ASTVisitor
/*     */   {
/*     */     private IMethod targetMethod;
/*     */     private MapperMethod mapperMethod;
/*     */     private int nestLevel;
/*     */     
/*     */     public StatementVisitor(IMethod targetMethod)
/*     */     {
/* 103 */       this.targetMethod = targetMethod;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean visit(TypeDeclaration node)
/*     */     {
/* 109 */       String targetType = this.targetMethod.getDeclaringType()
/* 110 */         .getFullyQualifiedName()
/* 111 */         .replace('$', '.');
/* 112 */       String currentType = node.resolveBinding().getQualifiedName();
/* 113 */       if (targetType.equals(currentType)) {
/* 114 */         this.nestLevel = 1;
/* 115 */       } else if (this.nestLevel > 0) {
/* 116 */         this.nestLevel += 1;
/*     */       }
/* 118 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean visit(AnonymousClassDeclaration node)
/*     */     {
/* 124 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean visit(MethodDeclaration node)
/*     */     {
/* 130 */       if (this.nestLevel != 1)
/* 131 */         return false;
/* 132 */       if (this.targetMethod.getElementName().equals(node.getName().getFullyQualifiedName()))
/*     */       {
/* 134 */         IMethod method = (IMethod)node.resolveBinding().getJavaElement();
/* 135 */         if (this.targetMethod.isSimilar(method))
/*     */         {
/* 137 */           this.mapperMethod = new MapperMethod();
/* 138 */           this.mapperMethod.setMethodDeclaration(node);
/* 139 */           return true;
/*     */         }
/*     */       }
/* 142 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */     public boolean visit(SingleMemberAnnotation node)
/*     */     {
/* 148 */       if (this.nestLevel != 1)
/* 149 */         return false;
/* 150 */       String typeFqn = node.resolveTypeBinding().getQualifiedName();
/* 151 */       if (("org.apache.ibatis.annotations.Select".equals(typeFqn)) || 
/* 152 */         ("org.apache.ibatis.annotations.Update".equals(typeFqn)) || 
/* 153 */         ("org.apache.ibatis.annotations.Insert".equals(typeFqn)) || 
/* 154 */         ("org.apache.ibatis.annotations.Delete".equals(typeFqn)))
/*     */       {
/* 156 */         Expression value = node.getValue();
/* 157 */         int valueType = value.getNodeType();
/* 158 */         if (valueType == 45)
/*     */         {
/* 160 */           this.mapperMethod.setStatement(((StringLiteral)value).getLiteralValue());
/*     */         }
/* 162 */         else if (valueType == 4)
/*     */         {
/* 164 */           StringBuilder buffer = new StringBuilder();
/*     */           
/* 166 */           List<Expression> expressions = ((ArrayInitializer)value).expressions();
/* 167 */           for (Expression expression : expressions)
/*     */           {
/* 169 */             int expressionType = expression.getNodeType();
/* 170 */             if (expressionType == 45)
/*     */             {
/* 172 */               if (buffer.length() > 0)
/* 173 */                 buffer.append(' ');
/* 174 */               buffer.append(((StringLiteral)expression).getLiteralValue());
/*     */             }
/* 176 */             else if (expressionType == 27)
/*     */             {
/* 178 */               buffer.append(parseInfixExpression((InfixExpression)expression));
/*     */             }
/*     */           }
/* 181 */           this.mapperMethod.setStatement(buffer.toString());
/*     */         }
/* 183 */         else if (valueType == 27)
/*     */         {
/* 185 */           this.mapperMethod.setStatement(parseInfixExpression((InfixExpression)value));
/*     */         }
/*     */       }
/* 188 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */     private String parseInfixExpression(InfixExpression expression)
/*     */     {
/* 194 */       return expression.toString();
/*     */     }
/*     */     
/*     */ 
/*     */     public void endVisit(TypeDeclaration node)
/*     */     {
/* 200 */       this.nestLevel -= 1;
/*     */     }
/*     */     
/*     */     public MapperMethod getMapperMethod()
/*     */     {
/* 205 */       return this.mapperMethod;
/*     */     }
/*     */   }
/*     */   
/*     */   public static CompilationUnit getAstNode(ICompilationUnit compilationUnit)
/*     */   {
/* 211 */     ASTParser parser = ASTParser.newParser(4);
/* 212 */     parser.setSource(compilationUnit);
/* 213 */     parser.setKind(8);
/* 214 */     parser.setResolveBindings(true);
/* 215 */     return (CompilationUnit)parser.createAST(new NullProgressMonitor());
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\JavaMapperUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */