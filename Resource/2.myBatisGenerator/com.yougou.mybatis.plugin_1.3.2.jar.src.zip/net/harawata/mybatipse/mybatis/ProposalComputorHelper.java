/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import net.harawata.mybatipse.bean.BeanPropertyCache;
/*     */ import net.harawata.mybatipse.bean.JavaCompletionProposal;
/*     */ import net.harawata.mybatipse.util.NameUtil;
/*     */ import net.harawata.mybatipse.util.XpathUtil;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.jdt.core.Flags;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.core.compiler.CharOperation;
/*     */ import org.eclipse.jdt.core.search.IJavaSearchScope;
/*     */ import org.eclipse.jdt.core.search.SearchEngine;
/*     */ import org.eclipse.jdt.core.search.TypeNameRequestor;
/*     */ import org.eclipse.jface.text.contentassist.CompletionProposal;
/*     */ import org.eclipse.jface.text.contentassist.ICompletionProposal;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProposalComputorHelper
/*     */ {
/*     */   public static List<ICompletionProposal> proposeReference(IJavaProject project, Document domDoc, String matchString, int start, int length, String targetElement)
/*     */   {
/*  54 */     List<ICompletionProposal> results = new ArrayList();
/*     */     try
/*     */     {
/*  57 */       int lastDot = matchString.lastIndexOf('.');
/*  58 */       if (lastDot == -1)
/*     */       {
/*  60 */         char[] matchChrs = matchString.toCharArray();
/*  61 */         NodeList nodes = XpathUtil.xpathNodes(domDoc, "//" + targetElement + "/@id");
/*  62 */         results.addAll(proposalFromNodes(nodes, null, matchChrs, start, length));
/*  63 */         results.addAll(proposeNamespace(project, domDoc, "", matchChrs, start, length));
/*     */       }
/*     */       else
/*     */       {
/*  67 */         String namespace = matchString.substring(0, lastDot);
/*  68 */         char[] matchChrs = matchString.substring(lastDot + 1).toCharArray();
/*  69 */         IFile mapperFile = MapperNamespaceCache.getInstance().get(project, namespace, null);
/*  70 */         if (mapperFile != null)
/*     */         {
/*  72 */           Document mapperDoc = MybatipseXmlUtil.getMapperDocument(mapperFile);
/*  73 */           if (mapperDoc != null)
/*     */           {
/*  75 */             NodeList nodes = XpathUtil.xpathNodes(mapperDoc, "//" + targetElement + "/@id");
/*  76 */             results.addAll(proposalFromNodes(nodes, namespace, matchChrs, start, length));
/*     */           }
/*  78 */           results.addAll(proposeNamespace(project, domDoc, namespace, matchChrs, start, length));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (XPathExpressionException e)
/*     */     {
/*  84 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*  86 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */   private static List<ICompletionProposal> proposalFromNodes(NodeList nodes, String namespace, char[] matchChrs, int start, int length)
/*     */   {
/*  92 */     List<ICompletionProposal> results = new ArrayList();
/*  93 */     for (int j = 0; j < nodes.getLength(); j++)
/*     */     {
/*  95 */       String id = nodes.item(j).getNodeValue();
/*  96 */       if ((matchChrs.length == 0) || (CharOperation.camelCaseMatch(matchChrs, id.toCharArray())))
/*     */       {
/*  98 */         StringBuilder replacementStr = new StringBuilder();
/*  99 */         if ((namespace != null) && (namespace.length() > 0))
/* 100 */           replacementStr.append(namespace).append('.');
/* 101 */         replacementStr.append(id);
/* 102 */         int cursorPos = replacementStr.length();
/* 103 */         ICompletionProposal proposal = new JavaCompletionProposal(replacementStr.toString(), 
/* 104 */           start, length, cursorPos, Activator.getIcon(), id, null, null, 200);
/* 105 */         results.add(proposal);
/*     */       }
/*     */     }
/* 108 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */   private static List<? extends ICompletionProposal> proposeNamespace(IJavaProject project, Document domDoc, String partialNamespace, char[] matchChrs, int start, int length)
/*     */   {
/* 114 */     List<ICompletionProposal> results = new ArrayList();
/*     */     try
/*     */     {
/* 117 */       String currentNamespace = XpathUtil.xpathString(domDoc, "//mapper/@namespace");
/*     */       
/*     */ 
/* 120 */       Iterator localIterator = MapperNamespaceCache.getInstance().getCacheMap(project, null).keySet().iterator();
/* 118 */       while (localIterator.hasNext())
/*     */       {
/* 120 */         String namespace = (String)localIterator.next();
/*     */         
/* 122 */         if ((!namespace.equals(currentNamespace)) && (namespace.startsWith(partialNamespace)) && 
/* 123 */           (!namespace.equals(partialNamespace)))
/*     */         {
/* 125 */           char[] simpleName = CharOperation.lastSegment(namespace.toCharArray(), '.');
/* 126 */           if ((matchChrs.length == 0) || (CharOperation.camelCaseMatch(matchChrs, simpleName)))
/*     */           {
/* 128 */             StringBuilder replacementStr = new StringBuilder().append(namespace).append('.');
/* 129 */             int cursorPos = replacementStr.length();
/* 130 */             String displayString = simpleName + 
/* 131 */               " - " + 
/* 132 */               namespace;
/*     */             
/* 134 */             results.add(new JavaCompletionProposal(replacementStr.toString(), start, length, 
/* 135 */               cursorPos, Activator.getIcon("/icons/mybatis-ns.png"), displayString, null, null, 
/* 136 */               100));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (XPathExpressionException e)
/*     */     {
/* 143 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/* 145 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */   public static List<ICompletionProposal> proposeOptionName(int offset, int length, String matchString)
/*     */   {
/* 151 */     List<ICompletionProposal> proposals = new ArrayList();
/* 152 */     String[] arrayOfString; int j = (arrayOfString = ExpressionProposalParser.options).length; for (int i = 0; i < j; i++) { String option = arrayOfString[i];
/*     */       
/* 154 */       if ((matchString.length() == 0) || 
/* 155 */         (CharOperation.camelCaseMatch(matchString.toCharArray(), option.toCharArray())))
/*     */       {
/* 157 */         String replacementString = option + "=";
/* 158 */         proposals.add(new CompletionProposal(replacementString, offset, length, 
/* 159 */           replacementString.length(), Activator.getIcon(), option, null, null));
/*     */       }
/*     */     }
/* 162 */     return proposals;
/*     */   }
/*     */   
/*     */ 
/*     */   public static List<ICompletionProposal> proposeJdbcType(int offset, int length, String matchString)
/*     */   {
/* 168 */     List<ICompletionProposal> proposals = new ArrayList();
/* 169 */     String[] arrayOfString; int j = (arrayOfString = ExpressionProposalParser.jdbcTypes).length; for (int i = 0; i < j; i++) { String jdbcType = arrayOfString[i];
/*     */       
/* 171 */       if ((matchString.length() == 0) || 
/* 172 */         (CharOperation.prefixEquals(matchString.toCharArray(), jdbcType.toCharArray(), false)))
/*     */       {
/* 174 */         proposals.add(new CompletionProposal(jdbcType, offset, length, jdbcType.length(), 
/* 175 */           Activator.getIcon(), null, null, null));
/*     */       }
/*     */     }
/* 178 */     return proposals;
/*     */   }
/*     */   
/*     */ 
/*     */   public static List<ICompletionProposal> proposeJavaType(IJavaProject project, final int start, final int length, boolean includeAlias, String matchString)
/*     */   {
/* 184 */     List<ICompletionProposal> proposals = new ArrayList();
/* 185 */     if (includeAlias)
/*     */     {
/* 187 */       Map<String, String> aliasMap = TypeAliasCache.getInstance().searchTypeAliases(project, 
/* 188 */         matchString);
/* 189 */       for (Map.Entry<String, String> entry : aliasMap.entrySet())
/*     */       {
/* 191 */         String qualifiedName = (String)entry.getKey();
/* 192 */         String alias = (String)entry.getValue();
/* 193 */         proposals.add(new JavaCompletionProposal(alias, start, length, alias.length(), 
/* 194 */           Activator.getIcon("/icons/mybatis-alias.png"), alias + " - " + qualifiedName, null, 
/* 195 */           null, 200));
/*     */       }
/*     */     }
/*     */     
/* 199 */     int includeMask = 9;
/*     */     
/* 201 */     boolean pkgSpecified = (matchString != null) && (matchString.indexOf('.') > 0);
/* 202 */     if (pkgSpecified)
/* 203 */       includeMask |= 0x2;
/* 204 */     IJavaSearchScope scope = SearchEngine.createJavaSearchScope(new IJavaProject[] {
/* 205 */       project }, 
/* 206 */       includeMask);
/* 207 */     TypeNameRequestor requestor = new JavaTypeNameRequestor()
/*     */     {
/*     */ 
/*     */       public void acceptType(int modifiers, char[] packageName, char[] simpleTypeName, char[][] enclosingTypeNames, String path)
/*     */       {
/*     */ 
/* 213 */         if ((Flags.isAbstract(modifiers)) || (Flags.isInterface(modifiers))) {
/* 214 */           return;
/*     */         }
/* 216 */         addJavaTypeProposal(ProposalComputorHelper.this, start, length, packageName, simpleTypeName, 
/* 217 */           enclosingTypeNames);
/*     */       }
/*     */     };
/*     */     try
/*     */     {
/* 222 */       searchJavaType(matchString, scope, requestor);
/*     */     }
/*     */     catch (JavaModelException e)
/*     */     {
/* 226 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/* 228 */     return proposals;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static List<ICompletionProposal> proposeParameters(IJavaProject project, int offset, int length, Map<String, String> paramMap, boolean searchReadable, String matchString)
/*     */   {
/* 235 */     List<ICompletionProposal> proposals = new ArrayList();
/* 236 */     if (paramMap.size() == 1)
/*     */     {
/*     */ 
/*     */ 
/* 240 */       String paramType = (String)paramMap.values().iterator().next();
/* 241 */       proposals = proposePropertyFor(project, offset, length, paramType, searchReadable, -1, 
/* 242 */         matchString);
/*     */     }
/* 244 */     else if (paramMap.size() > 1)
/*     */     {
/* 246 */       int dotPos = matchString.indexOf('.');
/* 247 */       if (dotPos == -1)
/*     */       {
/* 249 */         for (Map.Entry<String, String> paramEntry : paramMap.entrySet())
/*     */         {
/* 251 */           String paramName = (String)paramEntry.getKey();
/* 252 */           if ((matchString.length() == 0) || 
/* 253 */             (CharOperation.camelCaseMatch(matchString.toCharArray(), paramName.toCharArray())))
/*     */           {
/* 255 */             String displayStr = paramName + " - " + (String)paramEntry.getValue();
/* 256 */             proposals.add(new CompletionProposal(paramName, offset, length, paramName.length(), 
/* 257 */               Activator.getIcon(), displayStr, null, null));
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 263 */         String paramName = matchString.substring(0, dotPos);
/* 264 */         String qualifiedName = (String)paramMap.get(paramName);
/* 265 */         if (qualifiedName != null)
/*     */         {
/* 267 */           proposals = proposePropertyFor(project, offset, length, qualifiedName, 
/* 268 */             searchReadable, dotPos, matchString);
/*     */         }
/*     */       }
/*     */     }
/* 272 */     return proposals;
/*     */   }
/*     */   
/*     */   public static void searchJavaType(String matchString, IJavaSearchScope scope, TypeNameRequestor requestor)
/*     */     throws JavaModelException
/*     */   {
/* 278 */     char[] searchPkg = (char[])null;
/* 279 */     char[] searchType = (char[])null;
/* 280 */     if ((matchString != null) && (matchString.length() > 0))
/*     */     {
/* 282 */       char[] match = matchString.toCharArray();
/* 283 */       int lastDotPos = matchString.lastIndexOf('.');
/* 284 */       if (lastDotPos == -1)
/*     */       {
/* 286 */         searchType = match;
/*     */       }
/*     */       else
/*     */       {
/* 290 */         if (lastDotPos + 1 < match.length)
/*     */         {
/* 292 */           searchType = CharOperation.lastSegment(match, '.');
/*     */         }
/* 294 */         searchPkg = Arrays.copyOfRange(match, 0, lastDotPos);
/*     */       }
/*     */     }
/* 297 */     SearchEngine searchEngine = new SearchEngine();
/* 298 */     searchEngine.searchAllTypeNames(searchPkg, 1, searchType, 
/* 299 */       128, 5, scope, requestor, 
/* 300 */       3, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public static List<ICompletionProposal> proposeTypeHandler(IJavaProject project, final int start, final int length, String matchString)
/*     */   {
/*     */     try
/*     */     {
/* 308 */       List<ICompletionProposal> results = new ArrayList();
/*     */       
/*     */ 
/* 311 */       IType typeHandler = project.findType("org.apache.ibatis.type.TypeHandler");
/* 312 */       if (typeHandler == null)
/* 313 */         return Collections.emptyList();
/* 314 */       final Map<String, String> aliasMap = TypeAliasCache.getInstance().searchTypeAliases(
/* 315 */         project, matchString);
/* 316 */       IJavaSearchScope scope = SearchEngine.createStrictHierarchyScope(project, typeHandler, true, false, null);
/* 317 */       TypeNameRequestor requestor = new JavaTypeNameRequestor()
/*     */       {
/*     */ 
/*     */ 
/*     */         public void acceptType(int modifiers, char[] packageName, char[] simpleTypeName, char[][] enclosingTypeNames, String path)
/*     */         {
/*     */ 
/* 324 */           if (Flags.isAbstract(modifiers)) {
/* 325 */             return;
/*     */           }
/* 327 */           addJavaTypeProposal(ProposalComputorHelper.this, start, length, packageName, simpleTypeName, 
/* 328 */             enclosingTypeNames);
/*     */           
/* 330 */           String qualifiedName = NameUtil.buildQualifiedName(packageName, simpleTypeName, 
/* 331 */             enclosingTypeNames, true);
/* 332 */           String alias = (String)aliasMap.get(qualifiedName);
/* 333 */           if (alias != null)
/*     */           {
/* 335 */             ProposalComputorHelper.this.add(new JavaCompletionProposal(alias, start, length, alias.length(), 
/* 336 */               Activator.getIcon("/icons/mybatis-alias.png"), alias + " - " + qualifiedName, 
/* 337 */               null, null, 200));
/*     */           }
/*     */         }
/* 340 */       };
/* 341 */       searchJavaType(matchString, scope, requestor);
/* 342 */       return results;
/*     */     }
/*     */     catch (JavaModelException e)
/*     */     {
/* 346 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/* 348 */     return Collections.emptyList();
/*     */   }
/*     */   
/*     */ 
/*     */   public static List<ICompletionProposal> proposeCacheType(IJavaProject project, final int start, final int length, String matchString)
/*     */   {
/* 354 */     List<ICompletionProposal> results = new ArrayList();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 359 */       IType cache = project.findType("org.apache.ibatis.cache.Cache");
/* 360 */       if (cache == null)
/* 361 */         return results;
/* 362 */       IJavaSearchScope scope = SearchEngine.createHierarchyScope(cache);
/* 363 */       TypeNameRequestor requestor = new JavaTypeNameRequestor()
/*     */       {
/*     */ 
/*     */ 
/*     */         public void acceptType(int modifiers, char[] packageName, char[] simpleTypeName, char[][] enclosingTypeNames, String path)
/*     */         {
/*     */ 
/* 370 */           if (Flags.isAbstract(modifiers)) {
/* 371 */             return;
/*     */           }
/* 373 */           addJavaTypeProposal(ProposalComputorHelper.this, start, length, packageName, simpleTypeName, 
/* 374 */             enclosingTypeNames);
/*     */         }
/* 376 */       };
/* 377 */       searchJavaType(matchString, scope, requestor);
/*     */     }
/*     */     catch (JavaModelException e)
/*     */     {
/* 381 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/* 383 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */   public static List<ICompletionProposal> proposePropertyFor(IJavaProject project, int offset, int length, String qualifiedName, boolean searchReadable, int currentIdx, String matchString)
/*     */   {
/* 389 */     if (MybatipseXmlUtil.isDefaultTypeAlias(qualifiedName))
/* 390 */       return Collections.emptyList();
/* 391 */     Map<String, String> fields = BeanPropertyCache.searchFields(project, qualifiedName, 
/* 392 */       matchString, searchReadable, currentIdx, false);
/* 393 */     return BeanPropertyCache.buildFieldNameProposal(fields, matchString, offset, length);
/*     */   }
/*     */   
/*     */   static abstract class JavaTypeNameRequestor extends TypeNameRequestor
/*     */   {
/* 398 */     private int relevance = 100;
/*     */     
/*     */ 
/*     */ 
/*     */     protected void addJavaTypeProposal(List<ICompletionProposal> results, int start, int length, char[] packageName, char[] simpleTypeName, char[][] enclosingTypeNames)
/*     */     {
/* 404 */       String typeFqn = NameUtil.buildQualifiedName(packageName, simpleTypeName, 
/* 405 */         enclosingTypeNames, true);
/* 406 */       String displayStr = simpleTypeName + 
/* 407 */         " - " + 
/* 408 */         packageName;
/*     */       
/* 410 */       results.add(new JavaCompletionProposal(typeFqn, start, length, typeFqn.length(), 
/* 411 */         Activator.getIcon(), displayStr, null, null, this.relevance));
/*     */     }
/*     */     
/*     */     protected JavaTypeNameRequestor init(int relevance)
/*     */     {
/* 416 */       this.relevance = relevance;
/* 417 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\ProposalComputorHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */