/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import net.harawata.mybatipse.util.NameUtil;
/*     */ import net.harawata.mybatipse.util.XpathUtil;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IMarker;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IProgressMonitor;
/*     */ import org.eclipse.core.runtime.NullProgressMonitor;
/*     */ import org.eclipse.core.runtime.OperationCanceledException;
/*     */ import org.eclipse.jdt.core.IField;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IMethod;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.ITypeHierarchy;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.wst.sse.core.StructuredModelManager;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.IModelManager;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.IStructuredModel;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.text.IStructuredDocument;
/*     */ import org.eclipse.wst.validation.AbstractValidator;
/*     */ import org.eclipse.wst.validation.ValidationResult;
/*     */ import org.eclipse.wst.validation.ValidationState;
/*     */ import org.eclipse.wst.validation.internal.provisional.core.IReporter;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMAttr;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMDocument;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMElement;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMModel;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlValidator
/*     */   extends AbstractValidator
/*     */ {
/*     */   public static final String MARKER_ID = "net.harawata.mybatipse.XmlProblem";
/*     */   public static final String MISSING_TYPE = "missingType";
/*     */   public static final String NO_WRITABLE_PROPERTY = "noWritableProperty";
/*     */   public static final String MISSING_TYPE_HANDLER = "missingTypeHandler";
/*     */   public static final String MISSING_STATEMENT_METHOD = "missingStatementMethod";
/*     */   public static final String MISSING_RESULT_MAP = "missingResultMap";
/*     */   public static final String MISSING_SQL = "missingSql";
/*     */   public static final String MISSING_NAMESPACE = "missingNamespace";
/*     */   public static final String NAMESPACE_MANDATORY = "namespaceMandatory";
/*     */   public static final String DEPRECATED = "deprecated";
/*  85 */   private static final List<String> validatableTags = Arrays.asList(new String[] { "id", "idArg", "result", "arg", "resultMap", "collection", "association", "select", "insert", "update", "delete", "include", "cache", "typeAlias", "typeHandler", "objectFactory", "objectWrapperFactory", "plugin", "transactionManager", "mapper", "package", "databaseIdProvider" });
/*     */   
/*     */ 
/*     */ 
/*     */   public void cleanup(IReporter reporter) {}
/*     */   
/*     */ 
/*     */   public ValidationResult validate(IResource resource, int kind, ValidationState state, IProgressMonitor monitor)
/*     */   {
/*  94 */     if (resource.getType() != 1)
/*  95 */       return null;
/*  96 */     ValidationResult result = new ValidationResult();
/*  97 */     IReporter reporter = result.getReporter(monitor);
/*  98 */     validateFile((IFile)resource, reporter, result);
/*  99 */     return result;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void validateFile(IFile file, IReporter reporter, ValidationResult result)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_2
/*     */     //   1: ifnull +20 -> 21
/*     */     //   4: aload_2
/*     */     //   5: invokeinterface 140 1 0
/*     */     //   10: ifeq +11 -> 21
/*     */     //   13: new 146	org/eclipse/core/runtime/OperationCanceledException
/*     */     //   16: dup
/*     */     //   17: invokespecial 148	org/eclipse/core/runtime/OperationCanceledException:<init>	()V
/*     */     //   20: athrow
/*     */     //   21: aconst_null
/*     */     //   22: astore 4
/*     */     //   24: aload_1
/*     */     //   25: ldc 8
/*     */     //   27: iconst_0
/*     */     //   28: iconst_0
/*     */     //   29: invokeinterface 149 4 0
/*     */     //   34: invokestatic 153	org/eclipse/wst/sse/core/StructuredModelManager:getModelManager	()Lorg/eclipse/wst/sse/core/internal/provisional/IModelManager;
/*     */     //   37: aload_1
/*     */     //   38: invokeinterface 159 2 0
/*     */     //   43: astore 4
/*     */     //   45: aload 4
/*     */     //   47: checkcast 165	org/eclipse/wst/xml/core/internal/provisional/document/IDOMModel
/*     */     //   50: astore 5
/*     */     //   52: aload 5
/*     */     //   54: invokeinterface 167 1 0
/*     */     //   59: astore 6
/*     */     //   61: aload 6
/*     */     //   63: invokeinterface 171 1 0
/*     */     //   68: astore 7
/*     */     //   70: aload_1
/*     */     //   71: invokeinterface 177 1 0
/*     */     //   76: invokestatic 181	org/eclipse/jdt/core/JavaCore:create	(Lorg/eclipse/core/resources/IProject;)Lorg/eclipse/jdt/core/IJavaProject;
/*     */     //   79: astore 8
/*     */     //   81: iconst_0
/*     */     //   82: istore 9
/*     */     //   84: goto +41 -> 125
/*     */     //   87: aload 7
/*     */     //   89: iload 9
/*     */     //   91: invokeinterface 187 2 0
/*     */     //   96: astore 10
/*     */     //   98: aload 10
/*     */     //   100: instanceof 193
/*     */     //   103: ifeq +19 -> 122
/*     */     //   106: aload_0
/*     */     //   107: aload 8
/*     */     //   109: aload 10
/*     */     //   111: checkcast 193	org/eclipse/wst/xml/core/internal/provisional/document/IDOMElement
/*     */     //   114: aload_1
/*     */     //   115: aload 6
/*     */     //   117: aload_2
/*     */     //   118: aload_3
/*     */     //   119: invokespecial 195	net/harawata/mybatipse/mybatis/XmlValidator:validateElement	(Lorg/eclipse/jdt/core/IJavaProject;Lorg/eclipse/wst/xml/core/internal/provisional/document/IDOMElement;Lorg/eclipse/core/resources/IFile;Lorg/eclipse/wst/xml/core/internal/provisional/document/IDOMDocument;Lorg/eclipse/wst/validation/internal/provisional/core/IReporter;Lorg/eclipse/wst/validation/ValidationResult;)V
/*     */     //   122: iinc 9 1
/*     */     //   125: iload 9
/*     */     //   127: aload 7
/*     */     //   129: invokeinterface 199 1 0
/*     */     //   134: if_icmplt -47 -> 87
/*     */     //   137: goto +45 -> 182
/*     */     //   140: astore 5
/*     */     //   142: iconst_2
/*     */     //   143: ldc -54
/*     */     //   145: aload 5
/*     */     //   147: invokestatic 204	net/harawata/mybatipse/Activator:log	(ILjava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   150: aload 4
/*     */     //   152: ifnull +42 -> 194
/*     */     //   155: aload 4
/*     */     //   157: invokeinterface 210 1 0
/*     */     //   162: goto +32 -> 194
/*     */     //   165: astore 11
/*     */     //   167: aload 4
/*     */     //   169: ifnull +10 -> 179
/*     */     //   172: aload 4
/*     */     //   174: invokeinterface 210 1 0
/*     */     //   179: aload 11
/*     */     //   181: athrow
/*     */     //   182: aload 4
/*     */     //   184: ifnull +10 -> 194
/*     */     //   187: aload 4
/*     */     //   189: invokeinterface 210 1 0
/*     */     //   194: return
/*     */     // Line number table:
/*     */     //   Java source line #104	-> byte code offset #0
/*     */     //   Java source line #105	-> byte code offset #13
/*     */     //   Java source line #107	-> byte code offset #21
/*     */     //   Java source line #109	-> byte code offset #24
/*     */     //   Java source line #110	-> byte code offset #34
/*     */     //   Java source line #111	-> byte code offset #37
/*     */     //   Java source line #110	-> byte code offset #38
/*     */     //   Java source line #112	-> byte code offset #45
/*     */     //   Java source line #113	-> byte code offset #52
/*     */     //   Java source line #114	-> byte code offset #61
/*     */     //   Java source line #116	-> byte code offset #70
/*     */     //   Java source line #118	-> byte code offset #81
/*     */     //   Java source line #119	-> byte code offset #87
/*     */     //   Java source line #120	-> byte code offset #98
/*     */     //   Java source line #121	-> byte code offset #106
/*     */     //   Java source line #122	-> byte code offset #117
/*     */     //   Java source line #121	-> byte code offset #119
/*     */     //   Java source line #118	-> byte code offset #122
/*     */     //   Java source line #125	-> byte code offset #140
/*     */     //   Java source line #126	-> byte code offset #142
/*     */     //   Java source line #127	-> byte code offset #145
/*     */     //   Java source line #126	-> byte code offset #147
/*     */     //   Java source line #129	-> byte code offset #150
/*     */     //   Java source line #130	-> byte code offset #155
/*     */     //   Java source line #128	-> byte code offset #165
/*     */     //   Java source line #129	-> byte code offset #167
/*     */     //   Java source line #130	-> byte code offset #172
/*     */     //   Java source line #132	-> byte code offset #179
/*     */     //   Java source line #129	-> byte code offset #182
/*     */     //   Java source line #130	-> byte code offset #187
/*     */     //   Java source line #133	-> byte code offset #194
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	195	0	this	XmlValidator
/*     */     //   0	195	1	file	IFile
/*     */     //   0	195	2	reporter	IReporter
/*     */     //   0	195	3	result	ValidationResult
/*     */     //   22	166	4	model	IStructuredModel
/*     */     //   50	3	5	domModel	IDOMModel
/*     */     //   140	6	5	e	Exception
/*     */     //   59	57	6	domDoc	IDOMDocument
/*     */     //   68	60	7	nodes	NodeList
/*     */     //   79	29	8	project	IJavaProject
/*     */     //   82	44	9	k	int
/*     */     //   96	14	10	child	Node
/*     */     //   165	15	11	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   24	137	140	java/lang/Exception
/*     */     //   24	150	165	finally
/*     */   }
/*     */   
/*     */   private void validateElement(IJavaProject project, IDOMElement element, IFile file, IDOMDocument doc, IReporter reporter, ValidationResult result)
/*     */     throws JavaModelException, XPathExpressionException
/*     */   {
/* 139 */     if ((reporter != null) && (reporter.isCancelled())) {
/* 140 */       throw new OperationCanceledException();
/*     */     }
/* 142 */     if (element == null) {
/* 143 */       return;
/*     */     }
/* 145 */     String tagName = element.getNodeName();
/*     */     
/* 147 */     if (validatableTags.contains(tagName)) {
/* 148 */       NamedNodeMap attrs = element.getAttributes();
/* 149 */       for (int i = 0; i < attrs.getLength(); i++) {
/* 150 */         IDOMAttr attr = (IDOMAttr)attrs.item(i);
/* 151 */         String attrName = attr.getName();
/* 152 */         String attrValue = attr.getValue().trim();
/*     */         
/*     */ 
/* 155 */         if ((("type".equals(attrName)) && (!"dataSource".equals(tagName))) || 
/* 156 */           ("resultType".equals(attrName)) || 
/* 157 */           ("parameterType".equals(attrName)) || 
/* 158 */           ("ofType".equals(attrName)) || 
/* 159 */           ("typeHandler".equals(attrName)) || 
/* 160 */           ("handler".equals(attrName)) || 
/* 161 */           ("interceptor".equals(attrName)) || 
/* 162 */           ("class".equals(attrName))) {
/* 163 */           String qualifiedName = 
/* 164 */             MybatipseXmlUtil.normalizeTypeName(attrValue);
/*     */           
/* 166 */           validateJavaType(project, file, doc, attr, qualifiedName, 
/* 167 */             result, reporter);
/* 168 */         } else if ("property".equals(attrName)) {
/* 169 */           validateProperty(element, file, doc, result, project, attr, 
/* 170 */             attrValue, reporter);
/* 171 */         } else if (("id".equals(attrName)) && (
/* 172 */           ("select".equals(tagName)) || 
/* 173 */           ("update".equals(tagName)) || 
/* 174 */           ("insert".equals(tagName)) || 
/* 175 */           ("delete".equals(tagName)))) {
/* 176 */           validateStatementId(element, file, doc, result, project, 
/* 177 */             attr, attrValue);
/* 178 */         } else if (("resultMap".equals(attrName)) || 
/* 179 */           ("resultMap".equals(attrName))) {
/* 180 */           validateResultMapId(project, file, doc, result, attr, 
/* 181 */             attrValue, reporter);
/* 182 */         } else if ("refid".equals(attrName)) {
/* 183 */           validateSqlId(project, file, doc, result, attr, attrValue, 
/* 184 */             reporter);
/* 185 */         } else if ("select".equals(attrName)) {
/* 186 */           validateSelectId(project, file, doc, result, attr, 
/* 187 */             attrValue, reporter);
/* 188 */         } else if ("namespace".equals(attrName)) {
/* 189 */           validateNamespace(file, doc, result, attr, attrValue);
/* 190 */         } else if ("parameterMap".equals(tagName)) {
/* 191 */           warnDeprecated(file, doc, result, tagName, attr);
/* 192 */         } else if (("parameter".equals(attrName)) || 
/* 193 */           ("parameterMap".equals(attrName))) {
/* 194 */           warnDeprecated(file, doc, result, attrName, attr);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 199 */     NodeList nodes = element.getChildNodes();
/* 200 */     for (int j = 0; j < nodes.getLength(); j++) {
/* 201 */       Node child = nodes.item(j);
/* 202 */       if ((child instanceof IDOMElement)) {
/* 203 */         validateElement(project, (IDOMElement)child, file, doc, 
/* 204 */           reporter, result);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateNamespace(IFile file, IDOMDocument doc, ValidationResult result, IDOMAttr attr, String attrValue)
/*     */   {
/* 211 */     if ((attrValue == null) || (attrValue.length() == 0)) {
/* 212 */       addMarker(result, file, doc.getStructuredDocument(), attr, 
/* 213 */         "namespaceMandatory", 2, 
/* 214 */         2, "Namespace must be specified.");
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateResultMapId(IJavaProject project, IFile file, IDOMDocument doc, ValidationResult result, IDOMAttr attr, String attrValue, IReporter reporter)
/*     */     throws JavaModelException
/*     */   {
/* 221 */     if (attrValue.indexOf(',') == -1) {
/* 222 */       validateReference(project, file, doc, result, attr, attrValue, 
/* 223 */         "resultMap", reporter);
/*     */     } else {
/* 225 */       String[] resultMapArr = attrValue.split(",");
/* 226 */       String[] arrayOfString1; int j = (arrayOfString1 = resultMapArr).length; for (int i = 0; i < j; i++) { String resultMapRef = arrayOfString1[i];
/* 227 */         String ref = resultMapRef.trim();
/* 228 */         if (ref.length() > 0) {
/* 229 */           validateReference(project, file, doc, result, attr, ref, 
/* 230 */             "resultMap", reporter);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void validateSelectId(IJavaProject project, IFile file, IDOMDocument doc, ValidationResult result, IDOMAttr attr, String attrValue, IReporter reporter)
/*     */     throws JavaModelException
/*     */   {
/* 239 */     validateReference(project, file, doc, result, attr, attrValue, 
/* 240 */       "select", reporter);
/*     */   }
/*     */   
/*     */   private void validateSqlId(IJavaProject project, IFile file, IDOMDocument doc, ValidationResult result, IDOMAttr attr, String attrValue, IReporter reporter)
/*     */     throws JavaModelException
/*     */   {
/* 246 */     validateReference(project, file, doc, result, attr, attrValue, "sql", 
/* 247 */       reporter);
/*     */   }
/*     */   
/*     */   private void validateReference(IJavaProject project, IFile file, IDOMDocument doc, ValidationResult result, IDOMAttr attr, String attrValue, String targetElement, IReporter reporter)
/*     */     throws JavaModelException
/*     */   {
/*     */     try
/*     */     {
/* 255 */       if (attrValue.indexOf('$') > -1) {
/* 256 */         return;
/*     */       }
/* 258 */       if (attrValue.indexOf('.') == -1)
/*     */       {
/* 260 */         if ("select".equals(targetElement)) {
/* 261 */           String qualifiedName = MybatipseXmlUtil.getNamespace(doc);
/* 262 */           if (mapperMethodExists(project, qualifiedName, attrValue)) {
/* 263 */             return;
/*     */           }
/*     */         }
/* 266 */         String xpath = "count(//" + targetElement + "[@id='" + 
/* 267 */           attrValue + "']) > 0";
/* 268 */         if (!XpathUtil.xpathBool(doc, xpath)) {
/* 269 */           addMarker(result, file, doc.getStructuredDocument(), attr, 
/* 270 */             "missingSql", 2, 
/* 271 */             2, targetElement + " with id='" + 
/* 272 */             attrValue + "' not found.");
/*     */         }
/*     */       }
/*     */       else {
/* 276 */         int lastDot = attrValue.lastIndexOf('.');
/* 277 */         String namespace = attrValue.substring(0, lastDot);
/* 278 */         String statementId = attrValue.substring(lastDot + 1);
/* 279 */         if (("select".equals(targetElement)) && 
/* 280 */           (mapperMethodExists(project, namespace, statementId))) {
/* 281 */           return;
/*     */         }
/* 283 */         IFile mapperFile = MapperNamespaceCache.getInstance().get(
/* 284 */           project, namespace, reporter);
/* 285 */         if (mapperFile == null) {
/* 286 */           addMarker(result, file, doc.getStructuredDocument(), attr, 
/* 287 */             "missingNamespace", 2, 
/* 288 */             2, "Namespace='" + namespace + 
/* 289 */             "' not found.");
/*     */         } else {
/* 291 */           String xpath = "count(//" + targetElement + "[@id='" + 
/* 292 */             statementId + "']) > 0";
/* 293 */           if (!isElementExists(mapperFile, xpath)) {
/* 294 */             addMarker(result, file, doc.getStructuredDocument(), 
/* 295 */               attr, "missingSql", 2, 
/* 296 */               2, targetElement + 
/* 297 */               " with id='" + attrValue + 
/* 298 */               "' not found.");
/*     */           }
/*     */         }
/*     */       }
/*     */     } catch (XPathExpressionException e) {
/* 303 */       Activator.log(4, "Error while searching sql with id = " + 
/* 304 */         attrValue, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void validateStatementId(IDOMElement element, IFile file, IDOMDocument doc, ValidationResult result, IJavaProject project, IDOMAttr attr, String attrValue)
/*     */     throws JavaModelException, XPathExpressionException
/*     */   {
/* 312 */     if (attrValue == null) {
/* 313 */       return;
/*     */     }
/*     */     
/* 316 */     String qualifiedName = MybatipseXmlUtil.getNamespace(doc);
/* 317 */     if (!mapperMethodExists(project, qualifiedName, attrValue)) {
/* 318 */       addMarker(result, file, doc.getStructuredDocument(), attr, 
/* 319 */         "missingStatementMethod", 1, 
/* 320 */         2, "Method '" + attrValue + 
/* 321 */         "' not found in mapper interface " + 
/* 322 */         qualifiedName);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean mapperMethodExists(IJavaProject project, String qualifiedName, String methodName) throws JavaModelException
/*     */   {
/* 328 */     IType javaMapperType = project.findType(qualifiedName);
/* 329 */     if (javaMapperType == null)
/* 330 */       return false;
/*     */     IMethod[] arrayOfIMethod;
/* 332 */     int j = (arrayOfIMethod = javaMapperType.getMethods()).length; for (int i = 0; i < j; i++) { IMethod method = arrayOfIMethod[i];
/* 333 */       if (methodName.equals(method.getElementName())) {
/* 334 */         return true;
/*     */       }
/*     */     }
/*     */     
/* 338 */     List<IMethod> methods = NameUtil.getAllSuperMethods(null, project, javaMapperType);
/* 339 */     for (IMethod method : methods) {
/* 340 */       if (methodName.equals(method.getElementName()))
/* 341 */         return true;
/*     */     }
/* 343 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateProperty(IDOMElement element, IFile file, IDOMDocument doc, ValidationResult result, IJavaProject project, IDOMAttr attr, String attrValue, IReporter reporter)
/*     */     throws JavaModelException
/*     */   {
/* 375 */     String qualifiedName = MybatipseXmlUtil.findEnclosingType(element);
/* 376 */     IType javaMapperType = project.findType(qualifiedName);
/*     */     
/* 378 */     if (javaMapperType == null) {
/* 379 */       qualifiedName = TypeAliasCache.getInstance().resolveAlias(project, 
/* 380 */         qualifiedName, reporter);
/* 381 */       if (qualifiedName != null)
/* 382 */         javaMapperType = project.findType(qualifiedName);
/*     */     }
/* 384 */     if ((javaMapperType == null) || (!isValidatable(project, javaMapperType))) {
/* 385 */       return;
/*     */     }
/* 387 */     List<IMethod> superMethods = NameUtil.getAllSuperMethods(null, project, javaMapperType);
/* 388 */     Map<String, IField> map = new HashMap();
/* 389 */     Object localObject1; int j = (localObject1 = javaMapperType.getFields()).length; for (int i = 0; i < j; i++) { IField field = localObject1[i];
/* 390 */       map.put(field.getElementName(), field);
/*     */     }
/* 392 */     if (map.get(attrValue) != null)
/*     */     {
/* 394 */       Map<String, IMethod> mapMethod = new HashMap();
/* 395 */       IMethod[] methods = javaMapperType.getMethods();
/*     */       
/* 397 */       if ((javaMapperType != null) && (methods != null) && (methods.length > 0)) {
/* 398 */         superMethods.addAll(Arrays.asList(methods));
/* 399 */         for (localObject1 = superMethods.iterator(); ((Iterator)localObject1).hasNext();) { IMethod method = (IMethod)((Iterator)localObject1).next();
/* 400 */           mapMethod.put(method.getElementName(), method);
/*     */         }
/*     */       }
/*     */       
/* 404 */       validateSetAndGetMethod(file, doc, result, attr, attrValue, 
/* 405 */         qualifiedName, map, mapMethod);
/*     */     }
/*     */     else {
/* 408 */       List<IField> fields = NameUtil.getAllSuperFields(null, project, javaMapperType);
/* 409 */       if ((fields == null) || (fields.size() == 0)) {
/* 410 */         addMarker(result, file, doc.getStructuredDocument(), attr, 
/* 411 */           "missingType", 2, 
/* 412 */           2, "Property '" + attrValue + 
/* 413 */           "' not found in class " + qualifiedName);
/*     */       }
/*     */       else {
/* 416 */         map = new HashMap();
/* 417 */         Object mapMethod = new HashMap();
/* 418 */         for (localObject1 = fields.iterator(); ((Iterator)localObject1).hasNext();) { IField field = (IField)((Iterator)localObject1).next();
/* 419 */           map.put(field.getElementName(), field);
/*     */         }
/* 421 */         if ((javaMapperType != null) && (superMethods != null) && (superMethods.size() > 0)) {
/* 422 */           for (localObject1 = superMethods.iterator(); ((Iterator)localObject1).hasNext();) { IMethod method = (IMethod)((Iterator)localObject1).next();
/* 423 */             ((Map)mapMethod).put(method.getElementName(), method);
/*     */           }
/*     */         }
/* 426 */         if (map.get(attrValue) == null) {
/* 427 */           addMarker(result, file, doc.getStructuredDocument(), attr, 
/* 428 */             "missingType", 2, 
/* 429 */             2, "Property '" + attrValue + 
/* 430 */             "' not found in class " + qualifiedName);
/*     */         } else {
/* 432 */           validateSetAndGetMethod(file, doc, result, attr, attrValue, 
/* 433 */             qualifiedName, map, (Map)mapMethod);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void validateSetAndGetMethod(IFile file, IDOMDocument doc, ValidationResult result, IDOMAttr attr, String attrValue, String qualifiedName, Map<String, IField> map, Map<String, IMethod> mapMethod)
/*     */   {
/* 444 */     String elementName = ((IField)map.get(attrValue)).getElementName();
/* 445 */     String setMethod = 
/* 446 */       "set" + elementName.toUpperCase();
/* 447 */     String getMethod = 
/* 448 */       "get" + elementName.toUpperCase();
/* 449 */     if ((mapMethod == null) || ((mapMethod.get(setMethod) == null) && (mapMethod.get(getMethod) == null))) {
/* 450 */       addMarker(result, file, doc.getStructuredDocument(), attr, 
/* 451 */         "missingType", 2, 
/* 452 */         2, "Property '" + attrValue + 
/* 453 */         "' not found " + setMethod + " method and " + getMethod + " method in class " + qualifiedName);
/* 454 */     } else if ((mapMethod.get(setMethod) == null) && (mapMethod.get(getMethod) != null)) {
/* 455 */       addMarker(result, file, doc.getStructuredDocument(), attr, 
/* 456 */         "missingType", 2, 
/* 457 */         2, "Property '" + attrValue + 
/* 458 */         "' not found " + setMethod + " method in class " + qualifiedName);
/* 459 */     } else if ((mapMethod.get(setMethod) != null) && (mapMethod.get(getMethod) == null)) {
/* 460 */       addMarker(result, file, doc.getStructuredDocument(), attr, 
/* 461 */         "missingType", 2, 
/* 462 */         2, "Property '" + attrValue + 
/* 463 */         "' not found " + getMethod + " method in class " + qualifiedName);
/*     */     } else {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean isValidatable(IJavaProject project, IType type)
/*     */     throws JavaModelException
/*     */   {
/* 472 */     IType map = project.findType("java.util.Map");
/* 473 */     return !isAssignable(type, map);
/*     */   }
/*     */   
/*     */   private boolean isAssignable(IType type, IType targetType) throws JavaModelException
/*     */   {
/* 478 */     ITypeHierarchy supertypes = type
/* 479 */       .newSupertypeHierarchy(new NullProgressMonitor());
/* 480 */     return supertypes.contains(targetType);
/*     */   }
/*     */   
/*     */ 
/*     */   private void validateJavaType(IJavaProject project, IFile file, IDOMDocument doc, IDOMAttr attr, String qualifiedName, ValidationResult result, IReporter reporter)
/*     */     throws JavaModelException
/*     */   {
/* 487 */     if ((!MybatipseXmlUtil.isDefaultTypeAlias(qualifiedName)) && 
/* 488 */       (project.findType(qualifiedName) == null) && 
/* 489 */       (TypeAliasCache.getInstance().resolveAlias(project, 
/* 490 */       qualifiedName, reporter) == null)) {
/* 491 */       addMarker(result, file, doc.getStructuredDocument(), attr, 
/* 492 */         "missingType", 2, 
/* 493 */         2, "Class/TypeAlias '" + qualifiedName + 
/* 494 */         "' not found.");
/*     */     }
/*     */   }
/*     */   
/*     */   private void warnDeprecated(IFile file, IDOMDocument doc, ValidationResult result, String tagName, IDOMAttr attr)
/*     */   {
/* 500 */     addMarker(result, file, doc.getStructuredDocument(), attr, "deprecated", 
/* 501 */       1, 2, "'" + tagName + 
/* 502 */       "' is deprecated and should not be used.");
/*     */   }
/*     */   
/*     */ 
/*     */   private void addMarker(ValidationResult result, IFile file, IStructuredDocument doc, IDOMAttr attr, String problemType, int severity, int priority, String message)
/*     */   {
/* 508 */     int start = attr.getValueRegionStartOffset();
/* 509 */     int length = attr.getValueRegionText().length();
/* 510 */     int lineNo = doc.getLineOfOffset(start);
/*     */     
/*     */     try
/*     */     {
/* 514 */       IMarker marker = file.createMarker("net.harawata.mybatipse.XmlProblem");
/* 515 */       marker.setAttribute("severity", severity);
/* 516 */       marker.setAttribute("priority", priority);
/* 517 */       marker.setAttribute("message", message);
/* 518 */       marker.setAttribute("lineNumber", lineNo);
/* 519 */       if (start != 0) {
/* 520 */         marker.setAttribute("charStart", start);
/* 521 */         marker.setAttribute("charEnd", start + length);
/*     */       }
/*     */       
/* 524 */       marker.setAttribute("problemType", problemType);
/* 525 */       marker.setAttribute("errorValue", attr.getValue());
/*     */     }
/*     */     catch (CoreException e) {
/* 528 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isElementExists(IFile file, String xpath) {
/* 533 */     IStructuredModel model = null;
/*     */     try {
/* 535 */       model = StructuredModelManager.getModelManager().getModelForRead(
/* 536 */         file);
/* 537 */       IDOMModel domModel = (IDOMModel)model;
/* 538 */       IDOMDocument domDoc = domModel.getDocument();
/*     */       
/* 540 */       return XpathUtil.xpathBool(domDoc, xpath);
/*     */     } catch (Exception e) {
/* 542 */       Activator.log(4, "Error occurred during parsing mapper:" + 
/* 543 */         file.getFullPath(), e);
/*     */     } finally {
/* 545 */       if (model != null) {
/* 546 */         model.releaseFromRead();
/*     */       }
/*     */     }
/* 549 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\XmlValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */