/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import net.harawata.mybatipse.util.XpathUtil;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.jdt.core.IClasspathEntry;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.ui.IEditorInput;
/*     */ import org.eclipse.ui.IEditorPart;
/*     */ import org.eclipse.ui.IWorkbench;
/*     */ import org.eclipse.ui.IWorkbenchPage;
/*     */ import org.eclipse.ui.IWorkbenchWindow;
/*     */ import org.eclipse.ui.PlatformUI;
/*     */ import org.eclipse.ui.part.FileEditorInput;
/*     */ import org.eclipse.wst.sse.core.StructuredModelManager;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.IModelManager;
/*     */ import org.eclipse.wst.sse.core.internal.provisional.IStructuredModel;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMDocument;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMModel;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MybatipseXmlUtil
/*     */ {
/*  75 */   private static final List<String> defaultTypeAliases = Arrays.asList(new String[] { "_byte", "_long", "_short", "_int", "_integer", "_double", "_float", "_boolean", "string", "byte", "long", "short", "int", "integer", "double", "float", "boolean", "date", "decimal", "bigdecimal", "object", "map", "hashmap", "list", "arraylist", "collection", "iterator", "jdbc", "managed", "jndi", "pooled", "unpooled", "perpetual", "fifo", "lru", "soft", "weak", "db_vendor", "xml", "raw", "slf4j", "commons_logging", "log4j", "log4j2", "jdk_logging", "stdout_logging", "no_logging", "cglib", "javassist" });
/*     */   
/*     */   public static boolean isDefaultTypeAlias(String type)
/*     */   {
/*  79 */     return (type != null) && (defaultTypeAliases.contains(type.toLowerCase(Locale.ENGLISH)));
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public static IJavaProject getJavaProject(org.eclipse.jface.text.IDocument document)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_1
/*     */     //   2: aconst_null
/*     */     //   3: astore_2
/*     */     //   4: aconst_null
/*     */     //   5: astore_3
/*     */     //   6: invokestatic 145	org/eclipse/wst/sse/core/StructuredModelManager:getModelManager	()Lorg/eclipse/wst/sse/core/internal/provisional/IModelManager;
/*     */     //   9: aload_0
/*     */     //   10: invokeinterface 151 2 0
/*     */     //   15: astore_1
/*     */     //   16: aload_1
/*     */     //   17: ifnull +28 -> 45
/*     */     //   20: aload_1
/*     */     //   21: invokeinterface 157 1 0
/*     */     //   26: astore_2
/*     */     //   27: goto +18 -> 45
/*     */     //   30: astore 4
/*     */     //   32: aload_1
/*     */     //   33: ifnull +9 -> 42
/*     */     //   36: aload_1
/*     */     //   37: invokeinterface 163 1 0
/*     */     //   42: aload 4
/*     */     //   44: athrow
/*     */     //   45: aload_1
/*     */     //   46: ifnull +9 -> 55
/*     */     //   49: aload_1
/*     */     //   50: invokeinterface 163 1 0
/*     */     //   55: aload_2
/*     */     //   56: ifnull +68 -> 124
/*     */     //   59: invokestatic 166	org/eclipse/core/resources/ResourcesPlugin:getWorkspace	()Lorg/eclipse/core/resources/IWorkspace;
/*     */     //   62: invokeinterface 172 1 0
/*     */     //   67: astore 4
/*     */     //   69: new 178	org/eclipse/core/runtime/Path
/*     */     //   72: dup
/*     */     //   73: aload_2
/*     */     //   74: invokespecial 180	org/eclipse/core/runtime/Path:<init>	(Ljava/lang/String;)V
/*     */     //   77: astore 5
/*     */     //   79: aconst_null
/*     */     //   80: astore 6
/*     */     //   82: aload 5
/*     */     //   84: invokeinterface 184 1 0
/*     */     //   89: iconst_1
/*     */     //   90: if_icmple +14 -> 104
/*     */     //   93: aload 4
/*     */     //   95: aload 5
/*     */     //   97: invokeinterface 190 2 0
/*     */     //   102: astore 6
/*     */     //   104: aload 6
/*     */     //   106: ifnull +18 -> 124
/*     */     //   109: aload 6
/*     */     //   111: invokeinterface 196 1 0
/*     */     //   116: astore 7
/*     */     //   118: aload 7
/*     */     //   120: invokestatic 202	org/eclipse/jdt/core/JavaCore:create	(Lorg/eclipse/core/resources/IProject;)Lorg/eclipse/jdt/core/IJavaProject;
/*     */     //   123: astore_3
/*     */     //   124: aload_3
/*     */     //   125: areturn
/*     */     // Line number table:
/*     */     //   Java source line #84	-> byte code offset #0
/*     */     //   Java source line #85	-> byte code offset #2
/*     */     //   Java source line #86	-> byte code offset #4
/*     */     //   Java source line #91	-> byte code offset #6
/*     */     //   Java source line #92	-> byte code offset #16
/*     */     //   Java source line #94	-> byte code offset #20
/*     */     //   Java source line #98	-> byte code offset #30
/*     */     //   Java source line #99	-> byte code offset #32
/*     */     //   Java source line #100	-> byte code offset #36
/*     */     //   Java source line #101	-> byte code offset #42
/*     */     //   Java source line #99	-> byte code offset #45
/*     */     //   Java source line #100	-> byte code offset #49
/*     */     //   Java source line #102	-> byte code offset #55
/*     */     //   Java source line #104	-> byte code offset #59
/*     */     //   Java source line #105	-> byte code offset #69
/*     */     //   Java source line #106	-> byte code offset #79
/*     */     //   Java source line #108	-> byte code offset #82
/*     */     //   Java source line #110	-> byte code offset #93
/*     */     //   Java source line #112	-> byte code offset #104
/*     */     //   Java source line #114	-> byte code offset #109
/*     */     //   Java source line #115	-> byte code offset #118
/*     */     //   Java source line #118	-> byte code offset #124
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	126	0	document	org.eclipse.jface.text.IDocument
/*     */     //   1	49	1	model	IStructuredModel
/*     */     //   3	71	2	baseLocation	String
/*     */     //   5	120	3	result	IJavaProject
/*     */     //   30	13	4	localObject	Object
/*     */     //   67	27	4	root	org.eclipse.core.resources.IWorkspaceRoot
/*     */     //   77	19	5	filePath	IPath
/*     */     //   80	30	6	file	IFile
/*     */     //   116	3	7	project	org.eclipse.core.resources.IProject
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   6	30	30	finally
/*     */   }
/*     */   
/*     */   public static String getNamespace(Document document)
/*     */     throws XPathExpressionException
/*     */   {
/* 123 */     return XpathUtil.xpathString(document, "//mapper/@namespace");
/*     */   }
/*     */   
/*     */   public static String getJavaMapperType(IJavaProject project)
/*     */   {
/* 128 */     return getJavaMapperFqn(project, null);
/*     */   }
/*     */   
/*     */   public static String getJavaMapperFqn(IJavaProject project, IResource resource)
/*     */   {
/* 133 */     IPath path = null;
/* 134 */     IWorkbenchWindow window; IWorkbenchPage page; IEditorPart editor; if (resource != null)
/*     */     {
/* 136 */       path = resource.getFullPath();
/*     */     }
/*     */     else
/*     */     {
/* 140 */       IWorkbench wb = PlatformUI.getWorkbench();
/* 141 */       window = wb.getActiveWorkbenchWindow();
/* 142 */       page = window.getActivePage();
/* 143 */       editor = page.getActiveEditor();
/* 144 */       IEditorInput input = editor.getEditorInput();
/* 145 */       path = ((FileEditorInput)input).getFile().getFullPath();
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 150 */       page = (editor = project.getRawClasspath()).length; for (window = 0; window < page; window++) { IClasspathEntry entry = editor[window];
/*     */         
/* 152 */         if (entry.getPath().isPrefixOf(path))
/*     */         {
/* 154 */           IPath relativePath = path.makeRelativeTo(entry.getPath());
/* 155 */           return relativePath.removeFileExtension().toString().replace('/', '.');
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (JavaModelException e)
/*     */     {
/* 161 */       Activator.log(4, 
/* 162 */         "Failed to get raw classpath for project: " + project.getElementName(), e);
/*     */     }
/* 164 */     return null;
/*     */   }
/*     */   
/*     */   public static IDOMDocument getMapperDocument(IFile mapperXmlFile)
/*     */   {
/* 169 */     if (mapperXmlFile == null)
/* 170 */       return null;
/* 171 */     IStructuredModel model = null;
/*     */     try
/*     */     {
/* 174 */       model = StructuredModelManager.getModelManager().getModelForRead(mapperXmlFile);
/* 175 */       IDOMModel domModel = (IDOMModel)model;
/* 176 */       IDOMDocument mapperDocument = domModel.getDocument();
/* 177 */       return mapperDocument;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 181 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*     */     finally
/*     */     {
/* 185 */       if (model != null)
/*     */       {
/* 187 */         model.releaseFromRead();
/*     */       }
/*     */     }
/* 190 */     return null;
/*     */   }
/*     */   
/*     */   public static String findEnclosingType(Node node)
/*     */   {
/* 195 */     String type = null;
/* 196 */     Node parentNode = node.getParentNode();
/* 197 */     while ((parentNode != null) && (type == null))
/*     */     {
/* 199 */       String nodeName = parentNode.getNodeName();
/* 200 */       if ("resultMap".equals(nodeName)) {
/* 201 */         type = getAttribute(parentNode, "type");
/* 202 */       } else if ("collection".equals(nodeName)) {
/* 203 */         type = getAttribute(parentNode, "ofType");
/* 204 */       } else if ("association".equals(nodeName)) {
/* 205 */         type = getAttribute(parentNode, "javaType");
/* 206 */       } else if ("case".equals(nodeName))
/* 207 */         type = getAttribute(parentNode, "resultType");
/* 208 */       parentNode = parentNode.getParentNode();
/*     */     }
/* 210 */     return normalizeTypeName(type);
/*     */   }
/*     */   
/*     */   public static String normalizeTypeName(String src)
/*     */   {
/* 215 */     return src == null ? null : src.replace('$', '.');
/*     */   }
/*     */   
/*     */   private static String getAttribute(Node node, String attributeName)
/*     */   {
/* 220 */     NamedNodeMap attributes = node.getAttributes();
/* 221 */     if (attributes != null)
/*     */     {
/* 223 */       Node typeAttrNode = attributes.getNamedItem(attributeName);
/* 224 */       if (typeAttrNode != null)
/*     */       {
/* 226 */         return typeAttrNode.getNodeValue();
/*     */       }
/*     */     }
/* 229 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\MybatipseXmlUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */