/*    */ package net.harawata.mybatipse.mybatis;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.eclipse.jdt.core.dom.MethodDeclaration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MapperMethod
/*    */ {
/*    */   private MethodDeclaration methodDeclaration;
/*    */   private String statement;
/*    */   
/*    */   public MethodDeclaration getMethodDeclaration()
/*    */   {
/* 29 */     return this.methodDeclaration;
/*    */   }
/*    */   
/*    */   public void setMethodDeclaration(MethodDeclaration methodDeclaration)
/*    */   {
/* 34 */     this.methodDeclaration = methodDeclaration;
/*    */   }
/*    */   
/*    */   public String getStatement()
/*    */   {
/* 39 */     return this.statement;
/*    */   }
/*    */   
/*    */   public void setStatement(String statement)
/*    */   {
/* 44 */     this.statement = statement;
/*    */   }
/*    */   
/*    */ 
/*    */   public List parameters()
/*    */   {
/* 50 */     return this.methodDeclaration.parameters();
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\MapperMethod.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */