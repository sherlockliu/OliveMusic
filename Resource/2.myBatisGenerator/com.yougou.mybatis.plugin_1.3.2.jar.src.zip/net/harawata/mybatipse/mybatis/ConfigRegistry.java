/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import net.harawata.mybatipse.MybatipseConstants;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IResourceProxy;
/*     */ import org.eclipse.core.resources.IResourceProxyVisitor;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.content.IContentDescription;
/*     */ import org.eclipse.core.runtime.content.IContentType;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigRegistry
/*     */ {
/*  39 */   private static final ConfigRegistry INSTANCE = new ConfigRegistry();
/*     */   
/*  41 */   private Map<String, Map<IFile, IContentType>> configMap = new ConcurrentHashMap();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Map<IFile, IContentType> get(IJavaProject javaProject)
/*     */   {
/*  51 */     IProject project = javaProject.getProject();
/*  52 */     Map<IFile, IContentType> files = (Map)this.configMap.get(project.getName());
/*  53 */     if (files == null)
/*     */     {
/*  55 */       files = search(javaProject);
/*  56 */       this.configMap.put(project.getName(), files);
/*  57 */       TypeAliasCache.getInstance().remove(project);
/*     */     }
/*  59 */     return files;
/*     */   }
/*     */   
/*     */   public void clear()
/*     */   {
/*  64 */     this.configMap.clear();
/*  65 */     TypeAliasCache.getInstance().clear();
/*     */   }
/*     */   
/*     */   public void remove(IProject project)
/*     */   {
/*  70 */     this.configMap.remove(project.getName());
/*  71 */     TypeAliasCache.getInstance().remove(project);
/*     */   }
/*     */   
/*     */   public void remove(IProject project, IFile file)
/*     */   {
/*  76 */     Map<IFile, IContentType> files = (Map)this.configMap.get(project.getName());
/*  77 */     if (files != null)
/*  78 */       files.remove(file);
/*  79 */     TypeAliasCache.getInstance().remove(project);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map<IFile, IContentType> search(IJavaProject project)
/*     */   {
/*  91 */     Map<IFile, IContentType> configFiles = new ConcurrentHashMap();
/*     */     try
/*     */     {
/*  94 */       project.getResource().accept(new ConfigVisitor(configFiles, null), 0);
/*     */       IPackageFragmentRoot[] arrayOfIPackageFragmentRoot;
/*  96 */       int j = (arrayOfIPackageFragmentRoot = project.getPackageFragmentRoots()).length; for (int i = 0; i < j; i++) { IPackageFragmentRoot root = arrayOfIPackageFragmentRoot[i];
/*     */         
/*  98 */         if (root.getKind() == 1)
/*     */         {
/* 100 */           root.getResource().accept(new ConfigVisitor(configFiles, null), 0);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (CoreException e) {
/* 105 */       Activator.log(4, "Searching MyBatis Config xml failed.", e);
/*     */     }
/*     */     
/* 108 */     return configFiles;
/*     */   }
/*     */   
/*     */   public static ConfigRegistry getInstance()
/*     */   {
/* 113 */     return INSTANCE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class ConfigVisitor
/*     */     implements IResourceProxyVisitor
/*     */   {
/*     */     private final Map<IFile, IContentType> configFiles;
/*     */     
/*     */ 
/*     */ 
/*     */     private ConfigVisitor()
/*     */     {
/* 127 */       this.configFiles = configFiles;
/*     */     }
/*     */     
/*     */     public boolean visit(IResourceProxy proxy)
/*     */       throws CoreException
/*     */     {
/* 133 */       if (proxy.isDerived()) {
/* 134 */         return false;
/*     */       }
/* 136 */       if ((proxy.getType() == 1) && (proxy.getName().endsWith(".xml")))
/*     */       {
/* 138 */         IFile file = (IFile)proxy.requestResource();
/* 139 */         IContentDescription contentDesc = file.getContentDescription();
/* 140 */         if (contentDesc != null)
/*     */         {
/* 142 */           IContentType contentType = contentDesc.getContentType();
/* 143 */           if ((contentType != null) && (
/* 144 */             (contentType.isKindOf(MybatipseConstants.configContentType)) || (contentType.isKindOf(MybatipseConstants.springConfigContentType))))
/*     */           {
/* 146 */             this.configFiles.put(file, contentType);
/*     */           }
/*     */         }
/*     */       }
/* 150 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\ConfigRegistry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */