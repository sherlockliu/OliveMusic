/*     */ package net.harawata.mybatipse.mybatis;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExpressionProposalParser
/*     */ {
/*     */   private final String text;
/*     */   
/*     */ 
/*     */ 
/*     */   private final int offset;
/*     */   
/*     */ 
/*     */ 
/*     */   private String matchString;
/*     */   
/*     */ 
/*     */ 
/*     */   private String proposalTarget;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean proposable;
/*     */   
/*     */ 
/*     */ 
/*  29 */   public static String[] options = {
/*  30 */     "jdbcType", "javaType", "typeHandler", "mode", "resultMap", "numericScale" };
/*     */   
/*     */ 
/*  33 */   public static String[] jdbcTypes = {
/*  34 */     "ARRAY", "BIGINT", "BINARY", "BIT", "BLOB", "BOOLEAN", "CHAR", "CLOB", "CURSOR", "DATE", 
/*  35 */     "DECIMAL", "DOUBLE", "FLOAT", "INTEGER", "LONGVARBINARY", "LONGVARCHAR", "NUMERIC", 
/*  36 */     "NCHAR", "NCLOB", "NULL", "NVARCHAR", "OTHER", "REAL", "SMALLINT", "STRUCT", "TIME", 
/*  37 */     "TIMESTAMP", "TINYINT", "UNDEFINED", "VARBINARY", "VARCHAR" };
/*     */   
/*     */ 
/*     */   public ExpressionProposalParser(String text, int offset)
/*     */   {
/*  42 */     this.text = text;
/*  43 */     this.offset = offset;
/*  44 */     parse();
/*     */   }
/*     */   
/*     */   private void parse()
/*     */   {
/*  49 */     StringBuilder buffer = new StringBuilder();
/*  50 */     int trailingWhitespaceMode = 0;
/*  51 */     for (int i = this.offset; i > 0; i--)
/*     */     {
/*  53 */       char c = this.text.charAt(i);
/*  54 */       if (c <= ' ')
/*     */       {
/*  56 */         if (trailingWhitespaceMode == 0) {
/*  57 */           trailingWhitespaceMode = 1;
/*     */         }
/*  59 */       } else if ((Character.isJavaIdentifierPart(c)) || (c == '[') || (c == ']') || (c == '.'))
/*     */       {
/*  61 */         if (trailingWhitespaceMode == 1)
/*     */           break;
/*  63 */         buffer.insert(0, c);
/*     */       }
/*  65 */       else if (c == ',')
/*     */       {
/*  67 */         trailingWhitespaceMode = 2;
/*  68 */         if (this.matchString == null)
/*     */         {
/*  70 */           this.matchString = buffer.toString();
/*  71 */           buffer.setLength(0);
/*     */         }
/*  73 */         if (this.proposalTarget == null)
/*     */         {
/*  75 */           this.proposalTarget = buffer.toString();
/*  76 */           buffer.setLength(0);
/*     */         }
/*     */       }
/*  79 */       else if (c == '=')
/*     */       {
/*  81 */         trailingWhitespaceMode = 2;
/*  82 */         if (this.matchString == null)
/*     */         {
/*  84 */           this.matchString = buffer.toString();
/*     */         }
/*  86 */         buffer.setLength(0);
/*     */       } else {
/*  88 */         if ((c != '{') || (i <= 0))
/*     */           break;
/*  90 */         char preChr = this.text.charAt(i - 1);
/*  91 */         if ((preChr == '#') || (preChr == '$'))
/*     */         {
/*  93 */           this.proposable = true;
/*  94 */           if (this.matchString == null)
/*     */           {
/*  96 */             this.proposalTarget = "property";
/*  97 */             this.matchString = buffer.toString(); break;
/*     */           }
/*  99 */           if (preChr != '$')
/*     */             break;
/* 101 */           this.proposable = false;
/*     */           
/* 103 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReplacementLength()
/*     */   {
/* 115 */     boolean inWhitespace = false;
/* 116 */     for (int i = this.offset + 1; 
/* 117 */         i < this.text.length(); i++)
/*     */     {
/* 119 */       char c = this.text.charAt(i);
/* 120 */       if ((Character.isJavaIdentifierPart(c)) || (c == '[') || (c == ']') || (c == '.'))
/*     */       {
/* 122 */         if (inWhitespace)
/* 123 */           return i - this.offset - 1 + this.matchString.length();
/*     */       } else {
/* 125 */         if (c > ' ')
/*     */           break;
/* 127 */         if ((c == '\n') || (c == '\r'))
/* 128 */           return i - this.offset - 1 + this.matchString.length();
/* 129 */         inWhitespace = true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 136 */     return i - this.offset - 1 + this.matchString.length();
/*     */   }
/*     */   
/*     */   public String getMatchString()
/*     */   {
/* 141 */     return this.matchString;
/*     */   }
/*     */   
/*     */   public String getProposalTarget()
/*     */   {
/* 146 */     return this.proposalTarget;
/*     */   }
/*     */   
/*     */   public boolean isProposable()
/*     */   {
/* 151 */     return this.proposable;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\mybatis\ExpressionProposalParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */