/*     */ package net.harawata.mybatipse.hyperlink;
/*     */ 
/*     */ import com.yougou.mybatis.plugins.Tools;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import javax.xml.xpath.XPathExpressionException;
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import net.harawata.mybatipse.mybatis.MapperNamespaceCache;
/*     */ import net.harawata.mybatipse.mybatis.MybatipseXmlUtil;
/*     */ import net.harawata.mybatipse.util.XpathUtil;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.jdt.core.IClassFile;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IImportDeclaration;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IMember;
/*     */ import org.eclipse.jdt.core.IMethod;
/*     */ import org.eclipse.jdt.core.IPackageFragment;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.ITypeHierarchy;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ import org.eclipse.jdt.core.Signature;
/*     */ import org.eclipse.jdt.internal.corext.util.JavaModelUtil;
/*     */ import org.eclipse.jdt.internal.corext.util.Messages;
/*     */ import org.eclipse.jdt.internal.corext.util.MethodOverrideTester;
/*     */ import org.eclipse.jdt.internal.ui.JavaPlugin;
/*     */ import org.eclipse.jdt.internal.ui.typehierarchy.HierarchyLabelProvider;
/*     */ import org.eclipse.jdt.internal.ui.typehierarchy.HierarchyViewerSorter;
/*     */ import org.eclipse.jdt.internal.ui.typehierarchy.SuperTypeHierarchyViewer.SuperTypeHierarchyContentProvider;
/*     */ import org.eclipse.jdt.internal.ui.typehierarchy.TraditionalHierarchyViewer.TraditionalHierarchyContentProvider;
/*     */ import org.eclipse.jdt.internal.ui.typehierarchy.TypeHierarchyContentProvider;
/*     */ import org.eclipse.jdt.internal.ui.typehierarchy.TypeHierarchyLifeCycle;
/*     */ import org.eclipse.jdt.internal.ui.typehierarchy.TypeHierarchyMessages;
/*     */ import org.eclipse.jdt.internal.ui.viewsupport.ColoringLabelProvider;
/*     */ import org.eclipse.jdt.ui.JavaElementLabels;
/*     */ import org.eclipse.jdt.ui.ProblemsLabelDecorator;
/*     */ import org.eclipse.jface.text.Region;
/*     */ import org.eclipse.jface.viewers.TreeViewer;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.jface.viewers.ViewerFilter;
/*     */ import org.eclipse.swt.events.KeyAdapter;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ import org.eclipse.ui.IEditorPart;
/*     */ import org.eclipse.ui.IWorkbench;
/*     */ import org.eclipse.ui.IWorkbenchWindow;
/*     */ import org.eclipse.ui.PartInitException;
/*     */ import org.eclipse.ui.PlatformUI;
/*     */ import org.eclipse.ui.ide.IDE;
/*     */ import org.eclipse.ui.keys.KeySequence;
/*     */ import org.eclipse.ui.keys.SWTKeySupport;
/*     */ import org.eclipse.ui.part.MultiPageEditorPart;
/*     */ import org.eclipse.ui.texteditor.ITextEditor;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMDocument;
/*     */ import org.eclipse.wst.xml.core.internal.provisional.document.IDOMNode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HierarchyInformationControl
/*     */   extends AbstractInformationControl
/*     */ {
/*     */   private TypeHierarchyLifeCycle fLifeCycle;
/*     */   private HierarchyLabelProvider fLabelProvider;
/*     */   private KeyAdapter fKeyAdapter;
/*     */   private Object[] fOtherExpandedElements;
/*     */   private TypeHierarchyContentProvider fOtherContentProvider;
/*     */   private IMethod fFocus;
/*     */   private boolean fDoFilter;
/*     */   private MethodOverrideTester fMethodOverrideTester;
/*     */   private String expression;
/*     */   
/*     */   public HierarchyInformationControl(Shell parent, int shellStyle, int treeStyle, String expression)
/*     */   {
/*  79 */     super(parent, shellStyle, treeStyle, "org.eclipse.jdt.ui.edit.text.java.open.hierarchy", true);
/*  80 */     this.fOtherExpandedElements = null;
/*  81 */     this.fDoFilter = true;
/*  82 */     this.fMethodOverrideTester = null;
/*  83 */     this.expression = expression;
/*     */   }
/*     */   
/*     */   private KeyAdapter getKeyAdapter() {
/*  87 */     if (this.fKeyAdapter == null) {
/*  88 */       this.fKeyAdapter = new KeyAdapter() {
/*     */         public void keyPressed(KeyEvent e) {
/*  90 */           int accelerator = 
/*  91 */             SWTKeySupport.convertEventToUnmodifiedAccelerator(e);
/*  92 */           KeySequence keySequence = 
/*  93 */             KeySequence.getInstance(
/*  94 */             SWTKeySupport.convertAcceleratorToKeyStroke(accelerator));
/*  95 */           KeySequence[] sequences = HierarchyInformationControl.this
/*  96 */             .getInvokingCommandKeySequences();
/*  97 */           if (sequences == null) {
/*  98 */             return;
/*     */           }
/* 100 */           for (int i = 0; i < sequences.length; i++)
/* 101 */             if (sequences[i].equals(keySequence)) {
/* 102 */               e.doit = false;
/* 103 */               HierarchyInformationControl.this.toggleHierarchy();
/* 104 */               return;
/*     */             }
/*     */         }
/*     */       };
/*     */     }
/* 109 */     return this.fKeyAdapter;
/*     */   }
/*     */   
/*     */   protected boolean hasHeader() {
/* 113 */     return true;
/*     */   }
/*     */   
/*     */   protected Text createFilterText(Composite parent) {
/* 117 */     Text text = super.createFilterText(parent);
/* 118 */     text.addKeyListener(getKeyAdapter());
/* 119 */     return text;
/*     */   }
/*     */   
/*     */   protected TreeViewer createTreeViewer(Composite parent, int style) {
/* 123 */     Tree tree = new Tree(parent, 0x4 | style & 0xFFFFFFFD);
/* 124 */     GridData gd = new GridData(1808);
/* 125 */     gd.heightHint = (tree.getItemHeight() * 12);
/* 126 */     tree.setLayoutData(gd);
/*     */     
/* 128 */     TreeViewer treeViewer = new TreeViewer(tree);
/* 129 */     treeViewer.addFilter(new ViewerFilter()
/*     */     {
/*     */       public boolean select(Viewer viewer, Object parentElement, Object element) {
/* 132 */         return element instanceof IType;
/*     */       }
/* 134 */     });
/* 135 */     this.fLifeCycle = new TypeHierarchyLifeCycle(false);
/*     */     
/* 137 */     treeViewer.setComparator(new HierarchyViewerSorter(this.fLifeCycle));
/* 138 */     treeViewer.setAutoExpandLevel(-1);
/*     */     
/* 140 */     this.fLabelProvider = new HierarchyLabelProvider(this.fLifeCycle);
/* 141 */     this.fLabelProvider.setFilter(new ViewerFilter()
/*     */     {
/*     */       public boolean select(Viewer viewer, Object parentElement, Object element) {
/* 144 */         return 
/* 145 */           HierarchyInformationControl.this.hasFocusMethod((IType)element);
/*     */       }
/*     */       
/* 148 */     });this.fLabelProvider
/* 149 */       .setTextFlags(JavaElementLabels.ALL_DEFAULT | 0x100000 | 0L);
/* 150 */     this.fLabelProvider.addLabelDecorator(new ProblemsLabelDecorator(null));
/* 151 */     treeViewer.setLabelProvider(new ColoringLabelProvider(
/* 152 */       this.fLabelProvider));
/*     */     
/* 154 */     treeViewer.getTree().addKeyListener(getKeyAdapter());
/*     */     
/* 156 */     return treeViewer;
/*     */   }
/*     */   
/*     */   protected boolean hasFocusMethod(IType type) {
/* 160 */     if (this.fFocus == null) {
/* 161 */       return true;
/*     */     }
/* 163 */     if (type.equals(this.fFocus.getDeclaringType())) {
/* 164 */       return true;
/*     */     }
/*     */     try {
/* 167 */       IMethod method = findMethod(this.fFocus, type);
/* 168 */       if (method != null) {
/* 169 */         IPackageFragment pack = (IPackageFragment)this.fFocus
/* 170 */           .getAncestor(4);
/* 171 */         if (JavaModelUtil.isVisibleInHierarchy(method, pack))
/* 172 */           return true;
/*     */       }
/*     */     } catch (JavaModelException e) {
/* 175 */       JavaPlugin.log(e);
/*     */     }
/* 177 */     return false;
/*     */   }
/*     */   
/*     */   private IMethod findMethod(IMethod filterMethod, IType typeToFindIn) throws JavaModelException
/*     */   {
/* 182 */     IType filterType = filterMethod.getDeclaringType();
/* 183 */     if (filterType.equals(typeToFindIn)) {
/* 184 */       return filterMethod;
/*     */     }
/*     */     
/* 187 */     ITypeHierarchy hierarchy = this.fLifeCycle.getHierarchy();
/*     */     
/* 189 */     boolean filterOverrides = JavaModelUtil.isSuperType(hierarchy, 
/* 190 */       typeToFindIn, filterType);
/* 191 */     IType focusType = filterOverrides ? filterType : typeToFindIn;
/*     */     
/* 193 */     if ((this.fMethodOverrideTester == null) || 
/*     */     
/* 195 */       (!this.fMethodOverrideTester.getFocusType().equals(focusType))) {
/* 196 */       this.fMethodOverrideTester = new MethodOverrideTester(focusType, 
/* 197 */         hierarchy);
/*     */     }
/*     */     
/* 200 */     if (filterOverrides) {
/* 201 */       return this.fMethodOverrideTester.findOverriddenMethodInType(
/* 202 */         typeToFindIn, filterMethod);
/*     */     }
/* 204 */     return this.fMethodOverrideTester.findOverridingMethodInType(
/* 205 */       typeToFindIn, filterMethod);
/*     */   }
/*     */   
/*     */   public void setInput(Object information) {
/* 209 */     if (!(information instanceof IJavaElement)) {
/* 210 */       inputChanged(null, null);
/* 211 */       return;
/*     */     }
/* 213 */     IJavaElement input = null;
/* 214 */     IMethod locked = null;
/*     */     try {
/* 216 */       IJavaElement elem = (IJavaElement)information;
/* 217 */       switch (elem.getElementType()) {
/*     */       case 14: 
/*     */       case 15: 
/* 220 */         elem = elem.getParent();
/*     */       }
/*     */       
/* 223 */       switch (elem.getElementType()) {
/*     */       case 2: 
/*     */       case 3: 
/*     */       case 4: 
/*     */       case 7: 
/* 228 */         input = elem;
/* 229 */         break;
/*     */       case 5: 
/* 231 */         input = ((ICompilationUnit)elem).findPrimaryType();
/* 232 */         break;
/*     */       case 6: 
/* 234 */         input = ((IClassFile)elem).getType();
/* 235 */         break;
/*     */       case 9: 
/* 237 */         IMethod method = (IMethod)elem;
/* 238 */         if (!method.isConstructor()) {
/* 239 */           locked = method;
/*     */         }
/* 241 */         input = method.getDeclaringType();
/* 242 */         break;
/*     */       case 8: 
/*     */       case 10: 
/* 245 */         input = ((IMember)elem).getDeclaringType();
/* 246 */         break;
/*     */       case 11: 
/* 248 */         input = elem.getParent().getParent();
/* 249 */         break;
/*     */       case 13: 
/* 251 */         IImportDeclaration decl = (IImportDeclaration)elem;
/* 252 */         if (decl.isOnDemand()) {
/* 253 */           input = JavaModelUtil.findTypeContainer(
/* 254 */             decl.getJavaProject(), 
/* 255 */             Signature.getQualifier(decl.getElementName()));
/*     */         } else {
/* 257 */           input = decl.getJavaProject().findType(
/* 258 */             decl.getElementName());
/*     */         }
/* 260 */         break;
/*     */       
/*     */       case 12: 
/*     */       default: 
/* 264 */         JavaPlugin.logErrorMessage(
/* 265 */           "Element unsupported by the hierarchy: " + elem.getClass());
/*     */       }
/*     */     } catch (JavaModelException e) {
/* 268 */       JavaPlugin.log(e);
/*     */     }
/*     */     
/* 271 */     super.setTitleText(getHeaderLabel(locked == null ? input : locked));
/*     */     try {
/* 273 */       this.fLifeCycle.ensureRefreshedTypeHierarchy(input, 
/* 274 */         JavaPlugin.getActiveWorkbenchWindow());
/*     */     } catch (InvocationTargetException localInvocationTargetException) {
/* 276 */       input = null;
/*     */     } catch (InterruptedException localInterruptedException) {
/* 278 */       dispose();
/* 279 */       return;
/*     */     }
/* 281 */     IMember[] memberFilter = locked != null ? new IMember[] { locked } : 
/* 282 */       null;
/*     */     
/* 284 */     TraditionalHierarchyViewer.TraditionalHierarchyContentProvider contentProvider = new TraditionalHierarchyViewer.TraditionalHierarchyContentProvider(
/* 285 */       this.fLifeCycle);
/* 286 */     contentProvider.setMemberFilter(memberFilter);
/* 287 */     getTreeViewer().setContentProvider(contentProvider);
/*     */     
/* 289 */     this.fOtherContentProvider = new SuperTypeHierarchyViewer.SuperTypeHierarchyContentProvider(
/* 290 */       this.fLifeCycle);
/* 291 */     this.fOtherContentProvider.setMemberFilter(memberFilter);
/*     */     
/* 293 */     this.fFocus = locked;
/*     */     
/* 295 */     Object[] topLevelObjects = contentProvider.getElements(this.fLifeCycle);
/* 296 */     if ((topLevelObjects.length > 0) && 
/* 297 */       (contentProvider.getChildren(topLevelObjects[0]).length > 40)) {
/* 298 */       this.fDoFilter = false;
/*     */     } else {
/* 300 */       getTreeViewer().addFilter(
/* 301 */         new AbstractInformationControl.NamePatternFilter(this));
/*     */     }
/*     */     
/* 304 */     Object selection = null;
/* 305 */     if ((input instanceof IMember)) {
/* 306 */       selection = input;
/* 307 */     } else if (topLevelObjects.length > 0) {
/* 308 */       selection = topLevelObjects[0];
/*     */     }
/* 310 */     inputChanged(this.fLifeCycle, selection);
/*     */   }
/*     */   
/*     */   protected void stringMatcherUpdated() {
/* 314 */     if (this.fDoFilter) {
/* 315 */       super.stringMatcherUpdated();
/*     */     } else
/* 317 */       selectFirstMatch();
/*     */   }
/*     */   
/*     */   protected void toggleHierarchy() {
/* 321 */     TreeViewer treeViewer = getTreeViewer();
/*     */     
/* 323 */     treeViewer.getTree().setRedraw(false);
/*     */     
/* 325 */     Object[] expandedElements = treeViewer.getExpandedElements();
/* 326 */     TypeHierarchyContentProvider contentProvider = (TypeHierarchyContentProvider)treeViewer
/* 327 */       .getContentProvider();
/* 328 */     treeViewer.setContentProvider(this.fOtherContentProvider);
/*     */     
/* 330 */     treeViewer.refresh();
/* 331 */     if (this.fOtherExpandedElements != null) {
/* 332 */       treeViewer.setExpandedElements(this.fOtherExpandedElements);
/*     */     } else {
/* 334 */       treeViewer.expandAll();
/*     */     }
/*     */     
/* 337 */     Object selectedElement = getSelectedElement();
/* 338 */     if (selectedElement != null) {
/* 339 */       getTreeViewer().reveal(selectedElement);
/*     */     } else {
/* 341 */       selectFirstMatch();
/*     */     }
/* 343 */     treeViewer.getTree().setRedraw(true);
/*     */     
/* 345 */     this.fOtherContentProvider = contentProvider;
/* 346 */     this.fOtherExpandedElements = expandedElements;
/*     */     
/* 348 */     updateStatusFieldText();
/*     */   }
/*     */   
/*     */   private String getHeaderLabel(IJavaElement input) {
/* 352 */     if ((input instanceof IMethod)) {
/* 353 */       String[] args = {
/* 354 */         JavaElementLabels.getElementLabel(input.getParent(), 
/* 355 */         JavaElementLabels.ALL_DEFAULT), 
/* 356 */         JavaElementLabels.getElementLabel(input, 
/* 357 */         JavaElementLabels.ALL_DEFAULT) };
/* 358 */       return 
/* 359 */         Messages.format(TypeHierarchyMessages.HierarchyInformationControl_methodhierarchy_label, 
/* 360 */         args);
/*     */     }
/* 362 */     if (input != null) {
/* 363 */       String arg = JavaElementLabels.getElementLabel(input, 
/* 364 */         JavaElementLabels.DEFAULT_QUALIFIED);
/* 365 */       return 
/* 366 */         Messages.format(TypeHierarchyMessages.HierarchyInformationControl_hierarchy_label, 
/* 367 */         arg);
/*     */     }
/* 369 */     return "";
/*     */   }
/*     */   
/*     */   protected String getStatusFieldText() {
/* 373 */     KeySequence[] sequences = getInvokingCommandKeySequences();
/* 374 */     String keyName = "";
/* 375 */     if ((sequences != null) && (sequences.length > 0)) {
/* 376 */       keyName = sequences[0].format();
/*     */     }
/* 378 */     if ((this.fOtherContentProvider instanceof TraditionalHierarchyViewer.TraditionalHierarchyContentProvider)) {
/* 379 */       return 
/* 380 */         Messages.format(TypeHierarchyMessages.HierarchyInformationControl_toggle_traditionalhierarchy_label, 
/* 381 */         keyName);
/*     */     }
/* 383 */     return "select subClass to see the subClass xml file ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected String getId()
/*     */   {
/* 390 */     return "org.eclipse.jdt.internal.ui.typehierarchy.QuickHierarchy";
/*     */   }
/*     */   
/*     */   protected Object getSelectedElement() {
/* 394 */     Object selectedElement = super.getSelectedElement();
/* 395 */     if (((selectedElement instanceof IType)) && (this.fFocus != null)) {
/* 396 */       IType type = (IType)selectedElement;
/*     */       try {
/* 398 */         IMethod method = findMethod(this.fFocus, type);
/* 399 */         if (method != null)
/* 400 */           return method;
/*     */       } catch (JavaModelException e) {
/* 402 */         JavaPlugin.log(e);
/*     */       }
/*     */     }
/* 405 */     return selectedElement;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void gotoSelectedElement()
/*     */   {
/*     */     try
/*     */     {
/* 414 */       IType type = (IType)getSelectedElement();
/* 415 */       IFile mapperFile = MapperNamespaceCache.getInstance().get(
/* 416 */         type.getJavaProject(), type.getFullyQualifiedName(), null);
/* 417 */       IDOMDocument mapperDocument = 
/* 418 */         MybatipseXmlUtil.getMapperDocument(mapperFile);
/* 419 */       if (mapperDocument != null) {
/*     */         try {
/* 421 */           IDOMNode domNode = (IDOMNode)XpathUtil.xpathNode(
/* 422 */             mapperDocument, this.expression);
/* 423 */           if (domNode == null) return;
/* 424 */           Region destRegion = new Region(
/* 425 */             domNode.getStartOffset(), 
/* 426 */             domNode.getEndOffset() - 
/* 427 */             domNode.getStartOffset());
/* 428 */           IWorkbenchWindow window = PlatformUI.getWorkbench()
/* 429 */             .getActiveWorkbenchWindow();
/* 430 */           if (window == null) return;
/* 431 */           IEditorPart editorPart = IDE.openEditor(
/* 432 */             window.getActivePage(), mapperFile);
/* 433 */           if (!(editorPart instanceof MultiPageEditorPart)) return;
/* 434 */           MultiPageEditorPart multiPageEditorPart = (MultiPageEditorPart)editorPart;
/* 435 */           IEditorPart[] editors = multiPageEditorPart
/* 436 */             .findEditors(editorPart
/* 437 */             .getEditorInput());
/* 438 */           if ((editors.length != 1) || 
/* 439 */             (!(editors[0] instanceof ITextEditor))) return;
/* 440 */           ((ITextEditor)editors[0]).selectAndReveal(
/* 441 */             destRegion.getOffset(), 
/* 442 */             destRegion.getLength());
/*     */ 
/*     */         }
/*     */         catch (XPathExpressionException e)
/*     */         {
/*     */ 
/* 448 */           Activator.log(4, e.getMessage(), e);
/*     */         }
/*     */       } else {
/* 451 */         String msg = "Not found " + type.getFullyQualifiedName() + " xml file!";
/* 452 */         Tools.writeLine(msg);
/* 453 */         Activator.log(4, msg);
/*     */       }
/*     */     } catch (PartInitException e) {
/* 456 */       Activator.log(4, e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\hyperlink\HierarchyInformationControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */