/*    */ package net.harawata.mybatipse.hyperlink;
/*    */ 
/*    */ import net.harawata.mybatipse.Activator;
/*    */ import org.eclipse.jdt.core.IJavaElement;
/*    */ import org.eclipse.jdt.ui.JavaUI;
/*    */ import org.eclipse.jface.text.IRegion;
/*    */ import org.eclipse.jface.text.hyperlink.IHyperlink;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ToJavaHyperlink
/*    */   implements IHyperlink
/*    */ {
/*    */   private IJavaElement type;
/*    */   private IRegion region;
/*    */   private String linkLabel;
/*    */   
/*    */   public ToJavaHyperlink(IJavaElement type, IRegion region, String linkLabel)
/*    */   {
/* 36 */     this.type = type;
/* 37 */     this.region = region;
/* 38 */     this.linkLabel = linkLabel;
/*    */   }
/*    */   
/*    */   public IRegion getHyperlinkRegion()
/*    */   {
/* 43 */     return this.region;
/*    */   }
/*    */   
/*    */   public String getTypeLabel()
/*    */   {
/* 48 */     return this.linkLabel;
/*    */   }
/*    */   
/*    */   public String getHyperlinkText()
/*    */   {
/* 53 */     return this.linkLabel;
/*    */   }
/*    */   
/*    */   public void open()
/*    */   {
/*    */     try
/*    */     {
/* 60 */       JavaUI.openInEditor(this.type);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 64 */       Activator.log(2, 
/* 65 */         "Failed to open Java editor for type: " + this.type.getElementName(), e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\hyperlink\ToJavaHyperlink.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */