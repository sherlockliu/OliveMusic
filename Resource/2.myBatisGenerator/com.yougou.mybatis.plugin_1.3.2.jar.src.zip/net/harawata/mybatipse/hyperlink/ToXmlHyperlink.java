/*     */ package net.harawata.mybatipse.hyperlink;
/*     */ 
/*     */ import net.harawata.mybatipse.Activator;
/*     */ import org.eclipse.core.resources.IFile;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jface.text.IRegion;
/*     */ import org.eclipse.jface.text.ITextViewer;
/*     */ import org.eclipse.jface.text.hyperlink.IHyperlink;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.ui.IEditorPart;
/*     */ import org.eclipse.ui.IWorkbench;
/*     */ import org.eclipse.ui.IWorkbenchWindow;
/*     */ import org.eclipse.ui.PartInitException;
/*     */ import org.eclipse.ui.PlatformUI;
/*     */ import org.eclipse.ui.ide.IDE;
/*     */ import org.eclipse.ui.part.MultiPageEditorPart;
/*     */ import org.eclipse.ui.texteditor.ITextEditor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ToXmlHyperlink
/*     */   implements IHyperlink
/*     */ {
/*     */   private ITextViewer textViewer;
/*     */   private IFile file;
/*     */   private IRegion srcRegion;
/*     */   private String linkLabel;
/*     */   private IRegion destRegion;
/*     */   private IType type;
/*     */   private String expression;
/*     */   
/*     */   public ToXmlHyperlink(ITextViewer textViewer, IRegion srcRegion, String linkLabel, IRegion destRegion)
/*     */   {
/*  56 */     this.textViewer = textViewer;
/*  57 */     this.srcRegion = srcRegion;
/*  58 */     this.linkLabel = linkLabel;
/*  59 */     this.destRegion = destRegion;
/*     */   }
/*     */   
/*     */   public ToXmlHyperlink(IFile file, IRegion srcRegion, String linkLabel, IRegion destRegion)
/*     */   {
/*  64 */     this.file = file;
/*  65 */     this.srcRegion = srcRegion;
/*  66 */     this.linkLabel = linkLabel;
/*  67 */     this.destRegion = destRegion;
/*     */   }
/*     */   
/*     */   public IRegion getHyperlinkRegion() {
/*  71 */     return this.srcRegion;
/*     */   }
/*     */   
/*     */   public String getTypeLabel() {
/*  75 */     return this.linkLabel;
/*     */   }
/*     */   
/*     */   public String getHyperlinkText() {
/*  79 */     return this.linkLabel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(IType type)
/*     */   {
/*  88 */     this.type = type;
/*     */   }
/*     */   
/*     */   public void setExpression(String expression) {
/*  92 */     this.expression = expression;
/*     */   }
/*     */   
/*     */   public void open() {
/*  96 */     if (this.file == null) {
/*  97 */       Shell parentShell = PlatformUI.getWorkbench()
/*  98 */         .getActiveWorkbenchWindow().getShell();
/*     */       
/* 100 */       HierarchyInformationControl hierarchy = new HierarchyInformationControl(
/* 101 */         parentShell, 16, 768, 
/* 102 */         this.expression);
/*     */       
/*     */ 
/*     */ 
/* 106 */       hierarchy.setSize(400, 350);
/* 107 */       hierarchy.createTreeViewer(parentShell, 768);
/*     */       
/*     */ 
/* 110 */       hierarchy.setInput(this.type);
/* 111 */       hierarchy.open();
/*     */     } else {
/*     */       try {
/* 114 */         openXmlFile();
/*     */       } catch (Exception e) {
/* 116 */         Activator.log(2, e.getMessage(), e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void openXmlFile()
/*     */     throws PartInitException
/*     */   {
/* 127 */     IWorkbenchWindow window = PlatformUI.getWorkbench()
/* 128 */       .getActiveWorkbenchWindow();
/* 129 */     if (window != null) {
/* 130 */       IEditorPart editorPart = IDE.openEditor(window.getActivePage(), 
/* 131 */         this.file);
/* 132 */       if ((editorPart instanceof MultiPageEditorPart)) {
/* 133 */         MultiPageEditorPart multiPageEditorPart = (MultiPageEditorPart)editorPart;
/* 134 */         IEditorPart[] editors = multiPageEditorPart
/* 135 */           .findEditors(editorPart.getEditorInput());
/* 136 */         if ((editors.length == 1) && ((editors[0] instanceof ITextEditor))) {
/* 137 */           ((ITextEditor)editors[0]).selectAndReveal(
/* 138 */             this.destRegion.getOffset(), this.destRegion.getLength());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\hyperlink\ToXmlHyperlink.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */