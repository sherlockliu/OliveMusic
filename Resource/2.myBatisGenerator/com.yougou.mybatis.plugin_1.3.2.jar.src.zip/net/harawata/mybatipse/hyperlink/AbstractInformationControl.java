/*     */ package net.harawata.mybatipse.hyperlink;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.IJavaElement;
/*     */ import org.eclipse.jdt.core.IParent;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.internal.ui.JavaPlugin;
/*     */ import org.eclipse.jdt.internal.ui.util.StringMatcher;
/*     */ import org.eclipse.jdt.ui.actions.CustomFiltersActionGroup;
/*     */ import org.eclipse.jface.action.Action;
/*     */ import org.eclipse.jface.action.IAction;
/*     */ import org.eclipse.jface.action.IMenuManager;
/*     */ import org.eclipse.jface.dialogs.Dialog;
/*     */ import org.eclipse.jface.dialogs.IDialogSettings;
/*     */ import org.eclipse.jface.dialogs.PopupDialog;
/*     */ import org.eclipse.jface.text.IInformationControl;
/*     */ import org.eclipse.jface.text.IInformationControlExtension;
/*     */ import org.eclipse.jface.text.IInformationControlExtension2;
/*     */ import org.eclipse.jface.viewers.ILabelProvider;
/*     */ import org.eclipse.jface.viewers.IStructuredSelection;
/*     */ import org.eclipse.jface.viewers.ITreeContentProvider;
/*     */ import org.eclipse.jface.viewers.StructuredSelection;
/*     */ import org.eclipse.jface.viewers.TreeViewer;
/*     */ import org.eclipse.jface.viewers.Viewer;
/*     */ import org.eclipse.jface.viewers.ViewerFilter;
/*     */ import org.eclipse.osgi.util.TextProcessor;
/*     */ import org.eclipse.swt.events.DisposeEvent;
/*     */ import org.eclipse.swt.events.DisposeListener;
/*     */ import org.eclipse.swt.events.FocusListener;
/*     */ import org.eclipse.swt.events.KeyEvent;
/*     */ import org.eclipse.swt.events.KeyListener;
/*     */ import org.eclipse.swt.events.ModifyEvent;
/*     */ import org.eclipse.swt.events.ModifyListener;
/*     */ import org.eclipse.swt.events.MouseAdapter;
/*     */ import org.eclipse.swt.events.MouseEvent;
/*     */ import org.eclipse.swt.events.MouseMoveListener;
/*     */ import org.eclipse.swt.events.SelectionEvent;
/*     */ import org.eclipse.swt.events.SelectionListener;
/*     */ import org.eclipse.swt.graphics.Color;
/*     */ import org.eclipse.swt.graphics.Point;
/*     */ import org.eclipse.swt.graphics.Rectangle;
/*     */ import org.eclipse.swt.layout.GridData;
/*     */ import org.eclipse.swt.widgets.Composite;
/*     */ import org.eclipse.swt.widgets.Control;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Item;
/*     */ import org.eclipse.swt.widgets.Label;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.eclipse.swt.widgets.Text;
/*     */ import org.eclipse.swt.widgets.Tree;
/*     */ import org.eclipse.swt.widgets.TreeItem;
/*     */ import org.eclipse.ui.IWorkbench;
/*     */ import org.eclipse.ui.PlatformUI;
/*     */ import org.eclipse.ui.commands.ActionHandler;
/*     */ import org.eclipse.ui.commands.HandlerSubmission;
/*     */ import org.eclipse.ui.commands.ICommand;
/*     */ import org.eclipse.ui.commands.ICommandManager;
/*     */ import org.eclipse.ui.commands.IKeySequenceBinding;
/*     */ import org.eclipse.ui.commands.IWorkbenchCommandSupport;
/*     */ import org.eclipse.ui.commands.Priority;
/*     */ import org.eclipse.ui.keys.KeySequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractInformationControl
/*     */   extends PopupDialog
/*     */   implements IInformationControl, IInformationControlExtension, IInformationControlExtension2, DisposeListener
/*     */ {
/*     */   private Text fFilterText;
/*     */   private TreeViewer fTreeViewer;
/*     */   protected StringMatcher fStringMatcher;
/*     */   private ICommand fInvokingCommand;
/*     */   private KeySequence[] fInvokingCommandKeySequences;
/*     */   private Composite fViewMenuButtonComposite;
/*     */   private CustomFiltersActionGroup fCustomFiltersActionGroup;
/*     */   private IAction fShowViewMenuAction;
/*     */   private HandlerSubmission fShowViewMenuHandlerSubmission;
/*     */   private int fTreeStyle;
/*     */   protected IType fInitiallySelectedType;
/*     */   
/*     */   public AbstractInformationControl(Shell parent, int shellStyle, int treeStyle, String invokingCommandId, boolean showStatusField)
/*     */   {
/*  86 */     super(parent, shellStyle, true, true, false, true, true, null, null);
/*  87 */     if (invokingCommandId != null) {
/*  88 */       ICommandManager commandManager = PlatformUI.getWorkbench()
/*  89 */         .getCommandSupport().getCommandManager();
/*  90 */       this.fInvokingCommand = commandManager
/*  91 */         .getCommand(invokingCommandId);
/*  92 */       if ((this.fInvokingCommand != null) && 
/*  93 */         (!this.fInvokingCommand.isDefined())) {
/*  94 */         this.fInvokingCommand = null;
/*     */       } else
/*  96 */         getInvokingCommandKeySequences();
/*     */     }
/*  98 */     this.fTreeStyle = treeStyle;
/*     */     
/* 100 */     if (hasHeader())
/* 101 */       setTitleText("");
/* 102 */     setInfoText("");
/*     */     
/* 104 */     create();
/*     */     
/* 106 */     setInfoText(getStatusFieldText());
/*     */   }
/*     */   
/*     */   protected Control createDialogArea(Composite parent) {
/* 110 */     this.fTreeViewer = createTreeViewer(parent, this.fTreeStyle);
/*     */     
/* 112 */     this.fCustomFiltersActionGroup = new CustomFiltersActionGroup(getId(), 
/* 113 */       this.fTreeViewer);
/*     */     
/* 115 */     final Tree tree = this.fTreeViewer.getTree();
/* 116 */     tree.addKeyListener(new KeyListener() {
/*     */       public void keyPressed(KeyEvent e) {
/* 118 */         if (e.character == '\033') {
/* 119 */           AbstractInformationControl.this.dispose();
/*     */         }
/*     */       }
/*     */       
/*     */       public void keyReleased(KeyEvent e) {}
/* 124 */     });
/* 125 */     tree.addSelectionListener(new SelectionListener()
/*     */     {
/*     */       public void widgetSelected(SelectionEvent e) {}
/*     */       
/*     */       public void widgetDefaultSelected(SelectionEvent e) {
/* 130 */         AbstractInformationControl.this.gotoSelectedElement();
/*     */       }
/*     */       
/* 133 */     });
/* 134 */     tree.addMouseMoveListener(new MouseMoveListener() {
/* 135 */       TreeItem fLastItem = null;
/*     */       
/*     */       public void mouseMove(MouseEvent e) {
/* 138 */         if (tree.equals(e.getSource())) {
/* 139 */           Object o = tree.getItem(new Point(e.x, e.y));
/* 140 */           if (((this.fLastItem == null ? 1 : 0) ^ (o == null ? 1 : 0)) != 0) {
/* 141 */             tree.setCursor(o == null ? null : tree.getDisplay()
/* 142 */               .getSystemCursor(21));
/*     */           }
/* 144 */           if ((o instanceof TreeItem)) {
/* 145 */             Rectangle clientArea = tree.getClientArea();
/* 146 */             if (!o.equals(this.fLastItem)) {
/* 147 */               this.fLastItem = ((TreeItem)o);
/* 148 */               tree.setSelection(new TreeItem[] { this.fLastItem });
/* 149 */             } else if (e.y - clientArea.y < tree.getItemHeight() / 4) {
/* 150 */               Point p = tree.toDisplay(e.x, e.y);
/* 151 */               Item item = AbstractInformationControl.this.fTreeViewer
/* 152 */                 .scrollUp(p.x, p.y);
/* 153 */               if ((item instanceof TreeItem)) {
/* 154 */                 this.fLastItem = ((TreeItem)item);
/* 155 */                 tree.setSelection(new TreeItem[] { this.fLastItem });
/*     */               }
/*     */             }
/* 158 */             else if (clientArea.y + clientArea.height - e.y < tree.getItemHeight() / 4) {
/* 159 */               Point p = tree.toDisplay(e.x, e.y);
/* 160 */               Item item = AbstractInformationControl.this.fTreeViewer
/* 161 */                 .scrollDown(p.x, p.y);
/* 162 */               if ((item instanceof TreeItem)) {
/* 163 */                 this.fLastItem = ((TreeItem)item);
/* 164 */                 tree.setSelection(new TreeItem[] { this.fLastItem });
/*     */               }
/*     */             }
/* 167 */           } else if (o == null) {
/* 168 */             this.fLastItem = null;
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 173 */     });
/* 174 */     tree.addMouseListener(new MouseAdapter() {
/*     */       public void mouseUp(MouseEvent e) {
/* 176 */         if (tree.getSelectionCount() < 1) {
/* 177 */           return;
/*     */         }
/* 179 */         if (e.button != 1) {
/* 180 */           return;
/*     */         }
/* 182 */         if (tree.equals(e.getSource())) {
/* 183 */           Object o = tree.getItem(new Point(e.x, e.y));
/* 184 */           TreeItem selection = tree.getSelection()[0];
/* 185 */           if (selection.equals(o)) {
/* 186 */             AbstractInformationControl.this.gotoSelectedElement();
/*     */           }
/*     */           
/*     */         }
/*     */       }
/* 191 */     });
/* 192 */     installFilter();
/*     */     
/* 194 */     addDisposeListener(this);
/* 195 */     return this.fTreeViewer.getControl();
/*     */   }
/*     */   
/*     */   public AbstractInformationControl(Shell parent, int shellStyle, int treeStyle)
/*     */   {
/* 200 */     this(parent, shellStyle, treeStyle, null, false);
/*     */   }
/*     */   
/*     */   protected abstract TreeViewer createTreeViewer(Composite paramComposite, int paramInt);
/*     */   
/*     */   protected abstract String getId();
/*     */   
/*     */   protected TreeViewer getTreeViewer()
/*     */   {
/* 209 */     return this.fTreeViewer;
/*     */   }
/*     */   
/*     */   protected boolean hasHeader() {
/* 213 */     return false;
/*     */   }
/*     */   
/*     */   protected Text getFilterText() {
/* 217 */     return this.fFilterText;
/*     */   }
/*     */   
/*     */   protected Text createFilterText(Composite parent) {
/* 221 */     this.fFilterText = new Text(parent, 0);
/* 222 */     Dialog.applyDialogFont(this.fFilterText);
/*     */     
/* 224 */     GridData data = new GridData(768);
/* 225 */     data.horizontalAlignment = 4;
/* 226 */     data.verticalAlignment = 2;
/* 227 */     this.fFilterText.setLayoutData(data);
/*     */     
/* 229 */     this.fFilterText.addKeyListener(new KeyListener() {
/*     */       public void keyPressed(KeyEvent e) {
/* 231 */         if (e.keyCode == 13)
/* 232 */           AbstractInformationControl.this.gotoSelectedElement();
/* 233 */         if (e.keyCode == 16777218)
/*     */         {
/* 235 */           AbstractInformationControl.this.fTreeViewer.getTree().setFocus(); }
/* 236 */         if (e.keyCode == 16777217)
/*     */         {
/* 238 */           AbstractInformationControl.this.fTreeViewer.getTree().setFocus(); }
/* 239 */         if (e.character == '\033') {
/* 240 */           AbstractInformationControl.this.dispose();
/*     */         }
/*     */       }
/*     */       
/*     */       public void keyReleased(KeyEvent e) {}
/* 245 */     });
/* 246 */     return this.fFilterText;
/*     */   }
/*     */   
/*     */   protected void createHorizontalSeparator(Composite parent) {
/* 250 */     Label separator = new Label(parent, 259);
/* 251 */     separator.setLayoutData(new GridData(768));
/*     */   }
/*     */   
/*     */   protected void updateStatusFieldText() {
/* 255 */     setInfoText(getStatusFieldText());
/*     */   }
/*     */   
/*     */   protected String getStatusFieldText() {
/* 259 */     return "";
/*     */   }
/*     */   
/*     */   private void installFilter() {
/* 263 */     this.fFilterText.setText("");
/*     */     
/* 265 */     this.fFilterText.addModifyListener(new ModifyListener() {
/*     */       public void modifyText(ModifyEvent e) {
/* 267 */         String text = ((Text)e.widget).getText();
/* 268 */         int length = text.length();
/* 269 */         if ((length > 0) && (text.charAt(length - 1) != '*')) {
/* 270 */           text = text + '*';
/*     */         }
/* 272 */         AbstractInformationControl.this.setMatcherString(text, true);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   protected void stringMatcherUpdated() {
/* 278 */     this.fTreeViewer.getControl().setRedraw(false);
/* 279 */     this.fTreeViewer.refresh();
/* 280 */     this.fTreeViewer.expandAll();
/* 281 */     selectFirstMatch();
/* 282 */     this.fTreeViewer.getControl().setRedraw(true);
/*     */   }
/*     */   
/*     */   protected void setMatcherString(String pattern, boolean update) {
/* 286 */     if (pattern.length() == 0) {
/* 287 */       this.fStringMatcher = null;
/*     */     } else {
/* 289 */       boolean ignoreCase = pattern.toLowerCase().equals(pattern);
/* 290 */       this.fStringMatcher = new StringMatcher(pattern, ignoreCase, false);
/*     */     }
/*     */     
/* 293 */     if (update)
/* 294 */       stringMatcherUpdated();
/*     */   }
/*     */   
/*     */   protected StringMatcher getMatcher() {
/* 298 */     return this.fStringMatcher;
/*     */   }
/*     */   
/*     */   protected Object getSelectedElement() {
/* 302 */     if (this.fTreeViewer == null) {
/* 303 */       return null;
/*     */     }
/* 305 */     return 
/* 306 */       ((IStructuredSelection)this.fTreeViewer.getSelection()).getFirstElement();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void gotoSelectedElement();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void selectFirstMatch()
/*     */   {
/* 327 */     Object selectedElement = this.fTreeViewer
/* 328 */       .testFindItem(this.fInitiallySelectedType);
/*     */     
/* 330 */     Tree tree = this.fTreeViewer.getTree();
/*     */     TreeItem element;
/* 332 */     TreeItem element; if ((selectedElement instanceof TreeItem)) {
/* 333 */       element = findElement(new TreeItem[] { (TreeItem)selectedElement });
/*     */     } else {
/* 335 */       element = findElement(tree.getItems());
/*     */     }
/* 337 */     if (element != null) {
/* 338 */       tree.setSelection(element);
/* 339 */       tree.showItem(element);
/*     */     } else {
/* 341 */       this.fTreeViewer.setSelection(StructuredSelection.EMPTY);
/*     */     }
/*     */   }
/*     */   
/*     */   private TreeItem findElement(TreeItem[] items) {
/* 346 */     return findElement(items, null, true);
/*     */   }
/*     */   
/*     */   private TreeItem findElement(TreeItem[] items, TreeItem[] toBeSkipped, boolean allowToGoUp)
/*     */   {
/* 351 */     if (this.fStringMatcher == null) {
/* 352 */       return items.length > 0 ? items[0] : null;
/*     */     }
/* 354 */     ILabelProvider labelProvider = (ILabelProvider)this.fTreeViewer
/* 355 */       .getLabelProvider();
/*     */     
/* 357 */     for (int i = 0; i < items.length; i++) {
/* 358 */       TreeItem item = items[i];
/* 359 */       IJavaElement element = (IJavaElement)item.getData();
/* 360 */       if (element != null) {
/* 361 */         String label = labelProvider.getText(element);
/* 362 */         if (this.fStringMatcher.match(label)) {
/* 363 */           return item;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 368 */     for (int i = 0; i < items.length; i++) {
/* 369 */       TreeItem item = items[i];
/* 370 */       TreeItem foundItem = findElement(
/* 371 */         selectItems(item.getItems(), toBeSkipped), null, false);
/* 372 */       if (foundItem != null) {
/* 373 */         return foundItem;
/*     */       }
/*     */     }
/* 376 */     if ((!allowToGoUp) || (items.length == 0)) {
/* 377 */       return null;
/*     */     }
/*     */     
/* 380 */     TreeItem parentItem = items[0].getParentItem();
/* 381 */     if (parentItem != null) {
/* 382 */       return findElement(new TreeItem[] { parentItem }, items, true);
/*     */     }
/*     */     
/* 385 */     return findElement(selectItems(items[0].getParent().getItems(), items), 
/* 386 */       null, false);
/*     */   }
/*     */   
/*     */   private boolean canSkip(TreeItem item, TreeItem[] toBeSkipped) {
/* 390 */     if (toBeSkipped == null) {
/* 391 */       return false;
/*     */     }
/* 393 */     for (int i = 0; i < toBeSkipped.length; i++) {
/* 394 */       if (toBeSkipped[i] == item)
/* 395 */         return true;
/*     */     }
/* 397 */     return false;
/*     */   }
/*     */   
/*     */   private TreeItem[] selectItems(TreeItem[] items, TreeItem[] toBeSkipped) {
/* 401 */     if ((toBeSkipped == null) || (toBeSkipped.length == 0)) {
/* 402 */       return items;
/*     */     }
/* 404 */     int j = 0;
/* 405 */     for (int i = 0; i < items.length; i++) {
/* 406 */       TreeItem item = items[i];
/* 407 */       if (!canSkip(item, toBeSkipped))
/* 408 */         items[(j++)] = item;
/*     */     }
/* 410 */     if (j == items.length) {
/* 411 */       return items;
/*     */     }
/* 413 */     TreeItem[] result = new TreeItem[j];
/* 414 */     System.arraycopy(items, 0, result, 0, j);
/* 415 */     return result;
/*     */   }
/*     */   
/*     */   public void setInformation(String information) {}
/*     */   
/*     */   public abstract void setInput(Object paramObject);
/*     */   
/*     */   protected void fillViewMenu(IMenuManager viewMenu)
/*     */   {
/* 424 */     this.fCustomFiltersActionGroup.fillViewMenu(viewMenu);
/*     */   }
/*     */   
/*     */   protected void fillDialogMenu(IMenuManager dialogMenu) {
/* 428 */     super.fillDialogMenu(dialogMenu);
/* 429 */     fillViewMenu(dialogMenu);
/*     */   }
/*     */   
/*     */   protected void inputChanged(Object newInput, Object newSelection) {
/* 433 */     this.fFilterText.setText("");
/* 434 */     this.fInitiallySelectedType = null;
/* 435 */     if ((newSelection instanceof IJavaElement)) {
/* 436 */       IJavaElement javaElement = (IJavaElement)newSelection;
/* 437 */       if (javaElement.getElementType() == 7) {
/* 438 */         this.fInitiallySelectedType = ((IType)javaElement);
/*     */       } else
/* 440 */         this.fInitiallySelectedType = 
/* 441 */           ((IType)javaElement.getAncestor(7));
/*     */     }
/* 443 */     this.fTreeViewer.setInput(newInput);
/* 444 */     if (newSelection != null)
/*     */     {
/* 446 */       this.fTreeViewer.setSelection(new StructuredSelection(newSelection)); }
/*     */   }
/*     */   
/*     */   public void setVisible(boolean visible) {
/* 450 */     if (visible) {
/* 451 */       open();
/*     */     } else {
/* 453 */       removeHandlerAndKeyBindingSupport();
/* 454 */       saveDialogBounds(getShell());
/* 455 */       getShell().setVisible(false);
/*     */     }
/*     */   }
/*     */   
/*     */   public int open() {
/* 460 */     addHandlerAndKeyBindingSupport();
/* 461 */     return super.open();
/*     */   }
/*     */   
/*     */   public final void dispose() {
/* 465 */     close();
/*     */   }
/*     */   
/*     */   public void widgetDisposed(DisposeEvent event) {
/* 469 */     removeHandlerAndKeyBindingSupport();
/* 470 */     this.fTreeViewer = null;
/* 471 */     this.fFilterText = null;
/*     */   }
/*     */   
/*     */   protected void addHandlerAndKeyBindingSupport() {
/* 475 */     if (this.fShowViewMenuHandlerSubmission == null) {
/* 476 */       this.fShowViewMenuHandlerSubmission = new HandlerSubmission(null, 
/* 477 */         getShell(), null, 
/* 478 */         this.fShowViewMenuAction.getActionDefinitionId(), 
/* 479 */         new ActionHandler(this.fShowViewMenuAction), 
/* 480 */         Priority.MEDIUM);
/* 481 */       PlatformUI.getWorkbench().getCommandSupport()
/* 482 */         .addHandlerSubmission(this.fShowViewMenuHandlerSubmission);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void removeHandlerAndKeyBindingSupport() {
/* 487 */     if (this.fShowViewMenuHandlerSubmission != null)
/*     */     {
/*     */ 
/*     */ 
/* 491 */       PlatformUI.getWorkbench().getCommandSupport().removeHandlerSubmission(
/* 492 */         this.fShowViewMenuHandlerSubmission);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean hasContents() {
/* 497 */     return (this.fTreeViewer != null) && (this.fTreeViewer.getInput() != null);
/*     */   }
/*     */   
/*     */   public void setSizeConstraints(int maxWidth, int maxHeight) {}
/*     */   
/*     */   public Point computeSizeHint()
/*     */   {
/* 504 */     return getShell().getSize();
/*     */   }
/*     */   
/*     */   public void setLocation(Point location) {
/* 508 */     if ((!getPersistLocation()) || (getDialogSettings() == null))
/* 509 */       getShell().setLocation(location);
/*     */   }
/*     */   
/*     */   public void setSize(int width, int height) {
/* 513 */     getShell().setSize(width, height);
/*     */   }
/*     */   
/*     */   public void addDisposeListener(DisposeListener listener) {
/* 517 */     getShell().addDisposeListener(listener);
/*     */   }
/*     */   
/*     */   public void removeDisposeListener(DisposeListener listener) {
/* 521 */     getShell().removeDisposeListener(listener);
/*     */   }
/*     */   
/*     */   public void setForegroundColor(Color foreground) {
/* 525 */     applyForegroundColor(foreground, getContents());
/*     */   }
/*     */   
/*     */   public void setBackgroundColor(Color background) {
/* 529 */     applyBackgroundColor(background, getContents());
/*     */   }
/*     */   
/*     */   public boolean isFocusControl() {
/* 533 */     return getShell().getDisplay().getActiveShell() == getShell();
/*     */   }
/*     */   
/*     */   public void setFocus() {
/* 537 */     getShell().forceFocus();
/* 538 */     this.fFilterText.setFocus();
/*     */   }
/*     */   
/*     */   public void addFocusListener(FocusListener listener) {
/* 542 */     getShell().addFocusListener(listener);
/*     */   }
/*     */   
/*     */   public void removeFocusListener(FocusListener listener) {
/* 546 */     getShell().removeFocusListener(listener);
/*     */   }
/*     */   
/*     */   protected final ICommand getInvokingCommand() {
/* 550 */     return this.fInvokingCommand;
/*     */   }
/*     */   
/*     */   protected final KeySequence[] getInvokingCommandKeySequences()
/*     */   {
/* 555 */     if ((this.fInvokingCommandKeySequences == null) && 
/* 556 */       (getInvokingCommand() != null)) {
/* 557 */       List list = getInvokingCommand().getKeySequenceBindings();
/* 558 */       if (!list.isEmpty()) {
/* 559 */         this.fInvokingCommandKeySequences = new KeySequence[list.size()];
/* 560 */         for (int i = 0; i < this.fInvokingCommandKeySequences.length; i++) {
/* 561 */           this.fInvokingCommandKeySequences[i] = 
/* 562 */             ((IKeySequenceBinding)list.get(i)).getKeySequence();
/*     */         }
/* 564 */         return this.fInvokingCommandKeySequences;
/*     */       }
/*     */     }
/*     */     
/* 568 */     return this.fInvokingCommandKeySequences;
/*     */   }
/*     */   
/*     */   protected IDialogSettings getDialogSettings() {
/* 572 */     String sectionName = getId();
/*     */     
/* 574 */     IDialogSettings settings = JavaPlugin.getDefault().getDialogSettings()
/* 575 */       .getSection(sectionName);
/* 576 */     if (settings == null) {
/* 577 */       settings = 
/* 578 */         JavaPlugin.getDefault().getDialogSettings().addNewSection(sectionName);
/*     */     }
/* 580 */     return settings;
/*     */   }
/*     */   
/*     */   protected Control createTitleMenuArea(Composite parent) {
/* 584 */     this.fViewMenuButtonComposite = 
/* 585 */       ((Composite)super.createTitleMenuArea(parent));
/*     */     
/* 587 */     if (hasHeader()) {
/* 588 */       this.fFilterText = createFilterText(parent);
/*     */     }
/*     */     
/* 591 */     this.fShowViewMenuAction = new Action("showViewMenu") {
/*     */       public void run() {
/* 593 */         AbstractInformationControl.this.showDialogMenu();
/*     */       }
/* 595 */     };
/* 596 */     this.fShowViewMenuAction.setEnabled(true);
/* 597 */     this.fShowViewMenuAction
/* 598 */       .setActionDefinitionId("org.eclipse.ui.window.showViewMenu");
/*     */     
/* 600 */     return this.fViewMenuButtonComposite;
/*     */   }
/*     */   
/*     */   protected Control createTitleControl(Composite parent) {
/* 604 */     if (hasHeader()) {
/* 605 */       return super.createTitleControl(parent);
/*     */     }
/* 607 */     this.fFilterText = createFilterText(parent);
/* 608 */     return this.fFilterText;
/*     */   }
/*     */   
/*     */   protected void setTabOrder(Composite composite) {
/* 612 */     if (hasHeader()) {
/* 613 */       composite.setTabList(new Control[] { this.fFilterText, 
/* 614 */         this.fTreeViewer.getTree() });
/*     */     }
/*     */     else {
/* 617 */       this.fViewMenuButtonComposite.setTabList(new Control[] { this.fFilterText });
/* 618 */       composite.setTabList(new Control[] { this.fViewMenuButtonComposite, 
/* 619 */         this.fTreeViewer.getTree() });
/*     */     }
/*     */   }
/*     */   
/*     */   protected class NamePatternFilter extends ViewerFilter
/*     */   {
/*     */     public NamePatternFilter() {}
/*     */     
/*     */     public boolean select(Viewer viewer, Object parentElement, Object element)
/*     */     {
/* 629 */       StringMatcher matcher = AbstractInformationControl.this
/* 630 */         .getMatcher();
/* 631 */       if ((matcher == null) || (!(viewer instanceof TreeViewer)))
/* 632 */         return true;
/* 633 */       TreeViewer treeViewer = (TreeViewer)viewer;
/*     */       
/* 635 */       String matchName = ((ILabelProvider)treeViewer.getLabelProvider())
/* 636 */         .getText(element);
/* 637 */       matchName = TextProcessor.deprocess(matchName);
/* 638 */       if ((matchName != null) && (matcher.match(matchName))) {
/* 639 */         return true;
/*     */       }
/* 641 */       return hasUnfilteredChild(treeViewer, element);
/*     */     }
/*     */     
/*     */     private boolean hasUnfilteredChild(TreeViewer viewer, Object element) {
/* 645 */       if ((element instanceof IParent)) {
/* 646 */         Object[] children = ((ITreeContentProvider)viewer
/* 647 */           .getContentProvider()).getChildren(element);
/* 648 */         for (int i = 0; i < children.length; i++)
/* 649 */           if (select(viewer, element, children[i]))
/* 650 */             return true;
/*     */       }
/* 652 */       return false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\hyperlink\AbstractInformationControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */