/*     */ package net.harawata.mybatipse.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.ICompilationUnit;
/*     */ import org.eclipse.jdt.core.IField;
/*     */ import org.eclipse.jdt.core.IImportDeclaration;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IMethod;
/*     */ import org.eclipse.jdt.core.IPackageDeclaration;
/*     */ import org.eclipse.jdt.core.IType;
/*     */ import org.eclipse.jdt.core.JavaModelException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameUtil
/*     */ {
/*     */   public static String buildQualifiedName(char[] packageName, char[] simpleTypeName, char[][] enclosingTypeNames, boolean useDollarForInnerClassSeparator)
/*     */   {
/*  44 */     char innerClassSeparator = useDollarForInnerClassSeparator ? '$' : '.';
/*  45 */     StringBuilder typeFqn = new StringBuilder().append(packageName).append('.');
/*  46 */     char[][] arrayOfChar; int j = (arrayOfChar = enclosingTypeNames).length; for (int i = 0; i < j; i++) { char[] enclosingTypeName = arrayOfChar[i];
/*     */       
/*  48 */       typeFqn.append(enclosingTypeName).append(innerClassSeparator);
/*     */     }
/*  50 */     typeFqn.append(simpleTypeName).toString();
/*  51 */     return typeFqn.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static List<IMethod> getAllSuperMethods(List<IMethod> methods, IJavaProject project, IType javaMapperType)
/*     */     throws JavaModelException
/*     */   {
/*  59 */     if (javaMapperType == null) {
/*  60 */       return methods;
/*     */     }
/*     */     
/*  63 */     String[] qualifiedNames = javaMapperType.getSuperInterfaceNames();
/*     */     
/*  65 */     String qualifiedClassName = javaMapperType.getSuperclassName();
/*     */     
/*  67 */     if (((qualifiedNames == null) || (qualifiedNames.length == 0)) && (qualifiedClassName == null)) {
/*  68 */       if (methods == null) {
/*  69 */         methods = new ArrayList();
/*     */       }
/*  71 */       methods.addAll(Arrays.asList(javaMapperType.getMethods()));
/*  72 */       return methods;
/*     */     }
/*  74 */     ICompilationUnit compilationUnit = javaMapperType.getCompilationUnit();
/*  75 */     if (compilationUnit == null) {
/*  76 */       return methods;
/*     */     }
/*  78 */     IImportDeclaration[] imports = compilationUnit.getImports();
/*  79 */     Object localObject; int j; int i; if ((imports != null) && (imports.length > 0)) {
/*  80 */       j = (localObject = imports).length; for (i = 0; i < j; i++) { IImportDeclaration im = localObject[i];
/*  81 */         if ((qualifiedNames != null) && (qualifiedNames.length > 0)) { String[] arrayOfString1;
/*  82 */           int m = (arrayOfString1 = qualifiedNames).length; for (int k = 0; k < m; k++) { String name = arrayOfString1[k];
/*  83 */             methods = getMethods(methods, project, javaMapperType, im, name);
/*     */           }
/*     */         }
/*     */         
/*  87 */         if ((qualifiedClassName != null) && (!"".equals(qualifiedClassName.trim()))) {
/*  88 */           methods = getMethods(methods, project, javaMapperType, im, 
/*  89 */             qualifiedClassName);
/*     */         }
/*     */       }
/*     */     } else {
/*  93 */       if ((qualifiedNames != null) && (qualifiedNames.length > 0)) {
/*  94 */         j = (localObject = qualifiedNames).length; for (i = 0; i < j; i++) { String name = localObject[i];
/*  95 */           methods = getMethods(methods, project, javaMapperType, null, name);
/*     */         }
/*     */       }
/*     */       
/*  99 */       if ((qualifiedClassName != null) && (!"".equals(qualifiedClassName.trim()))) {
/* 100 */         methods = getMethods(methods, project, javaMapperType, null, 
/* 101 */           qualifiedClassName);
/*     */       }
/*     */     }
/*     */     
/* 105 */     return methods;
/*     */   }
/*     */   
/*     */   public static List<IField> getAllSuperFields(List<IField> fields, IJavaProject project, IType javaMapperType) throws JavaModelException
/*     */   {
/* 110 */     if (javaMapperType == null) {
/* 111 */       return fields;
/*     */     }
/*     */     
/* 114 */     String[] qualifiedNames = javaMapperType.getSuperInterfaceNames();
/*     */     
/* 116 */     String qualifiedClassName = javaMapperType.getSuperclassName();
/*     */     
/* 118 */     if (((qualifiedNames == null) || (qualifiedNames.length == 0)) && (qualifiedClassName == null)) {
/* 119 */       if (fields == null) {
/* 120 */         fields = new ArrayList();
/*     */       }
/* 122 */       fields.addAll(Arrays.asList(javaMapperType.getFields()));
/* 123 */       return fields;
/*     */     }
/* 125 */     ICompilationUnit compilationUnit = javaMapperType.getCompilationUnit();
/* 126 */     if (compilationUnit == null) {
/* 127 */       return fields;
/*     */     }
/* 129 */     IImportDeclaration[] imports = compilationUnit.getImports();
/* 130 */     Object localObject; int j; int i; if ((imports != null) && (imports.length > 0)) {
/* 131 */       j = (localObject = imports).length; for (i = 0; i < j; i++) { IImportDeclaration im = localObject[i];
/* 132 */         if ((qualifiedNames != null) && (qualifiedNames.length > 0)) { String[] arrayOfString1;
/* 133 */           int m = (arrayOfString1 = qualifiedNames).length; for (int k = 0; k < m; k++) { String name = arrayOfString1[k];
/* 134 */             fields = getFields(fields, project, javaMapperType, im, name);
/*     */           }
/*     */         }
/*     */         
/* 138 */         if ((qualifiedClassName != null) && (!"".equals(qualifiedClassName.trim()))) {
/* 139 */           fields = getFields(fields, project, javaMapperType, im, 
/* 140 */             qualifiedClassName);
/*     */         }
/*     */       }
/*     */     } else {
/* 144 */       if ((qualifiedNames != null) && (qualifiedNames.length > 0)) {
/* 145 */         j = (localObject = qualifiedNames).length; for (i = 0; i < j; i++) { String name = localObject[i];
/* 146 */           fields = getFields(fields, project, javaMapperType, null, name);
/*     */         }
/*     */       }
/*     */       
/* 150 */       if ((qualifiedClassName != null) && (!"".equals(qualifiedClassName.trim()))) {
/* 151 */         fields = getFields(fields, project, javaMapperType, null, 
/* 152 */           qualifiedClassName);
/*     */       }
/*     */     }
/*     */     
/* 156 */     return fields;
/*     */   }
/*     */   
/*     */ 
/*     */   private static List<IMethod> getMethods(List<IMethod> methods, IJavaProject project, IType javaMapperType, IImportDeclaration im, String name)
/*     */     throws JavaModelException
/*     */   {
/* 163 */     IType findType = null;
/* 164 */     if ((im != null) && (im.getElementName().endsWith(name))) {
/* 165 */       findType = project.findType(im.getElementName());
/* 166 */       if (methods == null) {
/* 167 */         methods = new ArrayList();
/*     */       }
/* 169 */       if ((findType != null) && (findType.getMethods() != null) && (findType.getMethods().length > 0)) {
/* 170 */         methods.addAll(Arrays.asList(findType.getMethods()));
/*     */       }
/*     */     }
/*     */     else {
/* 174 */       findType = project.findType(name);
/* 175 */       if (findType == null) {
/* 176 */         IPackageDeclaration[] packages = javaMapperType.getCompilationUnit().getPackageDeclarations();
/* 177 */         if ((packages != null) && (packages.length > 0)) {
/* 178 */           String pack = packages[0].getElementName() + "." + name;
/* 179 */           findType = project.findType(pack);
/* 180 */           if ((findType != null) && (findType.getMethods() != null) && (findType.getMethods().length > 0)) {
/* 181 */             if (methods == null) {
/* 182 */               methods = new ArrayList();
/*     */             }
/* 184 */             methods.addAll(Arrays.asList(findType.getMethods()));
/*     */           }
/*     */         }
/*     */       } else {
/* 188 */         if (methods == null) {
/* 189 */           methods = new ArrayList();
/*     */         }
/* 191 */         if ((findType.getMethods() != null) && (findType.getMethods().length > 0)) {
/* 192 */           methods.addAll(Arrays.asList(findType.getMethods()));
/*     */         }
/*     */       }
/*     */     }
/* 196 */     return getAllSuperMethods(methods, project, findType);
/*     */   }
/*     */   
/*     */ 
/*     */   private static List<IField> getFields(List<IField> fields, IJavaProject project, IType javaMapperType, IImportDeclaration im, String name)
/*     */     throws JavaModelException
/*     */   {
/* 203 */     IType findType = null;
/* 204 */     if ((im != null) && (im.getElementName().endsWith(name))) {
/* 205 */       findType = project.findType(im.getElementName());
/* 206 */       if (fields == null) {
/* 207 */         fields = new ArrayList();
/*     */       }
/* 209 */       if ((findType != null) && (findType.getFields() != null) && (findType.getFields().length > 0)) {
/* 210 */         fields.addAll(Arrays.asList(findType.getFields()));
/*     */       }
/*     */     } else {
/* 213 */       findType = project.findType(name);
/* 214 */       if (findType == null) {
/* 215 */         IPackageDeclaration[] packages = javaMapperType.getCompilationUnit().getPackageDeclarations();
/* 216 */         if ((packages != null) && (packages.length > 0)) {
/* 217 */           String pack = packages[0].getElementName() + "." + name;
/* 218 */           findType = project.findType(pack);
/* 219 */           if ((findType != null) && (findType.getFields() != null) && (findType.getFields().length > 0)) {
/* 220 */             if (fields == null) {
/* 221 */               fields = new ArrayList();
/*     */             }
/* 223 */             fields.addAll(Arrays.asList(findType.getFields()));
/*     */           }
/*     */         }
/*     */       } else {
/* 227 */         if (fields == null) {
/* 228 */           fields = new ArrayList();
/*     */         }
/* 230 */         if ((findType.getFields() != null) && (findType.getFields().length > 0)) {
/* 231 */           fields.addAll(Arrays.asList(findType.getFields()));
/*     */         }
/*     */       }
/*     */     }
/* 235 */     return getAllSuperFields(fields, project, findType);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\util\NameUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */