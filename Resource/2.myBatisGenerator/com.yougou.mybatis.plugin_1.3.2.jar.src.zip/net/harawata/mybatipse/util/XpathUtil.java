/*    */ package net.harawata.mybatipse.util;
/*    */ 
/*    */ import javax.xml.namespace.NamespaceContext;
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.xpath.XPath;
/*    */ import javax.xml.xpath.XPathConstants;
/*    */ import javax.xml.xpath.XPathExpressionException;
/*    */ import javax.xml.xpath.XPathFactory;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XpathUtil
/*    */ {
/*    */   public static boolean xpathBool(Node node, String expression)
/*    */     throws XPathExpressionException
/*    */   {
/* 31 */     return ((Boolean)evaluateXpath(expression, node, XPathConstants.BOOLEAN, null)).booleanValue();
/*    */   }
/*    */   
/*    */   public static String xpathString(Node node, String expression)
/*    */     throws XPathExpressionException
/*    */   {
/* 37 */     return (String)evaluateXpath(expression, node, XPathConstants.STRING, null);
/*    */   }
/*    */   
/*    */   public static Node xpathNode(Node node, String expression) throws XPathExpressionException
/*    */   {
/* 42 */     return (Node)evaluateXpath(expression, node, XPathConstants.NODE, null);
/*    */   }
/*    */   
/*    */   public static NodeList xpathNodes(Node node, String expression)
/*    */     throws XPathExpressionException
/*    */   {
/* 48 */     return xpathNodes(node, expression, null);
/*    */   }
/*    */   
/*    */   public static NodeList xpathNodes(Node node, String expression, NamespaceContext nsContext)
/*    */     throws XPathExpressionException
/*    */   {
/* 54 */     return (NodeList)evaluateXpath(expression, node, XPathConstants.NODESET, nsContext);
/*    */   }
/*    */   
/*    */   public static Object evaluateXpath(String expression, Object node, QName returnType, NamespaceContext nsContext)
/*    */     throws XPathExpressionException
/*    */   {
/* 60 */     XPathFactory xpathFactory = XPathFactory.newInstance();
/* 61 */     XPath xpath = xpathFactory.newXPath();
/* 62 */     if (nsContext != null)
/*    */     {
/* 64 */       xpath.setNamespaceContext(nsContext);
/*    */     }
/* 66 */     return xpath.evaluate(expression, node, returnType);
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\util\XpathUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */