/*    */ package net.harawata.mybatipse;
/*    */ 
/*    */ import org.eclipse.core.runtime.Platform;
/*    */ import org.eclipse.core.runtime.content.IContentType;
/*    */ import org.eclipse.core.runtime.content.IContentTypeManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MybatipseConstants
/*    */ {
/*    */   public static final String PLUGIN_ID = "com.yougou.mybatis.plugin";
/*    */   public static final String CONTENT_TYPE_CONFIG = "net.harawata.mybatipse.Config";
/*    */   public static final String CONTENT_TYPE_MAPPER = "net.harawata.mybatipse.Mapper";
/*    */   public static final String CONTENT_TYPE_SPRING_CONFIG = "net.harawata.mybatipse.SpringConfig";
/*    */   public static final String PREF_CUSTOM_TYPE_ALIASES = "prefCustomTypeAliases";
/*    */   public static final String PREF_CUSTOM_MAPPER_NAMES = "prefCustomMapperNames";
/*    */   public static final String DEBUG_BEAN_PROPERTY_CACHE = "com.yougou.mybatis.plugin/debug/beanPropertyCache";
/*    */   public static final IContentType mapperContentType;
/*    */   public static final IContentType configContentType;
/*    */   public static final IContentType springConfigContentType;
/*    */   
/*    */   static
/*    */   {
/* 48 */     IContentTypeManager contentTypeManager = Platform.getContentTypeManager();
/* 49 */     mapperContentType = contentTypeManager.getContentType("net.harawata.mybatipse.Mapper");
/* 50 */     configContentType = contentTypeManager.getContentType("net.harawata.mybatipse.Config");
/* 51 */     springConfigContentType = contentTypeManager.getContentType("net.harawata.mybatipse.SpringConfig");
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\net\harawata\mybatipse\MybatipseConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */