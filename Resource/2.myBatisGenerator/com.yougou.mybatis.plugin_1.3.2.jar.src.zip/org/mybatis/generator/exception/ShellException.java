/*    */ package org.mybatis.generator.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ShellException
/*    */   extends Exception
/*    */ {
/*    */   static final long serialVersionUID = -2026841561754434544L;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ShellException() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ShellException(String arg0)
/*    */   {
/* 38 */     super(arg0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public ShellException(String arg0, Throwable arg1)
/*    */   {
/* 46 */     super(arg0, arg1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ShellException(Throwable arg0)
/*    */   {
/* 53 */     super(arg0);
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\exception\ShellException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */