/*    */ package org.mybatis.generator.exception;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InvalidConfigurationException
/*    */   extends Exception
/*    */ {
/*    */   static final long serialVersionUID = 4902307610148543411L;
/*    */   private List<String> errors;
/*    */   
/*    */   public InvalidConfigurationException(List<String> errors)
/*    */   {
/* 33 */     this.errors = errors;
/*    */   }
/*    */   
/*    */   public List<String> getErrors() {
/* 37 */     return this.errors;
/*    */   }
/*    */   
/*    */   public String getMessage()
/*    */   {
/* 42 */     if ((this.errors != null) && (this.errors.size() > 0)) {
/* 43 */       return (String)this.errors.get(0);
/*    */     }
/*    */     
/* 46 */     return super.getMessage();
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\exception\InvalidConfigurationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */