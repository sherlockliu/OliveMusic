/*    */ package org.mybatis.generator.ant;
/*    */ 
/*    */ import org.apache.tools.ant.Task;
/*    */ import org.mybatis.generator.internal.NullProgressCallback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AntProgressCallback
/*    */   extends NullProgressCallback
/*    */ {
/*    */   private Task task;
/*    */   private boolean verbose;
/*    */   
/*    */   public AntProgressCallback(Task task, boolean verbose)
/*    */   {
/* 39 */     this.task = task;
/* 40 */     this.verbose = verbose;
/*    */   }
/*    */   
/*    */   public void startTask(String subTaskName)
/*    */   {
/* 45 */     if (this.verbose) {
/* 46 */       this.task.log(subTaskName, 3);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\ant\AntProgressCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */