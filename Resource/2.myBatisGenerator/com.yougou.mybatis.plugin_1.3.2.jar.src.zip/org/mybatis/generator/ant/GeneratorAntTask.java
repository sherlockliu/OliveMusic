/*     */ package org.mybatis.generator.ant;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.PropertySet;
/*     */ import org.mybatis.generator.api.MyBatisGenerator;
/*     */ import org.mybatis.generator.config.Configuration;
/*     */ import org.mybatis.generator.config.xml.ConfigurationParser;
/*     */ import org.mybatis.generator.exception.InvalidConfigurationException;
/*     */ import org.mybatis.generator.exception.XMLParserException;
/*     */ import org.mybatis.generator.internal.DefaultShellCallback;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeneratorAntTask
/*     */   extends Task
/*     */ {
/*     */   private String configfile;
/*     */   private boolean overwrite;
/*     */   private PropertySet propertyset;
/*     */   private boolean verbose;
/*     */   private String contextIds;
/*     */   private String fullyQualifiedTableNames;
/*     */   
/*     */   public void execute()
/*     */     throws BuildException
/*     */   {
/* 103 */     if (!StringUtility.stringHasValue(this.configfile)) {
/* 104 */       throw new BuildException(Messages.getString("RuntimeError.0"));
/*     */     }
/*     */     
/* 107 */     List<String> warnings = new ArrayList();
/*     */     
/* 109 */     File configurationFile = new File(this.configfile);
/* 110 */     if (!configurationFile.exists()) {
/* 111 */       throw new BuildException(Messages.getString(
/* 112 */         "RuntimeError.1", this.configfile));
/*     */     }
/*     */     
/* 115 */     Set<String> fullyqualifiedTables = new HashSet();
/* 116 */     if (StringUtility.stringHasValue(this.fullyQualifiedTableNames)) {
/* 117 */       StringTokenizer st = new StringTokenizer(this.fullyQualifiedTableNames, 
/* 118 */         ",");
/* 119 */       while (st.hasMoreTokens()) {
/* 120 */         String s = st.nextToken().trim();
/* 121 */         if (s.length() > 0) {
/* 122 */           fullyqualifiedTables.add(s);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 127 */     Set<String> contexts = new HashSet();
/* 128 */     if (StringUtility.stringHasValue(this.contextIds)) {
/* 129 */       StringTokenizer st = new StringTokenizer(this.contextIds, ",");
/* 130 */       while (st.hasMoreTokens()) {
/* 131 */         String s = st.nextToken().trim();
/* 132 */         if (s.length() > 0) {
/* 133 */           contexts.add(s);
/*     */         }
/*     */       }
/*     */     }
/*     */     String error;
/*     */     try {
/* 139 */       Properties p = this.propertyset == null ? null : this.propertyset
/* 140 */         .getProperties();
/*     */       
/* 142 */       ConfigurationParser cp = new ConfigurationParser(p, warnings);
/* 143 */       config = cp.parseConfiguration(configurationFile);
/*     */       
/* 145 */       DefaultShellCallback callback = new DefaultShellCallback(this.overwrite);
/*     */       
/* 147 */       MyBatisGenerator myBatisGenerator = new MyBatisGenerator(config, callback, warnings);
/*     */       
/* 149 */       myBatisGenerator.generate(new AntProgressCallback(this, this.verbose), contexts, 
/* 150 */         fullyqualifiedTables);
/*     */     }
/*     */     catch (XMLParserException e) {
/* 153 */       for (String error : e.getErrors()) {
/* 154 */         log(error, 0);
/*     */       }
/*     */       
/* 157 */       throw new BuildException(e.getMessage());
/*     */     } catch (SQLException e) {
/* 159 */       throw new BuildException(e.getMessage());
/*     */     } catch (IOException e) {
/* 161 */       throw new BuildException(e.getMessage());
/*     */     } catch (InvalidConfigurationException e) {
/* 163 */       for (Configuration config = e.getErrors().iterator(); config.hasNext();) { error = (String)config.next();
/* 164 */         log(error, 0);
/*     */       }
/*     */       
/* 167 */       throw new BuildException(e.getMessage());
/*     */ 
/*     */     }
/*     */     catch (InterruptedException localInterruptedException) {}catch (Exception e)
/*     */     {
/* 172 */       e.printStackTrace();
/* 173 */       throw new BuildException(e.getMessage());
/*     */     }
/*     */     
/* 176 */     for (String error : warnings) {
/* 177 */       log(error, 1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getConfigfile()
/*     */   {
/* 185 */     return this.configfile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConfigfile(String configfile)
/*     */   {
/* 193 */     this.configfile = configfile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isOverwrite()
/*     */   {
/* 200 */     return this.overwrite;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOverwrite(boolean overwrite)
/*     */   {
/* 208 */     this.overwrite = overwrite;
/*     */   }
/*     */   
/*     */   public PropertySet createPropertyset() {
/* 212 */     if (this.propertyset == null) {
/* 213 */       this.propertyset = new PropertySet();
/*     */     }
/*     */     
/* 216 */     return this.propertyset;
/*     */   }
/*     */   
/*     */   public boolean isVerbose() {
/* 220 */     return this.verbose;
/*     */   }
/*     */   
/*     */   public void setVerbose(boolean verbose) {
/* 224 */     this.verbose = verbose;
/*     */   }
/*     */   
/*     */   public String getContextIds() {
/* 228 */     return this.contextIds;
/*     */   }
/*     */   
/*     */   public void setContextIds(String contextIds) {
/* 232 */     this.contextIds = contextIds;
/*     */   }
/*     */   
/*     */   public String getFullyQualifiedTableNames() {
/* 236 */     return this.fullyQualifiedTableNames;
/*     */   }
/*     */   
/*     */   public void setFullyQualifiedTableNames(String fullyQualifiedTableNames) {
/* 240 */     this.fullyQualifiedTableNames = fullyQualifiedTableNames;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\ant\GeneratorAntTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */