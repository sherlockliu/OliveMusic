package org.mybatis.generator.enums;

public enum DbmsTypeEnum
{
  MYSQL,  ORACLE,  POSTGRESQL;
}


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\enums\DbmsTypeEnum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */