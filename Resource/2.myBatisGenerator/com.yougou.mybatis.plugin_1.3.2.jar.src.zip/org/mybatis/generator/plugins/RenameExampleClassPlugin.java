/*    */ package org.mybatis.generator.plugins;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Properties;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.PluginAdapter;
/*    */ import org.mybatis.generator.internal.util.StringUtility;
/*    */ import org.mybatis.generator.internal.util.messages.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RenameExampleClassPlugin
/*    */   extends PluginAdapter
/*    */ {
/*    */   private String searchString;
/*    */   private String replaceString;
/*    */   private Pattern pattern;
/*    */   
/*    */   public boolean validate(List<String> warnings)
/*    */   {
/* 68 */     this.searchString = this.properties.getProperty("searchString");
/* 69 */     this.replaceString = this.properties.getProperty("replaceString");
/*    */     
/* 71 */     boolean valid = (StringUtility.stringHasValue(this.searchString)) && 
/* 72 */       (StringUtility.stringHasValue(this.replaceString));
/*    */     
/* 74 */     if (valid) {
/* 75 */       this.pattern = Pattern.compile(this.searchString);
/*    */     } else {
/* 77 */       if (!StringUtility.stringHasValue(this.searchString)) {
/* 78 */         warnings.add(Messages.getString("ValidationError.18", 
/* 79 */           "RenameExampleClassPlugin", 
/* 80 */           "searchString"));
/*    */       }
/* 82 */       if (!StringUtility.stringHasValue(this.replaceString)) {
/* 83 */         warnings.add(Messages.getString("ValidationError.18", 
/* 84 */           "RenameExampleClassPlugin", 
/* 85 */           "replaceString"));
/*    */       }
/*    */     }
/*    */     
/* 89 */     return valid;
/*    */   }
/*    */   
/*    */   public void initialized(IntrospectedTable introspectedTable)
/*    */   {
/* 94 */     String oldType = introspectedTable.getExampleType();
/* 95 */     Matcher matcher = this.pattern.matcher(oldType);
/* 96 */     oldType = matcher.replaceAll(this.replaceString);
/*    */     
/* 98 */     introspectedTable.setExampleType(oldType);
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\plugins\RenameExampleClassPlugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */