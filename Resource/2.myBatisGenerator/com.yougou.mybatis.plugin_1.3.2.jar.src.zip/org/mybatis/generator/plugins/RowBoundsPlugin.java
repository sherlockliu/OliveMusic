/*     */ package org.mybatis.generator.plugins;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable.TargetRuntime;
/*     */ import org.mybatis.generator.api.PluginAdapter;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.Document;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RowBoundsPlugin
/*     */   extends PluginAdapter
/*     */ {
/*     */   private FullyQualifiedJavaType rowBounds;
/*     */   private Map<FullyQualifiedTable, List<XmlElement>> elementsToAdd;
/*     */   
/*     */   public RowBoundsPlugin()
/*     */   {
/*  49 */     this.rowBounds = new FullyQualifiedJavaType("org.apache.ibatis.session.RowBounds");
/*  50 */     this.elementsToAdd = new HashMap();
/*     */   }
/*     */   
/*     */   public boolean validate(List<String> warnings) {
/*  54 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean clientSelectByExampleWithBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/*  60 */     if (introspectedTable.getTargetRuntime() == IntrospectedTable.TargetRuntime.MYBATIS3) {
/*  61 */       copyAndAddMethod(method, interfaze);
/*     */     }
/*  63 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean clientSelectByExampleWithoutBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/*  70 */     if (introspectedTable.getTargetRuntime() == IntrospectedTable.TargetRuntime.MYBATIS3) {
/*  71 */       copyAndAddMethod(method, interfaze);
/*     */     }
/*  73 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean sqlMapSelectByExampleWithoutBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/*  79 */     if (introspectedTable.getTargetRuntime() == IntrospectedTable.TargetRuntime.MYBATIS3) {
/*  80 */       copyAndSaveElement(element, introspectedTable.getFullyQualifiedTable());
/*     */     }
/*  82 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean sqlMapSelectByExampleWithBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/*  88 */     if (introspectedTable.getTargetRuntime() == IntrospectedTable.TargetRuntime.MYBATIS3) {
/*  89 */       copyAndSaveElement(element, introspectedTable.getFullyQualifiedTable());
/*     */     }
/*  91 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean sqlMapDocumentGenerated(Document document, IntrospectedTable introspectedTable)
/*     */   {
/* 101 */     List<XmlElement> elements = (List)this.elementsToAdd.get(introspectedTable.getFullyQualifiedTable());
/* 102 */     if (elements != null) {
/* 103 */       for (XmlElement element : elements) {
/* 104 */         document.getRootElement().addElement(element);
/*     */       }
/*     */     }
/*     */     
/* 108 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void copyAndAddMethod(Method method, Interface interfaze)
/*     */   {
/* 119 */     Method newMethod = new Method(method);
/* 120 */     newMethod.setName(method.getName() + "WithRowbounds");
/* 121 */     newMethod.addParameter(new Parameter(this.rowBounds, "rowBounds"));
/* 122 */     interfaze.addMethod(newMethod);
/* 123 */     interfaze.addImportedType(this.rowBounds);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void copyAndSaveElement(XmlElement element, FullyQualifiedTable fqt)
/*     */   {
/* 133 */     XmlElement newElement = new XmlElement(element);
/*     */     
/*     */ 
/* 136 */     for (Iterator<Attribute> iterator = newElement.getAttributes().iterator(); iterator.hasNext();) {
/* 137 */       Attribute attribute = (Attribute)iterator.next();
/* 138 */       if ("id".equals(attribute.getName())) {
/* 139 */         iterator.remove();
/* 140 */         Attribute newAttribute = new Attribute("id", attribute.getValue() + "WithRowbounds");
/* 141 */         newElement.addAttribute(newAttribute);
/* 142 */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 148 */     List<XmlElement> elements = (List)this.elementsToAdd.get(fqt);
/* 149 */     if (elements == null) {
/* 150 */       elements = new ArrayList();
/* 151 */       this.elementsToAdd.put(fqt, elements);
/*     */     }
/* 153 */     elements.add(newElement);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\plugins\RowBoundsPlugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */