/*     */ package org.mybatis.generator.plugins;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.PluginAdapter;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.config.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerializablePlugin
/*     */   extends PluginAdapter
/*     */ {
/*     */   private FullyQualifiedJavaType serializable;
/*     */   private FullyQualifiedJavaType gwtSerializable;
/*     */   private boolean addGWTInterface;
/*     */   private boolean suppressJavaInterface;
/*     */   
/*     */   public SerializablePlugin()
/*     */   {
/*  50 */     this.serializable = new FullyQualifiedJavaType("java.io.Serializable");
/*  51 */     this.gwtSerializable = new FullyQualifiedJavaType("com.google.gwt.user.client.rpc.IsSerializable");
/*     */   }
/*     */   
/*     */   public boolean validate(List<String> warnings)
/*     */   {
/*  56 */     return true;
/*     */   }
/*     */   
/*     */   public void setProperties(Properties properties)
/*     */   {
/*  61 */     super.setProperties(properties);
/*  62 */     this.addGWTInterface = Boolean.valueOf(properties.getProperty("addGWTInterface")).booleanValue();
/*  63 */     this.suppressJavaInterface = Boolean.valueOf(properties.getProperty("suppressJavaInterface")).booleanValue();
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean modelBaseRecordClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/*  69 */     makeSerializable(topLevelClass, introspectedTable);
/*  70 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean modelPrimaryKeyClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/*  76 */     makeSerializable(topLevelClass, introspectedTable);
/*  77 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean modelRecordWithBLOBsClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/*  83 */     makeSerializable(topLevelClass, introspectedTable);
/*  84 */     return true;
/*     */   }
/*     */   
/*     */   protected void makeSerializable(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/*  89 */     if (this.addGWTInterface) {
/*  90 */       topLevelClass.addImportedType(this.gwtSerializable);
/*  91 */       topLevelClass.addSuperInterface(this.gwtSerializable);
/*     */     }
/*     */     
/*  94 */     if (!this.suppressJavaInterface) {
/*  95 */       topLevelClass.addImportedType(this.serializable);
/*  96 */       topLevelClass.addSuperInterface(this.serializable);
/*     */       
/*  98 */       Field field = new Field();
/*  99 */       field.setFinal(true);
/* 100 */       field.setInitializationString("1L");
/* 101 */       field.setName("serialVersionUID");
/* 102 */       field.setStatic(true);
/* 103 */       field.setType(new FullyQualifiedJavaType("long"));
/* 104 */       field.setVisibility(JavaVisibility.PRIVATE);
/* 105 */       this.context.getCommentGenerator().addFieldComment(field, introspectedTable);
/*     */       
/* 107 */       topLevelClass.addField(field);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\plugins\SerializablePlugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */