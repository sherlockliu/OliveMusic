/*    */ package org.mybatis.generator.plugins;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Properties;
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.PluginAdapter;
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.Document;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ import org.mybatis.generator.config.Context;
/*    */ import org.mybatis.generator.internal.util.StringUtility;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachePlugin
/*    */   extends PluginAdapter
/*    */ {
/*    */   public static enum CacheProperty
/*    */   {
/* 34 */     EVICTION("cache_eviction", "eviction"), 
/* 35 */     FLUSH_INTERVAL("cache_flushInterval", "flushInterval"), 
/* 36 */     READ_ONLY("cache_readOnly", "readOnly"), 
/* 37 */     SIZE("cache_size", "size"), 
/* 38 */     TYPE("cache_type", "type");
/*    */     
/*    */     private String propertyName;
/*    */     private String attributeName;
/*    */     
/*    */     private CacheProperty(String propertyName, String attributeName) {
/* 44 */       this.propertyName = propertyName;
/* 45 */       this.attributeName = attributeName;
/*    */     }
/*    */     
/*    */     public String getPropertyName() {
/* 49 */       return this.propertyName;
/*    */     }
/*    */     
/*    */     public String getAttributeName() {
/* 53 */       return this.attributeName;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean validate(List<String> warnings)
/*    */   {
/* 62 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean sqlMapDocumentGenerated(Document document, IntrospectedTable introspectedTable)
/*    */   {
/* 68 */     XmlElement element = new XmlElement("cache");
/* 69 */     this.context.getCommentGenerator().addComment(element);
/*    */     CacheProperty[] arrayOfCacheProperty;
/* 71 */     int j = (arrayOfCacheProperty = CacheProperty.values()).length; for (int i = 0; i < j; i++) { CacheProperty cacheProperty = arrayOfCacheProperty[i];
/* 72 */       addAttributeIfExists(element, introspectedTable, cacheProperty);
/*    */     }
/*    */     
/* 75 */     document.getRootElement().addElement(element);
/*    */     
/* 77 */     return true;
/*    */   }
/*    */   
/*    */   private void addAttributeIfExists(XmlElement element, IntrospectedTable introspectedTable, CacheProperty cacheProperty)
/*    */   {
/* 82 */     String property = introspectedTable.getTableConfigurationProperty(cacheProperty.getPropertyName());
/* 83 */     if (property == null) {
/* 84 */       property = this.properties.getProperty(cacheProperty.getPropertyName());
/*    */     }
/*    */     
/* 87 */     if (StringUtility.stringHasValue(property)) {
/* 88 */       element.addAttribute(new Attribute(cacheProperty.getAttributeName(), property));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\plugins\CachePlugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */