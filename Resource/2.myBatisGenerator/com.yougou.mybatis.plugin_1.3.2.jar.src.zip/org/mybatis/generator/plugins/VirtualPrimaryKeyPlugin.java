/*    */ package org.mybatis.generator.plugins;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.StringTokenizer;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.PluginAdapter;
/*    */ import org.mybatis.generator.config.TableConfiguration;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VirtualPrimaryKeyPlugin
/*    */   extends PluginAdapter
/*    */ {
/*    */   public boolean validate(List<String> warnings)
/*    */   {
/* 41 */     return true;
/*    */   }
/*    */   
/*    */   public void initialized(IntrospectedTable introspectedTable)
/*    */   {
/* 46 */     String virtualKey = introspectedTable.getTableConfiguration()
/* 47 */       .getProperty("virtualKeyColumns");
/*    */     
/* 49 */     if (virtualKey != null) {
/* 50 */       StringTokenizer st = new StringTokenizer(virtualKey, ", ", false);
/* 51 */       while (st.hasMoreTokens()) {
/* 52 */         String column = st.nextToken();
/* 53 */         introspectedTable.addPrimaryKeyColumn(column);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\plugins\VirtualPrimaryKeyPlugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */