/*    */ package org.mybatis.generator.plugins;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.PluginAdapter;
/*    */ import org.mybatis.generator.api.dom.java.Field;
/*    */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*    */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*    */ import org.mybatis.generator.api.dom.java.Method;
/*    */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*    */ import org.mybatis.generator.config.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ToStringPlugin
/*    */   extends PluginAdapter
/*    */ {
/*    */   public boolean validate(List<String> warnings)
/*    */   {
/* 30 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean modelBaseRecordClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*    */   {
/* 36 */     generateToString(introspectedTable, topLevelClass);
/* 37 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean modelRecordWithBLOBsClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*    */   {
/* 43 */     generateToString(introspectedTable, topLevelClass);
/* 44 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean modelPrimaryKeyClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*    */   {
/* 50 */     generateToString(introspectedTable, topLevelClass);
/* 51 */     return true;
/*    */   }
/*    */   
/*    */   private void generateToString(IntrospectedTable introspectedTable, TopLevelClass topLevelClass)
/*    */   {
/* 56 */     Method method = new Method();
/* 57 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 58 */     method.setReturnType(FullyQualifiedJavaType.getStringInstance());
/* 59 */     method.setName("toString");
/* 60 */     if (introspectedTable.isJava5Targeted()) {
/* 61 */       method.addAnnotation("@Override");
/*    */     }
/*    */     
/* 64 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 65 */       introspectedTable);
/*    */     
/* 67 */     method.addBodyLine("StringBuilder sb = new StringBuilder();");
/* 68 */     method.addBodyLine("sb.append(getClass().getSimpleName());");
/* 69 */     method.addBodyLine("sb.append(\" [\");");
/* 70 */     method.addBodyLine("sb.append(\"Hash = \").append(hashCode());");
/* 71 */     StringBuilder sb = new StringBuilder();
/* 72 */     for (Field field : topLevelClass.getFields()) {
/* 73 */       String property = field.getName();
/* 74 */       sb.setLength(0);
/* 75 */       sb.append("sb.append(\"").append(", ").append(property)
/* 76 */         .append("=\")").append(".append(").append(property)
/* 77 */         .append(");");
/* 78 */       method.addBodyLine(sb.toString());
/*    */     }
/*    */     
/* 81 */     method.addBodyLine("sb.append(\"]\");");
/* 82 */     method.addBodyLine("return sb.toString();");
/*    */     
/* 84 */     topLevelClass.addMethod(method);
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\plugins\ToStringPlugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */