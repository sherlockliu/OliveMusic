package org.mybatis.generator.api;

import java.io.File;
import org.mybatis.generator.exception.ShellException;

public abstract interface ShellCallback
{
  public abstract File getDirectory(String paramString1, String paramString2)
    throws ShellException;
  
  public abstract String mergeJavaFile(String paramString1, String paramString2, String[] paramArrayOfString, String paramString3)
    throws ShellException;
  
  public abstract void refreshProject(String paramString);
  
  public abstract boolean isMergeSupported();
  
  public abstract boolean isOverwriteEnabled();
}


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\ShellCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */