/*     */ package org.mybatis.generator.api;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.api.dom.xml.Document;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.config.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PluginAdapter
/*     */   implements Plugin
/*     */ {
/*     */   protected Context context;
/*     */   protected Properties properties;
/*     */   
/*     */   public PluginAdapter()
/*     */   {
/*  45 */     this.properties = new Properties();
/*     */   }
/*     */   
/*     */   public Context getContext() {
/*  49 */     return this.context;
/*     */   }
/*     */   
/*     */   public void setContext(Context context) {
/*  53 */     this.context = context;
/*     */   }
/*     */   
/*     */   public Properties getProperties() {
/*  57 */     return this.properties;
/*     */   }
/*     */   
/*     */   public void setProperties(Properties properties) {
/*  61 */     this.properties.putAll(properties);
/*     */   }
/*     */   
/*     */   public List<GeneratedJavaFile> contextGenerateAdditionalJavaFiles() {
/*  65 */     return null;
/*     */   }
/*     */   
/*     */   public List<GeneratedJavaFile> contextGenerateAdditionalJavaFiles(IntrospectedTable introspectedTable)
/*     */   {
/*  70 */     return null;
/*     */   }
/*     */   
/*     */   public List<GeneratedXmlFile> contextGenerateAdditionalXmlFiles() {
/*  74 */     return null;
/*     */   }
/*     */   
/*     */   public List<GeneratedXmlFile> contextGenerateAdditionalXmlFiles(IntrospectedTable introspectedTable)
/*     */   {
/*  79 */     return null;
/*     */   }
/*     */   
/*     */   public boolean clientCountByExampleMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/*  84 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientCountByExampleMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/*  89 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientDeleteByExampleMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/*  94 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientDeleteByExampleMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/*  99 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientDeleteByPrimaryKeyMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 104 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientDeleteByPrimaryKeyMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 109 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientInsertMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 114 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientInsertMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 119 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean clientGenerated(Interface interfaze, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 125 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientSelectByExampleWithBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 130 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean clientSelectCountMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 145 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean clientSelectByExampleWithBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 151 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientSelectByExampleWithoutBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 156 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientSelectByExampleWithoutBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 161 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientSelectByPrimaryKeyMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 166 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientSelectByPrimaryKeyMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 171 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientUpdateByExampleSelectiveMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 176 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientUpdateByExampleSelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 181 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientUpdateByExampleWithBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 186 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientUpdateByExampleWithBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 191 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientUpdateByExampleWithoutBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 196 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientUpdateByExampleWithoutBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 201 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientUpdateByPrimaryKeySelectiveMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 206 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientUpdateByPrimaryKeySelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 211 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientUpdateByPrimaryKeyWithBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 216 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientUpdateByPrimaryKeyWithBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 221 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean clientUpdateByPrimaryKeyWithoutBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 227 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean clientUpdateByPrimaryKeyWithoutBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 233 */     return true;
/*     */   }
/*     */   
/*     */   public boolean modelBaseRecordClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 238 */     return true;
/*     */   }
/*     */   
/*     */   public boolean modelExampleClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 243 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean modelFieldGenerated(Field field, TopLevelClass topLevelClass, IntrospectedColumn introspectedColumn, IntrospectedTable introspectedTable, Plugin.ModelClassType modelClassType)
/*     */   {
/* 250 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean modelGetterMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedColumn introspectedColumn, IntrospectedTable introspectedTable, Plugin.ModelClassType modelClassType)
/*     */   {
/* 257 */     return true;
/*     */   }
/*     */   
/*     */   public boolean modelPrimaryKeyClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 262 */     return true;
/*     */   }
/*     */   
/*     */   public boolean modelRecordWithBLOBsClassGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 267 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean modelSetterMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedColumn introspectedColumn, IntrospectedTable introspectedTable, Plugin.ModelClassType modelClassType)
/*     */   {
/* 274 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapResultMapWithoutBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 279 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapCountByExampleElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 284 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapDeleteByExampleElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 289 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapDeleteByPrimaryKeyElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 294 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapDocumentGenerated(Document document, IntrospectedTable introspectedTable)
/*     */   {
/* 299 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapExampleWhereClauseElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 304 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapGenerated(GeneratedXmlFile sqlMap, IntrospectedTable introspectedTable)
/*     */   {
/* 309 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapInsertElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 314 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapResultMapWithBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 319 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapSelectByExampleWithoutBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 324 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapSelectByExampleWithBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 329 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapSelectByPrimaryKeyElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 334 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapUpdateByExampleSelectiveElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 339 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapUpdateByExampleWithBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 344 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapUpdateByExampleWithoutBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 349 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapUpdateByPrimaryKeySelectiveElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 354 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapUpdateByPrimaryKeyWithBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 359 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapUpdateByPrimaryKeyWithoutBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 364 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapInsertSelectiveElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 369 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientInsertSelectiveMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 374 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientInsertSelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 379 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public void initialized(IntrospectedTable introspectedTable) {}
/*     */   
/*     */   public boolean sqlMapBaseColumnListElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 387 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapBlobColumnListElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 392 */     return true;
/*     */   }
/*     */   
/*     */   public boolean providerGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 397 */     return true;
/*     */   }
/*     */   
/*     */   public boolean providerApplyWhereMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 402 */     return true;
/*     */   }
/*     */   
/*     */   public boolean providerCountByExampleMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 407 */     return true;
/*     */   }
/*     */   
/*     */   public boolean providerDeleteByExampleMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 412 */     return true;
/*     */   }
/*     */   
/*     */   public boolean providerInsertSelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 417 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean providerSelectByExampleWithBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 423 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean providerSelectByExampleWithoutBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 429 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean providerUpdateByExampleSelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 435 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean providerUpdateByExampleWithBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 441 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean providerUpdateByExampleWithoutBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 447 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean providerUpdateByPrimaryKeySelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 453 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientSelectAllMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*     */   {
/* 458 */     return true;
/*     */   }
/*     */   
/*     */   public boolean clientSelectAllMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*     */   {
/* 463 */     return true;
/*     */   }
/*     */   
/*     */   public boolean sqlMapSelectAllElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*     */   {
/* 468 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\PluginAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */