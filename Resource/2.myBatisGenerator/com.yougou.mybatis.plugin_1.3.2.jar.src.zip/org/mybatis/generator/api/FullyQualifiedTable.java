/*     */ package org.mybatis.generator.api;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map.Entry;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.YouGouTableSettingConfiguration;
/*     */ import org.mybatis.generator.internal.util.EqualsUtil;
/*     */ import org.mybatis.generator.internal.util.HashCodeUtil;
/*     */ import org.mybatis.generator.internal.util.JavaBeansUtil;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FullyQualifiedTable
/*     */ {
/*     */   private String introspectedCatalog;
/*     */   private String introspectedSchema;
/*     */   private String introspectedTableName;
/*     */   private String runtimeCatalog;
/*     */   private String runtimeSchema;
/*     */   private String runtimeTableName;
/*     */   private String domainObjectName;
/*     */   private String domainObjectSubPackage;
/*     */   private String alias;
/*     */   private boolean ignoreQualifiersAtRuntime;
/*     */   private String beginningDelimiter;
/*     */   private String endingDelimiter;
/*     */   private boolean disableMapperGeneratorSchema;
/*     */   private HashMap<String, String> replaceTablePrefixMap;
/*     */   
/*     */   public FullyQualifiedTable(String introspectedCatalog, String introspectedSchema, String introspectedTableName, String domainObjectName, String alias, boolean ignoreQualifiersAtRuntime, String runtimeCatalog, String runtimeSchema, String runtimeTableName, boolean delimitIdentifiers, Context context)
/*     */   {
/* 134 */     this.introspectedCatalog = introspectedCatalog;
/* 135 */     this.introspectedSchema = introspectedSchema;
/* 136 */     this.introspectedTableName = introspectedTableName;
/* 137 */     this.domainObjectName = domainObjectName;
/* 138 */     this.ignoreQualifiersAtRuntime = ignoreQualifiersAtRuntime;
/* 139 */     this.runtimeCatalog = runtimeCatalog;
/* 140 */     this.runtimeSchema = runtimeSchema;
/* 141 */     this.runtimeTableName = runtimeTableName;
/*     */     
/* 143 */     if (StringUtility.stringHasValue(domainObjectName)) {
/* 144 */       int index = domainObjectName.lastIndexOf('.');
/* 145 */       if (index == -1) {
/* 146 */         this.domainObjectName = domainObjectName;
/*     */       } else {
/* 148 */         this.domainObjectName = domainObjectName.substring(index + 1);
/* 149 */         this.domainObjectSubPackage = domainObjectName.substring(0, index);
/*     */       }
/*     */     }
/*     */     
/* 153 */     if (alias == null) {
/* 154 */       this.alias = null;
/*     */     } else {
/* 156 */       this.alias = alias.trim();
/*     */     }
/*     */     
/* 159 */     this.beginningDelimiter = (delimitIdentifiers ? context
/* 160 */       .getBeginningDelimiter() : "");
/* 161 */     this.endingDelimiter = (delimitIdentifiers ? context.getEndingDelimiter() : 
/* 162 */       "");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */     YouGouTableSettingConfiguration tableSettingConf = context.getYouGouTableSettingConfiguration();
/* 170 */     this.disableMapperGeneratorSchema = tableSettingConf.isIgnoreGeneratorSchema();
/* 171 */     this.replaceTablePrefixMap = tableSettingConf.getReplaceTablePrefixMap();
/*     */   }
/*     */   
/*     */   public String getIntrospectedCatalog() {
/* 175 */     return this.introspectedCatalog;
/*     */   }
/*     */   
/*     */   public String getIntrospectedSchema() {
/* 179 */     return this.introspectedSchema;
/*     */   }
/*     */   
/*     */   public String getIntrospectedTableName() {
/* 183 */     return this.introspectedTableName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFullyQualifiedTableNameAtRuntime()
/*     */   {
/* 190 */     StringBuilder localCatalog = new StringBuilder();
/* 191 */     if (!this.ignoreQualifiersAtRuntime) {
/* 192 */       if (StringUtility.stringHasValue(this.runtimeCatalog)) {
/* 193 */         localCatalog.append(this.runtimeCatalog);
/* 194 */       } else if (StringUtility.stringHasValue(this.introspectedCatalog)) {
/* 195 */         localCatalog.append(this.introspectedCatalog);
/*     */       }
/*     */     }
/* 198 */     if (localCatalog.length() > 0) {
/* 199 */       addDelimiters(localCatalog);
/*     */     }
/*     */     
/* 202 */     StringBuilder localSchema = new StringBuilder();
/* 203 */     if (!this.ignoreQualifiersAtRuntime) {
/* 204 */       if (StringUtility.stringHasValue(this.runtimeSchema)) {
/* 205 */         localSchema.append(this.runtimeSchema);
/* 206 */       } else if (StringUtility.stringHasValue(this.introspectedSchema)) {
/* 207 */         localSchema.append(this.introspectedSchema);
/*     */       }
/*     */     }
/* 210 */     if (localSchema.length() > 0) {
/* 211 */       addDelimiters(localSchema);
/*     */     }
/*     */     
/* 214 */     StringBuilder localTableName = new StringBuilder();
/* 215 */     if (StringUtility.stringHasValue(this.runtimeTableName)) {
/* 216 */       localTableName.append(this.runtimeTableName);
/*     */     } else {
/* 218 */       localTableName.append(this.introspectedTableName);
/*     */     }
/* 220 */     addDelimiters(localTableName);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */     if (this.disableMapperGeneratorSchema) {
/* 228 */       return localTableName.toString();
/*     */     }
/* 230 */     return StringUtility.composeFullyQualifiedTableName(localCatalog
/* 231 */       .toString(), localSchema.toString(), localTableName.toString(), 
/* 232 */       '.');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getYouGouFullyQualifiedTableNameAtRuntime()
/*     */   {
/* 240 */     StringBuilder localCatalog = new StringBuilder();
/* 241 */     if (!this.ignoreQualifiersAtRuntime) {
/* 242 */       if (StringUtility.stringHasValue(this.runtimeCatalog)) {
/* 243 */         localCatalog.append(this.runtimeCatalog);
/* 244 */       } else if (StringUtility.stringHasValue(this.introspectedCatalog)) {
/* 245 */         localCatalog.append(this.introspectedCatalog);
/*     */       }
/*     */     }
/* 248 */     if (localCatalog.length() > 0) {
/* 249 */       addDelimiters(localCatalog);
/*     */     }
/*     */     
/* 252 */     StringBuilder localSchema = new StringBuilder();
/* 253 */     if (!this.ignoreQualifiersAtRuntime) {
/* 254 */       if (StringUtility.stringHasValue(this.runtimeSchema)) {
/* 255 */         localSchema.append(this.runtimeSchema);
/* 256 */       } else if (StringUtility.stringHasValue(this.introspectedSchema)) {
/* 257 */         localSchema.append(this.introspectedSchema);
/*     */       }
/*     */     }
/* 260 */     if (localSchema.length() > 0) {
/* 261 */       addDelimiters(localSchema);
/*     */     }
/*     */     
/* 264 */     StringBuilder localTableName = new StringBuilder();
/* 265 */     localTableName.append(this.introspectedTableName);
/* 266 */     addDelimiters(localTableName);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 273 */     if (this.disableMapperGeneratorSchema) {
/* 274 */       return localTableName.toString();
/*     */     }
/* 276 */     return StringUtility.composeFullyQualifiedTableName(localCatalog
/* 277 */       .toString(), localSchema.toString(), localTableName.toString(), 
/* 278 */       '.');
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getAliasedFullyQualifiedTableNameAtRuntime()
/*     */   {
/* 286 */     String name = getYouGouFullyQualifiedTableNameAtRuntime();
/* 287 */     StringBuilder sb1 = new StringBuilder();
/* 288 */     sb1.append(name);
/* 289 */     if (StringUtility.stringHasValue(this.alias)) {
/* 290 */       sb1.append(' ');
/* 291 */       sb1.append(this.alias);
/*     */     }
/*     */     
/* 294 */     return sb1.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getIbatis2SqlMapNamespace()
/*     */   {
/* 304 */     String localCatalog = StringUtility.stringHasValue(this.runtimeCatalog) ? this.runtimeCatalog : 
/* 305 */       this.introspectedCatalog;
/* 306 */     String localSchema = StringUtility.stringHasValue(this.runtimeSchema) ? this.runtimeSchema : 
/* 307 */       this.introspectedSchema;
/* 308 */     String localTable = StringUtility.stringHasValue(this.runtimeTableName) ? this.runtimeTableName : 
/* 309 */       this.introspectedTableName;
/*     */     
/* 311 */     return StringUtility.composeFullyQualifiedTableName(
/* 312 */       this.ignoreQualifiersAtRuntime ? null : localCatalog, 
/* 313 */       this.ignoreQualifiersAtRuntime ? null : localSchema, 
/* 314 */       localTable, '_');
/*     */   }
/*     */   
/*     */   public String getDomainObjectName() {
/* 318 */     if (StringUtility.stringHasValue(this.domainObjectName))
/* 319 */       return this.domainObjectName;
/* 320 */     if (StringUtility.stringHasValue(this.runtimeTableName)) {
/* 321 */       return JavaBeansUtil.getCamelCaseString(this.runtimeTableName, true);
/*     */     }
/* 323 */     return JavaBeansUtil.getCamelCaseString(this.introspectedTableName, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTableName4Controller()
/*     */   {
/* 334 */     String temp = this.introspectedTableName.toLowerCase();
/* 335 */     for (Map.Entry<String, String> te : this.replaceTablePrefixMap.entrySet()) {
/* 336 */       if (temp.indexOf(((String)te.getKey()).toLowerCase()) != -1) {
/* 337 */         temp = temp.replaceAll(((String)te.getKey()).toLowerCase(), ((String)te.getValue()).toLowerCase());
/* 338 */         break;
/*     */       }
/*     */     }
/* 341 */     return temp;
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 346 */     if (this == obj) {
/* 347 */       return true;
/*     */     }
/*     */     
/* 350 */     if (!(obj instanceof FullyQualifiedTable)) {
/* 351 */       return false;
/*     */     }
/*     */     
/* 354 */     FullyQualifiedTable other = (FullyQualifiedTable)obj;
/*     */     
/* 356 */     if (EqualsUtil.areEqual(this.introspectedTableName, 
/* 357 */       other.introspectedTableName)) {
/* 358 */       if (EqualsUtil.areEqual(this.introspectedCatalog, 
/* 359 */         other.introspectedCatalog)) {
/* 360 */         if (EqualsUtil.areEqual(this.introspectedSchema, 
/* 361 */           other.introspectedSchema)) {
/* 360 */           return true;
/*     */         }
/*     */       }
/*     */     }
/* 356 */     return 
/*     */     
/*     */ 
/*     */ 
/* 360 */       false;
/*     */   }
/*     */   
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 366 */     int result = 23;
/* 367 */     result = HashCodeUtil.hash(result, this.introspectedTableName);
/* 368 */     result = HashCodeUtil.hash(result, this.introspectedCatalog);
/* 369 */     result = HashCodeUtil.hash(result, this.introspectedSchema);
/*     */     
/* 371 */     return result;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 376 */     return StringUtility.composeFullyQualifiedTableName(
/* 377 */       this.introspectedCatalog, this.introspectedSchema, this.introspectedTableName, 
/* 378 */       '.');
/*     */   }
/*     */   
/*     */   public String getAlias() {
/* 382 */     return this.alias;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSubPackage(boolean isSubPackagesEnabled)
/*     */   {
/* 392 */     StringBuilder sb = new StringBuilder();
/* 393 */     if ((!this.ignoreQualifiersAtRuntime) && (isSubPackagesEnabled)) {
/* 394 */       if (StringUtility.stringHasValue(this.runtimeCatalog)) {
/* 395 */         sb.append('.');
/* 396 */         sb.append(this.runtimeCatalog.toLowerCase());
/* 397 */       } else if (StringUtility.stringHasValue(this.introspectedCatalog)) {
/* 398 */         sb.append('.');
/* 399 */         sb.append(this.introspectedCatalog.toLowerCase());
/*     */       }
/*     */       
/* 402 */       if (StringUtility.stringHasValue(this.runtimeSchema)) {
/* 403 */         sb.append('.');
/* 404 */         sb.append(this.runtimeSchema.toLowerCase());
/* 405 */       } else if (StringUtility.stringHasValue(this.introspectedSchema)) {
/* 406 */         sb.append('.');
/* 407 */         sb.append(this.introspectedSchema.toLowerCase());
/*     */       }
/*     */     }
/*     */     
/* 411 */     if (StringUtility.stringHasValue(this.domainObjectSubPackage)) {
/* 412 */       sb.append('.');
/* 413 */       sb.append(this.domainObjectSubPackage);
/*     */     }
/*     */     
/*     */ 
/* 417 */     return sb.toString();
/*     */   }
/*     */   
/*     */   private void addDelimiters(StringBuilder sb) {
/* 421 */     if (StringUtility.stringHasValue(this.beginningDelimiter)) {
/* 422 */       sb.insert(0, this.beginningDelimiter);
/*     */     }
/*     */     
/* 425 */     if (StringUtility.stringHasValue(this.endingDelimiter)) {
/* 426 */       sb.append(this.endingDelimiter);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\FullyQualifiedTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */