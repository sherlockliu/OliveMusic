/*      */ package org.mybatis.generator.api;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import org.mybatis.generator.config.Context;
/*      */ import org.mybatis.generator.config.GeneratedKey;
/*      */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.JavaModelGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.ModelType;
/*      */ import org.mybatis.generator.config.PropertyHolder;
/*      */ import org.mybatis.generator.config.SqlMapGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.TableConfiguration;
/*      */ import org.mybatis.generator.config.YouGouControllerGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.YouGouManagerGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.YouGouServiceGeneratorConfiguration;
/*      */ import org.mybatis.generator.internal.rules.ConditionalModelRules;
/*      */ import org.mybatis.generator.internal.rules.FlatModelRules;
/*      */ import org.mybatis.generator.internal.rules.HierarchicalModelRules;
/*      */ import org.mybatis.generator.internal.rules.Rules;
/*      */ import org.mybatis.generator.internal.util.StringUtility;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class IntrospectedTable
/*      */ {
/*      */   protected TableConfiguration tableConfiguration;
/*      */   protected FullyQualifiedTable fullyQualifiedTable;
/*      */   protected Context context;
/*      */   protected Rules rules;
/*      */   protected List<IntrospectedColumn> primaryKeyColumns;
/*      */   protected List<IntrospectedColumn> baseColumns;
/*      */   protected List<IntrospectedColumn> blobColumns;
/*      */   protected TargetRuntime targetRuntime;
/*      */   protected Map<String, Object> attributes;
/*      */   protected Map<InternalAttribute, String> internalAttributes;
/*      */   
/*      */   public static enum TargetRuntime
/*      */   {
/*   56 */     IBATIS2,  MYBATIS3;
/*      */   }
/*      */   
/*      */   protected static enum InternalAttribute {
/*   60 */     ATTR_DAO_IMPLEMENTATION_TYPE, 
/*   61 */     ATTR_DAO_INTERFACE_TYPE, 
/*   62 */     ATTR_PRIMARY_KEY_TYPE, 
/*   63 */     ATTR_BASE_RECORD_TYPE, 
/*   64 */     ATTR_RECORD_WITH_BLOBS_TYPE, 
/*   65 */     ATTR_EXAMPLE_TYPE, 
/*   66 */     ATTR_IBATIS2_SQL_MAP_PACKAGE, 
/*   67 */     ATTR_IBATIS2_SQL_MAP_FILE_NAME, 
/*   68 */     ATTR_IBATIS2_SQL_MAP_NAMESPACE, 
/*   69 */     ATTR_MYBATIS3_XML_MAPPER_PACKAGE, 
/*   70 */     ATTR_MYBATIS3_XML_MAPPER_FILE_NAME, 
/*   71 */     ATTR_MYBATIS3_JAVA_MAPPER_TYPE, 
/*      */     
/*   73 */     ATTR_MYBATIS3_JAVA_SERVICE_TYPE, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   79 */     ATTR_MYBATIS3_JAVA_SERVICEIMPL_TYPE, 
/*   80 */     ATTR_MYBATIS3_JAVA_MANAGER_TYPE, 
/*   81 */     ATTR_MYBATIS3_JAVA_MANAGERIMPL_TYPE, 
/*   82 */     ATTR_MYBATIS3_JAVA_CONTROLLER_TYPE, 
/*   83 */     ATTR_MYBATIS3_JAVA_CONTROLLER_INSTANCE_NAME, 
/*      */     
/*      */ 
/*   86 */     ATTR_MYBATIS3_FALLBACK_SQL_MAP_NAMESPACE, 
/*   87 */     ATTR_FULLY_QUALIFIED_TABLE_NAME_AT_RUNTIME, 
/*   88 */     ATTR_ALIASED_FULLY_QUALIFIED_TABLE_NAME_AT_RUNTIME, 
/*   89 */     ATTR_COUNT_BY_EXAMPLE_STATEMENT_ID, 
/*   90 */     ATTR_DELETE_BY_EXAMPLE_STATEMENT_ID, 
/*   91 */     ATTR_DELETE_BY_PRIMARY_KEY_STATEMENT_ID, 
/*   92 */     ATTR_INSERT_STATEMENT_ID, 
/*   93 */     ATTR_INSERT_SELECTIVE_STATEMENT_ID, 
/*   94 */     ATTR_SELECT_ALL_STATEMENT_ID, 
/*   95 */     ATTR_SELECT_BY_EXAMPLE_STATEMENT_ID, 
/*   96 */     ATTR_SELECT_BY_EXAMPLE_WITH_BLOBS_STATEMENT_ID, 
/*   97 */     ATTR_SELECT_BY_PRIMARY_KEY_STATEMENT_ID, 
/*   98 */     ATTR_SELECT_COUNT, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  105 */     ATTR_SELECT_BY_PAGE, 
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  112 */     ATTR_UPDATE_BY_EXAMPLE_STATEMENT_ID, 
/*  113 */     ATTR_UPDATE_BY_EXAMPLE_SELECTIVE_STATEMENT_ID, 
/*  114 */     ATTR_UPDATE_BY_EXAMPLE_WITH_BLOBS_STATEMENT_ID, 
/*  115 */     ATTR_UPDATE_BY_PRIMARY_KEY_STATEMENT_ID, 
/*  116 */     ATTR_UPDATE_BY_PRIMARY_KEY_SELECTIVE_STATEMENT_ID, 
/*  117 */     ATTR_UPDATE_BY_PRIMARY_KEY_WITH_BLOBS_STATEMENT_ID, 
/*  118 */     ATTR_BASE_RESULT_MAP_ID, 
/*  119 */     ATTR_RESULT_MAP_WITH_BLOBS_ID, 
/*  120 */     ATTR_EXAMPLE_WHERE_CLAUSE_ID, 
/*  121 */     ATTR_BASE_COLUMN_LIST_ID, 
/*  122 */     ATTR_BLOB_COLUMN_LIST_ID, 
/*  123 */     ATTR_MYBATIS3_UPDATE_BY_EXAMPLE_WHERE_CLAUSE_ID, 
/*  124 */     ATTR_MYBATIS3_SQL_PROVIDER_TYPE;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IntrospectedTable(TargetRuntime targetRuntime)
/*      */   {
/*  150 */     this.targetRuntime = targetRuntime;
/*  151 */     this.primaryKeyColumns = new ArrayList();
/*  152 */     this.baseColumns = new ArrayList();
/*  153 */     this.blobColumns = new ArrayList();
/*  154 */     this.attributes = new HashMap();
/*  155 */     this.internalAttributes = new HashMap();
/*      */   }
/*      */   
/*      */   public FullyQualifiedTable getFullyQualifiedTable() {
/*  159 */     return this.fullyQualifiedTable;
/*      */   }
/*      */   
/*      */   public String getSelectByExampleQueryId() {
/*  163 */     return this.tableConfiguration.getSelectByExampleQueryId();
/*      */   }
/*      */   
/*      */   public String getSelectByPrimaryKeyQueryId() {
/*  167 */     return this.tableConfiguration.getSelectByPrimaryKeyQueryId();
/*      */   }
/*      */   
/*      */   public GeneratedKey getGeneratedKey() {
/*  171 */     return this.tableConfiguration.getGeneratedKey();
/*      */   }
/*      */   
/*      */   public IntrospectedColumn getColumn(String columnName) {
/*  175 */     if (columnName == null) {
/*  176 */       return null;
/*      */     }
/*      */     
/*  179 */     for (IntrospectedColumn introspectedColumn : this.primaryKeyColumns) {
/*  180 */       if (introspectedColumn.isColumnNameDelimited()) {
/*  181 */         if (introspectedColumn.getActualColumnName().equals(
/*  182 */           columnName)) {
/*  183 */           return introspectedColumn;
/*      */         }
/*      */         
/*      */       }
/*  187 */       else if (introspectedColumn.getActualColumnName().equalsIgnoreCase(columnName)) {
/*  188 */         return introspectedColumn;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  194 */     for (IntrospectedColumn introspectedColumn : this.baseColumns) {
/*  195 */       if (introspectedColumn.isColumnNameDelimited()) {
/*  196 */         if (introspectedColumn.getActualColumnName().equals(
/*  197 */           columnName)) {
/*  198 */           return introspectedColumn;
/*      */         }
/*      */         
/*      */       }
/*  202 */       else if (introspectedColumn.getActualColumnName().equalsIgnoreCase(columnName)) {
/*  203 */         return introspectedColumn;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  209 */     for (IntrospectedColumn introspectedColumn : this.blobColumns) {
/*  210 */       if (introspectedColumn.isColumnNameDelimited()) {
/*  211 */         if (introspectedColumn.getActualColumnName().equals(
/*  212 */           columnName)) {
/*  213 */           return introspectedColumn;
/*      */         }
/*      */         
/*      */       }
/*  217 */       else if (introspectedColumn.getActualColumnName().equalsIgnoreCase(columnName)) {
/*  218 */         return introspectedColumn;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  223 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasJDBCDateColumns()
/*      */   {
/*  234 */     boolean rc = false;
/*      */     
/*  236 */     for (IntrospectedColumn introspectedColumn : this.primaryKeyColumns) {
/*  237 */       if (introspectedColumn.isJDBCDateColumn()) {
/*  238 */         rc = true;
/*  239 */         break;
/*      */       }
/*      */     }
/*      */     
/*  243 */     if (!rc) {
/*  244 */       for (IntrospectedColumn introspectedColumn : this.baseColumns) {
/*  245 */         if (introspectedColumn.isJDBCDateColumn()) {
/*  246 */           rc = true;
/*  247 */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  252 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean hasJDBCTimeColumns()
/*      */   {
/*  262 */     boolean rc = false;
/*      */     
/*  264 */     for (IntrospectedColumn introspectedColumn : this.primaryKeyColumns) {
/*  265 */       if (introspectedColumn.isJDBCTimeColumn()) {
/*  266 */         rc = true;
/*  267 */         break;
/*      */       }
/*      */     }
/*      */     
/*  271 */     if (!rc) {
/*  272 */       for (IntrospectedColumn introspectedColumn : this.baseColumns) {
/*  273 */         if (introspectedColumn.isJDBCTimeColumn()) {
/*  274 */           rc = true;
/*  275 */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  280 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<IntrospectedColumn> getPrimaryKeyColumns()
/*      */   {
/*  291 */     return this.primaryKeyColumns;
/*      */   }
/*      */   
/*      */   public boolean hasPrimaryKeyColumns() {
/*  295 */     return this.primaryKeyColumns.size() > 0;
/*      */   }
/*      */   
/*      */   public List<IntrospectedColumn> getBaseColumns() {
/*  299 */     return this.baseColumns;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<IntrospectedColumn> getAllColumns()
/*      */   {
/*  309 */     List<IntrospectedColumn> answer = new ArrayList();
/*  310 */     answer.addAll(this.primaryKeyColumns);
/*  311 */     answer.addAll(this.baseColumns);
/*  312 */     answer.addAll(this.blobColumns);
/*      */     
/*  314 */     return answer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<IntrospectedColumn> getNonBLOBColumns()
/*      */   {
/*  325 */     List<IntrospectedColumn> answer = new ArrayList();
/*  326 */     answer.addAll(this.primaryKeyColumns);
/*  327 */     answer.addAll(this.baseColumns);
/*      */     
/*  329 */     return answer;
/*      */   }
/*      */   
/*      */   public int getNonBLOBColumnCount() {
/*  333 */     return this.primaryKeyColumns.size() + this.baseColumns.size();
/*      */   }
/*      */   
/*      */   public List<IntrospectedColumn> getNonPrimaryKeyColumns() {
/*  337 */     List<IntrospectedColumn> answer = new ArrayList();
/*  338 */     answer.addAll(this.baseColumns);
/*  339 */     answer.addAll(this.blobColumns);
/*      */     
/*  341 */     return answer;
/*      */   }
/*      */   
/*      */   public List<IntrospectedColumn> getBLOBColumns() {
/*  345 */     return this.blobColumns;
/*      */   }
/*      */   
/*      */   public boolean hasBLOBColumns() {
/*  349 */     return this.blobColumns.size() > 0;
/*      */   }
/*      */   
/*      */   public boolean hasBaseColumns() {
/*  353 */     return this.baseColumns.size() > 0;
/*      */   }
/*      */   
/*      */   public Rules getRules() {
/*  357 */     return this.rules;
/*      */   }
/*      */   
/*      */   public String getTableConfigurationProperty(String property) {
/*  361 */     return this.tableConfiguration.getProperty(property);
/*      */   }
/*      */   
/*      */   public String getPrimaryKeyType() {
/*  365 */     return (String)this.internalAttributes.get(InternalAttribute.ATTR_PRIMARY_KEY_TYPE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getBaseRecordType()
/*      */   {
/*  375 */     return (String)this.internalAttributes.get(InternalAttribute.ATTR_BASE_RECORD_TYPE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getExampleType()
/*      */   {
/*  383 */     return (String)this.internalAttributes.get(InternalAttribute.ATTR_EXAMPLE_TYPE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRecordWithBLOBsType()
/*      */   {
/*  393 */     return 
/*  394 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_RECORD_WITH_BLOBS_TYPE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getIbatis2SqlMapFileName()
/*      */   {
/*  405 */     return 
/*  406 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_IBATIS2_SQL_MAP_FILE_NAME);
/*      */   }
/*      */   
/*      */   public String getIbatis2SqlMapNamespace() {
/*  410 */     return 
/*  411 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_IBATIS2_SQL_MAP_NAMESPACE);
/*      */   }
/*      */   
/*      */   public String getMyBatis3SqlMapNamespace() {
/*  415 */     String namespace = getMyBatis3JavaMapperType();
/*  416 */     if (namespace == null) {
/*  417 */       namespace = getMyBatis3FallbackSqlMapNamespace();
/*      */     }
/*      */     
/*  420 */     return namespace;
/*      */   }
/*      */   
/*      */   public String getMyBatis3FallbackSqlMapNamespace() {
/*  424 */     return 
/*  425 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_FALLBACK_SQL_MAP_NAMESPACE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getIbatis2SqlMapPackage()
/*      */   {
/*  434 */     return 
/*  435 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_IBATIS2_SQL_MAP_PACKAGE);
/*      */   }
/*      */   
/*      */   public String getDAOImplementationType() {
/*  439 */     return 
/*  440 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_DAO_IMPLEMENTATION_TYPE);
/*      */   }
/*      */   
/*      */   public String getDAOInterfaceType() {
/*  444 */     return 
/*  445 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_DAO_INTERFACE_TYPE);
/*      */   }
/*      */   
/*      */   public boolean hasAnyColumns()
/*      */   {
/*  450 */     return (this.primaryKeyColumns.size() > 0) || (this.baseColumns.size() > 0) || (this.blobColumns.size() > 0);
/*      */   }
/*      */   
/*      */   public void setTableConfiguration(TableConfiguration tableConfiguration) {
/*  454 */     this.tableConfiguration = tableConfiguration;
/*      */   }
/*      */   
/*      */   public void setFullyQualifiedTable(FullyQualifiedTable fullyQualifiedTable) {
/*  458 */     this.fullyQualifiedTable = fullyQualifiedTable;
/*      */   }
/*      */   
/*      */   public void setContext(Context context) {
/*  462 */     this.context = context;
/*      */   }
/*      */   
/*      */   public void addColumn(IntrospectedColumn introspectedColumn) {
/*  466 */     if (introspectedColumn.isBLOBColumn()) {
/*  467 */       this.blobColumns.add(introspectedColumn);
/*      */     } else {
/*  469 */       this.baseColumns.add(introspectedColumn);
/*      */     }
/*      */     
/*  472 */     introspectedColumn.setIntrospectedTable(this);
/*      */   }
/*      */   
/*      */   public void addPrimaryKeyColumn(String columnName) {
/*  476 */     boolean found = false;
/*      */     
/*  478 */     Iterator<IntrospectedColumn> iter = this.baseColumns.iterator();
/*  479 */     while (iter.hasNext()) {
/*  480 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)iter.next();
/*  481 */       if (introspectedColumn.getActualColumnName().equals(columnName)) {
/*  482 */         this.primaryKeyColumns.add(introspectedColumn);
/*  483 */         iter.remove();
/*  484 */         found = true;
/*  485 */         break;
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  490 */     if (!found) {
/*  491 */       iter = this.blobColumns.iterator();
/*  492 */       while (iter.hasNext()) {
/*  493 */         IntrospectedColumn introspectedColumn = (IntrospectedColumn)iter.next();
/*  494 */         if (introspectedColumn.getActualColumnName().equals(columnName)) {
/*  495 */           this.primaryKeyColumns.add(introspectedColumn);
/*  496 */           iter.remove();
/*  497 */           found = true;
/*  498 */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public Object getAttribute(String name) {
/*  505 */     return this.attributes.get(name);
/*      */   }
/*      */   
/*      */   public void removeAttribute(String name) {
/*  509 */     this.attributes.remove(name);
/*      */   }
/*      */   
/*      */   public void setAttribute(String name, Object value) {
/*  513 */     this.attributes.put(name, value);
/*      */   }
/*      */   
/*      */   public void initialize() {
/*  517 */     calculateJavaClientAttributes();
/*  518 */     calculateModelAttributes();
/*  519 */     calculateXmlAttributes();
/*      */     
/*  521 */     if (this.tableConfiguration.getModelType() == ModelType.HIERARCHICAL) {
/*  522 */       this.rules = new HierarchicalModelRules(this);
/*  523 */     } else if (this.tableConfiguration.getModelType() == ModelType.FLAT) {
/*  524 */       this.rules = new FlatModelRules(this);
/*      */     } else {
/*  526 */       this.rules = new ConditionalModelRules(this);
/*      */     }
/*      */     
/*  529 */     this.context.getPlugins().initialized(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected void calculateXmlAttributes()
/*      */   {
/*  536 */     setIbatis2SqlMapPackage(calculateSqlMapPackage());
/*  537 */     setIbatis2SqlMapFileName(calculateIbatis2SqlMapFileName());
/*  538 */     setMyBatis3XmlMapperFileName(calculateMyBatis3XmlMapperFileName());
/*  539 */     setMyBatis3XmlMapperPackage(calculateSqlMapPackage());
/*      */     
/*  541 */     setIbatis2SqlMapNamespace(calculateIbatis2SqlMapNamespace());
/*  542 */     setMyBatis3FallbackSqlMapNamespace(calculateMyBatis3FallbackSqlMapNamespace());
/*      */     
/*      */ 
/*  545 */     setSqlMapFullyQualifiedRuntimeTableName(calculateSqlMapFullyQualifiedRuntimeTableName());
/*  546 */     setSqlMapAliasedFullyQualifiedRuntimeTableName(calculateSqlMapAliasedFullyQualifiedRuntimeTableName());
/*      */     
/*  548 */     setCountByExampleStatementId("countByExample");
/*  549 */     setDeleteByExampleStatementId("deleteByExample");
/*  550 */     setDeleteByPrimaryKeyStatementId("deleteByPrimaryKey");
/*  551 */     setInsertStatementId("insert");
/*  552 */     setInsertSelectiveStatementId("insertSelective");
/*  553 */     setSelectAllStatementId("selectAll");
/*  554 */     setSelectByExampleStatementId("selectByExample");
/*  555 */     setSelectByExampleWithBLOBsStatementId("selectByExampleWithBLOBs");
/*  556 */     setSelectByPrimaryKeyStatementId("selectByPrimaryKey");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  562 */     setSelectCount("selectCount");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  568 */     setSelectByPage("selectByPage");
/*  569 */     setUpdateByExampleStatementId("updateByExample");
/*  570 */     setUpdateByExampleSelectiveStatementId("updateByExampleSelective");
/*  571 */     setUpdateByExampleWithBLOBsStatementId("updateByExampleWithBLOBs");
/*  572 */     setUpdateByPrimaryKeyStatementId("updateByPrimaryKey");
/*  573 */     setUpdateByPrimaryKeySelectiveStatementId("updateByPrimaryKeySelective");
/*  574 */     setUpdateByPrimaryKeyWithBLOBsStatementId("updateByPrimaryKeyWithBLOBs");
/*  575 */     setBaseResultMapId("BaseResultMap");
/*  576 */     setResultMapWithBLOBsId("ResultMapWithBLOBs");
/*  577 */     setExampleWhereClauseId("Example_Where_Clause");
/*  578 */     setBaseColumnListId("Base_Column_List");
/*  579 */     setBlobColumnListId("Blob_Column_List");
/*  580 */     setMyBatis3UpdateByExampleWhereClauseId("Update_By_Example_Where_Clause");
/*      */   }
/*      */   
/*      */   public void setBlobColumnListId(String s) {
/*  584 */     this.internalAttributes.put(InternalAttribute.ATTR_BLOB_COLUMN_LIST_ID, s);
/*      */   }
/*      */   
/*      */   public void setBaseColumnListId(String s) {
/*  588 */     this.internalAttributes.put(InternalAttribute.ATTR_BASE_COLUMN_LIST_ID, s);
/*      */   }
/*      */   
/*      */   public void setExampleWhereClauseId(String s) {
/*  592 */     this.internalAttributes.put(InternalAttribute.ATTR_EXAMPLE_WHERE_CLAUSE_ID, 
/*  593 */       s);
/*      */   }
/*      */   
/*      */   public void setMyBatis3UpdateByExampleWhereClauseId(String s)
/*      */   {
/*  598 */     this.internalAttributes.put(
/*  599 */       InternalAttribute.ATTR_MYBATIS3_UPDATE_BY_EXAMPLE_WHERE_CLAUSE_ID, 
/*  600 */       s);
/*      */   }
/*      */   
/*      */   public void setResultMapWithBLOBsId(String s) {
/*  604 */     this.internalAttributes.put(InternalAttribute.ATTR_RESULT_MAP_WITH_BLOBS_ID, 
/*  605 */       s);
/*      */   }
/*      */   
/*      */   public void setBaseResultMapId(String s) {
/*  609 */     this.internalAttributes.put(InternalAttribute.ATTR_BASE_RESULT_MAP_ID, s);
/*      */   }
/*      */   
/*      */   public void setUpdateByPrimaryKeyWithBLOBsStatementId(String s)
/*      */   {
/*  614 */     this.internalAttributes.put(
/*  615 */       InternalAttribute.ATTR_UPDATE_BY_PRIMARY_KEY_WITH_BLOBS_STATEMENT_ID, 
/*  616 */       s);
/*      */   }
/*      */   
/*      */   public void setUpdateByPrimaryKeySelectiveStatementId(String s)
/*      */   {
/*  621 */     this.internalAttributes.put(
/*  622 */       InternalAttribute.ATTR_UPDATE_BY_PRIMARY_KEY_SELECTIVE_STATEMENT_ID, 
/*  623 */       s);
/*      */   }
/*      */   
/*      */   public void setUpdateByPrimaryKeyStatementId(String s) {
/*  627 */     this.internalAttributes.put(
/*  628 */       InternalAttribute.ATTR_UPDATE_BY_PRIMARY_KEY_STATEMENT_ID, s);
/*      */   }
/*      */   
/*      */   public void setUpdateByExampleWithBLOBsStatementId(String s)
/*      */   {
/*  633 */     this.internalAttributes.put(
/*  634 */       InternalAttribute.ATTR_UPDATE_BY_EXAMPLE_WITH_BLOBS_STATEMENT_ID, 
/*  635 */       s);
/*      */   }
/*      */   
/*      */   public void setUpdateByExampleSelectiveStatementId(String s)
/*      */   {
/*  640 */     this.internalAttributes.put(
/*  641 */       InternalAttribute.ATTR_UPDATE_BY_EXAMPLE_SELECTIVE_STATEMENT_ID, 
/*  642 */       s);
/*      */   }
/*      */   
/*      */   public void setUpdateByExampleStatementId(String s) {
/*  646 */     this.internalAttributes.put(
/*  647 */       InternalAttribute.ATTR_UPDATE_BY_EXAMPLE_STATEMENT_ID, s);
/*      */   }
/*      */   
/*      */   public void setSelectByPrimaryKeyStatementId(String s) {
/*  651 */     this.internalAttributes.put(
/*  652 */       InternalAttribute.ATTR_SELECT_BY_PRIMARY_KEY_STATEMENT_ID, s);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelectCount(String s)
/*      */   {
/*  662 */     this.internalAttributes.put(
/*  663 */       InternalAttribute.ATTR_SELECT_COUNT, s);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setSelectByPage(String s)
/*      */   {
/*  674 */     this.internalAttributes.put(
/*  675 */       InternalAttribute.ATTR_SELECT_BY_PAGE, s);
/*      */   }
/*      */   
/*      */   public void setSelectByExampleWithBLOBsStatementId(String s)
/*      */   {
/*  680 */     this.internalAttributes.put(
/*  681 */       InternalAttribute.ATTR_SELECT_BY_EXAMPLE_WITH_BLOBS_STATEMENT_ID, 
/*  682 */       s);
/*      */   }
/*      */   
/*      */   public void setSelectAllStatementId(String s) {
/*  686 */     this.internalAttributes.put(
/*  687 */       InternalAttribute.ATTR_SELECT_ALL_STATEMENT_ID, s);
/*      */   }
/*      */   
/*      */   public void setSelectByExampleStatementId(String s) {
/*  691 */     this.internalAttributes.put(
/*  692 */       InternalAttribute.ATTR_SELECT_BY_EXAMPLE_STATEMENT_ID, s);
/*      */   }
/*      */   
/*      */   public void setInsertSelectiveStatementId(String s) {
/*  696 */     this.internalAttributes.put(
/*  697 */       InternalAttribute.ATTR_INSERT_SELECTIVE_STATEMENT_ID, s);
/*      */   }
/*      */   
/*      */   public void setInsertStatementId(String s) {
/*  701 */     this.internalAttributes.put(InternalAttribute.ATTR_INSERT_STATEMENT_ID, s);
/*      */   }
/*      */   
/*      */   public void setDeleteByPrimaryKeyStatementId(String s) {
/*  705 */     this.internalAttributes.put(
/*  706 */       InternalAttribute.ATTR_DELETE_BY_PRIMARY_KEY_STATEMENT_ID, s);
/*      */   }
/*      */   
/*      */   public void setDeleteByExampleStatementId(String s) {
/*  710 */     this.internalAttributes.put(
/*  711 */       InternalAttribute.ATTR_DELETE_BY_EXAMPLE_STATEMENT_ID, s);
/*      */   }
/*      */   
/*      */   public void setCountByExampleStatementId(String s) {
/*  715 */     this.internalAttributes.put(
/*  716 */       InternalAttribute.ATTR_COUNT_BY_EXAMPLE_STATEMENT_ID, s);
/*      */   }
/*      */   
/*      */   public String getBlobColumnListId() {
/*  720 */     return 
/*  721 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_BLOB_COLUMN_LIST_ID);
/*      */   }
/*      */   
/*      */   public String getBaseColumnListId() {
/*  725 */     return 
/*  726 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_BASE_COLUMN_LIST_ID);
/*      */   }
/*      */   
/*      */   public String getExampleWhereClauseId() {
/*  730 */     return 
/*  731 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_EXAMPLE_WHERE_CLAUSE_ID);
/*      */   }
/*      */   
/*      */   public String getMyBatis3UpdateByExampleWhereClauseId() {
/*  735 */     return 
/*  736 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_UPDATE_BY_EXAMPLE_WHERE_CLAUSE_ID);
/*      */   }
/*      */   
/*      */   public String getResultMapWithBLOBsId() {
/*  740 */     return 
/*  741 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_RESULT_MAP_WITH_BLOBS_ID);
/*      */   }
/*      */   
/*      */   public String getBaseResultMapId() {
/*  745 */     return 
/*  746 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_BASE_RESULT_MAP_ID);
/*      */   }
/*      */   
/*      */   public String getUpdateByPrimaryKeyWithBLOBsStatementId() {
/*  750 */     return 
/*  751 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_UPDATE_BY_PRIMARY_KEY_WITH_BLOBS_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getUpdateByPrimaryKeySelectiveStatementId() {
/*  755 */     return 
/*  756 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_UPDATE_BY_PRIMARY_KEY_SELECTIVE_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getUpdateByPrimaryKeyStatementId() {
/*  760 */     return 
/*  761 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_UPDATE_BY_PRIMARY_KEY_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getUpdateByExampleWithBLOBsStatementId() {
/*  765 */     return 
/*  766 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_UPDATE_BY_EXAMPLE_WITH_BLOBS_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getUpdateByExampleSelectiveStatementId() {
/*  770 */     return 
/*  771 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_UPDATE_BY_EXAMPLE_SELECTIVE_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getUpdateByExampleStatementId() {
/*  775 */     return 
/*  776 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_UPDATE_BY_EXAMPLE_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getSelectByPrimaryKeyStatementId() {
/*  780 */     return 
/*  781 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_SELECT_BY_PRIMARY_KEY_STATEMENT_ID);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSelectCount()
/*      */   {
/*  789 */     return 
/*  790 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_SELECT_COUNT);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getSelectByPage()
/*      */   {
/*  798 */     return 
/*  799 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_SELECT_BY_PAGE);
/*      */   }
/*      */   
/*      */   public String getSelectByExampleWithBLOBsStatementId() {
/*  803 */     return 
/*  804 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_SELECT_BY_EXAMPLE_WITH_BLOBS_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getSelectAllStatementId() {
/*  808 */     return 
/*  809 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_SELECT_ALL_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getSelectByExampleStatementId() {
/*  813 */     return 
/*  814 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_SELECT_BY_EXAMPLE_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getInsertSelectiveStatementId() {
/*  818 */     return 
/*  819 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_INSERT_SELECTIVE_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getInsertStatementId() {
/*  823 */     return 
/*  824 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_INSERT_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getDeleteByPrimaryKeyStatementId() {
/*  828 */     return 
/*  829 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_DELETE_BY_PRIMARY_KEY_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getDeleteByExampleStatementId() {
/*  833 */     return 
/*  834 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_DELETE_BY_EXAMPLE_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   public String getCountByExampleStatementId() {
/*  838 */     return 
/*  839 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_COUNT_BY_EXAMPLE_STATEMENT_ID);
/*      */   }
/*      */   
/*      */   protected String calculateJavaClientImplementationPackage() {
/*  843 */     JavaClientGeneratorConfiguration config = this.context
/*  844 */       .getJavaClientGeneratorConfiguration();
/*  845 */     if (config == null) {
/*  846 */       return null;
/*      */     }
/*      */     
/*  849 */     StringBuilder sb = new StringBuilder();
/*  850 */     if (StringUtility.stringHasValue(config.getImplementationPackage())) {
/*  851 */       sb.append(config.getImplementationPackage());
/*      */     } else {
/*  853 */       sb.append(config.getTargetPackage());
/*      */     }
/*      */     
/*  856 */     sb.append(this.fullyQualifiedTable.getSubPackage(isSubPackagesEnabled(config)));
/*      */     
/*  858 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String calculateJavaServiceInterfacePackage()
/*      */   {
/*  867 */     YouGouServiceGeneratorConfiguration config = this.context
/*  868 */       .getYouGouServiceGeneratorConfiguration();
/*  869 */     if (config == null) {
/*  870 */       return null;
/*      */     }
/*      */     
/*  873 */     StringBuilder sb = new StringBuilder();
/*  874 */     sb.append(config.getTargetPackage());
/*  875 */     if (StringUtility.isTrue(config
/*  876 */       .getProperty("enableSubPackages"))) {
/*  877 */       sb.append(this.fullyQualifiedTable.getSubPackage(isSubPackagesEnabled(config)));
/*      */     }
/*      */     
/*  880 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String calculateJavaManagerInterfacePackage()
/*      */   {
/*  889 */     YouGouManagerGeneratorConfiguration config = this.context
/*  890 */       .getYouGouManagerGeneratorConfiguration();
/*  891 */     if (config == null) {
/*  892 */       return null;
/*      */     }
/*      */     
/*  895 */     StringBuilder sb = new StringBuilder();
/*  896 */     sb.append(config.getTargetPackage());
/*  897 */     if (StringUtility.isTrue(config
/*  898 */       .getProperty("enableSubPackages"))) {
/*  899 */       sb.append(this.fullyQualifiedTable.getSubPackage(isSubPackagesEnabled(config)));
/*      */     }
/*      */     
/*  902 */     return sb.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected String calculateJavaControllerInterfacePackage()
/*      */   {
/*  911 */     YouGouControllerGeneratorConfiguration config = this.context
/*  912 */       .getYouGouControllerGeneratorConfiguration();
/*  913 */     if (config == null) {
/*  914 */       return null;
/*      */     }
/*      */     
/*  917 */     StringBuilder sb = new StringBuilder();
/*  918 */     sb.append(config.getTargetPackage());
/*  919 */     if (StringUtility.isTrue(config
/*  920 */       .getProperty("enableSubPackages"))) {
/*  921 */       sb.append(this.fullyQualifiedTable.getSubPackage(isSubPackagesEnabled(config)));
/*      */     }
/*  923 */     return sb.toString();
/*      */   }
/*      */   
/*      */   private boolean isSubPackagesEnabled(PropertyHolder propertyHolder) {
/*  927 */     return StringUtility.isTrue(propertyHolder.getProperty("enableSubPackages"));
/*      */   }
/*      */   
/*      */   protected String calculateJavaClientInterfacePackage() {
/*  931 */     JavaClientGeneratorConfiguration config = this.context
/*  932 */       .getJavaClientGeneratorConfiguration();
/*  933 */     if (config == null) {
/*  934 */       return null;
/*      */     }
/*      */     
/*  937 */     StringBuilder sb = new StringBuilder();
/*  938 */     sb.append(config.getTargetPackage());
/*      */     
/*  940 */     sb.append(this.fullyQualifiedTable.getSubPackage(isSubPackagesEnabled(config)));
/*      */     
/*  942 */     return sb.toString();
/*      */   }
/*      */   
/*      */   protected void calculateJavaClientAttributes() {
/*  946 */     if (this.context.getJavaClientGeneratorConfiguration() == null) {
/*  947 */       return;
/*      */     }
/*      */     
/*  950 */     StringBuilder sb = new StringBuilder();
/*  951 */     sb.append(calculateJavaClientImplementationPackage());
/*  952 */     sb.append('.');
/*  953 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/*  954 */     sb.append("DAOImpl");
/*  955 */     setDAOImplementationType(sb.toString());
/*      */     
/*  957 */     sb.setLength(0);
/*  958 */     sb.append(calculateJavaClientInterfacePackage());
/*  959 */     sb.append('.');
/*  960 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/*  961 */     sb.append("DAO");
/*  962 */     setDAOInterfaceType(sb.toString());
/*      */     
/*  964 */     sb.setLength(0);
/*  965 */     sb.append(calculateJavaClientInterfacePackage());
/*  966 */     sb.append('.');
/*  967 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/*  968 */     sb.append("Mapper");
/*  969 */     setMyBatis3JavaMapperType(sb.toString());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  975 */     sb.setLength(0);
/*  976 */     sb.append(calculateJavaServiceInterfacePackage());
/*  977 */     sb.append('.');
/*  978 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/*  979 */     sb.append("Service");
/*      */     
/*      */ 
/*      */ 
/*  983 */     setMyBatis3JavaServiceType(sb.toString());
/*  984 */     sb.setLength(0);
/*  985 */     sb.append(calculateJavaServiceInterfacePackage());
/*  986 */     sb.append(".");
/*      */     
/*  988 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/*  989 */     sb.append("ServiceImpl");
/*      */     
/*      */ 
/*      */ 
/*  993 */     setMyBatis3JavaServiceImplType(sb.toString());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1000 */     sb.setLength(0);
/* 1001 */     sb.append(calculateJavaManagerInterfacePackage());
/* 1002 */     sb.append('.');
/* 1003 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/* 1004 */     sb.append("Manager");
/*      */     
/*      */ 
/*      */ 
/* 1008 */     setMyBatis3JavaManagerType(sb.toString());
/* 1009 */     sb.setLength(0);
/* 1010 */     sb.append(calculateJavaManagerInterfacePackage());
/* 1011 */     sb.append(".");
/*      */     
/* 1013 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/* 1014 */     sb.append("ManagerImpl");
/*      */     
/*      */ 
/*      */ 
/* 1018 */     setMyBatis3JavaManagerImplType(sb.toString());
/* 1019 */     sb.setLength(0);
/* 1020 */     sb.append(calculateJavaControllerInterfacePackage());
/* 1021 */     sb.append(".");
/* 1022 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/* 1023 */     sb.append("Controller");
/* 1024 */     setMyBatis3JavaControllerType(sb.toString());
/*      */     
/* 1026 */     sb.setLength(0);
/* 1027 */     sb.append(this.fullyQualifiedTable.getTableName4Controller());
/* 1028 */     setMyBatis3JavaControllerInstanceName(sb.toString());
/*      */     
/* 1030 */     sb.setLength(0);
/* 1031 */     sb.append(calculateJavaClientInterfacePackage());
/* 1032 */     sb.append('.');
/* 1033 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/* 1034 */     sb.append("SqlProvider");
/* 1035 */     setMyBatis3SqlProviderType(sb.toString());
/*      */   }
/*      */   
/*      */   protected String calculateJavaModelPackage() {
/* 1039 */     JavaModelGeneratorConfiguration config = this.context
/* 1040 */       .getJavaModelGeneratorConfiguration();
/*      */     
/* 1042 */     StringBuilder sb = new StringBuilder();
/* 1043 */     sb.append(config.getTargetPackage());
/* 1044 */     sb.append(this.fullyQualifiedTable.getSubPackage(isSubPackagesEnabled(config)));
/*      */     
/* 1046 */     return sb.toString();
/*      */   }
/*      */   
/*      */   protected void calculateModelAttributes() {
/* 1050 */     String pakkage = calculateJavaModelPackage();
/*      */     
/* 1052 */     StringBuilder sb = new StringBuilder();
/* 1053 */     sb.append(pakkage);
/* 1054 */     sb.append('.');
/* 1055 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/* 1056 */     sb.append("Key");
/* 1057 */     setPrimaryKeyType(sb.toString());
/*      */     
/* 1059 */     sb.setLength(0);
/* 1060 */     sb.append(pakkage);
/* 1061 */     sb.append('.');
/* 1062 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/* 1063 */     setBaseRecordType(sb.toString());
/*      */     
/* 1065 */     sb.setLength(0);
/* 1066 */     sb.append(pakkage);
/* 1067 */     sb.append('.');
/* 1068 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/* 1069 */     sb.append("WithBLOBs");
/* 1070 */     setRecordWithBLOBsType(sb.toString());
/*      */     
/* 1072 */     sb.setLength(0);
/* 1073 */     sb.append(pakkage);
/* 1074 */     sb.append('.');
/* 1075 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/* 1076 */     sb.append("Example");
/* 1077 */     setExampleType(sb.toString());
/*      */   }
/*      */   
/*      */   protected String calculateSqlMapPackage() {
/* 1081 */     StringBuilder sb = new StringBuilder();
/* 1082 */     SqlMapGeneratorConfiguration config = this.context
/* 1083 */       .getSqlMapGeneratorConfiguration();
/*      */     
/*      */ 
/* 1086 */     if (config != null) {
/* 1087 */       sb.append(config.getTargetPackage());
/* 1088 */       sb.append(this.fullyQualifiedTable.getSubPackage(isSubPackagesEnabled(config)));
/*      */     }
/*      */     
/* 1091 */     return sb.toString();
/*      */   }
/*      */   
/*      */   protected String calculateIbatis2SqlMapFileName() {
/* 1095 */     StringBuilder sb = new StringBuilder();
/* 1096 */     sb.append(this.fullyQualifiedTable.getIbatis2SqlMapNamespace());
/* 1097 */     sb.append("_SqlMap.xml");
/* 1098 */     return sb.toString();
/*      */   }
/*      */   
/*      */   protected String calculateMyBatis3XmlMapperFileName() {
/* 1102 */     StringBuilder sb = new StringBuilder();
/* 1103 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/* 1104 */     sb.append("Mapper.xml");
/* 1105 */     return sb.toString();
/*      */   }
/*      */   
/*      */   protected String calculateIbatis2SqlMapNamespace() {
/* 1109 */     return this.fullyQualifiedTable.getIbatis2SqlMapNamespace();
/*      */   }
/*      */   
/*      */   protected String calculateMyBatis3FallbackSqlMapNamespace() {
/* 1113 */     StringBuilder sb = new StringBuilder();
/* 1114 */     sb.append(calculateSqlMapPackage());
/* 1115 */     sb.append('.');
/* 1116 */     sb.append(this.fullyQualifiedTable.getDomainObjectName());
/* 1117 */     sb.append("Mapper");
/* 1118 */     return sb.toString();
/*      */   }
/*      */   
/*      */   protected String calculateSqlMapFullyQualifiedRuntimeTableName() {
/* 1122 */     return this.fullyQualifiedTable.getYouGouFullyQualifiedTableNameAtRuntime();
/*      */   }
/*      */   
/*      */   protected String calculateSqlMapAliasedFullyQualifiedRuntimeTableName() {
/* 1126 */     return this.fullyQualifiedTable.getAliasedFullyQualifiedTableNameAtRuntime();
/*      */   }
/*      */   
/*      */   public String getFullyQualifiedTableNameAtRuntime() {
/* 1130 */     return 
/* 1131 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_FULLY_QUALIFIED_TABLE_NAME_AT_RUNTIME);
/*      */   }
/*      */   
/*      */   public String getAliasedFullyQualifiedTableNameAtRuntime() {
/* 1135 */     return 
/* 1136 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_ALIASED_FULLY_QUALIFIED_TABLE_NAME_AT_RUNTIME);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void calculateGenerators(List<String> paramList, ProgressCallback paramProgressCallback);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract List<GeneratedJavaFile> getGeneratedJavaFiles();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract List<GeneratedXmlFile> getGeneratedXmlFiles();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract boolean isJava5Targeted();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract int getGenerationSteps();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setRules(Rules rules)
/*      */   {
/* 1193 */     this.rules = rules;
/*      */   }
/*      */   
/*      */   public TableConfiguration getTableConfiguration() {
/* 1197 */     return this.tableConfiguration;
/*      */   }
/*      */   
/*      */   public void setDAOImplementationType(String DAOImplementationType) {
/* 1201 */     this.internalAttributes.put(InternalAttribute.ATTR_DAO_IMPLEMENTATION_TYPE, 
/* 1202 */       DAOImplementationType);
/*      */   }
/*      */   
/*      */   public void setDAOInterfaceType(String DAOInterfaceType) {
/* 1206 */     this.internalAttributes.put(InternalAttribute.ATTR_DAO_INTERFACE_TYPE, 
/* 1207 */       DAOInterfaceType);
/*      */   }
/*      */   
/*      */   public void setPrimaryKeyType(String primaryKeyType) {
/* 1211 */     this.internalAttributes.put(InternalAttribute.ATTR_PRIMARY_KEY_TYPE, 
/* 1212 */       primaryKeyType);
/*      */   }
/*      */   
/*      */   public void setBaseRecordType(String baseRecordType) {
/* 1216 */     this.internalAttributes.put(InternalAttribute.ATTR_BASE_RECORD_TYPE, 
/* 1217 */       baseRecordType);
/*      */   }
/*      */   
/*      */   public void setRecordWithBLOBsType(String recordWithBLOBsType) {
/* 1221 */     this.internalAttributes.put(InternalAttribute.ATTR_RECORD_WITH_BLOBS_TYPE, 
/* 1222 */       recordWithBLOBsType);
/*      */   }
/*      */   
/*      */   public void setExampleType(String exampleType)
/*      */   {
/* 1227 */     this.internalAttributes.put(InternalAttribute.ATTR_EXAMPLE_TYPE, exampleType);
/*      */   }
/*      */   
/*      */   public void setIbatis2SqlMapPackage(String sqlMapPackage) {
/* 1231 */     this.internalAttributes.put(InternalAttribute.ATTR_IBATIS2_SQL_MAP_PACKAGE, 
/* 1232 */       sqlMapPackage);
/*      */   }
/*      */   
/*      */   public void setIbatis2SqlMapFileName(String sqlMapFileName) {
/* 1236 */     this.internalAttributes.put(
/* 1237 */       InternalAttribute.ATTR_IBATIS2_SQL_MAP_FILE_NAME, 
/* 1238 */       sqlMapFileName);
/*      */   }
/*      */   
/*      */   public void setIbatis2SqlMapNamespace(String sqlMapNamespace) {
/* 1242 */     this.internalAttributes.put(
/* 1243 */       InternalAttribute.ATTR_IBATIS2_SQL_MAP_NAMESPACE, 
/* 1244 */       sqlMapNamespace);
/*      */   }
/*      */   
/*      */   public void setMyBatis3FallbackSqlMapNamespace(String sqlMapNamespace) {
/* 1248 */     this.internalAttributes.put(
/* 1249 */       InternalAttribute.ATTR_MYBATIS3_FALLBACK_SQL_MAP_NAMESPACE, 
/* 1250 */       sqlMapNamespace);
/*      */   }
/*      */   
/*      */   public void setSqlMapFullyQualifiedRuntimeTableName(String fullyQualifiedRuntimeTableName)
/*      */   {
/* 1255 */     this.internalAttributes.put(
/* 1256 */       InternalAttribute.ATTR_FULLY_QUALIFIED_TABLE_NAME_AT_RUNTIME, 
/* 1257 */       fullyQualifiedRuntimeTableName);
/*      */   }
/*      */   
/*      */ 
/*      */   public void setSqlMapAliasedFullyQualifiedRuntimeTableName(String aliasedFullyQualifiedRuntimeTableName)
/*      */   {
/* 1263 */     this.internalAttributes.put(
/* 1264 */       InternalAttribute.ATTR_ALIASED_FULLY_QUALIFIED_TABLE_NAME_AT_RUNTIME, 
/* 1265 */       aliasedFullyQualifiedRuntimeTableName);
/*      */   }
/*      */   
/*      */   public String getMyBatis3XmlMapperPackage() {
/* 1269 */     return 
/* 1270 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_XML_MAPPER_PACKAGE);
/*      */   }
/*      */   
/*      */   public void setMyBatis3XmlMapperPackage(String mybatis3XmlMapperPackage) {
/* 1274 */     this.internalAttributes.put(
/* 1275 */       InternalAttribute.ATTR_MYBATIS3_XML_MAPPER_PACKAGE, 
/* 1276 */       mybatis3XmlMapperPackage);
/*      */   }
/*      */   
/*      */   public String getMyBatis3XmlMapperFileName() {
/* 1280 */     return 
/* 1281 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_XML_MAPPER_FILE_NAME);
/*      */   }
/*      */   
/*      */   public void setMyBatis3XmlMapperFileName(String mybatis3XmlMapperFileName) {
/* 1285 */     this.internalAttributes.put(
/* 1286 */       InternalAttribute.ATTR_MYBATIS3_XML_MAPPER_FILE_NAME, 
/* 1287 */       mybatis3XmlMapperFileName);
/*      */   }
/*      */   
/*      */   public String getMyBatis3JavaMapperType() {
/* 1291 */     return 
/* 1292 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_JAVA_MAPPER_TYPE);
/*      */   }
/*      */   
/*      */   public void setMyBatis3JavaMapperType(String mybatis3JavaMapperType) {
/* 1296 */     this.internalAttributes.put(
/* 1297 */       InternalAttribute.ATTR_MYBATIS3_JAVA_MAPPER_TYPE, 
/* 1298 */       mybatis3JavaMapperType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMyBatis3JavaServiceType()
/*      */   {
/* 1307 */     return 
/* 1308 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_JAVA_SERVICE_TYPE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMyBatis3JavaServiceType(String mybatis3JavaMapperType)
/*      */   {
/* 1318 */     this.internalAttributes.put(
/* 1319 */       InternalAttribute.ATTR_MYBATIS3_JAVA_SERVICE_TYPE, 
/* 1320 */       mybatis3JavaMapperType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMyBatis3JavaServiceImplType()
/*      */   {
/* 1329 */     return 
/* 1330 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_JAVA_SERVICEIMPL_TYPE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMyBatis3JavaServiceImplType(String mybatis3JavaMapperType)
/*      */   {
/* 1340 */     this.internalAttributes.put(
/* 1341 */       InternalAttribute.ATTR_MYBATIS3_JAVA_SERVICEIMPL_TYPE, 
/* 1342 */       mybatis3JavaMapperType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMyBatis3JavaManagerType()
/*      */   {
/* 1351 */     return 
/* 1352 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_JAVA_MANAGER_TYPE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMyBatis3JavaManagerType(String mybatis3JavaMapperType)
/*      */   {
/* 1362 */     this.internalAttributes.put(
/* 1363 */       InternalAttribute.ATTR_MYBATIS3_JAVA_MANAGER_TYPE, 
/* 1364 */       mybatis3JavaMapperType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMyBatis3JavaManagerImplType()
/*      */   {
/* 1373 */     return 
/* 1374 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_JAVA_MANAGERIMPL_TYPE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMyBatis3JavaManagerImplType(String mybatis3JavaMapperType)
/*      */   {
/* 1384 */     this.internalAttributes.put(
/* 1385 */       InternalAttribute.ATTR_MYBATIS3_JAVA_MANAGERIMPL_TYPE, 
/* 1386 */       mybatis3JavaMapperType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMyBatis3JavaControllerType()
/*      */   {
/* 1395 */     return 
/* 1396 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_JAVA_CONTROLLER_TYPE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMyBatis3JavaControllerType(String mybatis3JavaControllerType)
/*      */   {
/* 1406 */     this.internalAttributes.put(
/* 1407 */       InternalAttribute.ATTR_MYBATIS3_JAVA_CONTROLLER_TYPE, 
/* 1408 */       mybatis3JavaControllerType);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMyBatis3JavaControllerInstanceName()
/*      */   {
/* 1417 */     return 
/* 1418 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_JAVA_CONTROLLER_INSTANCE_NAME);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setMyBatis3JavaControllerInstanceName(String mybatis3JavaControllerIntanceName)
/*      */   {
/* 1428 */     this.internalAttributes.put(
/* 1429 */       InternalAttribute.ATTR_MYBATIS3_JAVA_CONTROLLER_INSTANCE_NAME, 
/* 1430 */       mybatis3JavaControllerIntanceName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public String getMyBatis3SqlProviderType()
/*      */   {
/* 1437 */     return 
/* 1438 */       (String)this.internalAttributes.get(InternalAttribute.ATTR_MYBATIS3_SQL_PROVIDER_TYPE);
/*      */   }
/*      */   
/*      */   public void setMyBatis3SqlProviderType(String mybatis3SqlProviderType) {
/* 1442 */     this.internalAttributes.put(
/* 1443 */       InternalAttribute.ATTR_MYBATIS3_SQL_PROVIDER_TYPE, 
/* 1444 */       mybatis3SqlProviderType);
/*      */   }
/*      */   
/*      */   public TargetRuntime getTargetRuntime() {
/* 1448 */     return this.targetRuntime;
/*      */   }
/*      */   
/*      */   public boolean isImmutable() {
/*      */     Properties properties;
/*      */     Properties properties;
/* 1454 */     if (this.tableConfiguration.getProperties().containsKey("immutable")) {
/* 1455 */       properties = this.tableConfiguration.getProperties();
/*      */     } else {
/* 1457 */       properties = this.context.getJavaModelGeneratorConfiguration().getProperties();
/*      */     }
/*      */     
/* 1460 */     return StringUtility.isTrue(properties.getProperty("immutable"));
/*      */   }
/*      */   
/*      */   public boolean isConstructorBased() {
/* 1464 */     if (isImmutable()) {
/* 1465 */       return true;
/*      */     }
/*      */     
/*      */     Properties properties;
/*      */     Properties properties;
/* 1470 */     if (this.tableConfiguration.getProperties().containsKey("constructorBased")) {
/* 1471 */       properties = this.tableConfiguration.getProperties();
/*      */     } else {
/* 1473 */       properties = this.context.getJavaModelGeneratorConfiguration().getProperties();
/*      */     }
/*      */     
/* 1476 */     return StringUtility.isTrue(properties.getProperty("constructorBased"));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract boolean requiresXMLGenerator();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Context getContext()
/*      */   {
/* 1490 */     return this.context;
/*      */   }
/*      */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\IntrospectedTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */