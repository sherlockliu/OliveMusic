package org.mybatis.generator.api;

import java.util.List;
import java.util.Properties;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.config.Context;

public abstract interface JavaTypeResolver
{
  public abstract void addConfigurationProperties(Properties paramProperties);
  
  public abstract void setContext(Context paramContext);
  
  public abstract void setWarnings(List<String> paramList);
  
  public abstract FullyQualifiedJavaType calculateJavaType(IntrospectedColumn paramIntrospectedColumn);
  
  public abstract String calculateJdbcTypeName(IntrospectedColumn paramIntrospectedColumn);
}


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\JavaTypeResolver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */