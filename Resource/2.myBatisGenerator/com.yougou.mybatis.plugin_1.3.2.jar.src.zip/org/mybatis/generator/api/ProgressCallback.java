package org.mybatis.generator.api;

public abstract interface ProgressCallback
{
  public abstract void introspectionStarted(int paramInt);
  
  public abstract void generationStarted(int paramInt);
  
  public abstract void saveStarted(int paramInt);
  
  public abstract void startTask(String paramString);
  
  public abstract void done();
  
  public abstract void checkCancel()
    throws InterruptedException;
}


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\ProgressCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */