/*    */ package org.mybatis.generator.api;
/*    */ 
/*    */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*    */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GeneratedJavaFile
/*    */   extends GeneratedFile
/*    */ {
/*    */   private CompilationUnit compilationUnit;
/*    */   private String fileEncoding;
/*    */   private JavaFormatter javaFormatter;
/*    */   
/*    */   public GeneratedJavaFile(CompilationUnit compilationUnit, String targetProject, String fileEncoding, JavaFormatter javaFormatter)
/*    */   {
/* 35 */     super(targetProject);
/* 36 */     this.compilationUnit = compilationUnit;
/* 37 */     this.fileEncoding = fileEncoding;
/* 38 */     this.javaFormatter = javaFormatter;
/*    */   }
/*    */   
/*    */ 
/*    */   public GeneratedJavaFile(CompilationUnit compilationUnit, String targetProject, JavaFormatter javaFormatter)
/*    */   {
/* 44 */     this(compilationUnit, targetProject, null, javaFormatter);
/*    */   }
/*    */   
/*    */   public String getFormattedContent()
/*    */   {
/* 49 */     return this.javaFormatter.getFormattedContent(this.compilationUnit);
/*    */   }
/*    */   
/*    */   public String getFileName()
/*    */   {
/* 54 */     return this.compilationUnit.getType().getShortName() + ".java";
/*    */   }
/*    */   
/*    */   public String getTargetPackage() {
/* 58 */     return this.compilationUnit.getType().getPackageName();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CompilationUnit getCompilationUnit()
/*    */   {
/* 70 */     return this.compilationUnit;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isMergeable()
/*    */   {
/* 80 */     return true;
/*    */   }
/*    */   
/*    */   public String getFileEncoding() {
/* 84 */     return this.fileEncoding;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\GeneratedJavaFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */