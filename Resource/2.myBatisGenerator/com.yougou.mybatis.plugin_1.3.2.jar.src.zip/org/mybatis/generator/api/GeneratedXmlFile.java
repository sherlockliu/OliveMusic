/*    */ package org.mybatis.generator.api;
/*    */ 
/*    */ import org.mybatis.generator.api.dom.xml.Document;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GeneratedXmlFile
/*    */   extends GeneratedFile
/*    */ {
/*    */   private Document document;
/*    */   private String fileName;
/*    */   private String targetPackage;
/*    */   private boolean isMergeable;
/*    */   private XmlFormatter xmlFormatter;
/*    */   
/*    */   public GeneratedXmlFile(Document document, String fileName, String targetPackage, String targetProject, boolean isMergeable, XmlFormatter xmlFormatter)
/*    */   {
/* 47 */     super(targetProject);
/* 48 */     this.document = document;
/* 49 */     this.fileName = fileName;
/* 50 */     this.targetPackage = targetPackage;
/* 51 */     this.isMergeable = isMergeable;
/* 52 */     this.xmlFormatter = xmlFormatter;
/*    */   }
/*    */   
/*    */   public String getFormattedContent()
/*    */   {
/* 57 */     return this.xmlFormatter.getFormattedContent(this.document);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getFileName()
/*    */   {
/* 65 */     return this.fileName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getTargetPackage()
/*    */   {
/* 73 */     return this.targetPackage;
/*    */   }
/*    */   
/*    */   public boolean isMergeable()
/*    */   {
/* 78 */     return this.isMergeable;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\GeneratedXmlFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */