package org.mybatis.generator.api;

import org.mybatis.generator.api.dom.xml.Document;
import org.mybatis.generator.config.Context;

public abstract interface XmlFormatter
{
  public abstract void setContext(Context paramContext);
  
  public abstract String getFormattedContent(Document paramDocument);
}


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\XmlFormatter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */