/*     */ package org.mybatis.generator.api;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntrospectedColumn
/*     */ {
/*     */   protected String actualColumnName;
/*     */   protected int jdbcType;
/*     */   protected String jdbcTypeName;
/*     */   protected boolean nullable;
/*     */   protected int length;
/*     */   protected int scale;
/*     */   protected boolean identity;
/*     */   protected boolean isSequenceColumn;
/*     */   protected String javaProperty;
/*     */   protected FullyQualifiedJavaType fullyQualifiedJavaType;
/*     */   protected String tableAlias;
/*     */   protected String typeHandler;
/*     */   protected Context context;
/*     */   protected boolean isColumnNameDelimited;
/*     */   protected IntrospectedTable introspectedTable;
/*     */   protected Properties properties;
/*     */   protected String remarks;
/*     */   protected String defaultValue;
/*     */   
/*     */   public IntrospectedColumn()
/*     */   {
/*  76 */     this.properties = new Properties();
/*     */   }
/*     */   
/*     */   public int getJdbcType() {
/*  80 */     return this.jdbcType;
/*     */   }
/*     */   
/*     */   public void setJdbcType(int jdbcType) {
/*  84 */     this.jdbcType = jdbcType;
/*     */   }
/*     */   
/*     */   public int getLength() {
/*  88 */     return this.length;
/*     */   }
/*     */   
/*     */   public void setLength(int length) {
/*  92 */     this.length = length;
/*     */   }
/*     */   
/*     */   public boolean isNullable() {
/*  96 */     return this.nullable;
/*     */   }
/*     */   
/*     */   public void setNullable(boolean nullable) {
/* 100 */     this.nullable = nullable;
/*     */   }
/*     */   
/*     */   public int getScale() {
/* 104 */     return this.scale;
/*     */   }
/*     */   
/*     */   public void setScale(int scale) {
/* 108 */     this.scale = scale;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 117 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 119 */     sb.append("Actual Column Name: ");
/* 120 */     sb.append(this.actualColumnName);
/* 121 */     sb.append(", JDBC Type: ");
/* 122 */     sb.append(this.jdbcType);
/* 123 */     sb.append(", Nullable: ");
/* 124 */     sb.append(this.nullable);
/* 125 */     sb.append(", Length: ");
/* 126 */     sb.append(this.length);
/* 127 */     sb.append(", Scale: ");
/* 128 */     sb.append(this.scale);
/* 129 */     sb.append(", Identity: ");
/* 130 */     sb.append(this.identity);
/*     */     
/* 132 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void setActualColumnName(String actualColumnName) {
/* 136 */     this.actualColumnName = actualColumnName;
/* 137 */     this.isColumnNameDelimited = 
/* 138 */       StringUtility.stringContainsSpace(actualColumnName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isIdentity()
/*     */   {
/* 145 */     return this.identity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setIdentity(boolean identity)
/*     */   {
/* 153 */     this.identity = identity;
/*     */   }
/*     */   
/*     */   public boolean isBLOBColumn() {
/* 157 */     String typeName = getJdbcTypeName();
/*     */     
/*     */ 
/*     */ 
/* 161 */     return ("BINARY".equals(typeName)) || ("BLOB".equals(typeName)) || ("CLOB".equals(typeName)) || ("LONGVARBINARY".equals(typeName)) || ("LONGVARCHAR".equals(typeName)) || ("VARBINARY".equals(typeName));
/*     */   }
/*     */   
/*     */   public boolean isStringColumn() {
/* 165 */     return this.fullyQualifiedJavaType.equals(
/* 166 */       FullyQualifiedJavaType.getStringInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isJdbcCharacterColumn()
/*     */   {
/* 173 */     return (this.jdbcType == 1) || (this.jdbcType == 2005) || (this.jdbcType == -1) || (this.jdbcType == 12) || (this.jdbcType == -16) || (this.jdbcType == -15) || (this.jdbcType == 2011) || (this.jdbcType == -9);
/*     */   }
/*     */   
/*     */   public String getJavaProperty() {
/* 177 */     return getJavaProperty(null);
/*     */   }
/*     */   
/*     */   public String getJavaProperty(String prefix) {
/* 181 */     if (prefix == null) {
/* 182 */       return this.javaProperty;
/*     */     }
/*     */     
/* 185 */     StringBuilder sb = new StringBuilder();
/* 186 */     sb.append(prefix);
/* 187 */     sb.append(this.javaProperty);
/*     */     
/* 189 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void setJavaProperty(String javaProperty) {
/* 193 */     this.javaProperty = javaProperty;
/*     */   }
/*     */   
/*     */   public boolean isJDBCDateColumn() {
/* 197 */     if (this.fullyQualifiedJavaType.equals(
/* 198 */       FullyQualifiedJavaType.getDateInstance())) {
/* 199 */       if ("DATE".equalsIgnoreCase(this.jdbcTypeName)) return true;
/*     */     }
/* 197 */     return 
/*     */     
/* 199 */       false;
/*     */   }
/*     */   
/*     */   public boolean isJDBCTimeColumn() {
/* 203 */     if (this.fullyQualifiedJavaType.equals(
/* 204 */       FullyQualifiedJavaType.getDateInstance())) {
/* 205 */       if ("TIME".equalsIgnoreCase(this.jdbcTypeName)) return true;
/*     */     }
/* 203 */     return 
/*     */     
/* 205 */       false;
/*     */   }
/*     */   
/*     */   public String getTypeHandler() {
/* 209 */     return this.typeHandler;
/*     */   }
/*     */   
/*     */   public void setTypeHandler(String typeHandler) {
/* 213 */     this.typeHandler = typeHandler;
/*     */   }
/*     */   
/*     */   public String getActualColumnName() {
/* 217 */     return this.actualColumnName;
/*     */   }
/*     */   
/*     */   public void setColumnNameDelimited(boolean isColumnNameDelimited) {
/* 221 */     this.isColumnNameDelimited = isColumnNameDelimited;
/*     */   }
/*     */   
/*     */   public boolean isColumnNameDelimited() {
/* 225 */     return this.isColumnNameDelimited;
/*     */   }
/*     */   
/*     */   public String getJdbcTypeName() {
/* 229 */     if (this.jdbcTypeName == null) {
/* 230 */       return "OTHER";
/*     */     }
/*     */     
/* 233 */     return this.jdbcTypeName;
/*     */   }
/*     */   
/*     */   public void setJdbcTypeName(String jdbcTypeName) {
/* 237 */     this.jdbcTypeName = jdbcTypeName;
/*     */   }
/*     */   
/*     */   public FullyQualifiedJavaType getFullyQualifiedJavaType() {
/* 241 */     return this.fullyQualifiedJavaType;
/*     */   }
/*     */   
/*     */   public void setFullyQualifiedJavaType(FullyQualifiedJavaType fullyQualifiedJavaType)
/*     */   {
/* 246 */     this.fullyQualifiedJavaType = fullyQualifiedJavaType;
/*     */   }
/*     */   
/*     */   public String getTableAlias() {
/* 250 */     return this.tableAlias;
/*     */   }
/*     */   
/*     */   public void setTableAlias(String tableAlias) {
/* 254 */     this.tableAlias = tableAlias;
/*     */   }
/*     */   
/*     */   public Context getContext() {
/* 258 */     return this.context;
/*     */   }
/*     */   
/*     */   public void setContext(Context context) {
/* 262 */     this.context = context;
/*     */   }
/*     */   
/*     */   public IntrospectedTable getIntrospectedTable() {
/* 266 */     return this.introspectedTable;
/*     */   }
/*     */   
/*     */   public void setIntrospectedTable(IntrospectedTable introspectedTable) {
/* 270 */     this.introspectedTable = introspectedTable;
/*     */   }
/*     */   
/*     */   public Properties getProperties() {
/* 274 */     return this.properties;
/*     */   }
/*     */   
/*     */   public void setProperties(Properties properties) {
/* 278 */     this.properties.putAll(properties);
/*     */   }
/*     */   
/*     */   public String getRemarks() {
/* 282 */     return this.remarks;
/*     */   }
/*     */   
/*     */   public void setRemarks(String remarks) {
/* 286 */     this.remarks = remarks;
/*     */   }
/*     */   
/*     */   public String getDefaultValue() {
/* 290 */     return this.defaultValue;
/*     */   }
/*     */   
/*     */   public void setDefaultValue(String defaultValue) {
/* 294 */     this.defaultValue = defaultValue;
/*     */   }
/*     */   
/*     */   public boolean isSequenceColumn() {
/* 298 */     return this.isSequenceColumn;
/*     */   }
/*     */   
/*     */   public void setSequenceColumn(boolean isSequenceColumn) {
/* 302 */     this.isSequenceColumn = isSequenceColumn;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\IntrospectedColumn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */