/*     */ package org.mybatis.generator.api.dom;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OutputUtilities
/*     */ {
/*     */   private static final String lineSeparator;
/*     */   
/*     */   static
/*     */   {
/*  30 */     String ls = System.getProperty("line.separator");
/*  31 */     if (ls == null) {
/*  32 */       ls = "\n";
/*     */     }
/*  34 */     lineSeparator = ls;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void javaIndent(StringBuilder sb, int indentLevel)
/*     */   {
/*  54 */     for (int i = 0; i < indentLevel; i++) {
/*  55 */       sb.append("    ");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void xmlIndent(StringBuilder sb, int indentLevel)
/*     */   {
/*  69 */     for (int i = 0; i < indentLevel; i++) {
/*  70 */       sb.append("  ");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void newLine(StringBuilder sb)
/*     */   {
/*  81 */     sb.append(lineSeparator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Set<String> calculateImports(Set<FullyQualifiedJavaType> importedTypes)
/*     */   {
/*  92 */     StringBuilder sb = new StringBuilder();
/*  93 */     Set<String> importStrings = new TreeSet();
/*  94 */     Iterator localIterator2; for (Iterator localIterator1 = importedTypes.iterator(); localIterator1.hasNext(); 
/*  95 */         localIterator2.hasNext())
/*     */     {
/*  94 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)localIterator1.next();
/*  95 */       localIterator2 = fqjt.getImportList().iterator(); continue;String importString = (String)localIterator2.next();
/*  96 */       sb.setLength(0);
/*  97 */       sb.append("import ");
/*  98 */       sb.append(importString);
/*  99 */       sb.append(';');
/* 100 */       importStrings.add(sb.toString());
/*     */     }
/*     */     
/*     */ 
/* 104 */     return importStrings;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\OutputUtilities.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */