/*     */ package org.mybatis.generator.api.dom.xml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.dom.OutputUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlElement
/*     */   extends Element
/*     */ {
/*     */   private List<Attribute> attributes;
/*     */   private List<Element> elements;
/*     */   private String name;
/*     */   
/*     */   public XmlElement(String name)
/*     */   {
/*  38 */     this.attributes = new ArrayList();
/*  39 */     this.elements = new ArrayList();
/*  40 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XmlElement(XmlElement original)
/*     */   {
/*  51 */     this.attributes = new ArrayList();
/*  52 */     this.attributes.addAll(original.attributes);
/*  53 */     this.elements = new ArrayList();
/*  54 */     this.elements.addAll(original.elements);
/*  55 */     this.name = original.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Attribute> getAttributes()
/*     */   {
/*  62 */     return this.attributes;
/*     */   }
/*     */   
/*     */   public void addAttribute(Attribute attribute) {
/*  66 */     this.attributes.add(attribute);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Element> getElements()
/*     */   {
/*  73 */     return this.elements;
/*     */   }
/*     */   
/*     */   public void addElement(Element element) {
/*  77 */     this.elements.add(element);
/*     */   }
/*     */   
/*     */   public void addElement(int index, Element element) {
/*  81 */     this.elements.add(index, element);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  88 */     return this.name;
/*     */   }
/*     */   
/*     */   public String getFormattedContent(int indentLevel)
/*     */   {
/*  93 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  95 */     OutputUtilities.xmlIndent(sb, indentLevel);
/*  96 */     sb.append('<');
/*  97 */     sb.append(this.name);
/*     */     
/*  99 */     for (Attribute att : this.attributes) {
/* 100 */       sb.append(' ');
/* 101 */       sb.append(att.getFormattedContent());
/*     */     }
/*     */     
/* 104 */     if (this.elements.size() > 0) {
/* 105 */       sb.append(" >");
/* 106 */       for (Element element : this.elements) {
/* 107 */         OutputUtilities.newLine(sb);
/* 108 */         sb.append(element.getFormattedContent(indentLevel + 1));
/*     */       }
/* 110 */       OutputUtilities.newLine(sb);
/* 111 */       OutputUtilities.xmlIndent(sb, indentLevel);
/* 112 */       sb.append("</");
/* 113 */       sb.append(this.name);
/* 114 */       sb.append('>');
/*     */     }
/*     */     else {
/* 117 */       sb.append(" />");
/*     */     }
/*     */     
/* 120 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 124 */     this.name = name;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\xml\XmlElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */