/*     */ package org.mybatis.generator.api.dom.java;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import org.mybatis.generator.api.dom.OutputUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Method
/*     */   extends JavaElement
/*     */ {
/*     */   private List<String> bodyLines;
/*     */   private boolean constructor;
/*     */   private FullyQualifiedJavaType returnType;
/*     */   private String name;
/*     */   private List<Parameter> parameters;
/*     */   private List<FullyQualifiedJavaType> exceptions;
/*     */   private boolean isSynchronized;
/*     */   private boolean isNative;
/*     */   
/*     */   public Method()
/*     */   {
/*  51 */     this("bar");
/*     */   }
/*     */   
/*     */   public Method(String name)
/*     */   {
/*  56 */     this.bodyLines = new ArrayList();
/*  57 */     this.parameters = new ArrayList();
/*  58 */     this.exceptions = new ArrayList();
/*  59 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Method(Method original)
/*     */   {
/*  69 */     super(original);
/*  70 */     this.bodyLines = new ArrayList();
/*  71 */     this.parameters = new ArrayList();
/*  72 */     this.exceptions = new ArrayList();
/*  73 */     this.bodyLines.addAll(original.bodyLines);
/*  74 */     this.constructor = original.constructor;
/*  75 */     this.exceptions.addAll(original.exceptions);
/*  76 */     this.name = original.name;
/*  77 */     this.parameters.addAll(original.parameters);
/*  78 */     this.returnType = original.returnType;
/*  79 */     this.isNative = original.isNative;
/*  80 */     this.isSynchronized = original.isSynchronized;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<String> getBodyLines()
/*     */   {
/*  87 */     return this.bodyLines;
/*     */   }
/*     */   
/*     */   public void addBodyLine(String line) {
/*  91 */     this.bodyLines.add(line);
/*     */   }
/*     */   
/*     */   public void addBodyLine(int index, String line) {
/*  95 */     this.bodyLines.add(index, line);
/*     */   }
/*     */   
/*     */   public void addBodyLines(Collection<String> lines) {
/*  99 */     this.bodyLines.addAll(lines);
/*     */   }
/*     */   
/*     */   public void addBodyLines(int index, Collection<String> lines) {
/* 103 */     this.bodyLines.addAll(index, lines);
/*     */   }
/*     */   
/*     */   public String getFormattedContent(int indentLevel, boolean interfaceMethod) {
/* 107 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 109 */     addFormattedJavadoc(sb, indentLevel);
/* 110 */     addFormattedAnnotations(sb, indentLevel);
/*     */     
/* 112 */     OutputUtilities.javaIndent(sb, indentLevel);
/*     */     
/* 114 */     if (!interfaceMethod) {
/* 115 */       sb.append(getVisibility().getValue());
/*     */       
/* 117 */       if (isStatic()) {
/* 118 */         sb.append("static ");
/*     */       }
/*     */       
/* 121 */       if (isFinal()) {
/* 122 */         sb.append("final ");
/*     */       }
/*     */       
/* 125 */       if (isSynchronized()) {
/* 126 */         sb.append("synchronized ");
/*     */       }
/*     */       
/* 129 */       if (isNative()) {
/* 130 */         sb.append("native ");
/* 131 */       } else if (this.bodyLines.size() == 0) {
/* 132 */         sb.append("abstract ");
/*     */       }
/*     */     }
/*     */     
/* 136 */     if (!this.constructor) {
/* 137 */       if (getReturnType() == null) {
/* 138 */         sb.append("void");
/*     */       } else {
/* 140 */         sb.append(getReturnType().getShortName());
/*     */       }
/* 142 */       sb.append(' ');
/*     */     }
/*     */     
/* 145 */     sb.append(getName());
/* 146 */     sb.append('(');
/*     */     
/* 148 */     boolean comma = false;
/* 149 */     for (Parameter parameter : getParameters()) {
/* 150 */       if (comma) {
/* 151 */         sb.append(", ");
/*     */       } else {
/* 153 */         comma = true;
/*     */       }
/*     */       
/* 156 */       sb.append(parameter.getFormattedContent());
/*     */     }
/*     */     
/* 159 */     sb.append(')');
/*     */     
/* 161 */     if (getExceptions().size() > 0) {
/* 162 */       sb.append(" throws ");
/* 163 */       comma = false;
/* 164 */       for (FullyQualifiedJavaType fqjt : getExceptions()) {
/* 165 */         if (comma) {
/* 166 */           sb.append(", ");
/*     */         } else {
/* 168 */           comma = true;
/*     */         }
/*     */         
/* 171 */         sb.append(fqjt.getShortName());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 176 */     if ((this.bodyLines.size() == 0) || (isNative())) {
/* 177 */       sb.append(';');
/*     */     } else {
/* 179 */       sb.append(" {");
/* 180 */       indentLevel++;
/*     */       
/* 182 */       ListIterator<String> listIter = this.bodyLines.listIterator();
/* 183 */       while (listIter.hasNext()) {
/* 184 */         String line = (String)listIter.next();
/* 185 */         if (line.startsWith("}")) {
/* 186 */           indentLevel--;
/*     */         }
/*     */         
/* 189 */         OutputUtilities.newLine(sb);
/* 190 */         OutputUtilities.javaIndent(sb, indentLevel);
/* 191 */         sb.append(line);
/*     */         
/* 193 */         if (((line.endsWith("{")) && (!line.startsWith("switch"))) || 
/* 194 */           (line.endsWith(":"))) {
/* 195 */           indentLevel++;
/*     */         }
/*     */         
/* 198 */         if (line.startsWith("break"))
/*     */         {
/* 200 */           if (listIter.hasNext()) {
/* 201 */             String nextLine = (String)listIter.next();
/* 202 */             if (nextLine.startsWith("}")) {
/* 203 */               indentLevel++;
/*     */             }
/*     */             
/*     */ 
/* 207 */             listIter.previous();
/*     */           }
/* 209 */           indentLevel--;
/*     */         }
/*     */       }
/*     */       
/* 213 */       indentLevel--;
/* 214 */       OutputUtilities.newLine(sb);
/* 215 */       OutputUtilities.javaIndent(sb, indentLevel);
/* 216 */       sb.append('}');
/*     */     }
/*     */     
/* 219 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isConstructor()
/*     */   {
/* 226 */     return this.constructor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConstructor(boolean constructor)
/*     */   {
/* 234 */     this.constructor = constructor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 241 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 249 */     this.name = name;
/*     */   }
/*     */   
/*     */   public List<Parameter> getParameters() {
/* 253 */     return this.parameters;
/*     */   }
/*     */   
/*     */   public void addParameter(Parameter parameter) {
/* 257 */     this.parameters.add(parameter);
/*     */   }
/*     */   
/*     */   public void addParameter(int index, Parameter parameter) {
/* 261 */     this.parameters.add(index, parameter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FullyQualifiedJavaType getReturnType()
/*     */   {
/* 268 */     return this.returnType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReturnType(FullyQualifiedJavaType returnType)
/*     */   {
/* 276 */     this.returnType = returnType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<FullyQualifiedJavaType> getExceptions()
/*     */   {
/* 283 */     return this.exceptions;
/*     */   }
/*     */   
/*     */   public void addException(FullyQualifiedJavaType exception) {
/* 287 */     this.exceptions.add(exception);
/*     */   }
/*     */   
/*     */   public boolean isSynchronized() {
/* 291 */     return this.isSynchronized;
/*     */   }
/*     */   
/*     */   public void setSynchronized(boolean isSynchronized) {
/* 295 */     this.isSynchronized = isSynchronized;
/*     */   }
/*     */   
/*     */   public boolean isNative() {
/* 299 */     return this.isNative;
/*     */   }
/*     */   
/*     */   public void setNative(boolean isNative) {
/* 303 */     this.isNative = isNative;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\java\Method.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */