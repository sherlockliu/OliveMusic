/*     */ package org.mybatis.generator.api.dom.java;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.mybatis.generator.api.dom.OutputUtilities;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Interface
/*     */   extends JavaElement
/*     */   implements CompilationUnit
/*     */ {
/*     */   private Set<FullyQualifiedJavaType> importedTypes;
/*     */   private Set<String> staticImports;
/*     */   private FullyQualifiedJavaType type;
/*     */   private Set<FullyQualifiedJavaType> superInterfaceTypes;
/*     */   private List<Method> methods;
/*     */   private List<String> fileCommentLines;
/*     */   
/*     */   public Interface(FullyQualifiedJavaType type)
/*     */   {
/*  52 */     this.type = type;
/*  53 */     this.superInterfaceTypes = new LinkedHashSet();
/*  54 */     this.methods = new ArrayList();
/*  55 */     this.importedTypes = new TreeSet();
/*  56 */     this.fileCommentLines = new ArrayList();
/*  57 */     this.staticImports = new TreeSet();
/*     */   }
/*     */   
/*     */   public Interface(String type) {
/*  61 */     this(new FullyQualifiedJavaType(type));
/*     */   }
/*     */   
/*     */   public Set<FullyQualifiedJavaType> getImportedTypes() {
/*  65 */     return Collections.unmodifiableSet(this.importedTypes);
/*     */   }
/*     */   
/*     */   public void addImportedType(FullyQualifiedJavaType importedType) {
/*  69 */     if ((importedType.isExplicitlyImported()) && 
/*  70 */       (!importedType.getPackageName().equals(this.type.getPackageName()))) {
/*  71 */       this.importedTypes.add(importedType);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getFormattedContent() {
/*  76 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  78 */     for (String commentLine : this.fileCommentLines) {
/*  79 */       sb.append(commentLine);
/*  80 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/*  83 */     if (StringUtility.stringHasValue(getType().getPackageName())) {
/*  84 */       sb.append("package ");
/*  85 */       sb.append(getType().getPackageName());
/*  86 */       sb.append(';');
/*  87 */       OutputUtilities.newLine(sb);
/*  88 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/*  91 */     for (String staticImport : this.staticImports) {
/*  92 */       sb.append("import static ");
/*  93 */       sb.append(staticImport);
/*  94 */       sb.append(';');
/*  95 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/*  98 */     if (this.staticImports.size() > 0) {
/*  99 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/* 102 */     Set<String> importStrings = OutputUtilities.calculateImports(this.importedTypes);
/* 103 */     for (String importString : importStrings) {
/* 104 */       sb.append(importString);
/* 105 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/* 108 */     if (importStrings.size() > 0) {
/* 109 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/* 112 */     int indentLevel = 0;
/*     */     
/* 114 */     addFormattedJavadoc(sb, indentLevel);
/* 115 */     addFormattedAnnotations(sb, indentLevel);
/*     */     
/* 117 */     sb.append(getVisibility().getValue());
/*     */     
/* 119 */     if (isStatic()) {
/* 120 */       sb.append("static ");
/*     */     }
/*     */     
/* 123 */     if (isFinal()) {
/* 124 */       sb.append("final ");
/*     */     }
/*     */     
/* 127 */     sb.append("interface ");
/* 128 */     sb.append(getType().getShortName());
/*     */     
/* 130 */     if (getSuperInterfaceTypes().size() > 0) {
/* 131 */       sb.append(" extends ");
/*     */       
/* 133 */       boolean comma = false;
/* 134 */       for (FullyQualifiedJavaType fqjt : getSuperInterfaceTypes()) {
/* 135 */         if (comma) {
/* 136 */           sb.append(", ");
/*     */         } else {
/* 138 */           comma = true;
/*     */         }
/*     */         
/* 141 */         sb.append(fqjt.getShortName());
/*     */       }
/*     */     }
/*     */     
/* 145 */     sb.append(" {");
/* 146 */     indentLevel++;
/*     */     
/* 148 */     Object mtdIter = getMethods().iterator();
/* 149 */     while (((Iterator)mtdIter).hasNext()) {
/* 150 */       OutputUtilities.newLine(sb);
/* 151 */       Method method = (Method)((Iterator)mtdIter).next();
/* 152 */       sb.append(method.getFormattedContent(indentLevel, true));
/* 153 */       if (((Iterator)mtdIter).hasNext()) {
/* 154 */         OutputUtilities.newLine(sb);
/*     */       }
/*     */     }
/*     */     
/* 158 */     indentLevel--;
/* 159 */     OutputUtilities.newLine(sb);
/* 160 */     OutputUtilities.javaIndent(sb, indentLevel);
/* 161 */     sb.append('}');
/*     */     
/* 163 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public void addSuperInterface(FullyQualifiedJavaType superInterface) {
/* 167 */     this.superInterfaceTypes.add(superInterface);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Method> getMethods()
/*     */   {
/* 174 */     return this.methods;
/*     */   }
/*     */   
/*     */   public void addMethod(Method method) {
/* 178 */     this.methods.add(method);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FullyQualifiedJavaType getType()
/*     */   {
/* 185 */     return this.type;
/*     */   }
/*     */   
/*     */   public FullyQualifiedJavaType getSuperClass()
/*     */   {
/* 190 */     return null;
/*     */   }
/*     */   
/*     */   public Set<FullyQualifiedJavaType> getSuperInterfaceTypes() {
/* 194 */     return this.superInterfaceTypes;
/*     */   }
/*     */   
/*     */   public boolean isJavaInterface() {
/* 198 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isJavaEnumeration() {
/* 202 */     return false;
/*     */   }
/*     */   
/*     */   public void addFileCommentLine(String commentLine) {
/* 206 */     this.fileCommentLines.add(commentLine);
/*     */   }
/*     */   
/*     */   public List<String> getFileCommentLines() {
/* 210 */     return this.fileCommentLines;
/*     */   }
/*     */   
/*     */   public void addImportedTypes(Set<FullyQualifiedJavaType> importedTypes) {
/* 214 */     this.importedTypes.addAll(importedTypes);
/*     */   }
/*     */   
/*     */   public Set<String> getStaticImports() {
/* 218 */     return this.staticImports;
/*     */   }
/*     */   
/*     */   public void addStaticImport(String staticImport) {
/* 222 */     this.staticImports.add(staticImport);
/*     */   }
/*     */   
/*     */   public void addStaticImports(Set<String> staticImports) {
/* 226 */     this.staticImports.addAll(staticImports);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\java\Interface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */