/*    */ package org.mybatis.generator.api.dom;
/*    */ 
/*    */ import org.mybatis.generator.api.JavaFormatter;
/*    */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*    */ import org.mybatis.generator.config.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultJavaFormatter
/*    */   implements JavaFormatter
/*    */ {
/*    */   protected Context context;
/*    */   
/*    */   public String getFormattedContent(CompilationUnit compilationUnit)
/*    */   {
/* 33 */     return compilationUnit.getFormattedContent();
/*    */   }
/*    */   
/*    */   public void setContext(Context context) {
/* 37 */     this.context = context;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\DefaultJavaFormatter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */