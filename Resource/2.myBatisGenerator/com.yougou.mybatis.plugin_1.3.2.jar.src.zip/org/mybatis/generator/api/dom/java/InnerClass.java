/*     */ package org.mybatis.generator.api.dom.java;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.mybatis.generator.api.dom.OutputUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InnerClass
/*     */   extends JavaElement
/*     */ {
/*     */   private List<Field> fields;
/*     */   private List<InnerClass> innerClasses;
/*     */   private List<InnerEnum> innerEnums;
/*     */   private FullyQualifiedJavaType superClass;
/*     */   private FullyQualifiedJavaType type;
/*     */   private Set<FullyQualifiedJavaType> superInterfaceTypes;
/*     */   private List<Method> methods;
/*     */   private boolean isAbstract;
/*     */   private List<InitializationBlock> initializationBlocks;
/*     */   
/*     */   public InnerClass(FullyQualifiedJavaType type)
/*     */   {
/*  56 */     this.type = type;
/*  57 */     this.fields = new ArrayList();
/*  58 */     this.innerClasses = new ArrayList();
/*  59 */     this.innerEnums = new ArrayList();
/*  60 */     this.superInterfaceTypes = new HashSet();
/*  61 */     this.methods = new ArrayList();
/*  62 */     this.initializationBlocks = new ArrayList();
/*     */   }
/*     */   
/*     */   public InnerClass(String typeName) {
/*  66 */     this(new FullyQualifiedJavaType(typeName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Field> getFields()
/*     */   {
/*  73 */     return this.fields;
/*     */   }
/*     */   
/*     */   public void addField(Field field) {
/*  77 */     this.fields.add(field);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FullyQualifiedJavaType getSuperClass()
/*     */   {
/*  84 */     return this.superClass;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSuperClass(FullyQualifiedJavaType superClass)
/*     */   {
/*  92 */     this.superClass = superClass;
/*     */   }
/*     */   
/*     */   public void setSuperClass(String superClassType) {
/*  96 */     this.superClass = new FullyQualifiedJavaType(superClassType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<InnerClass> getInnerClasses()
/*     */   {
/* 103 */     return this.innerClasses;
/*     */   }
/*     */   
/*     */   public void addInnerClass(InnerClass innerClass) {
/* 107 */     this.innerClasses.add(innerClass);
/*     */   }
/*     */   
/*     */   public List<InnerEnum> getInnerEnums() {
/* 111 */     return this.innerEnums;
/*     */   }
/*     */   
/*     */   public void addInnerEnum(InnerEnum innerEnum) {
/* 115 */     this.innerEnums.add(innerEnum);
/*     */   }
/*     */   
/*     */   public List<InitializationBlock> getInitializationBlocks() {
/* 119 */     return this.initializationBlocks;
/*     */   }
/*     */   
/*     */   public void addInitializationBlock(InitializationBlock initializationBlock) {
/* 123 */     this.initializationBlocks.add(initializationBlock);
/*     */   }
/*     */   
/*     */   public String getFormattedContent(int indentLevel) {
/* 127 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 129 */     addFormattedJavadoc(sb, indentLevel);
/* 130 */     addFormattedAnnotations(sb, indentLevel);
/*     */     
/* 132 */     OutputUtilities.javaIndent(sb, indentLevel);
/* 133 */     sb.append(getVisibility().getValue());
/*     */     
/* 135 */     if (isAbstract()) {
/* 136 */       sb.append("abstract ");
/*     */     }
/*     */     
/* 139 */     if (isStatic()) {
/* 140 */       sb.append("static ");
/*     */     }
/*     */     
/* 143 */     if (isFinal()) {
/* 144 */       sb.append("final ");
/*     */     }
/*     */     
/* 147 */     sb.append("class ");
/* 148 */     sb.append(getType().getShortName());
/*     */     
/* 150 */     if (this.superClass != null) {
/* 151 */       sb.append(" extends ");
/* 152 */       sb.append(this.superClass.getShortName());
/*     */     }
/*     */     
/* 155 */     if (this.superInterfaceTypes.size() > 0) {
/* 156 */       sb.append(" implements ");
/*     */       
/* 158 */       boolean comma = false;
/* 159 */       for (FullyQualifiedJavaType fqjt : this.superInterfaceTypes) {
/* 160 */         if (comma) {
/* 161 */           sb.append(", ");
/*     */         } else {
/* 163 */           comma = true;
/*     */         }
/*     */         
/* 166 */         sb.append(fqjt.getShortName());
/*     */       }
/*     */     }
/*     */     
/* 170 */     sb.append(" {");
/* 171 */     indentLevel++;
/*     */     
/* 173 */     Iterator<Field> fldIter = this.fields.iterator();
/* 174 */     while (fldIter.hasNext()) {
/* 175 */       OutputUtilities.newLine(sb);
/* 176 */       Field field = (Field)fldIter.next();
/* 177 */       sb.append(field.getFormattedContent(indentLevel));
/* 178 */       if (fldIter.hasNext()) {
/* 179 */         OutputUtilities.newLine(sb);
/*     */       }
/*     */     }
/*     */     
/* 183 */     if (this.initializationBlocks.size() > 0) {
/* 184 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/* 187 */     Iterator<InitializationBlock> blkIter = this.initializationBlocks.iterator();
/* 188 */     while (blkIter.hasNext()) {
/* 189 */       OutputUtilities.newLine(sb);
/* 190 */       InitializationBlock initializationBlock = (InitializationBlock)blkIter.next();
/* 191 */       sb.append(initializationBlock.getFormattedContent(indentLevel));
/* 192 */       if (blkIter.hasNext()) {
/* 193 */         OutputUtilities.newLine(sb);
/*     */       }
/*     */     }
/*     */     
/* 197 */     if (this.methods.size() > 0) {
/* 198 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/* 201 */     Object mtdIter = this.methods.iterator();
/* 202 */     while (((Iterator)mtdIter).hasNext()) {
/* 203 */       OutputUtilities.newLine(sb);
/* 204 */       Method method = (Method)((Iterator)mtdIter).next();
/* 205 */       sb.append(method.getFormattedContent(indentLevel, false));
/* 206 */       if (((Iterator)mtdIter).hasNext()) {
/* 207 */         OutputUtilities.newLine(sb);
/*     */       }
/*     */     }
/*     */     
/* 211 */     if (this.innerClasses.size() > 0) {
/* 212 */       OutputUtilities.newLine(sb);
/*     */     }
/* 214 */     Iterator<InnerClass> icIter = this.innerClasses.iterator();
/* 215 */     while (icIter.hasNext()) {
/* 216 */       OutputUtilities.newLine(sb);
/* 217 */       InnerClass innerClass = (InnerClass)icIter.next();
/* 218 */       sb.append(innerClass.getFormattedContent(indentLevel));
/* 219 */       if (icIter.hasNext()) {
/* 220 */         OutputUtilities.newLine(sb);
/*     */       }
/*     */     }
/*     */     
/* 224 */     if (this.innerEnums.size() > 0) {
/* 225 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/* 228 */     Iterator<InnerEnum> ieIter = this.innerEnums.iterator();
/* 229 */     while (ieIter.hasNext()) {
/* 230 */       OutputUtilities.newLine(sb);
/* 231 */       InnerEnum innerEnum = (InnerEnum)ieIter.next();
/* 232 */       sb.append(innerEnum.getFormattedContent(indentLevel));
/* 233 */       if (ieIter.hasNext()) {
/* 234 */         OutputUtilities.newLine(sb);
/*     */       }
/*     */     }
/*     */     
/* 238 */     indentLevel--;
/* 239 */     OutputUtilities.newLine(sb);
/* 240 */     OutputUtilities.javaIndent(sb, indentLevel);
/* 241 */     sb.append('}');
/*     */     
/* 243 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<FullyQualifiedJavaType> getSuperInterfaceTypes()
/*     */   {
/* 250 */     return this.superInterfaceTypes;
/*     */   }
/*     */   
/*     */   public void addSuperInterface(FullyQualifiedJavaType superInterface) {
/* 254 */     this.superInterfaceTypes.add(superInterface);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<Method> getMethods()
/*     */   {
/* 261 */     return this.methods;
/*     */   }
/*     */   
/*     */   public void addMethod(Method method) {
/* 265 */     this.methods.add(method);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FullyQualifiedJavaType getType()
/*     */   {
/* 272 */     return this.type;
/*     */   }
/*     */   
/*     */   public boolean isAbstract() {
/* 276 */     return this.isAbstract;
/*     */   }
/*     */   
/*     */   public void setAbstract(boolean isAbtract) {
/* 280 */     this.isAbstract = isAbtract;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\java\InnerClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */