/*    */ package org.mybatis.generator.api.dom;
/*    */ 
/*    */ import org.mybatis.generator.api.XmlFormatter;
/*    */ import org.mybatis.generator.api.dom.xml.Document;
/*    */ import org.mybatis.generator.config.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultXmlFormatter
/*    */   implements XmlFormatter
/*    */ {
/*    */   protected Context context;
/*    */   
/*    */   public String getFormattedContent(Document document)
/*    */   {
/* 33 */     return document.getFormattedContent();
/*    */   }
/*    */   
/*    */   public void setContext(Context context) {
/* 37 */     this.context = context;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\DefaultXmlFormatter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */