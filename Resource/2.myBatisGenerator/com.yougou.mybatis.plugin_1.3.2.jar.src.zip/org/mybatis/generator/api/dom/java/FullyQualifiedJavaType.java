/*     */ package org.mybatis.generator.api.dom.java;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FullyQualifiedJavaType
/*     */   implements Comparable<FullyQualifiedJavaType>
/*     */ {
/*     */   private static final String JAVA_LANG = "java.lang";
/*  31 */   private static FullyQualifiedJavaType intInstance = null;
/*  32 */   private static FullyQualifiedJavaType stringInstance = null;
/*  33 */   private static FullyQualifiedJavaType booleanPrimitiveInstance = null;
/*  34 */   private static FullyQualifiedJavaType objectInstance = null;
/*  35 */   private static FullyQualifiedJavaType dateInstance = null;
/*  36 */   private static FullyQualifiedJavaType criteriaInstance = null;
/*  37 */   private static FullyQualifiedJavaType generatedCriteriaInstance = null;
/*     */   
/*     */ 
/*     */   private String baseShortName;
/*     */   
/*     */ 
/*     */   private String baseQualifiedName;
/*     */   
/*     */ 
/*     */   private boolean explicitlyImported;
/*     */   
/*     */ 
/*     */   private String packageName;
/*     */   
/*     */ 
/*     */   private boolean primitive;
/*     */   
/*     */ 
/*     */   private PrimitiveTypeWrapper primitiveTypeWrapper;
/*     */   
/*     */   private List<FullyQualifiedJavaType> typeArguments;
/*     */   
/*     */   private boolean wildcardType;
/*     */   
/*     */   private boolean boundedWildcard;
/*     */   
/*     */   private boolean extendsBoundedWildcard;
/*     */   
/*     */ 
/*     */   public FullyQualifiedJavaType(String fullTypeSpecification)
/*     */   {
/*  68 */     this.typeArguments = new ArrayList();
/*  69 */     parse(fullTypeSpecification);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isExplicitlyImported()
/*     */   {
/*  76 */     return this.explicitlyImported;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFullyQualifiedName()
/*     */   {
/*  86 */     StringBuilder sb = new StringBuilder();
/*  87 */     if (this.wildcardType) {
/*  88 */       sb.append('?');
/*  89 */       if (this.boundedWildcard) {
/*  90 */         if (this.extendsBoundedWildcard) {
/*  91 */           sb.append(" extends ");
/*     */         } else {
/*  93 */           sb.append(" super ");
/*     */         }
/*     */         
/*  96 */         sb.append(this.baseQualifiedName);
/*     */       }
/*     */     } else {
/*  99 */       sb.append(this.baseQualifiedName);
/*     */     }
/*     */     
/* 102 */     if (this.typeArguments.size() > 0) {
/* 103 */       boolean first = true;
/* 104 */       sb.append('<');
/* 105 */       for (FullyQualifiedJavaType fqjt : this.typeArguments) {
/* 106 */         if (first) {
/* 107 */           first = false;
/*     */         } else {
/* 109 */           sb.append(", ");
/*     */         }
/* 111 */         sb.append(fqjt.getFullyQualifiedName());
/*     */       }
/*     */       
/* 114 */       sb.append('>');
/*     */     }
/*     */     
/* 117 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getImportList()
/*     */   {
/* 125 */     List<String> answer = new ArrayList();
/* 126 */     StringBuilder sb; if (isExplicitlyImported()) {
/* 127 */       int index = this.baseShortName.indexOf('.');
/* 128 */       if (index == -1) {
/* 129 */         answer.add(this.baseQualifiedName);
/*     */       }
/*     */       else
/*     */       {
/* 133 */         sb = new StringBuilder();
/* 134 */         sb.append(this.packageName);
/* 135 */         sb.append('.');
/* 136 */         sb.append(this.baseShortName.substring(0, index));
/* 137 */         answer.add(sb.toString());
/*     */       }
/*     */     }
/*     */     
/* 141 */     for (FullyQualifiedJavaType fqjt : this.typeArguments) {
/* 142 */       answer.addAll(fqjt.getImportList());
/*     */     }
/*     */     
/* 145 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getPackageName()
/*     */   {
/* 152 */     return this.packageName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getShortName()
/*     */   {
/* 159 */     StringBuilder sb = new StringBuilder();
/* 160 */     if (this.wildcardType) {
/* 161 */       sb.append('?');
/* 162 */       if (this.boundedWildcard) {
/* 163 */         if (this.extendsBoundedWildcard) {
/* 164 */           sb.append(" extends ");
/*     */         } else {
/* 166 */           sb.append(" super ");
/*     */         }
/*     */         
/* 169 */         sb.append(this.baseShortName);
/*     */       }
/*     */     } else {
/* 172 */       sb.append(this.baseShortName);
/*     */     }
/*     */     
/* 175 */     if (this.typeArguments.size() > 0) {
/* 176 */       boolean first = true;
/* 177 */       sb.append('<');
/* 178 */       for (FullyQualifiedJavaType fqjt : this.typeArguments) {
/* 179 */         if (first) {
/* 180 */           first = false;
/*     */         } else {
/* 182 */           sb.append(", ");
/*     */         }
/* 184 */         sb.append(fqjt.getShortName());
/*     */       }
/*     */       
/* 187 */       sb.append('>');
/*     */     }
/*     */     
/* 190 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 200 */     if (this == obj) {
/* 201 */       return true;
/*     */     }
/*     */     
/* 204 */     if (!(obj instanceof FullyQualifiedJavaType)) {
/* 205 */       return false;
/*     */     }
/*     */     
/* 208 */     FullyQualifiedJavaType other = (FullyQualifiedJavaType)obj;
/*     */     
/* 210 */     return getFullyQualifiedName().equals(other.getFullyQualifiedName());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 220 */     return getFullyQualifiedName().hashCode();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 230 */     return getFullyQualifiedName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isPrimitive()
/*     */   {
/* 237 */     return this.primitive;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PrimitiveTypeWrapper getPrimitiveTypeWrapper()
/*     */   {
/* 244 */     return this.primitiveTypeWrapper;
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getIntInstance() {
/* 248 */     if (intInstance == null) {
/* 249 */       intInstance = new FullyQualifiedJavaType("int");
/*     */     }
/*     */     
/* 252 */     return intInstance;
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getNewMapInstance()
/*     */   {
/* 257 */     return new FullyQualifiedJavaType("java.util.Map");
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getNewListInstance()
/*     */   {
/* 262 */     return new FullyQualifiedJavaType("java.util.List");
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getNewHashMapInstance()
/*     */   {
/* 267 */     return new FullyQualifiedJavaType("java.util.HashMap");
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getNewArrayListInstance()
/*     */   {
/* 272 */     return new FullyQualifiedJavaType("java.util.ArrayList");
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getNewIteratorInstance()
/*     */   {
/* 277 */     return new FullyQualifiedJavaType("java.util.Iterator");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final FullyQualifiedJavaType getAnnotateParam()
/*     */   {
/* 288 */     return new FullyQualifiedJavaType("org.apache.ibatis.annotations.Param");
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getStringInstance() {
/* 292 */     if (stringInstance == null) {
/* 293 */       stringInstance = new FullyQualifiedJavaType("java.lang.String");
/*     */     }
/*     */     
/* 296 */     return stringInstance;
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getBooleanPrimitiveInstance() {
/* 300 */     if (booleanPrimitiveInstance == null) {
/* 301 */       booleanPrimitiveInstance = new FullyQualifiedJavaType("boolean");
/*     */     }
/*     */     
/* 304 */     return booleanPrimitiveInstance;
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getObjectInstance() {
/* 308 */     if (objectInstance == null) {
/* 309 */       objectInstance = new FullyQualifiedJavaType("java.lang.Object");
/*     */     }
/*     */     
/* 312 */     return objectInstance;
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getDateInstance() {
/* 316 */     if (dateInstance == null) {
/* 317 */       dateInstance = new FullyQualifiedJavaType("java.util.Date");
/*     */     }
/*     */     
/* 320 */     return dateInstance;
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getCriteriaInstance() {
/* 324 */     if (criteriaInstance == null) {
/* 325 */       criteriaInstance = new FullyQualifiedJavaType("Criteria");
/*     */     }
/*     */     
/* 328 */     return criteriaInstance;
/*     */   }
/*     */   
/*     */   public static final FullyQualifiedJavaType getGeneratedCriteriaInstance() {
/* 332 */     if (generatedCriteriaInstance == null) {
/* 333 */       generatedCriteriaInstance = new FullyQualifiedJavaType(
/* 334 */         "GeneratedCriteria");
/*     */     }
/*     */     
/* 337 */     return generatedCriteriaInstance;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compareTo(FullyQualifiedJavaType other)
/*     */   {
/* 346 */     return getFullyQualifiedName().compareTo(other.getFullyQualifiedName());
/*     */   }
/*     */   
/*     */   public void addTypeArgument(FullyQualifiedJavaType type) {
/* 350 */     this.typeArguments.add(type);
/*     */   }
/*     */   
/*     */   private void parse(String fullTypeSpecification) {
/* 354 */     String spec = fullTypeSpecification.trim();
/*     */     
/* 356 */     if (spec.startsWith("?")) {
/* 357 */       this.wildcardType = true;
/* 358 */       spec = spec.substring(1).trim();
/* 359 */       if (spec.startsWith("extends ")) {
/* 360 */         this.boundedWildcard = true;
/* 361 */         this.extendsBoundedWildcard = true;
/* 362 */         spec = spec.substring(8);
/* 363 */       } else if (spec.startsWith("super ")) {
/* 364 */         this.boundedWildcard = true;
/* 365 */         this.extendsBoundedWildcard = false;
/* 366 */         spec = spec.substring(6);
/*     */       } else {
/* 368 */         this.boundedWildcard = false;
/*     */       }
/* 370 */       parse(spec);
/*     */     } else {
/* 372 */       int index = fullTypeSpecification.indexOf('<');
/* 373 */       if (index == -1) {
/* 374 */         simpleParse(fullTypeSpecification);
/*     */       } else {
/* 376 */         simpleParse(fullTypeSpecification.substring(0, index));
/* 377 */         genericParse(fullTypeSpecification.substring(index));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void simpleParse(String typeSpecification) {
/* 383 */     this.baseQualifiedName = typeSpecification.trim();
/* 384 */     if (this.baseQualifiedName.contains(".")) {
/* 385 */       this.packageName = getPackage(this.baseQualifiedName);
/* 386 */       this.baseShortName = this.baseQualifiedName
/* 387 */         .substring(this.packageName.length() + 1);
/* 388 */       int index = this.baseShortName.lastIndexOf('.');
/* 389 */       if (index != -1) {
/* 390 */         this.baseShortName = this.baseShortName.substring(index + 1);
/*     */       }
/*     */       
/* 393 */       if ("java.lang".equals(this.packageName)) {
/* 394 */         this.explicitlyImported = false;
/*     */       } else {
/* 396 */         this.explicitlyImported = true;
/*     */       }
/*     */     } else {
/* 399 */       this.baseShortName = this.baseQualifiedName;
/* 400 */       this.explicitlyImported = false;
/* 401 */       this.packageName = "";
/*     */       
/* 403 */       if ("byte".equals(this.baseQualifiedName)) {
/* 404 */         this.primitive = true;
/* 405 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getByteInstance();
/* 406 */       } else if ("short".equals(this.baseQualifiedName)) {
/* 407 */         this.primitive = true;
/* 408 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getShortInstance();
/* 409 */       } else if ("int".equals(this.baseQualifiedName)) {
/* 410 */         this.primitive = true;
/* 411 */         this.primitiveTypeWrapper = 
/* 412 */           PrimitiveTypeWrapper.getIntegerInstance();
/* 413 */       } else if ("long".equals(this.baseQualifiedName)) {
/* 414 */         this.primitive = true;
/* 415 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getLongInstance();
/* 416 */       } else if ("char".equals(this.baseQualifiedName)) {
/* 417 */         this.primitive = true;
/* 418 */         this.primitiveTypeWrapper = 
/* 419 */           PrimitiveTypeWrapper.getCharacterInstance();
/* 420 */       } else if ("float".equals(this.baseQualifiedName)) {
/* 421 */         this.primitive = true;
/* 422 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getFloatInstance();
/* 423 */       } else if ("double".equals(this.baseQualifiedName)) {
/* 424 */         this.primitive = true;
/* 425 */         this.primitiveTypeWrapper = PrimitiveTypeWrapper.getDoubleInstance();
/* 426 */       } else if ("boolean".equals(this.baseQualifiedName)) {
/* 427 */         this.primitive = true;
/* 428 */         this.primitiveTypeWrapper = 
/* 429 */           PrimitiveTypeWrapper.getBooleanInstance();
/*     */       } else {
/* 431 */         this.primitive = false;
/* 432 */         this.primitiveTypeWrapper = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void genericParse(String genericSpecification) {
/* 438 */     int lastIndex = genericSpecification.lastIndexOf('>');
/* 439 */     if (lastIndex == -1) {
/* 440 */       throw new RuntimeException(Messages.getString(
/* 441 */         "RuntimeError.22", genericSpecification));
/*     */     }
/* 443 */     String argumentString = genericSpecification.substring(1, lastIndex);
/*     */     
/* 445 */     StringTokenizer st = new StringTokenizer(argumentString, ",<>", true);
/* 446 */     int openCount = 0;
/* 447 */     StringBuilder sb = new StringBuilder();
/* 448 */     while (st.hasMoreTokens()) {
/* 449 */       String token = st.nextToken();
/* 450 */       if ("<".equals(token)) {
/* 451 */         sb.append(token);
/* 452 */         openCount++;
/* 453 */       } else if (">".equals(token)) {
/* 454 */         sb.append(token);
/* 455 */         openCount--;
/* 456 */       } else if (",".equals(token)) {
/* 457 */         if (openCount == 0)
/*     */         {
/* 459 */           this.typeArguments.add(new FullyQualifiedJavaType(sb.toString()));
/* 460 */           sb.setLength(0);
/*     */         } else {
/* 462 */           sb.append(token);
/*     */         }
/*     */       } else {
/* 465 */         sb.append(token);
/*     */       }
/*     */     }
/*     */     
/* 469 */     if (openCount != 0) {
/* 470 */       throw new RuntimeException(Messages.getString(
/* 471 */         "RuntimeError.22", genericSpecification));
/*     */     }
/*     */     
/* 474 */     String finalType = sb.toString();
/* 475 */     if (StringUtility.stringHasValue(finalType)) {
/* 476 */       this.typeArguments.add(new FullyQualifiedJavaType(finalType));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static String getPackage(String baseQualifiedName)
/*     */   {
/* 492 */     int index = baseQualifiedName.lastIndexOf('.');
/* 493 */     return baseQualifiedName.substring(0, index);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\java\FullyQualifiedJavaType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */