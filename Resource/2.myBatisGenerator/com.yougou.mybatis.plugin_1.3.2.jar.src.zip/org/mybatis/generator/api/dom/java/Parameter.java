/*    */ package org.mybatis.generator.api.dom.java;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Parameter
/*    */ {
/*    */   private String name;
/*    */   private FullyQualifiedJavaType type;
/*    */   private boolean isVarargs;
/*    */   private List<String> annotations;
/*    */   
/*    */   public Parameter(FullyQualifiedJavaType type, String name, boolean isVarargs)
/*    */   {
/* 33 */     this.name = name;
/* 34 */     this.type = type;
/* 35 */     this.isVarargs = isVarargs;
/* 36 */     this.annotations = new ArrayList();
/*    */   }
/*    */   
/*    */   public Parameter(FullyQualifiedJavaType type, String name) {
/* 40 */     this(type, name, false);
/*    */   }
/*    */   
/*    */   public Parameter(FullyQualifiedJavaType type, String name, String annotation) {
/* 44 */     this(type, name, false);
/* 45 */     addAnnotation(annotation);
/*    */   }
/*    */   
/*    */   public Parameter(FullyQualifiedJavaType type, String name, String annotation, boolean isVarargs) {
/* 49 */     this(type, name, isVarargs);
/* 50 */     addAnnotation(annotation);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public String getName()
/*    */   {
/* 57 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public FullyQualifiedJavaType getType()
/*    */   {
/* 64 */     return this.type;
/*    */   }
/*    */   
/*    */   public List<String> getAnnotations() {
/* 68 */     return this.annotations;
/*    */   }
/*    */   
/*    */   public void addAnnotation(String annotation) {
/* 72 */     this.annotations.add(annotation);
/*    */   }
/*    */   
/*    */   public String getFormattedContent() {
/* 76 */     StringBuilder sb = new StringBuilder();
/*    */     
/* 78 */     for (String annotation : this.annotations) {
/* 79 */       sb.append(annotation);
/* 80 */       sb.append(' ');
/*    */     }
/*    */     
/* 83 */     sb.append(this.type.getShortName());
/* 84 */     sb.append(' ');
/* 85 */     if (this.isVarargs) {
/* 86 */       sb.append("... ");
/*    */     }
/* 88 */     sb.append(this.name);
/*    */     
/* 90 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public String toString()
/*    */   {
/* 95 */     return getFormattedContent();
/*    */   }
/*    */   
/*    */   public boolean isVarargs() {
/* 99 */     return this.isVarargs;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\java\Parameter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */