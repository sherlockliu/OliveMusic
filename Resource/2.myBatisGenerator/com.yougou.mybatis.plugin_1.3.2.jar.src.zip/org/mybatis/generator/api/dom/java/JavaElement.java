/*     */ package org.mybatis.generator.api.dom.java;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.dom.OutputUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JavaElement
/*     */ {
/*     */   private List<String> javaDocLines;
/*  29 */   private JavaVisibility visibility = JavaVisibility.DEFAULT;
/*     */   
/*     */ 
/*     */   private boolean isStatic;
/*     */   
/*     */ 
/*     */   private boolean isFinal;
/*     */   
/*     */   private List<String> annotations;
/*     */   
/*     */ 
/*     */   public JavaElement()
/*     */   {
/*  42 */     this.javaDocLines = new ArrayList();
/*  43 */     this.annotations = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JavaElement(JavaElement original)
/*     */   {
/*  52 */     this();
/*  53 */     this.annotations.addAll(original.annotations);
/*  54 */     this.isFinal = original.isFinal;
/*  55 */     this.isStatic = original.isFinal;
/*  56 */     this.javaDocLines.addAll(original.javaDocLines);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getJavaDocLines()
/*     */   {
/*  64 */     return this.javaDocLines;
/*     */   }
/*     */   
/*     */   public void addJavaDocLine(String javaDocLine) {
/*  68 */     this.javaDocLines.add(javaDocLine);
/*     */   }
/*     */   
/*     */   public List<String> getAnnotations() {
/*  72 */     return this.annotations;
/*     */   }
/*     */   
/*     */   public void addAnnotation(String annotation) {
/*  76 */     this.annotations.add(annotation);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JavaVisibility getVisibility()
/*     */   {
/*  83 */     return this.visibility;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setVisibility(JavaVisibility visibility)
/*     */   {
/*  91 */     this.visibility = visibility;
/*     */   }
/*     */   
/*     */   public void addSuppressTypeWarningsAnnotation() {
/*  95 */     addAnnotation("@SuppressWarnings(\"unchecked\")");
/*     */   }
/*     */   
/*     */   public void addFormattedJavadoc(StringBuilder sb, int indentLevel) {
/*  99 */     for (String javaDocLine : this.javaDocLines) {
/* 100 */       OutputUtilities.javaIndent(sb, indentLevel);
/* 101 */       sb.append(javaDocLine);
/* 102 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addFormattedAnnotations(StringBuilder sb, int indentLevel) {
/* 107 */     for (String annotation : this.annotations) {
/* 108 */       OutputUtilities.javaIndent(sb, indentLevel);
/* 109 */       sb.append(annotation);
/* 110 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isFinal() {
/* 115 */     return this.isFinal;
/*     */   }
/*     */   
/*     */   public void setFinal(boolean isFinal) {
/* 119 */     this.isFinal = isFinal;
/*     */   }
/*     */   
/*     */   public boolean isStatic() {
/* 123 */     return this.isStatic;
/*     */   }
/*     */   
/*     */   public void setStatic(boolean isStatic) {
/* 127 */     this.isStatic = isStatic;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\java\JavaElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */