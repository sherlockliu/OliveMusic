/*     */ package org.mybatis.generator.api.dom.java;
/*     */ 
/*     */ import org.mybatis.generator.api.dom.OutputUtilities;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Field
/*     */   extends JavaElement
/*     */ {
/*     */   private FullyQualifiedJavaType type;
/*     */   private String name;
/*     */   private String initializationString;
/*     */   private boolean isTransient;
/*     */   private boolean isVolatile;
/*     */   
/*     */   public Field()
/*     */   {
/*  35 */     this("foo", FullyQualifiedJavaType.getIntInstance());
/*     */   }
/*     */   
/*     */   public Field(String name, FullyQualifiedJavaType type)
/*     */   {
/*  40 */     this.name = name;
/*  41 */     this.type = type;
/*     */   }
/*     */   
/*     */   public Field(Field field) {
/*  45 */     super(field);
/*  46 */     this.type = field.type;
/*  47 */     this.name = field.name;
/*  48 */     this.initializationString = field.initializationString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/*  55 */     return this.name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  63 */     this.name = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FullyQualifiedJavaType getType()
/*     */   {
/*  70 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setType(FullyQualifiedJavaType type)
/*     */   {
/*  78 */     this.type = type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getInitializationString()
/*     */   {
/*  85 */     return this.initializationString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInitializationString(String initializationString)
/*     */   {
/*  93 */     this.initializationString = initializationString;
/*     */   }
/*     */   
/*     */   public String getFormattedContent(int indentLevel) {
/*  97 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  99 */     addFormattedJavadoc(sb, indentLevel);
/* 100 */     addFormattedAnnotations(sb, indentLevel);
/*     */     
/* 102 */     OutputUtilities.javaIndent(sb, indentLevel);
/* 103 */     sb.append(getVisibility().getValue());
/*     */     
/* 105 */     if (isStatic()) {
/* 106 */       sb.append("static ");
/*     */     }
/*     */     
/* 109 */     if (isFinal()) {
/* 110 */       sb.append("final ");
/*     */     }
/*     */     
/* 113 */     if (isTransient()) {
/* 114 */       sb.append("transient ");
/*     */     }
/*     */     
/* 117 */     if (isVolatile()) {
/* 118 */       sb.append("volatile ");
/*     */     }
/*     */     
/* 121 */     sb.append(this.type.getShortName());
/*     */     
/* 123 */     sb.append(' ');
/* 124 */     sb.append(this.name);
/*     */     
/* 126 */     if ((this.initializationString != null) && (this.initializationString.length() > 0)) {
/* 127 */       sb.append(" = ");
/* 128 */       sb.append(this.initializationString);
/*     */     }
/*     */     
/* 131 */     sb.append(';');
/*     */     
/* 133 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public boolean isTransient() {
/* 137 */     return this.isTransient;
/*     */   }
/*     */   
/*     */   public void setTransient(boolean isTransient) {
/* 141 */     this.isTransient = isTransient;
/*     */   }
/*     */   
/*     */   public boolean isVolatile() {
/* 145 */     return this.isVolatile;
/*     */   }
/*     */   
/*     */   public void setVolatile(boolean isVolatile) {
/* 149 */     this.isVolatile = isVolatile;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\java\Field.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */