/*    */ package org.mybatis.generator.api.dom.java;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum JavaVisibility
/*    */ {
/* 24 */   PUBLIC("public "), 
/* 25 */   PRIVATE("private "), 
/* 26 */   PROTECTED("protected "), 
/* 27 */   DEFAULT("");
/*    */   
/*    */   private String value;
/*    */   
/*    */   private JavaVisibility(String value) {
/* 32 */     this.value = value;
/*    */   }
/*    */   
/*    */   public String getValue() {
/* 36 */     return this.value;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\java\JavaVisibility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */