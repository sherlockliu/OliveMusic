/*     */ package org.mybatis.generator.api.dom.java;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.mybatis.generator.api.dom.OutputUtilities;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TopLevelClass
/*     */   extends InnerClass
/*     */   implements CompilationUnit
/*     */ {
/*     */   private Set<FullyQualifiedJavaType> importedTypes;
/*     */   private Set<String> staticImports;
/*     */   private List<String> fileCommentLines;
/*     */   
/*     */   public TopLevelClass(FullyQualifiedJavaType type)
/*     */   {
/*  42 */     super(type);
/*  43 */     this.importedTypes = new TreeSet();
/*  44 */     this.fileCommentLines = new ArrayList();
/*  45 */     this.staticImports = new TreeSet();
/*     */   }
/*     */   
/*     */   public TopLevelClass(String typeName) {
/*  49 */     this(new FullyQualifiedJavaType(typeName));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Set<FullyQualifiedJavaType> getImportedTypes()
/*     */   {
/*  56 */     return Collections.unmodifiableSet(this.importedTypes);
/*     */   }
/*     */   
/*     */   public void addImportedType(String importedType) {
/*  60 */     addImportedType(new FullyQualifiedJavaType(importedType));
/*     */   }
/*     */   
/*     */   public void addImportedType(FullyQualifiedJavaType importedType) {
/*  64 */     if ((importedType != null) && 
/*  65 */       (importedType.isExplicitlyImported()) && 
/*  66 */       (!importedType.getPackageName().equals(
/*  67 */       getType().getPackageName()))) {
/*  68 */       this.importedTypes.add(importedType);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getFormattedContent() {
/*  73 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  75 */     for (String fileCommentLine : this.fileCommentLines) {
/*  76 */       sb.append(fileCommentLine);
/*  77 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/*  80 */     if (StringUtility.stringHasValue(getType().getPackageName())) {
/*  81 */       sb.append("package ");
/*  82 */       sb.append(getType().getPackageName());
/*  83 */       sb.append(';');
/*  84 */       OutputUtilities.newLine(sb);
/*  85 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/*  88 */     for (String staticImport : this.staticImports) {
/*  89 */       sb.append("import static ");
/*  90 */       sb.append(staticImport);
/*  91 */       sb.append(';');
/*  92 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/*  95 */     if (this.staticImports.size() > 0) {
/*  96 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/*  99 */     Set<String> importStrings = OutputUtilities.calculateImports(this.importedTypes);
/* 100 */     for (String importString : importStrings) {
/* 101 */       sb.append(importString);
/* 102 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/* 105 */     if (importStrings.size() > 0) {
/* 106 */       OutputUtilities.newLine(sb);
/*     */     }
/*     */     
/* 109 */     sb.append(super.getFormattedContent(0));
/*     */     
/* 111 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public boolean isJavaInterface() {
/* 115 */     return false;
/*     */   }
/*     */   
/*     */   public boolean isJavaEnumeration() {
/* 119 */     return false;
/*     */   }
/*     */   
/*     */   public void addFileCommentLine(String commentLine) {
/* 123 */     this.fileCommentLines.add(commentLine);
/*     */   }
/*     */   
/*     */   public List<String> getFileCommentLines() {
/* 127 */     return this.fileCommentLines;
/*     */   }
/*     */   
/*     */   public void addImportedTypes(Set<FullyQualifiedJavaType> importedTypes) {
/* 131 */     this.importedTypes.addAll(importedTypes);
/*     */   }
/*     */   
/*     */   public Set<String> getStaticImports() {
/* 135 */     return this.staticImports;
/*     */   }
/*     */   
/*     */   public void addStaticImport(String staticImport) {
/* 139 */     this.staticImports.add(staticImport);
/*     */   }
/*     */   
/*     */   public void addStaticImports(Set<String> staticImports) {
/* 143 */     this.staticImports.addAll(staticImports);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\java\TopLevelClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */