/*    */ package org.mybatis.generator.api.dom.xml;
/*    */ 
/*    */ import org.mybatis.generator.api.dom.OutputUtilities;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextElement
/*    */   extends Element
/*    */ {
/*    */   private String content;
/*    */   
/*    */   public TextElement(String content)
/*    */   {
/* 31 */     this.content = content;
/*    */   }
/*    */   
/*    */   public String getFormattedContent(int indentLevel)
/*    */   {
/* 36 */     StringBuilder sb = new StringBuilder();
/* 37 */     OutputUtilities.xmlIndent(sb, indentLevel);
/* 38 */     sb.append(this.content);
/* 39 */     return sb.toString();
/*    */   }
/*    */   
/*    */   public String getContent() {
/* 43 */     return this.content;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\xml\TextElement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */