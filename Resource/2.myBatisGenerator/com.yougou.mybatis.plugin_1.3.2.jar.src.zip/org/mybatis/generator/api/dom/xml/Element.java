package org.mybatis.generator.api.dom.xml;

public abstract class Element
{
  public abstract String getFormattedContent(int paramInt);
}


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\dom\xml\Element.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */