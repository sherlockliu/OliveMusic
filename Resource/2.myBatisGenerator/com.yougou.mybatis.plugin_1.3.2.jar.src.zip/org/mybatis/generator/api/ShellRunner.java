/*     */ package org.mybatis.generator.api;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.mybatis.generator.config.Configuration;
/*     */ import org.mybatis.generator.config.xml.ConfigurationParser;
/*     */ import org.mybatis.generator.exception.InvalidConfigurationException;
/*     */ import org.mybatis.generator.exception.XMLParserException;
/*     */ import org.mybatis.generator.internal.DefaultShellCallback;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ import org.mybatis.generator.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ShellRunner
/*     */ {
/*     */   private static final String CONFIG_FILE = "-configfile";
/*     */   private static final String OVERWRITE = "-overwrite";
/*     */   private static final String CONTEXT_IDS = "-contextids";
/*     */   private static final String TABLES = "-tables";
/*     */   private static final String VERBOSE = "-verbose";
/*     */   private static final String FORCE_JAVA_LOGGING = "-forceJavaLogging";
/*     */   private static final String HELP_1 = "-?";
/*     */   private static final String HELP_2 = "-h";
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/*  54 */     if (args.length == 0) {
/*  55 */       usage();
/*  56 */       System.exit(0);
/*  57 */       return;
/*     */     }
/*     */     
/*  60 */     Map<String, String> arguments = parseCommandLine(args);
/*     */     
/*  62 */     if (arguments.containsKey("-?")) {
/*  63 */       usage();
/*  64 */       System.exit(0);
/*  65 */       return;
/*     */     }
/*     */     
/*  68 */     if (!arguments.containsKey("-configfile")) {
/*  69 */       writeLine(Messages.getString("RuntimeError.0"));
/*  70 */       return;
/*     */     }
/*     */     
/*  73 */     List<String> warnings = new ArrayList();
/*     */     
/*  75 */     String configfile = (String)arguments.get("-configfile");
/*  76 */     File configurationFile = new File(configfile);
/*  77 */     if (!configurationFile.exists()) {
/*  78 */       writeLine(Messages.getString("RuntimeError.1", configfile));
/*  79 */       return;
/*     */     }
/*     */     
/*  82 */     Set<String> fullyqualifiedTables = new HashSet();
/*  83 */     if (arguments.containsKey("-tables")) {
/*  84 */       StringTokenizer st = new StringTokenizer((String)arguments.get("-tables"), ",");
/*  85 */       while (st.hasMoreTokens()) {
/*  86 */         String s = st.nextToken().trim();
/*  87 */         if (s.length() > 0) {
/*  88 */           fullyqualifiedTables.add(s);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  93 */     Set<String> contexts = new HashSet();
/*  94 */     if (arguments.containsKey("-contextids")) {
/*  95 */       StringTokenizer st = new StringTokenizer(
/*  96 */         (String)arguments.get("-contextids"), ",");
/*  97 */       while (st.hasMoreTokens()) {
/*  98 */         String s = st.nextToken().trim();
/*  99 */         if (s.length() > 0) {
/* 100 */           contexts.add(s);
/*     */         }
/*     */       }
/*     */     }
/*     */     String error;
/*     */     try {
/* 106 */       ConfigurationParser cp = new ConfigurationParser(warnings);
/* 107 */       Configuration config = cp.parseConfiguration(configurationFile);
/*     */       
/* 109 */       shellCallback = new DefaultShellCallback(
/* 110 */         arguments.containsKey("-overwrite"));
/*     */       
/* 112 */       MyBatisGenerator myBatisGenerator = new MyBatisGenerator(config, shellCallback, warnings);
/*     */       
/* 114 */       ProgressCallback progressCallback = arguments.containsKey("-verbose") ? new VerboseProgressCallback() : 
/* 115 */         null;
/*     */       
/* 117 */       myBatisGenerator.generate(progressCallback, contexts, fullyqualifiedTables);
/*     */     }
/*     */     catch (XMLParserException e) {
/* 120 */       writeLine(Messages.getString("Progress.3"));
/* 121 */       writeLine();
/* 122 */       for (String error : e.getErrors()) {
/* 123 */         writeLine(error);
/*     */       }
/*     */       
/* 126 */       return;
/*     */     } catch (SQLException e) {
/* 128 */       e.printStackTrace();
/* 129 */       return;
/*     */     } catch (IOException e) {
/* 131 */       e.printStackTrace();
/* 132 */       return;
/*     */     } catch (InvalidConfigurationException e) {
/* 134 */       writeLine(Messages.getString("Progress.16"));
/* 135 */       for (DefaultShellCallback shellCallback = e.getErrors().iterator(); shellCallback.hasNext();) { error = (String)shellCallback.next();
/* 136 */         writeLine(error);
/*     */       }
/* 138 */       return;
/*     */     }
/*     */     catch (InterruptedException localInterruptedException) {}
/*     */     
/*     */ 
/*     */ 
/* 144 */     for (String warning : warnings) {
/* 145 */       writeLine(warning);
/*     */     }
/*     */     
/* 148 */     if (warnings.size() == 0) {
/* 149 */       writeLine(Messages.getString("Progress.4"));
/*     */     } else {
/* 151 */       writeLine();
/* 152 */       writeLine(Messages.getString("Progress.5"));
/*     */     }
/*     */   }
/*     */   
/*     */   private static void usage() {
/* 157 */     String lines = Messages.getString("Usage.Lines");
/* 158 */     int iLines = Integer.parseInt(lines);
/* 159 */     for (int i = 0; i < iLines; i++) {
/* 160 */       String key = "Usage." + i;
/* 161 */       writeLine(Messages.getString(key));
/*     */     }
/*     */   }
/*     */   
/*     */   private static void writeLine(String message) {
/* 166 */     System.out.println(message);
/*     */   }
/*     */   
/*     */   private static void writeLine() {
/* 170 */     System.out.println();
/*     */   }
/*     */   
/*     */   private static Map<String, String> parseCommandLine(String[] args) {
/* 174 */     List<String> errors = new ArrayList();
/* 175 */     Map<String, String> arguments = new HashMap();
/*     */     
/* 177 */     for (int i = 0; i < args.length; i++) {
/* 178 */       if ("-configfile".equalsIgnoreCase(args[i])) {
/* 179 */         if (i + 1 < args.length) {
/* 180 */           arguments.put("-configfile", args[(i + 1)]);
/*     */         } else {
/* 182 */           errors.add(Messages.getString(
/* 183 */             "RuntimeError.19", "-configfile"));
/*     */         }
/* 185 */         i++;
/* 186 */       } else if ("-overwrite".equalsIgnoreCase(args[i])) {
/* 187 */         arguments.put("-overwrite", "Y");
/* 188 */       } else if ("-verbose".equalsIgnoreCase(args[i])) {
/* 189 */         arguments.put("-verbose", "Y");
/* 190 */       } else if ("-?".equalsIgnoreCase(args[i])) {
/* 191 */         arguments.put("-?", "Y");
/* 192 */       } else if ("-h".equalsIgnoreCase(args[i]))
/*     */       {
/*     */ 
/* 195 */         arguments.put("-?", "Y");
/* 196 */       } else if ("-forceJavaLogging".equalsIgnoreCase(args[i])) {
/* 197 */         LogFactory.forceJavaLogging();
/* 198 */       } else if ("-contextids".equalsIgnoreCase(args[i])) {
/* 199 */         if (i + 1 < args.length) {
/* 200 */           arguments.put("-contextids", args[(i + 1)]);
/*     */         } else {
/* 202 */           errors.add(Messages.getString(
/* 203 */             "RuntimeError.19", "-contextids"));
/*     */         }
/* 205 */         i++;
/* 206 */       } else if ("-tables".equalsIgnoreCase(args[i])) {
/* 207 */         if (i + 1 < args.length) {
/* 208 */           arguments.put("-tables", args[(i + 1)]);
/*     */         } else {
/* 210 */           errors.add(Messages.getString("RuntimeError.19", "-tables"));
/*     */         }
/* 212 */         i++;
/*     */       } else {
/* 214 */         errors.add(Messages.getString("RuntimeError.20", args[i]));
/*     */       }
/*     */     }
/*     */     
/* 218 */     if (!errors.isEmpty()) {
/* 219 */       for (String error : errors) {
/* 220 */         writeLine(error);
/*     */       }
/*     */       
/* 223 */       System.exit(-1);
/*     */     }
/*     */     
/* 226 */     return arguments;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\ShellRunner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */