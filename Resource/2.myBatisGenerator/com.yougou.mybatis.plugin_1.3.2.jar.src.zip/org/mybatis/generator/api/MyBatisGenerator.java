/*     */ package org.mybatis.generator.api;
/*     */ 
/*     */ import com.yougou.mybatis.plugins.MybatisConfigAddElement;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jface.dialogs.MessageDialog;
/*     */ import org.eclipse.swt.widgets.Display;
/*     */ import org.eclipse.swt.widgets.Shell;
/*     */ import org.mybatis.generator.config.Configuration;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.MergeConstants;
/*     */ import org.mybatis.generator.config.YouGouSqlMapConfigConfiguration;
/*     */ import org.mybatis.generator.exception.InvalidConfigurationException;
/*     */ import org.mybatis.generator.exception.ShellException;
/*     */ import org.mybatis.generator.internal.DefaultShellCallback;
/*     */ import org.mybatis.generator.internal.NullProgressCallback;
/*     */ import org.mybatis.generator.internal.ObjectFactory;
/*     */ import org.mybatis.generator.internal.XmlFileMergerJaxp;
/*     */ import org.mybatis.generator.internal.util.ClassloaderUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MyBatisGenerator
/*     */ {
/*     */   private Configuration configuration;
/*     */   private ShellCallback shellCallback;
/*     */   private List<GeneratedJavaFile> generatedJavaFiles;
/*     */   private List<GeneratedXmlFile> generatedXmlFiles;
/*     */   private List<String> warnings;
/*     */   private Set<String> projects;
/*     */   
/*     */   public MyBatisGenerator(Configuration configuration, ShellCallback shellCallback, List<String> warnings)
/*     */     throws InvalidConfigurationException
/*     */   {
/* 100 */     if (configuration == null) {
/* 101 */       throw new IllegalArgumentException(Messages.getString("RuntimeError.2"));
/*     */     }
/* 103 */     this.configuration = configuration;
/*     */     
/*     */ 
/* 106 */     if (shellCallback == null) {
/* 107 */       this.shellCallback = new DefaultShellCallback(true);
/*     */     } else {
/* 109 */       this.shellCallback = shellCallback;
/*     */     }
/*     */     
/* 112 */     if (warnings == null) {
/* 113 */       this.warnings = new ArrayList();
/*     */     } else {
/* 115 */       this.warnings = warnings;
/*     */     }
/* 117 */     this.generatedJavaFiles = new ArrayList();
/* 118 */     this.generatedXmlFiles = new ArrayList();
/* 119 */     this.projects = new HashSet();
/*     */     
/* 121 */     this.configuration.validate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void generate(ProgressCallback callback)
/*     */     throws SQLException, IOException, InterruptedException
/*     */   {
/* 140 */     generate(callback, null, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void generate(ProgressCallback callback, Set<String> contextIds)
/*     */     throws SQLException, IOException, InterruptedException
/*     */   {
/* 163 */     generate(callback, contextIds, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void generate(ProgressCallback callback, Set<String> contextIds, Set<String> fullyQualifiedTableNames)
/*     */     throws SQLException, IOException, InterruptedException
/*     */   {
/* 195 */     if (callback == null) {
/* 196 */       callback = new NullProgressCallback();
/*     */     }
/*     */     
/* 199 */     this.generatedJavaFiles.clear();
/* 200 */     this.generatedXmlFiles.clear();
/*     */     
/*     */     List<Context> contextsToRun;
/*     */     List<Context> contextsToRun;
/* 204 */     if ((contextIds == null) || (contextIds.size() == 0)) {
/* 205 */       contextsToRun = this.configuration.getContexts();
/*     */     } else {
/* 207 */       contextsToRun = new ArrayList();
/* 208 */       for (Context context : this.configuration.getContexts()) {
/* 209 */         if (contextIds.contains(context.getId())) {
/* 210 */           contextsToRun.add(context);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 216 */     if (this.configuration.getClassPathEntries().size() > 0) {
/* 217 */       ClassLoader classLoader = ClassloaderUtility.getCustomClassloader(this.configuration.getClassPathEntries());
/* 218 */       ObjectFactory.addExternalClassLoader(classLoader);
/*     */     }
/*     */     
/*     */ 
/* 222 */     int totalSteps = 0;
/* 223 */     for (Context context : contextsToRun) {
/* 224 */       totalSteps += context.getIntrospectionSteps();
/*     */     }
/* 226 */     callback.introspectionStarted(totalSteps);
/*     */     
/* 228 */     for (Context context : contextsToRun) {
/* 229 */       context.introspectTables(callback, this.warnings, 
/* 230 */         fullyQualifiedTableNames);
/*     */     }
/*     */     
/*     */ 
/* 234 */     totalSteps = 0;
/* 235 */     for (Context context : contextsToRun) {
/* 236 */       totalSteps += context.getGenerationSteps();
/*     */     }
/* 238 */     callback.generationStarted(totalSteps);
/*     */     
/* 240 */     for (Context context : contextsToRun) {
/* 241 */       context.generateFiles(callback, this.generatedJavaFiles, 
/* 242 */         this.generatedXmlFiles, this.warnings);
/*     */     }
/*     */     
/*     */ 
/* 246 */     callback.saveStarted(this.generatedXmlFiles.size() + 
/* 247 */       this.generatedJavaFiles.size());
/*     */     
/* 249 */     Shell shell = new Shell(new Display(), 16793600);
/* 250 */     for (GeneratedXmlFile gxf : this.generatedXmlFiles) {
/* 251 */       this.projects.add(gxf.getTargetProject());
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 256 */         File directory = this.shellCallback.getDirectory(gxf
/* 257 */           .getTargetProject(), gxf.getTargetPackage());
/* 258 */         File targetFile = new File(directory, gxf.getFileName());
/*     */         String source;
/* 260 */         if (targetFile.exists())
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 266 */           boolean flag = MessageDialog.openConfirm(shell, "确认", "是否覆盖" + targetFile.getName() + "文件");
/* 267 */           if (!flag) continue;
/*     */           String source;
/* 269 */           if (gxf.isMergeable()) {
/* 270 */             source = XmlFileMergerJaxp.getMergedSource(gxf, 
/* 271 */               targetFile); } else { String source;
/* 272 */             if (this.shellCallback.isOverwriteEnabled()) {
/* 273 */               source = gxf.getFormattedContent();
/*     */             }
/*     */             else
/*     */             {
/* 277 */               String source = gxf.getFormattedContent();
/* 278 */               targetFile = getUniqueFileName(directory, gxf
/* 279 */                 .getFileName());
/*     */             }
/*     */           }
/*     */         }
/*     */         else {
/* 284 */           source = gxf.getFormattedContent();
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 292 */           YouGouSqlMapConfigConfiguration sqlconfig = Context.getYouGouSqlMapConfigConfiguration();
/* 293 */           if (sqlconfig != null)
/*     */           {
/*     */             File configTargetFile;
/*     */             try {
/* 297 */               File configDirectory = this.shellCallback.getDirectory(sqlconfig.getTargetProject(), sqlconfig.getTargetPackage());
/* 298 */               configTargetFile = new File(configDirectory, sqlconfig.getConfileFileName());
/*     */             } catch (Exception localException1) { File configTargetFile;
/* 300 */               File configDirectory = this.shellCallback.getDirectory(sqlconfig.getTargetProject(), "");
/* 301 */               configTargetFile = new File(configDirectory, sqlconfig.getTargetPackage() + "/" + sqlconfig.getConfileFileName());
/*     */             }
/*     */             
/* 304 */             if (configTargetFile.exists()) {
/* 305 */               MybatisConfigAddElement.appendGeneratorXml(configTargetFile.getAbsolutePath(), sqlconfig.getConfileFilePackagePath(), gxf.getFileName());
/*     */             }
/*     */           }
/*     */         } catch (Exception e) {
/* 309 */           this.warnings.add(e.getMessage());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 316 */         callback.checkCancel();
/*     */       }
/*     */       catch (ShellException e)
/*     */       {
/* 312 */         this.warnings.add(e.getMessage());
/*     */       }
/*     */       
/*     */       String source;
/*     */       File targetFile;
/* 317 */       callback.startTask(Messages.getString(
/* 318 */         "Progress.15", targetFile.getName()));
/* 319 */       writeFile(targetFile, source, "UTF-8");
/*     */     }
/*     */     
/* 322 */     for (GeneratedJavaFile gjf : this.generatedJavaFiles) {
/* 323 */       this.projects.add(gjf.getTargetProject());
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 328 */         File directory = this.shellCallback.getDirectory(gjf
/* 329 */           .getTargetProject(), gjf.getTargetPackage());
/* 330 */         File targetFile = new File(directory, gjf.getFileName());
/*     */         String source;
/* 332 */         if (targetFile.exists())
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 338 */           boolean flag = MessageDialog.openConfirm(shell, "确认", "是否覆盖" + targetFile.getName() + "文件");
/* 339 */           if (!flag) continue;
/*     */           String source;
/* 341 */           if (this.shellCallback.isMergeSupported()) {
/* 342 */             source = this.shellCallback.mergeJavaFile(gjf
/* 343 */               .getFormattedContent(), targetFile
/* 344 */               .getAbsolutePath(), 
/* 345 */               MergeConstants.OLD_ELEMENT_TAGS, 
/* 346 */               gjf.getFileEncoding()); } else { String source;
/* 347 */             if (this.shellCallback.isOverwriteEnabled()) {
/* 348 */               source = gjf.getFormattedContent();
/*     */             }
/*     */             else
/*     */             {
/* 352 */               String source = gjf.getFormattedContent();
/* 353 */               targetFile = getUniqueFileName(directory, gjf
/* 354 */                 .getFileName());
/*     */             }
/*     */           }
/*     */         }
/*     */         else {
/* 359 */           source = gjf.getFormattedContent();
/*     */         }
/*     */         
/* 362 */         callback.checkCancel();
/* 363 */         callback.startTask(Messages.getString(
/* 364 */           "Progress.15", targetFile.getName()));
/* 365 */         writeFile(targetFile, source, gjf.getFileEncoding());
/*     */       } catch (ShellException e) {
/* 367 */         this.warnings.add(e.getMessage());
/*     */       }
/*     */     }
/*     */     
/* 371 */     for (String project : this.projects) {
/* 372 */       this.shellCallback.refreshProject(project);
/*     */     }
/*     */     
/* 375 */     callback.done();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeFile(File file, String content, String fileEncoding)
/*     */     throws IOException
/*     */   {
/* 385 */     FileOutputStream fos = new FileOutputStream(file, false);
/*     */     OutputStreamWriter osw;
/* 387 */     OutputStreamWriter osw; if (fileEncoding == null) {
/* 388 */       osw = new OutputStreamWriter(fos);
/*     */     } else {
/* 390 */       osw = new OutputStreamWriter(fos, fileEncoding);
/*     */     }
/*     */     
/* 393 */     BufferedWriter bw = new BufferedWriter(osw);
/* 394 */     bw.write(content);
/* 395 */     bw.close();
/*     */   }
/*     */   
/*     */   private File getUniqueFileName(File directory, String fileName) {
/* 399 */     File answer = null;
/*     */     
/*     */ 
/* 402 */     StringBuilder sb = new StringBuilder();
/* 403 */     for (int i = 1; i < 1000; i++) {
/* 404 */       sb.setLength(0);
/* 405 */       sb.append(fileName);
/* 406 */       sb.append('.');
/* 407 */       sb.append(i);
/*     */       
/* 409 */       File testFile = new File(directory, sb.toString());
/* 410 */       if (!testFile.exists()) {
/* 411 */         answer = testFile;
/* 412 */         break;
/*     */       }
/*     */     }
/*     */     
/* 416 */     if (answer == null) {
/* 417 */       throw new RuntimeException(Messages.getString(
/* 418 */         "RuntimeError.3", directory.getAbsolutePath()));
/*     */     }
/*     */     
/* 421 */     return answer;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\api\MyBatisGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */