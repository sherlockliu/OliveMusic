/*     */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.GeneratedKey;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InsertSelectiveElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  40 */     XmlElement answer = new XmlElement("insert");
/*     */     
/*  42 */     answer.addAttribute(new Attribute(
/*  43 */       "id", this.introspectedTable.getInsertSelectiveStatementId()));
/*     */     
/*  45 */     FullyQualifiedJavaType parameterType = this.introspectedTable.getRules()
/*  46 */       .calculateAllFieldsClass();
/*     */     
/*  48 */     answer.addAttribute(new Attribute("parameterType", 
/*  49 */       parameterType.getFullyQualifiedName()));
/*     */     
/*  51 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  53 */     GeneratedKey gk = this.introspectedTable.getGeneratedKey();
/*  54 */     if (gk != null) {
/*  55 */       IntrospectedColumn introspectedColumn = this.introspectedTable
/*  56 */         .getColumn(gk.getColumn());
/*     */       
/*     */ 
/*  59 */       if (introspectedColumn != null) {
/*  60 */         if (gk.isJdbcStandard()) {
/*  61 */           answer.addAttribute(new Attribute("useGeneratedKeys", "true"));
/*  62 */           answer.addAttribute(new Attribute("keyProperty", introspectedColumn.getJavaProperty()));
/*     */         } else {
/*  64 */           answer.addElement(getSelectKey(introspectedColumn, gk));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  69 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  71 */     sb.append("INSERT INTO ");
/*  72 */     sb.append(this.introspectedTable.getFullyQualifiedTableNameAtRuntime());
/*  73 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*  75 */     XmlElement insertTrimElement = new XmlElement("trim");
/*  76 */     insertTrimElement.addAttribute(new Attribute("prefix", "("));
/*  77 */     insertTrimElement.addAttribute(new Attribute("suffix", ")"));
/*  78 */     insertTrimElement.addAttribute(new Attribute("suffixOverrides", ","));
/*  79 */     answer.addElement(insertTrimElement);
/*     */     
/*  81 */     XmlElement valuesTrimElement = new XmlElement("trim");
/*  82 */     valuesTrimElement.addAttribute(new Attribute("prefix", "values ("));
/*  83 */     valuesTrimElement.addAttribute(new Attribute("suffix", ")"));
/*  84 */     valuesTrimElement.addAttribute(new Attribute("suffixOverrides", ","));
/*  85 */     answer.addElement(valuesTrimElement);
/*     */     
/*     */ 
/*  88 */     Iterator localIterator = this.introspectedTable.getAllColumns().iterator();
/*  87 */     while (localIterator.hasNext()) {
/*  88 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*  89 */       if (!introspectedColumn.isIdentity())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*  94 */         if ((introspectedColumn.isSequenceColumn()) || 
/*  95 */           (introspectedColumn.getFullyQualifiedJavaType().isPrimitive()))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */           sb.setLength(0);
/* 102 */           sb.append(
/* 103 */             MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn));
/* 104 */           sb.append(',');
/* 105 */           insertTrimElement.addElement(new TextElement(sb.toString()));
/*     */           
/* 107 */           sb.setLength(0);
/* 108 */           sb.append(
/* 109 */             MyBatis3FormattingUtilities.getParameterClause(introspectedColumn));
/* 110 */           sb.append(',');
/* 111 */           valuesTrimElement.addElement(new TextElement(sb.toString()));
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 116 */           XmlElement insertNotNullElement = new XmlElement("if");
/* 117 */           sb.setLength(0);
/* 118 */           sb.append(introspectedColumn.getJavaProperty());
/* 119 */           sb.append(" != null");
/* 120 */           insertNotNullElement.addAttribute(new Attribute(
/* 121 */             "test", sb.toString()));
/*     */           
/* 123 */           sb.setLength(0);
/* 124 */           sb.append(
/* 125 */             MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn));
/* 126 */           sb.append(',');
/* 127 */           insertNotNullElement.addElement(new TextElement(sb.toString()));
/* 128 */           insertTrimElement.addElement(insertNotNullElement);
/*     */           
/* 130 */           XmlElement valuesNotNullElement = new XmlElement("if");
/* 131 */           sb.setLength(0);
/* 132 */           sb.append(introspectedColumn.getJavaProperty());
/* 133 */           sb.append(" != null");
/* 134 */           valuesNotNullElement.addAttribute(new Attribute(
/* 135 */             "test", sb.toString()));
/*     */           
/* 137 */           sb.setLength(0);
/* 138 */           sb.append(
/* 139 */             MyBatis3FormattingUtilities.getParameterClause(introspectedColumn));
/* 140 */           sb.append(',');
/* 141 */           valuesNotNullElement.addElement(new TextElement(sb.toString()));
/* 142 */           valuesTrimElement.addElement(valuesNotNullElement);
/*     */         } }
/*     */     }
/* 145 */     if (this.context.getPlugins().sqlMapInsertSelectiveElementGenerated(
/* 146 */       answer, this.introspectedTable)) {
/* 147 */       parentElement.addElement(answer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\InsertSelectiveElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */