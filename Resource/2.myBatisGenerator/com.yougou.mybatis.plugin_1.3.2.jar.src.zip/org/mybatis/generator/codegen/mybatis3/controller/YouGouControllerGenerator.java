/*     */ package org.mybatis.generator.codegen.mybatis3.controller;
/*     */ 
/*     */ import com.yougou.mybatis.plugins.CodeLayoutEnum;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.YouGouControllerGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.YouGouManagerGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.YouGouServiceGeneratorConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YouGouControllerGenerator
/*     */   extends AbstractJavaGenerator
/*     */ {
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  33 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/*     */ 
/*  36 */     YouGouServiceGeneratorConfiguration serviceConfig = this.context.getYouGouServiceGeneratorConfiguration();
/*  37 */     YouGouManagerGeneratorConfiguration managerConfig = this.context.getYouGouManagerGeneratorConfiguration();
/*  38 */     YouGouControllerGeneratorConfiguration contrllerConfig = this.context.getYouGouControllerGeneratorConfiguration();
/*  39 */     String modelName = this.introspectedTable.getFullyQualifiedTable().getDomainObjectName();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  44 */     TopLevelClass c = new TopLevelClass(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaControllerType()));
/*  45 */     c.addImportedType(new FullyQualifiedJavaType("javax.annotation.Resource"));
/*  46 */     c.addImportedType(new FullyQualifiedJavaType("org.springframework.stereotype.Controller"));
/*  47 */     c.addImportedType(new FullyQualifiedJavaType("org.springframework.web.bind.annotation.RequestMapping"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */     Boolean flag = (Boolean)Context.getCodingLayer().get(CodeLayoutEnum.MANAGER_LAYOUT);
/*  54 */     if ((flag != null) && (flag.booleanValue())) {
/*  55 */       c.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaManagerType()));
/*  56 */       if (contrllerConfig.getExtendSupClassDoMain().length() > 0) {
/*  57 */         c.addImportedType(new FullyQualifiedJavaType(contrllerConfig.getExtendSupClass()));
/*  58 */         if (new Boolean(contrllerConfig.getEnableSupClassGenericity()).booleanValue()) {
/*  59 */           c.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getBaseRecordType()));
/*  60 */           c.setSuperClass(new FullyQualifiedJavaType(contrllerConfig.getExtendSupClassDoMain() + "<" + modelName + ">"));
/*     */         } else {
/*  62 */           c.setSuperClass(new FullyQualifiedJavaType(contrllerConfig.getExtendSupClassDoMain()));
/*     */         }
/*     */       }
/*     */     } else {
/*  66 */       c.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaServiceType()));
/*  67 */       if (contrllerConfig.getExtendSupClassDoMainFor3Layer().length() > 0) {
/*  68 */         c.addImportedType(new FullyQualifiedJavaType(contrllerConfig.getExtendSupClassFor3Layer()));
/*  69 */         if (new Boolean(contrllerConfig.getEnableSupClassGenericity()).booleanValue()) {
/*  70 */           c.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getBaseRecordType()));
/*  71 */           c.setSuperClass(new FullyQualifiedJavaType(contrllerConfig.getExtendSupClassDoMainFor3Layer() + "<" + modelName + ">"));
/*     */         } else {
/*  73 */           c.setSuperClass(new FullyQualifiedJavaType(contrllerConfig.getExtendSupClassDoMainFor3Layer()));
/*     */         }
/*     */       }
/*     */     }
/*  77 */     c.setVisibility(JavaVisibility.PUBLIC);
/*     */     
/*     */ 
/*     */ 
/*  81 */     Field field = new Field();
/*  82 */     field.addAnnotation("@Resource");
/*  83 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  84 */     String fieldName = "";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */     if ((flag != null) && (flag.booleanValue())) {
/*  92 */       field.setType(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaManagerType()));
/*  93 */       fieldName = firstCharToLower(this.introspectedTable.getMyBatis3JavaManagerType().substring(this.introspectedTable.getMyBatis3JavaManagerType().lastIndexOf(".") + 1));
/*     */     } else {
/*  95 */       field.setType(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaServiceType()));
/*  96 */       fieldName = firstCharToLower(this.introspectedTable.getMyBatis3JavaServiceType().substring(this.introspectedTable.getMyBatis3JavaServiceType().lastIndexOf(".") + 1));
/*     */     }
/*  98 */     field.setName(fieldName);
/*  99 */     c.addField(field);
/*     */     
/* 101 */     c.addAnnotation("@Controller");
/*     */     
/* 103 */     String controllerName = this.introspectedTable.getMyBatis3JavaControllerInstanceName();
/* 104 */     c.addAnnotation("@RequestMapping(\"/" + controllerName + "\")");
/*     */     
/* 106 */     Method method = new Method();
/* 107 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 108 */     method.addAnnotation("@Override");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */     if ((flag != null) && (flag.booleanValue())) {
/* 119 */       method.setReturnType(new FullyQualifiedJavaType(managerConfig.getInterFaceExtendSupInterfaceDoMain()));
/*     */     } else {
/* 121 */       method.setReturnType(new FullyQualifiedJavaType(serviceConfig.getInterFaceExtendSupInterfaceDoMain()));
/*     */     }
/*     */     
/* 124 */     method.setName("init");
/* 125 */     method.setReturnType(new FullyQualifiedJavaType("CrudInfo"));
/*     */     
/* 127 */     method.addBodyLine("return new CrudInfo(\"" + controllerName + "/\"," + fieldName + ");");
/* 128 */     c.addMethod(method);
/*     */     
/* 130 */     commentGenerator.addClassComment(c);
/*     */     
/* 132 */     List<CompilationUnit> answer = new ArrayList();
/* 133 */     answer.add(c);
/* 134 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String firstCharToLower(String modelName)
/*     */   {
/* 143 */     if (modelName.length() > 0) {
/* 144 */       modelName = new StringBuilder(String.valueOf(modelName.charAt(0))).toString().toLowerCase() + modelName.substring(1);
/*     */     } else {
/* 146 */       modelName = modelName.charAt(0).toLowerCase();
/*     */     }
/* 148 */     return modelName;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\controller\YouGouControllerGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */