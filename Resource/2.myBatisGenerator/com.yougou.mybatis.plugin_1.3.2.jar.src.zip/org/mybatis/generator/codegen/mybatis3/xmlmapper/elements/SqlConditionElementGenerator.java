/*    */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*    */ 
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.TextElement;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ import org.mybatis.generator.config.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SqlConditionElementGenerator
/*    */   extends AbstractXmlElementGenerator
/*    */ {
/*    */   public void addElements(XmlElement parentElement)
/*    */   {
/* 36 */     XmlElement answer = new XmlElement("sql");
/*    */     
/* 38 */     answer.addAttribute(new Attribute("id", "condition"));
/*    */     
/* 40 */     StringBuilder sb = new StringBuilder();
/*    */     
/*    */ 
/* 43 */     XmlElement conditionElement = new XmlElement("if");
/* 44 */     sb.append("null!=params");
/* 45 */     conditionElement.addAttribute(new Attribute(
/* 46 */       "test", sb.toString()));
/*    */     
/* 48 */     XmlElement conditionElement1 = new XmlElement("if");
/* 49 */     sb.setLength(0);
/* 50 */     sb.append("null!=params.queryCondition and ''!=params.queryCondition");
/* 51 */     conditionElement1.addAttribute(new Attribute(
/* 52 */       "test", sb.toString()));
/* 53 */     sb.setLength(0);
/* 54 */     sb.append("${params.queryCondition}");
/* 55 */     conditionElement1.addElement(new TextElement(sb.toString()));
/*    */     
/* 57 */     conditionElement.addElement(conditionElement1);
/*    */     
/* 59 */     answer.addElement(conditionElement);
/*    */     
/* 61 */     parentElement.addElement(answer);
/* 62 */     this.context.getCommentGenerator().addComment(answer);
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\SqlConditionElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */