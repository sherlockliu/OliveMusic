/*    */ package org.mybatis.generator.codegen.mybatis3.javamapper.elements;
/*    */ 
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*    */ import org.mybatis.generator.api.dom.java.Interface;
/*    */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*    */ import org.mybatis.generator.api.dom.java.Method;
/*    */ import org.mybatis.generator.config.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectCountMethodGenerator
/*    */   extends AbstractJavaMapperMethodGenerator
/*    */ {
/*    */   public void addInterfaceElements(Interface interfaze)
/*    */   {
/* 38 */     Method method = new Method();
/* 39 */     method.setVisibility(JavaVisibility.PUBLIC);
/*    */     
/*    */ 
/* 42 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*    */     
/* 44 */     method.setName(this.introspectedTable.getSelectCount());
/*    */     
/* 46 */     addMapperAnnotations(interfaze, method);
/*    */     
/* 48 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 49 */       this.introspectedTable);
/*    */     
/* 51 */     if (this.context.getPlugins().clientSelectCountMethodGenerated(
/* 52 */       method, interfaze, this.introspectedTable)) {
/* 53 */       interfaze.addMethod(method);
/*    */     }
/*    */   }
/*    */   
/*    */   public void addMapperAnnotations(Interface interfaze, Method method) {}
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\elements\SelectCountMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */