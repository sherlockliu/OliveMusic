/*     */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectByPrimaryKeyElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  40 */     XmlElement answer = new XmlElement("select");
/*     */     
/*  42 */     answer.addAttribute(new Attribute(
/*  43 */       "id", this.introspectedTable.getSelectByPrimaryKeyStatementId()));
/*  44 */     if (this.introspectedTable.getRules().generateResultMapWithBLOBs()) {
/*  45 */       answer.addAttribute(new Attribute("resultMap", 
/*  46 */         this.introspectedTable.getResultMapWithBLOBsId()));
/*     */     } else {
/*  48 */       answer.addAttribute(new Attribute("resultMap", 
/*  49 */         this.introspectedTable.getBaseResultMapId()));
/*     */     }
/*     */     String parameterType;
/*     */     String parameterType;
/*  53 */     if (this.introspectedTable.getRules().generatePrimaryKeyClass()) {
/*  54 */       parameterType = this.introspectedTable.getPrimaryKeyType();
/*     */     }
/*     */     else {
/*     */       String parameterType;
/*  58 */       if (this.introspectedTable.getPrimaryKeyColumns().size() > 1) {
/*  59 */         parameterType = "map";
/*     */       } else {
/*  61 */         parameterType = 
/*  62 */           ((IntrospectedColumn)this.introspectedTable.getPrimaryKeyColumns().get(0)).getFullyQualifiedJavaType().toString();
/*     */       }
/*     */     }
/*     */     
/*  66 */     answer.addAttribute(new Attribute("parameterType", 
/*  67 */       parameterType));
/*     */     
/*  69 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  71 */     StringBuilder sb = new StringBuilder();
/*  72 */     sb.append("SELECT ");
/*     */     
/*  74 */     if (StringUtility.stringHasValue(this.introspectedTable
/*  75 */       .getSelectByPrimaryKeyQueryId())) {
/*  76 */       sb.append('\'');
/*  77 */       sb.append(this.introspectedTable.getSelectByPrimaryKeyQueryId());
/*  78 */       sb.append("' as QUERYID,");
/*     */     }
/*  80 */     answer.addElement(new TextElement(sb.toString()));
/*  81 */     answer.addElement(getBaseColumnListElement());
/*  82 */     if (this.introspectedTable.hasBLOBColumns()) {
/*  83 */       answer.addElement(new TextElement(","));
/*  84 */       answer.addElement(getBlobColumnListElement());
/*     */     }
/*     */     
/*  87 */     sb.setLength(0);
/*  88 */     sb.append("FROM ");
/*  89 */     sb.append(this.introspectedTable
/*  90 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/*  91 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*  93 */     boolean and = false;
/*     */     
/*  95 */     Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/*  94 */     while (localIterator.hasNext()) {
/*  95 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*  96 */       sb.setLength(0);
/*  97 */       if (and) {
/*  98 */         sb.append("  AND ");
/*     */       } else {
/* 100 */         sb.append("WHERE ");
/* 101 */         and = true;
/*     */       }
/*     */       
/* 104 */       sb.append(
/* 105 */         MyBatis3FormattingUtilities.getAliasedEscapedColumnName(introspectedColumn));
/* 106 */       sb.append(" = ");
/* 107 */       sb.append(
/* 108 */         MyBatis3FormattingUtilities.getParameterClause(introspectedColumn));
/* 109 */       answer.addElement(new TextElement(sb.toString()));
/*     */     }
/*     */     
/*     */ 
/* 113 */     if (this.context.getPlugins().sqlMapSelectByPrimaryKeyElementGenerated(answer, 
/* 114 */       this.introspectedTable)) {
/* 115 */       parentElement.addElement(answer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\SelectByPrimaryKeyElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */