/*     */ package org.mybatis.generator.codegen.mybatis3.javamapper;
/*     */ 
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.codegen.AbstractXmlGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.AbstractJavaMapperMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedCountByExampleMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedDeleteByExampleMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedDeleteByPrimaryKeyMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedInsertMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedInsertSelectiveMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedSelectByExampleWithBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedSelectByExampleWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedSelectByPrimaryKeyMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedUpdateByExampleWithBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedUpdateByExampleWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedUpdateByPrimaryKeySelectiveMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedUpdateByPrimaryKeyWithBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedUpdateByPrimaryKeyWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ public class AnnotatedClientGenerator extends JavaMapperGenerator
/*     */ {
/*     */   public AnnotatedClientGenerator()
/*     */   {
/*  27 */     super(false);
/*     */   }
/*     */   
/*     */   protected void addCountByExampleMethod(Interface interfaze)
/*     */   {
/*  32 */     if (this.introspectedTable.getRules().generateCountByExample()) {
/*  33 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedCountByExampleMethodGenerator();
/*  34 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addDeleteByExampleMethod(Interface interfaze)
/*     */   {
/*  40 */     if (this.introspectedTable.getRules().generateDeleteByExample()) {
/*  41 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedDeleteByExampleMethodGenerator();
/*  42 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addDeleteByPrimaryKeyMethod(Interface interfaze)
/*     */   {
/*  48 */     if (this.introspectedTable.getRules().generateDeleteByPrimaryKey()) {
/*  49 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedDeleteByPrimaryKeyMethodGenerator(false);
/*  50 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertMethod(Interface interfaze)
/*     */   {
/*  56 */     if (this.introspectedTable.getRules().generateInsert()) {
/*  57 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedInsertMethodGenerator(false);
/*  58 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertSelectiveMethod(Interface interfaze)
/*     */   {
/*  64 */     if (this.introspectedTable.getRules().generateInsertSelective()) {
/*  65 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedInsertSelectiveMethodGenerator();
/*  66 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByExampleWithBLOBsMethod(Interface interfaze)
/*     */   {
/*  72 */     if (this.introspectedTable.getRules().generateSelectByExampleWithBLOBs()) {
/*  73 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedSelectByExampleWithBLOBsMethodGenerator();
/*  74 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByExampleWithoutBLOBsMethod(Interface interfaze)
/*     */   {
/*  80 */     if (this.introspectedTable.getRules().generateSelectByExampleWithoutBLOBs()) {
/*  81 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedSelectByExampleWithoutBLOBsMethodGenerator();
/*  82 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByPrimaryKeyMethod(Interface interfaze)
/*     */   {
/*  88 */     if (this.introspectedTable.getRules().generateSelectByPrimaryKey()) {
/*  89 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedSelectByPrimaryKeyMethodGenerator(false, false);
/*  90 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleSelectiveMethod(Interface interfaze)
/*     */   {
/*  96 */     if (this.introspectedTable.getRules().generateUpdateByExampleSelective()) {
/*  97 */       AbstractJavaMapperMethodGenerator methodGenerator = new org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedUpdateByExampleSelectiveMethodGenerator();
/*  98 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleWithBLOBsMethod(Interface interfaze)
/*     */   {
/* 104 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithBLOBs()) {
/* 105 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedUpdateByExampleWithBLOBsMethodGenerator();
/* 106 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleWithoutBLOBsMethod(Interface interfaze)
/*     */   {
/* 112 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithoutBLOBs()) {
/* 113 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedUpdateByExampleWithoutBLOBsMethodGenerator();
/* 114 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeySelectiveMethod(Interface interfaze)
/*     */   {
/* 120 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeySelective()) {
/* 121 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedUpdateByPrimaryKeySelectiveMethodGenerator();
/* 122 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeyWithBLOBsMethod(Interface interfaze)
/*     */   {
/* 128 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeyWithBLOBs()) {
/* 129 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedUpdateByPrimaryKeyWithBLOBsMethodGenerator();
/* 130 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addUpdateByPrimaryKeyWithoutBLOBsMethod(Interface interfaze)
/*     */   {
/* 137 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeyWithoutBLOBs()) {
/* 138 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedUpdateByPrimaryKeyWithoutBLOBsMethodGenerator(false);
/* 139 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   public java.util.List<CompilationUnit> getExtraCompilationUnits()
/*     */   {
/* 145 */     SqlProviderGenerator sqlProviderGenerator = new SqlProviderGenerator();
/* 146 */     sqlProviderGenerator.setContext(this.context);
/* 147 */     sqlProviderGenerator.setIntrospectedTable(this.introspectedTable);
/* 148 */     sqlProviderGenerator.setProgressCallback(this.progressCallback);
/* 149 */     sqlProviderGenerator.setWarnings(this.warnings);
/* 150 */     return sqlProviderGenerator.getCompilationUnits();
/*     */   }
/*     */   
/*     */ 
/*     */   public AbstractXmlGenerator getMatchedXMLGenerator()
/*     */   {
/* 156 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\AnnotatedClientGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */