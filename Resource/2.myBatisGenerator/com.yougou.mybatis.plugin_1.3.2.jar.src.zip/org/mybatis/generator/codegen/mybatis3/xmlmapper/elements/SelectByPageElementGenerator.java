/*     */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*     */ 
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.enums.DbmsTypeEnum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectByPageElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  37 */     String dbmsTypeStr = this.context.getDbmsType();
/*  38 */     DbmsTypeEnum dbmsTypeEnums = DbmsTypeEnum.valueOf(dbmsTypeStr.toUpperCase());
/*  39 */     switch (dbmsTypeEnums) {
/*     */     case ORACLE: 
/*  41 */       getOraclePageElement(parentElement);
/*  42 */       break;
/*     */     case MYSQL: 
/*  44 */       getMysqlPageElement(parentElement);
/*  45 */       break;
/*     */     case POSTGRESQL: 
/*  47 */       getPGPageElement(parentElement);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void getOraclePageElement(XmlElement parentElement)
/*     */   {
/*  57 */     XmlElement answer = new XmlElement("select");
/*     */     
/*  59 */     answer.addAttribute(new Attribute(
/*  60 */       "id", "selectByPage"));
/*  61 */     answer.addAttribute(new Attribute("resultMap", 
/*  62 */       this.introspectedTable.getBaseResultMapId()));
/*     */     
/*  64 */     answer.addAttribute(new Attribute("parameterType", 
/*  65 */       "map"));
/*     */     
/*  67 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  69 */     StringBuilder sb = new StringBuilder();
/*  70 */     sb.append("SELECT B.* from (SELECT A.*,ROWNUM rn FROM( ");
/*     */     
/*  72 */     sb.append("SELECT ");
/*     */     
/*  74 */     answer.addElement(new TextElement(sb.toString()));
/*  75 */     answer.addElement(getBaseColumnListElement());
/*  76 */     if (this.introspectedTable.hasBLOBColumns()) {
/*  77 */       answer.addElement(new TextElement(","));
/*  78 */       answer.addElement(getBlobColumnListElement());
/*     */     }
/*     */     
/*  81 */     sb.setLength(0);
/*  82 */     sb.append(" FROM ");
/*  83 */     sb.append(this.introspectedTable
/*  84 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/*  85 */     sb.append(" WHERE 1=1 ");
/*  86 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     XmlElement sqlElement = new XmlElement("include");
/*  94 */     sqlElement.addAttribute(new Attribute("refid", "condition"));
/*  95 */     answer.addElement(sqlElement);
/*     */     
/*  97 */     XmlElement orderByElement = new XmlElement("if");
/*  98 */     sb.setLength(0);
/*  99 */     sb.append("orderByField");
/* 100 */     sb.append(" != null and ");
/* 101 */     sb.append("''!=orderByField");
/* 102 */     orderByElement.addAttribute(new Attribute(
/* 103 */       "test", sb.toString()));
/* 104 */     sb.setLength(0);
/* 105 */     sb.append("ORDER BY ${orderByField}");
/* 106 */     orderByElement.addElement(new TextElement(sb.toString()));
/*     */     
/* 108 */     XmlElement orderByConditionElement = new XmlElement("if");
/* 109 */     sb.setLength(0);
/* 110 */     sb.append("orderByField");
/* 111 */     orderByConditionElement.addAttribute(new Attribute("test", sb.toString()));
/* 112 */     sb.setLength(0);
/* 113 */     sb.append("${orderBy}");
/* 114 */     orderByConditionElement.addElement(new TextElement(sb.toString()));
/* 115 */     orderByElement.addElement(orderByConditionElement);
/* 116 */     answer.addElement(orderByElement);
/*     */     
/* 118 */     sb.setLength(0);
/* 119 */     sb.append(") A WHERE ROWNUM &lt; #{page.endRowNum}");
/* 120 */     sb.append(") B WHERE rn &gt; #{page.startRowNum}");
/* 121 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*     */ 
/*     */ 
/* 125 */     parentElement.addElement(answer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void getMysqlPageElement(XmlElement parentElement)
/*     */   {
/* 133 */     XmlElement answer = new XmlElement("select");
/*     */     
/* 135 */     answer.addAttribute(new Attribute(
/* 136 */       "id", "selectByPage"));
/* 137 */     answer.addAttribute(new Attribute("resultMap", 
/* 138 */       this.introspectedTable.getBaseResultMapId()));
/*     */     
/* 140 */     answer.addAttribute(new Attribute("parameterType", 
/* 141 */       "map"));
/*     */     
/* 143 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/* 145 */     StringBuilder sb = new StringBuilder();
/*     */     
/*     */ 
/* 148 */     sb.append("SELECT ");
/*     */     
/* 150 */     answer.addElement(new TextElement(sb.toString()));
/* 151 */     answer.addElement(getBaseColumnListElement());
/* 152 */     if (this.introspectedTable.hasBLOBColumns()) {
/* 153 */       answer.addElement(new TextElement(","));
/* 154 */       answer.addElement(getBlobColumnListElement());
/*     */     }
/*     */     
/* 157 */     sb.setLength(0);
/* 158 */     sb.append(" FROM ");
/* 159 */     sb.append(this.introspectedTable
/* 160 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/* 161 */     sb.append(" WHERE 1=1 ");
/* 162 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */     XmlElement sqlElement = new XmlElement("include");
/* 170 */     sqlElement.addAttribute(new Attribute("refid", "condition"));
/* 171 */     answer.addElement(sqlElement);
/*     */     
/* 173 */     XmlElement orderByElement = new XmlElement("if");
/* 174 */     sb.setLength(0);
/* 175 */     sb.append("orderByField");
/* 176 */     sb.append(" != null and ");
/* 177 */     sb.append("''!=orderByField");
/* 178 */     orderByElement.addAttribute(new Attribute(
/* 179 */       "test", sb.toString()));
/* 180 */     sb.setLength(0);
/* 181 */     sb.append("ORDER BY ${orderByField}");
/* 182 */     orderByElement.addElement(new TextElement(sb.toString()));
/*     */     
/* 184 */     XmlElement orderByConditionElement = new XmlElement("if");
/* 185 */     sb.setLength(0);
/* 186 */     sb.append("orderByField");
/* 187 */     orderByConditionElement.addAttribute(new Attribute("test", sb.toString()));
/* 188 */     sb.setLength(0);
/* 189 */     sb.append("${orderBy}");
/* 190 */     orderByConditionElement.addElement(new TextElement(sb.toString()));
/* 191 */     orderByElement.addElement(orderByConditionElement);
/* 192 */     answer.addElement(orderByElement);
/*     */     
/* 194 */     sb.setLength(0);
/* 195 */     sb.append(" LIMIT #{page.startRowNum} ,#{page.pageSize} ");
/*     */     
/*     */ 
/* 198 */     answer.addElement(new TextElement(sb.toString()));
/* 199 */     parentElement.addElement(answer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void getPGPageElement(XmlElement parentElement)
/*     */   {
/* 207 */     XmlElement answer = new XmlElement("select");
/*     */     
/* 209 */     answer.addAttribute(new Attribute(
/* 210 */       "id", "selectByPage"));
/* 211 */     answer.addAttribute(new Attribute("resultMap", 
/* 212 */       this.introspectedTable.getBaseResultMapId()));
/*     */     
/* 214 */     answer.addAttribute(new Attribute("parameterType", 
/* 215 */       "map"));
/*     */     
/* 217 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/* 219 */     StringBuilder sb = new StringBuilder();
/*     */     
/*     */ 
/* 222 */     sb.append("SELECT ");
/*     */     
/* 224 */     answer.addElement(new TextElement(sb.toString()));
/* 225 */     answer.addElement(getBaseColumnListElement());
/* 226 */     if (this.introspectedTable.hasBLOBColumns()) {
/* 227 */       answer.addElement(new TextElement(","));
/* 228 */       answer.addElement(getBlobColumnListElement());
/*     */     }
/*     */     
/* 231 */     sb.setLength(0);
/* 232 */     sb.append(" FROM ");
/* 233 */     sb.append(this.introspectedTable
/* 234 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/*     */     
/* 236 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/* 238 */     XmlElement whereElement = new XmlElement("where");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 244 */     XmlElement sqlElement = new XmlElement("include");
/* 245 */     sqlElement.addAttribute(new Attribute("refid", "condition"));
/* 246 */     whereElement.addElement(sqlElement);
/* 247 */     answer.addElement(whereElement);
/*     */     
/* 249 */     XmlElement orderByElement = new XmlElement("if");
/* 250 */     sb.setLength(0);
/* 251 */     sb.append("orderByField");
/* 252 */     sb.append(" != null and ");
/* 253 */     sb.append("''!=orderByField");
/* 254 */     orderByElement.addAttribute(new Attribute(
/* 255 */       "test", sb.toString()));
/* 256 */     sb.setLength(0);
/* 257 */     sb.append("ORDER BY ${orderByField}");
/* 258 */     orderByElement.addElement(new TextElement(sb.toString()));
/*     */     
/* 260 */     XmlElement orderByConditionElement = new XmlElement("if");
/* 261 */     sb.setLength(0);
/* 262 */     sb.append("orderByField");
/* 263 */     orderByConditionElement.addAttribute(new Attribute("test", sb.toString()));
/* 264 */     sb.setLength(0);
/* 265 */     sb.append("${orderBy}");
/* 266 */     orderByConditionElement.addElement(new TextElement(sb.toString()));
/* 267 */     orderByElement.addElement(orderByConditionElement);
/* 268 */     answer.addElement(orderByElement);
/*     */     
/* 270 */     sb.setLength(0);
/* 271 */     sb.append(" LIMIT #{page.pageSize} OFFSET #{page.startRowNum} ");
/*     */     
/*     */ 
/* 274 */     answer.addElement(new TextElement(sb.toString()));
/* 275 */     parentElement.addElement(answer);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\SelectByPageElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */