/*     */ package org.mybatis.generator.codegen.mybatis3.manager;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.YouGouManagerGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.YouGouServiceGeneratorConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YouGouManagerGenerator
/*     */   extends AbstractJavaGenerator
/*     */ {
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  30 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/*  32 */     FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/*  33 */       this.introspectedTable.getMyBatis3JavaManagerType());
/*  34 */     Interface interfaze = new Interface(type);
/*  35 */     interfaze.setVisibility(JavaVisibility.PUBLIC);
/*     */     
/*     */ 
/*     */ 
/*  39 */     YouGouServiceGeneratorConfiguration serviceConfig = this.context.getYouGouServiceGeneratorConfiguration();
/*  40 */     YouGouManagerGeneratorConfiguration managerConfig = this.context.getYouGouManagerGeneratorConfiguration();
/*     */     
/*  42 */     String modelName = this.introspectedTable.getFullyQualifiedTable().getDomainObjectName();
/*  43 */     if (managerConfig.getInterFaceExtendSupInterfaceDoMain().length() > 0)
/*     */     {
/*  45 */       interfaze.addImportedType(new FullyQualifiedJavaType(managerConfig.getInterfaceExtendSupInterface()));
/*  46 */       String base = managerConfig.getInterFaceExtendSupInterfaceDoMain();
/*  47 */       interfaze.addImportedType(new FullyQualifiedJavaType(managerConfig.getInterfaceExtendSupInterface()));
/*  48 */       if (new Boolean(managerConfig.getEnableInterfaceSupInterfaceGenericity()).booleanValue()) {
/*  49 */         interfaze.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getBaseRecordType()));
/*  50 */         interfaze.addSuperInterface(new FullyQualifiedJavaType(base + "<" + modelName + ">"));
/*     */       } else {
/*  52 */         interfaze.addSuperInterface(new FullyQualifiedJavaType(base));
/*     */       }
/*  54 */       commentGenerator.addClassComment(interfaze);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  59 */     TopLevelClass c = new TopLevelClass(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaManagerImplType()));
/*  60 */     c.addImportedType(new FullyQualifiedJavaType("javax.annotation.Resource"));
/*  61 */     c.addImportedType(new FullyQualifiedJavaType("org.springframework.stereotype.Service"));
/*  62 */     c.addImportedType(new FullyQualifiedJavaType(managerConfig.getExtendSupClass()));
/*  63 */     c.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaManagerType()));
/*  64 */     c.addImportedType(new FullyQualifiedJavaType(serviceConfig.getInterfaceExtendSupInterface()));
/*  65 */     c.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaServiceType()));
/*  66 */     if ((serviceConfig.getInterfaceExtendSupInterface() != null) && (serviceConfig.getInterfaceExtendSupInterface().length() > 0)) {
/*  67 */       c.addImportedType(new FullyQualifiedJavaType(serviceConfig.getInterfaceExtendSupInterface()));
/*     */     }
/*     */     
/*  70 */     if (managerConfig.getInterFaceExtendSupInterfaceDoMain().length() > 0) {
/*  71 */       String ServiceName = firstCharToLower(this.introspectedTable.getMyBatis3JavaManagerType().substring(this.introspectedTable.getMyBatis3JavaManagerType().lastIndexOf(".") + 1));
/*  72 */       c.addAnnotation("@Service(\"" + ServiceName + "\")");
/*  73 */       if (new Boolean(managerConfig.getEnableSupClassGenericity()).booleanValue()) {
/*  74 */         c.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getBaseRecordType()));
/*  75 */         c.setSuperClass(new FullyQualifiedJavaType(managerConfig.getExtendSupClassDoMain() + "<" + modelName + ">"));
/*     */       } else {
/*  77 */         c.setSuperClass(new FullyQualifiedJavaType(managerConfig.getExtendSupClassDoMain()));
/*     */       }
/*  79 */       c.addSuperInterface(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaManagerType()));
/*     */     }
/*     */     
/*  82 */     Field field = new Field();
/*  83 */     field.addAnnotation("@Resource");
/*  84 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  85 */     field.setType(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaServiceType()));
/*  86 */     String fieldName = firstCharToLower(this.introspectedTable.getMyBatis3JavaServiceType().substring(this.introspectedTable.getMyBatis3JavaServiceType().lastIndexOf(".") + 1));
/*  87 */     field.setName(fieldName);
/*  88 */     c.addField(field);
/*     */     
/*     */ 
/*  91 */     Method method = new Method();
/*  92 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  93 */     method.addAnnotation("@Override");
/*  94 */     if (new Boolean(managerConfig.getEnableSupClassGenericity()).booleanValue()) {
/*  95 */       method.setReturnType(new FullyQualifiedJavaType(serviceConfig.getInterFaceExtendSupInterfaceDoMain() + "<" + modelName + ">"));
/*     */     } else {
/*  97 */       method.setReturnType(new FullyQualifiedJavaType(serviceConfig.getInterFaceExtendSupInterfaceDoMain()));
/*     */     }
/*  99 */     method.setName("init");
/* 100 */     method.addBodyLine("return " + fieldName + ";");
/* 101 */     c.addMethod(method);
/*     */     
/* 103 */     commentGenerator.addClassComment(c);
/*     */     
/* 105 */     List<CompilationUnit> answer = new ArrayList();
/* 106 */     answer.add(interfaze);
/* 107 */     answer.add(c);
/* 108 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String firstCharToLower(String modelName)
/*     */   {
/* 117 */     if (modelName.length() > 0) {
/* 118 */       modelName = new StringBuilder(String.valueOf(modelName.charAt(0))).toString().toLowerCase() + modelName.substring(1);
/*     */     } else {
/* 120 */       modelName = modelName.charAt(0).toLowerCase();
/*     */     }
/* 122 */     return modelName;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\manager\YouGouManagerGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */