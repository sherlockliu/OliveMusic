/*     */ package org.mybatis.generator.codegen.mybatis3;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.GeneratedJavaFile;
/*     */ import org.mybatis.generator.api.GeneratedXmlFile;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable.TargetRuntime;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.xml.Document;
/*     */ import org.mybatis.generator.codegen.AbstractGenerator;
/*     */ import org.mybatis.generator.codegen.AbstractJavaClientGenerator;
/*     */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*     */ import org.mybatis.generator.codegen.AbstractXmlGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.controller.YouGouControllerGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.AnnotatedClientGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.JavaMapperGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.MixedClientGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.manager.YouGouManagerGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.model.BaseRecordGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.model.ExampleGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.model.PrimaryKeyGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.model.RecordWithBLOBsGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.serivce.YouGouServiceGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.XMLMapperGenerator;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.JavaModelGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.SqlMapGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.YouGouControllerGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.YouGouManagerGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.YouGouServiceGeneratorConfiguration;
/*     */ import org.mybatis.generator.internal.ObjectFactory;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntrospectedTableMyBatis3Impl
/*     */   extends IntrospectedTable
/*     */ {
/*     */   protected List<AbstractJavaGenerator> javaModelGenerators;
/*     */   protected List<AbstractJavaGenerator> serviceGenerators;
/*     */   protected List<AbstractJavaGenerator> managerGenerators;
/*     */   protected List<AbstractJavaGenerator> controllerGenerators;
/*     */   protected List<AbstractJavaGenerator> clientGenerators;
/*     */   protected AbstractXmlGenerator xmlMapperGenerator;
/*     */   
/*     */   public IntrospectedTableMyBatis3Impl()
/*     */   {
/*  63 */     super(IntrospectedTable.TargetRuntime.MYBATIS3);
/*  64 */     this.javaModelGenerators = new ArrayList();
/*  65 */     this.clientGenerators = new ArrayList();
/*  66 */     this.serviceGenerators = new ArrayList();
/*  67 */     this.managerGenerators = new ArrayList();
/*  68 */     this.controllerGenerators = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */   public void calculateGenerators(List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/*  74 */     calculateJavaModelGenerators(warnings, progressCallback);
/*     */     
/*  76 */     AbstractJavaClientGenerator javaClientGenerator = 
/*  77 */       calculateClientGenerators(warnings, progressCallback);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */     if (this.context.getYouGouServiceGeneratorConfiguration() != null) {
/*  85 */       calculateServiceGenerators(warnings, progressCallback);
/*     */     }
/*  87 */     if (this.context.getYouGouManagerGeneratorConfiguration() != null) {
/*  88 */       calculateManagerGenerators(warnings, progressCallback);
/*     */     }
/*  90 */     if (this.context.getYouGouControllerGeneratorConfiguration() != null) {
/*  91 */       calculateControllerGenerators(warnings, progressCallback);
/*     */     }
/*     */     
/*     */ 
/*  95 */     calculateXmlMapperGenerator(javaClientGenerator, warnings, progressCallback);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void calculateXmlMapperGenerator(AbstractJavaClientGenerator javaClientGenerator, List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/* 101 */     if (javaClientGenerator == null) {
/* 102 */       if (this.context.getSqlMapGeneratorConfiguration() != null) {
/* 103 */         this.xmlMapperGenerator = new XMLMapperGenerator();
/*     */       }
/*     */     } else {
/* 106 */       this.xmlMapperGenerator = javaClientGenerator.getMatchedXMLGenerator();
/*     */     }
/*     */     
/* 109 */     initializeAbstractGenerator(this.xmlMapperGenerator, warnings, 
/* 110 */       progressCallback);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractJavaClientGenerator calculateClientGenerators(List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/* 121 */     if (!this.rules.generateJavaClient()) {
/* 122 */       return null;
/*     */     }
/*     */     
/* 125 */     AbstractJavaClientGenerator javaGenerator = createJavaClientGenerator();
/* 126 */     if (javaGenerator == null) {
/* 127 */       return null;
/*     */     }
/*     */     
/* 130 */     initializeAbstractGenerator(javaGenerator, warnings, progressCallback);
/* 131 */     this.clientGenerators.add(javaGenerator);
/*     */     
/* 133 */     return javaGenerator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void calculateServiceGenerators(List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/* 145 */     AbstractJavaGenerator javaGenerator = new YouGouServiceGenerator();
/* 146 */     initializeAbstractGenerator(javaGenerator, warnings, 
/* 147 */       progressCallback);
/* 148 */     this.serviceGenerators.add(javaGenerator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void calculateManagerGenerators(List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/* 159 */     AbstractJavaGenerator javaGenerator = new YouGouManagerGenerator();
/* 160 */     initializeAbstractGenerator(javaGenerator, warnings, 
/* 161 */       progressCallback);
/* 162 */     this.managerGenerators.add(javaGenerator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void calculateControllerGenerators(List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/* 173 */     AbstractJavaGenerator javaGenerator = new YouGouControllerGenerator();
/* 174 */     initializeAbstractGenerator(javaGenerator, warnings, 
/* 175 */       progressCallback);
/* 176 */     this.controllerGenerators.add(javaGenerator);
/*     */   }
/*     */   
/* 179 */   protected AbstractJavaClientGenerator createJavaClientGenerator() { if (this.context.getJavaClientGeneratorConfiguration() == null) {
/* 180 */       return null;
/*     */     }
/*     */     
/* 183 */     String type = this.context.getJavaClientGeneratorConfiguration()
/* 184 */       .getConfigurationType();
/*     */     AbstractJavaClientGenerator javaGenerator;
/*     */     AbstractJavaClientGenerator javaGenerator;
/* 187 */     if ("XMLMAPPER".equalsIgnoreCase(type)) {
/* 188 */       javaGenerator = new JavaMapperGenerator(); } else { AbstractJavaClientGenerator javaGenerator;
/* 189 */       if ("MIXEDMAPPER".equalsIgnoreCase(type)) {
/* 190 */         javaGenerator = new MixedClientGenerator(); } else { AbstractJavaClientGenerator javaGenerator;
/* 191 */         if ("ANNOTATEDMAPPER".equalsIgnoreCase(type)) {
/* 192 */           javaGenerator = new AnnotatedClientGenerator(); } else { AbstractJavaClientGenerator javaGenerator;
/* 193 */           if ("MAPPER".equalsIgnoreCase(type)) {
/* 194 */             javaGenerator = new JavaMapperGenerator();
/*     */           } else
/* 196 */             javaGenerator = (AbstractJavaClientGenerator)
/* 197 */               ObjectFactory.createInternalObject(type);
/*     */         }
/*     */       } }
/* 200 */     return javaGenerator;
/*     */   }
/*     */   
/*     */   protected void calculateJavaModelGenerators(List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/* 205 */     if (getRules().generateExampleClass()) {
/* 206 */       AbstractJavaGenerator javaGenerator = new ExampleGenerator();
/* 207 */       initializeAbstractGenerator(javaGenerator, warnings, 
/* 208 */         progressCallback);
/* 209 */       this.javaModelGenerators.add(javaGenerator);
/*     */     }
/*     */     
/* 212 */     if (getRules().generatePrimaryKeyClass()) {
/* 213 */       AbstractJavaGenerator javaGenerator = new PrimaryKeyGenerator();
/* 214 */       initializeAbstractGenerator(javaGenerator, warnings, 
/* 215 */         progressCallback);
/* 216 */       this.javaModelGenerators.add(javaGenerator);
/*     */     }
/*     */     
/* 219 */     if (getRules().generateBaseRecordClass()) {
/* 220 */       AbstractJavaGenerator javaGenerator = new BaseRecordGenerator();
/* 221 */       initializeAbstractGenerator(javaGenerator, warnings, 
/* 222 */         progressCallback);
/* 223 */       this.javaModelGenerators.add(javaGenerator);
/*     */     }
/*     */     
/* 226 */     if (getRules().generateRecordWithBLOBsClass()) {
/* 227 */       AbstractJavaGenerator javaGenerator = new RecordWithBLOBsGenerator();
/* 228 */       initializeAbstractGenerator(javaGenerator, warnings, 
/* 229 */         progressCallback);
/* 230 */       this.javaModelGenerators.add(javaGenerator);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initializeAbstractGenerator(AbstractGenerator abstractGenerator, List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/* 237 */     if (abstractGenerator == null) {
/* 238 */       return;
/*     */     }
/*     */     
/* 241 */     abstractGenerator.setContext(this.context);
/* 242 */     abstractGenerator.setIntrospectedTable(this);
/* 243 */     abstractGenerator.setProgressCallback(progressCallback);
/* 244 */     abstractGenerator.setWarnings(warnings);
/*     */   }
/*     */   
/*     */   public List<GeneratedJavaFile> getGeneratedJavaFiles()
/*     */   {
/* 249 */     List<GeneratedJavaFile> answer = new ArrayList();
/*     */     Iterator localIterator2;
/* 251 */     for (Iterator localIterator1 = this.javaModelGenerators.iterator(); localIterator1.hasNext(); 
/*     */         
/*     */ 
/* 254 */         localIterator2.hasNext())
/*     */     {
/* 251 */       AbstractJavaGenerator javaGenerator = (AbstractJavaGenerator)localIterator1.next();
/* 252 */       List<CompilationUnit> compilationUnits = javaGenerator
/* 253 */         .getCompilationUnits();
/* 254 */       localIterator2 = compilationUnits.iterator(); continue;CompilationUnit compilationUnit = (CompilationUnit)localIterator2.next();
/* 255 */       GeneratedJavaFile gjf = new GeneratedJavaFile(compilationUnit, 
/* 256 */         this.context.getJavaModelGeneratorConfiguration()
/* 257 */         .getTargetProject(), 
/* 258 */         this.context.getProperty("javaFileEncoding"), 
/* 259 */         this.context.getJavaFormatter());
/* 260 */       answer.add(gjf);
/*     */     }
/*     */     
/*     */ 
/* 264 */     for (localIterator1 = this.clientGenerators.iterator(); localIterator1.hasNext(); 
/*     */         
/*     */ 
/* 267 */         localIterator2.hasNext())
/*     */     {
/* 264 */       AbstractJavaGenerator javaGenerator = (AbstractJavaGenerator)localIterator1.next();
/* 265 */       List<CompilationUnit> compilationUnits = javaGenerator
/* 266 */         .getCompilationUnits();
/* 267 */       localIterator2 = compilationUnits.iterator(); continue;CompilationUnit compilationUnit = (CompilationUnit)localIterator2.next();
/* 268 */       GeneratedJavaFile gjf = new GeneratedJavaFile(compilationUnit, 
/* 269 */         this.context.getJavaClientGeneratorConfiguration()
/* 270 */         .getTargetProject(), 
/* 271 */         this.context.getProperty("javaFileEncoding"), 
/* 272 */         this.context.getJavaFormatter());
/* 273 */       answer.add(gjf);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 282 */     for (localIterator1 = this.serviceGenerators.iterator(); localIterator1.hasNext(); 
/*     */         
/*     */ 
/* 285 */         localIterator2.hasNext())
/*     */     {
/* 282 */       AbstractJavaGenerator javaGenerator = (AbstractJavaGenerator)localIterator1.next();
/* 283 */       List<CompilationUnit> compilationUnits = javaGenerator
/* 284 */         .getCompilationUnits();
/* 285 */       localIterator2 = compilationUnits.iterator(); continue;CompilationUnit compilationUnit = (CompilationUnit)localIterator2.next();
/* 286 */       GeneratedJavaFile gjf = new GeneratedJavaFile(compilationUnit, 
/* 287 */         this.context.getYouGouServiceGeneratorConfiguration()
/* 288 */         .getTargetProject(), 
/* 289 */         this.context.getProperty("javaFileEncoding"), 
/* 290 */         this.context.getJavaFormatter());
/* 291 */       answer.add(gjf);
/*     */     }
/*     */     
/* 294 */     for (localIterator1 = this.managerGenerators.iterator(); localIterator1.hasNext(); 
/*     */         
/*     */ 
/* 297 */         localIterator2.hasNext())
/*     */     {
/* 294 */       AbstractJavaGenerator javaGenerator = (AbstractJavaGenerator)localIterator1.next();
/* 295 */       List<CompilationUnit> compilationUnits = javaGenerator
/* 296 */         .getCompilationUnits();
/* 297 */       localIterator2 = compilationUnits.iterator(); continue;CompilationUnit compilationUnit = (CompilationUnit)localIterator2.next();
/* 298 */       GeneratedJavaFile gjf = new GeneratedJavaFile(compilationUnit, 
/* 299 */         this.context.getYouGouManagerGeneratorConfiguration()
/* 300 */         .getTargetProject(), 
/* 301 */         this.context.getProperty("javaFileEncoding"), 
/* 302 */         this.context.getJavaFormatter());
/* 303 */       answer.add(gjf);
/*     */     }
/*     */     
/* 306 */     for (localIterator1 = this.controllerGenerators.iterator(); localIterator1.hasNext(); 
/*     */         
/*     */ 
/* 309 */         localIterator2.hasNext())
/*     */     {
/* 306 */       AbstractJavaGenerator javaGenerator = (AbstractJavaGenerator)localIterator1.next();
/* 307 */       List<CompilationUnit> compilationUnits = javaGenerator
/* 308 */         .getCompilationUnits();
/* 309 */       localIterator2 = compilationUnits.iterator(); continue;CompilationUnit compilationUnit = (CompilationUnit)localIterator2.next();
/* 310 */       GeneratedJavaFile gjf = new GeneratedJavaFile(compilationUnit, 
/* 311 */         this.context.getYouGouControllerGeneratorConfiguration()
/* 312 */         .getTargetProject(), 
/* 313 */         this.context.getProperty("javaFileEncoding"), 
/* 314 */         this.context.getJavaFormatter());
/* 315 */       answer.add(gjf);
/*     */     }
/*     */     
/*     */ 
/* 319 */     return answer;
/*     */   }
/*     */   
/*     */   public List<GeneratedXmlFile> getGeneratedXmlFiles()
/*     */   {
/* 324 */     List<GeneratedXmlFile> answer = new ArrayList();
/*     */     
/* 326 */     if (this.xmlMapperGenerator != null) {
/* 327 */       Document document = this.xmlMapperGenerator.getDocument();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 333 */       GeneratedXmlFile gxf = new GeneratedXmlFile(document, 
/* 334 */         getMyBatis3XmlMapperFileName(), getMyBatis3XmlMapperPackage(), 
/* 335 */         this.context.getSqlMapGeneratorConfiguration().getTargetProject(), 
/* 336 */         false, this.context.getXmlFormatter());
/* 337 */       if (this.context.getPlugins().sqlMapGenerated(gxf, this)) {
/* 338 */         answer.add(gxf);
/*     */       }
/*     */     }
/*     */     
/* 342 */     return answer;
/*     */   }
/*     */   
/*     */   public int getGenerationSteps()
/*     */   {
/* 347 */     return this.javaModelGenerators.size() + this.clientGenerators.size() + (
/* 348 */       this.xmlMapperGenerator == null ? 0 : 1);
/*     */   }
/*     */   
/*     */   public boolean isJava5Targeted()
/*     */   {
/* 353 */     return true;
/*     */   }
/*     */   
/*     */   public boolean requiresXMLGenerator()
/*     */   {
/* 358 */     AbstractJavaClientGenerator javaClientGenerator = 
/* 359 */       createJavaClientGenerator();
/*     */     
/* 361 */     if (javaClientGenerator == null) {
/* 362 */       return false;
/*     */     }
/* 364 */     return javaClientGenerator.requiresXMLGenerator();
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\IntrospectedTableMyBatis3Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */