/*     */ package org.mybatis.generator.codegen.mybatis3.xmlmapper;
/*     */ 
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.Document;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.AbstractXmlGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.AbstractXmlElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.BaseColumnListElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.BlobColumnListElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.CountByExampleElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.DeleteByExampleElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.DeleteByPrimarayKeyForModelElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.DeleteByPrimaryKeyElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.ExampleWhereClauseElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.InsertElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.InsertSelectiveElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.ResultMapWithBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.ResultMapWithoutBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.SelectByDataAuthorityElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.SelectByExampleWithBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.SelectByExampleWithoutBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.SelectByPageElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.SelectByParamsElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.SelectByPrimaryKeyElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.SelectCountElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.SqlConditionElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.UpdateByExampleSelectiveElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.UpdateByExampleWithBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.UpdateByExampleWithoutBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.UpdateByPrimaryKeySelectiveElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.UpdateByPrimaryKeyWithBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.UpdateByPrimaryKeyWithoutBLOBsElementGenerator;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLMapperGenerator
/*     */   extends AbstractXmlGenerator
/*     */ {
/*     */   protected XmlElement getSqlMapElement()
/*     */   {
/*  65 */     FullyQualifiedTable table = this.introspectedTable.getFullyQualifiedTable();
/*  66 */     this.progressCallback.startTask(Messages.getString(
/*  67 */       "Progress.12", table.toString()));
/*  68 */     XmlElement answer = new XmlElement("mapper");
/*  69 */     String namespace = this.introspectedTable.getMyBatis3SqlMapNamespace();
/*  70 */     answer.addAttribute(new Attribute("namespace", 
/*  71 */       namespace));
/*     */     
/*  73 */     this.context.getCommentGenerator().addRootComment(answer);
/*     */     
/*  75 */     addResultMapWithoutBLOBsElement(answer);
/*  76 */     addResultMapWithBLOBsElement(answer);
/*  77 */     addExampleWhereClauseElement(answer);
/*  78 */     addMyBatis3UpdateByExampleWhereClauseElement(answer);
/*  79 */     addBaseColumnListElement(answer);
/*     */     
/*     */ 
/*     */ 
/*  83 */     addSqlConditionElement(answer);
/*     */     
/*  85 */     addBlobColumnListElement(answer);
/*  86 */     addSelectByExampleWithBLOBsElement(answer);
/*  87 */     addSelectByExampleWithoutBLOBsElement(answer);
/*  88 */     addSelectByPrimaryKeyElement(answer);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */     addSelectCountElement(answer);
/*  95 */     addSelectByPageElement(answer);
/*  96 */     addSelectByParamsElement(answer);
/*     */     
/*     */ 
/*  99 */     addDeleteByPrimaryKeyElement(answer);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */     addDeleteByPrimarayKeyForModelElement(answer);
/*     */     
/* 107 */     addDeleteByExampleElement(answer);
/* 108 */     addInsertElement(answer);
/* 109 */     addInsertSelectiveElement(answer);
/* 110 */     addCountByExampleElement(answer);
/* 111 */     addUpdateByExampleSelectiveElement(answer);
/* 112 */     addUpdateByExampleWithBLOBsElement(answer);
/* 113 */     addUpdateByExampleWithoutBLOBsElement(answer);
/* 114 */     addUpdateByPrimaryKeySelectiveElement(answer);
/* 115 */     addUpdateByPrimaryKeyWithBLOBsElement(answer);
/* 116 */     addUpdateByPrimaryKeyWithoutBLOBsElement(answer);
/*     */     
/* 118 */     return answer;
/*     */   }
/*     */   
/*     */   protected void addResultMapWithoutBLOBsElement(XmlElement parentElement) {
/* 122 */     if (this.introspectedTable.getRules().generateBaseResultMap()) {
/* 123 */       AbstractXmlElementGenerator elementGenerator = new ResultMapWithoutBLOBsElementGenerator(false);
/* 124 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addResultMapWithBLOBsElement(XmlElement parentElement) {
/* 129 */     if (this.introspectedTable.getRules().generateResultMapWithBLOBs()) {
/* 130 */       AbstractXmlElementGenerator elementGenerator = new ResultMapWithBLOBsElementGenerator();
/* 131 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addExampleWhereClauseElement(XmlElement parentElement) {
/* 136 */     if (this.introspectedTable.getRules().generateSQLExampleWhereClause()) {
/* 137 */       AbstractXmlElementGenerator elementGenerator = new ExampleWhereClauseElementGenerator(
/* 138 */         false);
/* 139 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addMyBatis3UpdateByExampleWhereClauseElement(XmlElement parentElement)
/*     */   {
/* 146 */     if (this.introspectedTable.getRules().generateMyBatis3UpdateByExampleWhereClause()) {
/* 147 */       AbstractXmlElementGenerator elementGenerator = new ExampleWhereClauseElementGenerator(
/* 148 */         true);
/* 149 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addBaseColumnListElement(XmlElement parentElement) {
/* 154 */     if (this.introspectedTable.getRules().generateBaseColumnList()) {
/* 155 */       AbstractXmlElementGenerator elementGenerator = new BaseColumnListElementGenerator();
/* 156 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addBlobColumnListElement(XmlElement parentElement) {
/* 161 */     if (this.introspectedTable.getRules().generateBlobColumnList()) {
/* 162 */       AbstractXmlElementGenerator elementGenerator = new BlobColumnListElementGenerator();
/* 163 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByExampleWithoutBLOBsElement(XmlElement parentElement)
/*     */   {
/* 169 */     if (this.introspectedTable.getRules().generateSelectByExampleWithoutBLOBs()) {
/* 170 */       AbstractXmlElementGenerator elementGenerator = new SelectByExampleWithoutBLOBsElementGenerator();
/* 171 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByExampleWithBLOBsElement(XmlElement parentElement) {
/* 176 */     if (this.introspectedTable.getRules().generateSelectByExampleWithBLOBs()) {
/* 177 */       AbstractXmlElementGenerator elementGenerator = new SelectByExampleWithBLOBsElementGenerator();
/* 178 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByPrimaryKeyElement(XmlElement parentElement) {
/* 183 */     if (this.introspectedTable.getRules().generateSelectByPrimaryKey()) {
/* 184 */       AbstractXmlElementGenerator elementGenerator = new SelectByPrimaryKeyElementGenerator();
/* 185 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addSelectCountElement(XmlElement parentElement)
/*     */   {
/* 195 */     if (this.introspectedTable.getRules().generateSelectByPrimaryKey()) {
/* 196 */       AbstractXmlElementGenerator elementGenerator = new SelectCountElementGenerator();
/* 197 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addSelectByPageElement(XmlElement parentElement)
/*     */   {
/* 206 */     if (this.introspectedTable.getRules().generateSelectByPrimaryKey()) {
/* 207 */       AbstractXmlElementGenerator elementGenerator = new SelectByPageElementGenerator();
/* 208 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addSelectByParamsElement(XmlElement parentElement)
/*     */   {
/* 217 */     AbstractXmlElementGenerator elementGenerator = new SelectByParamsElementGenerator();
/* 218 */     initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addSelectByDataAuthorityElement(XmlElement parentElement)
/*     */   {
/* 226 */     SelectByDataAuthorityElementGenerator elementGenerator = new SelectByDataAuthorityElementGenerator();
/* 227 */     initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addSqlConditionElement(XmlElement parentElement)
/*     */   {
/* 235 */     AbstractXmlElementGenerator elementGenerator = new SqlConditionElementGenerator();
/* 236 */     initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */   }
/*     */   
/*     */   protected void addDeleteByExampleElement(XmlElement parentElement) {
/* 240 */     if (this.introspectedTable.getRules().generateDeleteByExample()) {
/* 241 */       AbstractXmlElementGenerator elementGenerator = new DeleteByExampleElementGenerator();
/* 242 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addDeleteByPrimaryKeyElement(XmlElement parentElement) {
/* 247 */     if (this.introspectedTable.getRules().generateDeleteByPrimaryKey()) {
/* 248 */       AbstractXmlElementGenerator elementGenerator = new DeleteByPrimaryKeyElementGenerator(false);
/* 249 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addDeleteByPrimarayKeyForModelElement(XmlElement parentElement)
/*     */   {
/* 259 */     if (this.introspectedTable.getRules().generateDeleteByPrimaryKey()) {
/* 260 */       AbstractXmlElementGenerator elementGenerator = new DeleteByPrimarayKeyForModelElementGenerator();
/* 261 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertElement(XmlElement parentElement) {
/* 266 */     if (this.introspectedTable.getRules().generateInsert()) {
/* 267 */       AbstractXmlElementGenerator elementGenerator = new InsertElementGenerator(false);
/* 268 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertSelectiveElement(XmlElement parentElement) {
/* 273 */     if (this.introspectedTable.getRules().generateInsertSelective()) {
/* 274 */       AbstractXmlElementGenerator elementGenerator = new InsertSelectiveElementGenerator();
/* 275 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addCountByExampleElement(XmlElement parentElement) {
/* 280 */     if (this.introspectedTable.getRules().generateCountByExample()) {
/* 281 */       AbstractXmlElementGenerator elementGenerator = new CountByExampleElementGenerator();
/* 282 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleSelectiveElement(XmlElement parentElement) {
/* 287 */     if (this.introspectedTable.getRules().generateUpdateByExampleSelective()) {
/* 288 */       AbstractXmlElementGenerator elementGenerator = new UpdateByExampleSelectiveElementGenerator();
/* 289 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleWithBLOBsElement(XmlElement parentElement) {
/* 294 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithBLOBs()) {
/* 295 */       AbstractXmlElementGenerator elementGenerator = new UpdateByExampleWithBLOBsElementGenerator();
/* 296 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleWithoutBLOBsElement(XmlElement parentElement)
/*     */   {
/* 302 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithoutBLOBs()) {
/* 303 */       AbstractXmlElementGenerator elementGenerator = new UpdateByExampleWithoutBLOBsElementGenerator();
/* 304 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeySelectiveElement(XmlElement parentElement)
/*     */   {
/* 310 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeySelective()) {
/* 311 */       AbstractXmlElementGenerator elementGenerator = new UpdateByPrimaryKeySelectiveElementGenerator();
/* 312 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeyWithBLOBsElement(XmlElement parentElement)
/*     */   {
/* 318 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeyWithBLOBs()) {
/* 319 */       AbstractXmlElementGenerator elementGenerator = new UpdateByPrimaryKeyWithBLOBsElementGenerator();
/* 320 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addUpdateByPrimaryKeyWithoutBLOBsElement(XmlElement parentElement)
/*     */   {
/* 327 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeyWithoutBLOBs()) {
/* 328 */       AbstractXmlElementGenerator elementGenerator = new UpdateByPrimaryKeyWithoutBLOBsElementGenerator(false);
/* 329 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initializeAndExecuteGenerator(AbstractXmlElementGenerator elementGenerator, XmlElement parentElement)
/*     */   {
/* 336 */     elementGenerator.setContext(this.context);
/* 337 */     elementGenerator.setIntrospectedTable(this.introspectedTable);
/* 338 */     elementGenerator.setProgressCallback(this.progressCallback);
/* 339 */     elementGenerator.setWarnings(this.warnings);
/* 340 */     elementGenerator.addElements(parentElement);
/*     */   }
/*     */   
/*     */   public Document getDocument()
/*     */   {
/* 345 */     Document document = new Document(
/* 346 */       "-//mybatis.org//DTD Mapper 3.0//EN", 
/* 347 */       "http://mybatis.org/dtd/mybatis-3-mapper.dtd");
/* 348 */     document.setRootElement(getSqlMapElement());
/*     */     
/* 350 */     if (!this.context.getPlugins().sqlMapDocumentGenerated(document, 
/* 351 */       this.introspectedTable)) {
/* 352 */       document = null;
/*     */     }
/*     */     
/* 355 */     return document;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\XMLMapperGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */