/*     */ package org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.OutputUtilities;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.UpdateByPrimaryKeyWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotatedUpdateByPrimaryKeyWithoutBLOBsMethodGenerator
/*     */   extends UpdateByPrimaryKeyWithoutBLOBsMethodGenerator
/*     */ {
/*     */   private boolean isSimple;
/*     */   
/*     */   public AnnotatedUpdateByPrimaryKeyWithoutBLOBsMethodGenerator(boolean isSimple)
/*     */   {
/*  42 */     this.isSimple = isSimple;
/*     */   }
/*     */   
/*     */   public void addMapperAnnotations(Interface interfaze, Method method)
/*     */   {
/*  47 */     interfaze.addImportedType(new FullyQualifiedJavaType("org.apache.ibatis.annotations.Update"));
/*     */     
/*  49 */     method.addAnnotation("@Update({");
/*     */     
/*  51 */     StringBuilder sb = new StringBuilder();
/*  52 */     OutputUtilities.javaIndent(sb, 1);
/*  53 */     sb.append("\"update ");
/*  54 */     sb.append(StringUtility.escapeStringForJava(this.introspectedTable.getFullyQualifiedTableNameAtRuntime()));
/*  55 */     sb.append("\",");
/*  56 */     method.addAnnotation(sb.toString());
/*     */     
/*     */ 
/*  59 */     sb.setLength(0);
/*  60 */     OutputUtilities.javaIndent(sb, 1);
/*  61 */     sb.append("\"set ");
/*     */     
/*     */     Iterator<IntrospectedColumn> iter;
/*  64 */     if (this.isSimple) {
/*  65 */       iter = this.introspectedTable.getNonPrimaryKeyColumns().iterator();
/*     */     } else {
/*  67 */       iter = this.introspectedTable.getBaseColumns().iterator();
/*     */     }
/*  69 */     while (iter.hasNext()) {
/*  70 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)iter.next();
/*     */       
/*  72 */       sb.append(StringUtility.escapeStringForJava(MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn)));
/*  73 */       sb.append(" = ");
/*  74 */       sb.append(MyBatis3FormattingUtilities.getParameterClause(introspectedColumn));
/*     */       
/*  76 */       if (iter.hasNext()) {
/*  77 */         sb.append(',');
/*     */       }
/*     */       
/*  80 */       sb.append("\",");
/*  81 */       method.addAnnotation(sb.toString());
/*     */       
/*     */ 
/*  84 */       if (iter.hasNext()) {
/*  85 */         sb.setLength(0);
/*  86 */         OutputUtilities.javaIndent(sb, 1);
/*  87 */         sb.append("  \"");
/*     */       }
/*     */     }
/*     */     
/*  91 */     boolean and = false;
/*  92 */     Iterator<IntrospectedColumn> iter = this.introspectedTable.getPrimaryKeyColumns().iterator();
/*  93 */     while (iter.hasNext()) {
/*  94 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)iter.next();
/*  95 */       sb.setLength(0);
/*  96 */       OutputUtilities.javaIndent(sb, 1);
/*  97 */       if (and) {
/*  98 */         sb.append("  \"and ");
/*     */       } else {
/* 100 */         sb.append("\"where ");
/* 101 */         and = true;
/*     */       }
/*     */       
/* 104 */       sb.append(StringUtility.escapeStringForJava(MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn)));
/* 105 */       sb.append(" = ");
/* 106 */       sb.append(MyBatis3FormattingUtilities.getParameterClause(introspectedColumn));
/* 107 */       sb.append('"');
/* 108 */       if (iter.hasNext()) {
/* 109 */         sb.append(',');
/*     */       }
/* 111 */       method.addAnnotation(sb.toString());
/*     */     }
/*     */     
/* 114 */     method.addAnnotation("})");
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\elements\annotated\AnnotatedUpdateByPrimaryKeyWithoutBLOBsMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */