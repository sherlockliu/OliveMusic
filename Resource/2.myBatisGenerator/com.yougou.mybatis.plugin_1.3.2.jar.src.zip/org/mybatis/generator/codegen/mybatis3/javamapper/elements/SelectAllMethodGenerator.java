/*    */ package org.mybatis.generator.codegen.mybatis3.javamapper.elements;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*    */ import org.mybatis.generator.api.dom.java.Interface;
/*    */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*    */ import org.mybatis.generator.api.dom.java.Method;
/*    */ import org.mybatis.generator.config.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectAllMethodGenerator
/*    */   extends AbstractJavaMapperMethodGenerator
/*    */ {
/*    */   public void addInterfaceElements(Interface interfaze)
/*    */   {
/* 40 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/* 41 */     importedTypes.add(FullyQualifiedJavaType.getNewListInstance());
/*    */     
/* 43 */     Method method = new Method();
/* 44 */     method.setVisibility(JavaVisibility.PUBLIC);
/*    */     
/* 46 */     FullyQualifiedJavaType returnType = 
/* 47 */       FullyQualifiedJavaType.getNewListInstance();
/*    */     
/* 49 */     FullyQualifiedJavaType listType = new FullyQualifiedJavaType(
/* 50 */       this.introspectedTable.getBaseRecordType());
/*    */     
/* 52 */     importedTypes.add(listType);
/* 53 */     returnType.addTypeArgument(listType);
/* 54 */     method.setReturnType(returnType);
/* 55 */     method.setName(this.introspectedTable.getSelectAllStatementId());
/*    */     
/* 57 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 58 */       this.introspectedTable);
/*    */     
/* 60 */     addMapperAnnotations(interfaze, method);
/*    */     
/* 62 */     if (this.context.getPlugins().clientSelectAllMethodGenerated(method, 
/* 63 */       interfaze, this.introspectedTable)) {
/* 64 */       interfaze.addImportedTypes(importedTypes);
/* 65 */       interfaze.addMethod(method);
/*    */     }
/*    */   }
/*    */   
/*    */   public void addMapperAnnotations(Interface interfaze, Method method) {}
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\elements\SelectAllMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */