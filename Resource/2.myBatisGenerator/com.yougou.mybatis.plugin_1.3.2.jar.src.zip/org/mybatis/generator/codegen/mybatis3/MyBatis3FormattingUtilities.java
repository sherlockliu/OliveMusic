/*     */ package org.mybatis.generator.codegen.mybatis3;
/*     */ 
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MyBatis3FormattingUtilities
/*     */ {
/*     */   public static String getParameterClause(IntrospectedColumn introspectedColumn)
/*     */   {
/*  38 */     return getParameterClause(introspectedColumn, null);
/*     */   }
/*     */   
/*     */   public static String getParameterClause(IntrospectedColumn introspectedColumn, String prefix)
/*     */   {
/*  43 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  45 */     sb.append("#{");
/*  46 */     sb.append(introspectedColumn.getJavaProperty(prefix));
/*  47 */     sb.append(",jdbcType=");
/*  48 */     sb.append(introspectedColumn.getJdbcTypeName());
/*     */     
/*  50 */     if (StringUtility.stringHasValue(introspectedColumn.getTypeHandler())) {
/*  51 */       sb.append(",typeHandler=");
/*  52 */       sb.append(introspectedColumn.getTypeHandler());
/*     */     }
/*     */     
/*  55 */     sb.append('}');
/*     */     
/*  57 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getSelectListPhrase(IntrospectedColumn introspectedColumn)
/*     */   {
/*  68 */     if (StringUtility.stringHasValue(introspectedColumn.getTableAlias())) {
/*  69 */       StringBuilder sb = new StringBuilder();
/*     */       
/*  71 */       sb.append(getAliasedEscapedColumnName(introspectedColumn));
/*  72 */       sb.append(" as ");
/*  73 */       if (introspectedColumn.isColumnNameDelimited()) {
/*  74 */         sb.append(introspectedColumn.getContext()
/*  75 */           .getBeginningDelimiter());
/*     */       }
/*  77 */       sb.append(introspectedColumn.getTableAlias());
/*  78 */       sb.append('_');
/*  79 */       sb.append(escapeStringForMyBatis3(introspectedColumn
/*  80 */         .getActualColumnName()));
/*  81 */       if (introspectedColumn.isColumnNameDelimited()) {
/*  82 */         sb.append(introspectedColumn.getContext().getEndingDelimiter());
/*     */       }
/*  84 */       return sb.toString();
/*     */     }
/*  86 */     return getEscapedColumnName(introspectedColumn);
/*     */   }
/*     */   
/*     */ 
/*     */   public static String getEscapedColumnName(IntrospectedColumn introspectedColumn)
/*     */   {
/*  92 */     StringBuilder sb = new StringBuilder();
/*  93 */     sb.append(escapeStringForMyBatis3(introspectedColumn
/*  94 */       .getActualColumnName()));
/*     */     
/*  96 */     if (introspectedColumn.isColumnNameDelimited()) {
/*  97 */       sb.insert(0, introspectedColumn.getContext()
/*  98 */         .getBeginningDelimiter());
/*  99 */       sb.append(introspectedColumn.getContext().getEndingDelimiter());
/*     */     }
/*     */     
/* 102 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAliasedEscapedColumnName(IntrospectedColumn introspectedColumn)
/*     */   {
/* 112 */     if (StringUtility.stringHasValue(introspectedColumn.getTableAlias())) {
/* 113 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 115 */       sb.append(introspectedColumn.getTableAlias());
/* 116 */       sb.append('.');
/* 117 */       sb.append(getEscapedColumnName(introspectedColumn));
/* 118 */       return sb.toString();
/*     */     }
/* 120 */     return getEscapedColumnName(introspectedColumn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAliasedActualColumnName(IntrospectedColumn introspectedColumn)
/*     */   {
/* 138 */     StringBuilder sb = new StringBuilder();
/* 139 */     if (StringUtility.stringHasValue(introspectedColumn.getTableAlias())) {
/* 140 */       sb.append(introspectedColumn.getTableAlias());
/* 141 */       sb.append('.');
/*     */     }
/*     */     
/* 144 */     if (introspectedColumn.isColumnNameDelimited()) {
/* 145 */       sb.append(StringUtility.escapeStringForJava(introspectedColumn
/* 146 */         .getContext().getBeginningDelimiter()));
/*     */     }
/*     */     
/* 149 */     sb.append(introspectedColumn.getActualColumnName());
/*     */     
/* 151 */     if (introspectedColumn.isColumnNameDelimited()) {
/* 152 */       sb.append(StringUtility.escapeStringForJava(introspectedColumn
/* 153 */         .getContext().getEndingDelimiter()));
/*     */     }
/*     */     
/* 156 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getRenamedColumnNameForResultMap(IntrospectedColumn introspectedColumn)
/*     */   {
/* 168 */     if (StringUtility.stringHasValue(introspectedColumn.getTableAlias())) {
/* 169 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 171 */       sb.append(introspectedColumn.getTableAlias());
/* 172 */       sb.append('_');
/* 173 */       sb.append(introspectedColumn.getActualColumnName());
/* 174 */       return sb.toString();
/*     */     }
/* 176 */     return introspectedColumn.getActualColumnName();
/*     */   }
/*     */   
/*     */ 
/*     */   public static String escapeStringForMyBatis3(String s)
/*     */   {
/* 182 */     return s;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\MyBatis3FormattingUtilities.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */