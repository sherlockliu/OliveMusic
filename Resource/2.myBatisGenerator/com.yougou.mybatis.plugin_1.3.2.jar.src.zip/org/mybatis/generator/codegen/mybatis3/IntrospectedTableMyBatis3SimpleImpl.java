/*    */ package org.mybatis.generator.codegen.mybatis3;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.mybatis.generator.api.ProgressCallback;
/*    */ import org.mybatis.generator.codegen.AbstractJavaClientGenerator;
/*    */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*    */ import org.mybatis.generator.codegen.mybatis3.javamapper.SimpleAnnotatedClientGenerator;
/*    */ import org.mybatis.generator.codegen.mybatis3.javamapper.SimpleJavaClientGenerator;
/*    */ import org.mybatis.generator.codegen.mybatis3.model.SimpleModelGenerator;
/*    */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.SimpleXMLMapperGenerator;
/*    */ import org.mybatis.generator.config.Context;
/*    */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*    */ import org.mybatis.generator.internal.ObjectFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntrospectedTableMyBatis3SimpleImpl
/*    */   extends IntrospectedTableMyBatis3Impl
/*    */ {
/*    */   protected void calculateXmlMapperGenerator(AbstractJavaClientGenerator javaClientGenerator, List<String> warnings, ProgressCallback progressCallback)
/*    */   {
/* 43 */     if (javaClientGenerator == null) {
/* 44 */       if (this.context.getSqlMapGeneratorConfiguration() != null) {
/* 45 */         this.xmlMapperGenerator = new SimpleXMLMapperGenerator();
/*    */       }
/*    */     } else {
/* 48 */       this.xmlMapperGenerator = javaClientGenerator.getMatchedXMLGenerator();
/*    */     }
/*    */     
/* 51 */     initializeAbstractGenerator(this.xmlMapperGenerator, warnings, 
/* 52 */       progressCallback);
/*    */   }
/*    */   
/*    */   protected AbstractJavaClientGenerator createJavaClientGenerator()
/*    */   {
/* 57 */     if (this.context.getJavaClientGeneratorConfiguration() == null) {
/* 58 */       return null;
/*    */     }
/*    */     
/* 61 */     String type = this.context.getJavaClientGeneratorConfiguration()
/* 62 */       .getConfigurationType();
/*    */     AbstractJavaClientGenerator javaGenerator;
/*    */     AbstractJavaClientGenerator javaGenerator;
/* 65 */     if ("XMLMAPPER".equalsIgnoreCase(type)) {
/* 66 */       javaGenerator = new SimpleJavaClientGenerator(); } else { AbstractJavaClientGenerator javaGenerator;
/* 67 */       if ("ANNOTATEDMAPPER".equalsIgnoreCase(type)) {
/* 68 */         javaGenerator = new SimpleAnnotatedClientGenerator(); } else { AbstractJavaClientGenerator javaGenerator;
/* 69 */         if ("MAPPER".equalsIgnoreCase(type)) {
/* 70 */           javaGenerator = new SimpleJavaClientGenerator();
/*    */         } else
/* 72 */           javaGenerator = (AbstractJavaClientGenerator)
/* 73 */             ObjectFactory.createInternalObject(type);
/*    */       }
/*    */     }
/* 76 */     return javaGenerator;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected void calculateJavaModelGenerators(List<String> warnings, ProgressCallback progressCallback)
/*    */   {
/* 83 */     AbstractJavaGenerator javaGenerator = new SimpleModelGenerator();
/* 84 */     initializeAbstractGenerator(javaGenerator, warnings, 
/* 85 */       progressCallback);
/* 86 */     this.javaModelGenerators.add(javaGenerator);
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\IntrospectedTableMyBatis3SimpleImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */