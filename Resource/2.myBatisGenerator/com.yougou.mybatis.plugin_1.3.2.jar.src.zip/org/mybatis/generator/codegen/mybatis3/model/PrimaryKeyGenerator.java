/*     */ package org.mybatis.generator.codegen.mybatis3.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.Plugin.ModelClassType;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*     */ import org.mybatis.generator.codegen.RootClassInfo;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaModelGeneratorConfiguration;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrimaryKeyGenerator
/*     */   extends AbstractJavaGenerator
/*     */ {
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  52 */     FullyQualifiedTable table = this.introspectedTable.getFullyQualifiedTable();
/*  53 */     this.progressCallback.startTask(Messages.getString(
/*  54 */       "Progress.7", table.toString()));
/*  55 */     Plugin plugins = this.context.getPlugins();
/*  56 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/*  58 */     TopLevelClass topLevelClass = new TopLevelClass(this.introspectedTable
/*  59 */       .getPrimaryKeyType());
/*  60 */     topLevelClass.setVisibility(JavaVisibility.PUBLIC);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */     commentGenerator.addClassComment(topLevelClass);
/*     */     
/*  70 */     String rootClass = getRootClass();
/*  71 */     if (rootClass != null) {
/*  72 */       topLevelClass.setSuperClass(new FullyQualifiedJavaType(rootClass));
/*  73 */       topLevelClass.addImportedType(topLevelClass.getSuperClass());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */     String rootInterface = this.introspectedTable
/*  81 */       .getTableConfigurationProperty("rootInterface");
/*  82 */     if (!StringUtility.stringHasValue(rootInterface)) {
/*  83 */       rootInterface = 
/*  84 */         this.context.getJavaModelGeneratorConfiguration().getProperty("rootInterface");
/*     */     }
/*     */     
/*  87 */     if (StringUtility.stringHasValue(rootInterface)) {
/*  88 */       FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
/*  89 */         rootInterface);
/*  90 */       topLevelClass.addSuperInterface(fqjt);
/*  91 */       topLevelClass.addImportedType(fqjt);
/*     */     }
/*     */     
/*  94 */     if (this.introspectedTable.isConstructorBased()) {
/*  95 */       addParameterizedConstructor(topLevelClass);
/*     */       
/*  97 */       if (!this.introspectedTable.isImmutable()) {
/*  98 */         addDefaultConstructor(topLevelClass);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 103 */     Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/* 102 */     while (localIterator.hasNext()) {
/* 103 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*     */       
/* 105 */       if (!RootClassInfo.getInstance(rootClass, this.warnings).containsProperty(introspectedColumn))
/*     */       {
/*     */ 
/*     */ 
/* 109 */         Field field = getJavaBeansField(introspectedColumn);
/* 110 */         if (plugins.modelFieldGenerated(field, topLevelClass, 
/* 111 */           introspectedColumn, this.introspectedTable, 
/* 112 */           Plugin.ModelClassType.PRIMARY_KEY)) {
/* 113 */           topLevelClass.addField(field);
/* 114 */           topLevelClass.addImportedType(field.getType());
/*     */         }
/*     */         
/* 117 */         Method method = getJavaBeansGetter(introspectedColumn);
/* 118 */         if (plugins.modelGetterMethodGenerated(method, topLevelClass, 
/* 119 */           introspectedColumn, this.introspectedTable, 
/* 120 */           Plugin.ModelClassType.PRIMARY_KEY)) {
/* 121 */           topLevelClass.addMethod(method);
/*     */         }
/*     */         
/* 124 */         if (!this.introspectedTable.isImmutable()) {
/* 125 */           method = getJavaBeansSetter(introspectedColumn);
/* 126 */           if (plugins.modelSetterMethodGenerated(method, topLevelClass, 
/* 127 */             introspectedColumn, this.introspectedTable, 
/* 128 */             Plugin.ModelClassType.PRIMARY_KEY)) {
/* 129 */             topLevelClass.addMethod(method);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 134 */     List<CompilationUnit> answer = new ArrayList();
/* 135 */     if (this.context.getPlugins().modelPrimaryKeyClassGenerated(
/* 136 */       topLevelClass, this.introspectedTable)) {
/* 137 */       answer.add(topLevelClass);
/*     */     }
/* 139 */     return answer;
/*     */   }
/*     */   
/*     */   private void addParameterizedConstructor(TopLevelClass topLevelClass) {
/* 143 */     Method method = new Method();
/* 144 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 145 */     method.setConstructor(true);
/* 146 */     method.setName(topLevelClass.getType().getShortName());
/* 147 */     this.context.getCommentGenerator().addGeneralMethodComment(method, this.introspectedTable);
/*     */     
/* 149 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 151 */     Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/* 150 */     while (localIterator.hasNext()) {
/* 151 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/* 152 */       method.addParameter(new Parameter(introspectedColumn.getFullyQualifiedJavaType(), 
/* 153 */         introspectedColumn.getJavaProperty()));
/* 154 */       sb.setLength(0);
/* 155 */       sb.append("this.");
/* 156 */       sb.append(introspectedColumn.getJavaProperty());
/* 157 */       sb.append(" = ");
/* 158 */       sb.append(introspectedColumn.getJavaProperty());
/* 159 */       sb.append(';');
/* 160 */       method.addBodyLine(sb.toString());
/*     */     }
/*     */     
/* 163 */     topLevelClass.addMethod(method);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\model\PrimaryKeyGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */