/*     */ package org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.OutputUtilities;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.SelectAllMethodGenerator;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AnnotatedSelectAllMethodGenerator
/*     */   extends SelectAllMethodGenerator
/*     */ {
/*     */   public void addMapperAnnotations(Interface interfaze, Method method)
/*     */   {
/*  45 */     interfaze.addImportedType(new FullyQualifiedJavaType("org.apache.ibatis.annotations.Select"));
/*     */     
/*  47 */     StringBuilder sb = new StringBuilder();
/*  48 */     method.addAnnotation("@Select({");
/*  49 */     OutputUtilities.javaIndent(sb, 1);
/*  50 */     sb.append("\"select\",");
/*  51 */     method.addAnnotation(sb.toString());
/*     */     
/*  53 */     Iterator<IntrospectedColumn> iter = this.introspectedTable
/*  54 */       .getAllColumns().iterator();
/*  55 */     sb.setLength(0);
/*  56 */     OutputUtilities.javaIndent(sb, 1);
/*  57 */     sb.append('"');
/*  58 */     boolean hasColumns = false;
/*  59 */     while (iter.hasNext()) {
/*  60 */       sb.append(StringUtility.escapeStringForJava(MyBatis3FormattingUtilities.getSelectListPhrase((IntrospectedColumn)iter.next())));
/*  61 */       hasColumns = true;
/*     */       
/*  63 */       if (iter.hasNext()) {
/*  64 */         sb.append(", ");
/*     */       }
/*     */       
/*  67 */       if (sb.length() > 80) {
/*  68 */         sb.append("\",");
/*  69 */         method.addAnnotation(sb.toString());
/*     */         
/*  71 */         sb.setLength(0);
/*  72 */         OutputUtilities.javaIndent(sb, 1);
/*  73 */         sb.append('"');
/*  74 */         hasColumns = false;
/*     */       }
/*     */     }
/*     */     
/*  78 */     if (hasColumns) {
/*  79 */       sb.append("\",");
/*  80 */       method.addAnnotation(sb.toString());
/*     */     }
/*     */     
/*  83 */     String orderByClause = this.introspectedTable.getTableConfigurationProperty("selectAllOrderByClause");
/*  84 */     boolean hasOrderBy = StringUtility.stringHasValue(orderByClause);
/*     */     
/*  86 */     sb.setLength(0);
/*  87 */     OutputUtilities.javaIndent(sb, 1);
/*  88 */     sb.append("\"from ");
/*  89 */     sb.append(StringUtility.escapeStringForJava(this.introspectedTable
/*  90 */       .getAliasedFullyQualifiedTableNameAtRuntime()));
/*  91 */     sb.append('"');
/*  92 */     if (hasOrderBy) {
/*  93 */       sb.append(',');
/*     */     }
/*  95 */     method.addAnnotation(sb.toString());
/*     */     
/*  97 */     if (hasOrderBy) {
/*  98 */       sb.setLength(0);
/*  99 */       OutputUtilities.javaIndent(sb, 1);
/* 100 */       sb.append("\"order by ");
/* 101 */       sb.append(orderByClause);
/* 102 */       sb.append('"');
/* 103 */       method.addAnnotation(sb.toString());
/*     */     }
/*     */     
/* 106 */     method.addAnnotation("})");
/*     */     
/* 108 */     addAnnotatedResults(interfaze, method);
/*     */   }
/*     */   
/*     */   private void addAnnotatedResults(Interface interfaze, Method method) {
/* 112 */     interfaze.addImportedType(new FullyQualifiedJavaType("org.apache.ibatis.type.JdbcType"));
/*     */     
/* 114 */     if (this.introspectedTable.isConstructorBased()) {
/* 115 */       interfaze.addImportedType(new FullyQualifiedJavaType("org.apache.ibatis.annotations.Arg"));
/* 116 */       interfaze.addImportedType(new FullyQualifiedJavaType("org.apache.ibatis.annotations.ConstructorArgs"));
/* 117 */       method.addAnnotation("@ConstructorArgs({");
/*     */     } else {
/* 119 */       interfaze.addImportedType(new FullyQualifiedJavaType("org.apache.ibatis.annotations.Result"));
/* 120 */       interfaze.addImportedType(new FullyQualifiedJavaType("org.apache.ibatis.annotations.Results"));
/* 121 */       method.addAnnotation("@Results({");
/*     */     }
/*     */     
/* 124 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 126 */     Iterator<IntrospectedColumn> iterPk = this.introspectedTable.getPrimaryKeyColumns().iterator();
/* 127 */     Iterator<IntrospectedColumn> iterNonPk = this.introspectedTable.getNonPrimaryKeyColumns().iterator();
/* 128 */     while (iterPk.hasNext()) {
/* 129 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)iterPk.next();
/* 130 */       sb.setLength(0);
/* 131 */       OutputUtilities.javaIndent(sb, 1);
/* 132 */       sb.append(getResultAnnotation(interfaze, introspectedColumn, true, 
/* 133 */         this.introspectedTable.isConstructorBased()));
/*     */       
/* 135 */       if ((iterPk.hasNext()) || (iterNonPk.hasNext())) {
/* 136 */         sb.append(',');
/*     */       }
/*     */       
/* 139 */       method.addAnnotation(sb.toString());
/*     */     }
/*     */     
/* 142 */     while (iterNonPk.hasNext()) {
/* 143 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)iterNonPk.next();
/* 144 */       sb.setLength(0);
/* 145 */       OutputUtilities.javaIndent(sb, 1);
/* 146 */       sb.append(getResultAnnotation(interfaze, introspectedColumn, false, 
/* 147 */         this.introspectedTable.isConstructorBased()));
/*     */       
/* 149 */       if (iterNonPk.hasNext()) {
/* 150 */         sb.append(',');
/*     */       }
/*     */       
/* 153 */       method.addAnnotation(sb.toString());
/*     */     }
/*     */     
/* 156 */     method.addAnnotation("})");
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\elements\annotated\AnnotatedSelectAllMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */