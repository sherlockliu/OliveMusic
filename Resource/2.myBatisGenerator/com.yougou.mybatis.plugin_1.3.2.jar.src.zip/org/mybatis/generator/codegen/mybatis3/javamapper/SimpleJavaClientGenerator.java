/*     */ package org.mybatis.generator.codegen.mybatis3.javamapper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.codegen.AbstractJavaClientGenerator;
/*     */ import org.mybatis.generator.codegen.AbstractXmlGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.AbstractJavaMapperMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.DeleteByPrimaryKeyMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.InsertMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.SelectAllMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.SelectByPrimaryKeyMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.UpdateByPrimaryKeyWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.SimpleXMLMapperGenerator;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleJavaClientGenerator
/*     */   extends AbstractJavaClientGenerator
/*     */ {
/*     */   public SimpleJavaClientGenerator()
/*     */   {
/*  51 */     super(true);
/*     */   }
/*     */   
/*     */   public SimpleJavaClientGenerator(boolean requiresMatchedXMLGenerator) {
/*  55 */     super(requiresMatchedXMLGenerator);
/*     */   }
/*     */   
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  60 */     this.progressCallback.startTask(Messages.getString("Progress.17", 
/*  61 */       this.introspectedTable.getFullyQualifiedTable().toString()));
/*  62 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/*  64 */     FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/*  65 */       this.introspectedTable.getMyBatis3JavaMapperType());
/*  66 */     Interface interfaze = new Interface(type);
/*  67 */     interfaze.setVisibility(JavaVisibility.PUBLIC);
/*  68 */     commentGenerator.addJavaFileComment(interfaze);
/*     */     
/*  70 */     String rootInterface = this.introspectedTable
/*  71 */       .getTableConfigurationProperty("rootInterface");
/*  72 */     if (!StringUtility.stringHasValue(rootInterface)) {
/*  73 */       rootInterface = 
/*  74 */         this.context.getJavaClientGeneratorConfiguration().getProperty("rootInterface");
/*     */     }
/*     */     
/*  77 */     if (StringUtility.stringHasValue(rootInterface)) {
/*  78 */       FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
/*  79 */         rootInterface);
/*  80 */       interfaze.addSuperInterface(fqjt);
/*  81 */       interfaze.addImportedType(fqjt);
/*     */     }
/*     */     
/*  84 */     addDeleteByPrimaryKeyMethod(interfaze);
/*  85 */     addInsertMethod(interfaze);
/*  86 */     addSelectByPrimaryKeyMethod(interfaze);
/*  87 */     addSelectAllMethod(interfaze);
/*  88 */     addUpdateByPrimaryKeyMethod(interfaze);
/*     */     
/*  90 */     List<CompilationUnit> answer = new ArrayList();
/*  91 */     if (this.context.getPlugins().clientGenerated(interfaze, null, 
/*  92 */       this.introspectedTable)) {
/*  93 */       answer.add(interfaze);
/*     */     }
/*     */     
/*  96 */     List<CompilationUnit> extraCompilationUnits = getExtraCompilationUnits();
/*  97 */     if (extraCompilationUnits != null) {
/*  98 */       answer.addAll(extraCompilationUnits);
/*     */     }
/*     */     
/* 101 */     return answer;
/*     */   }
/*     */   
/*     */   protected void addDeleteByPrimaryKeyMethod(Interface interfaze) {
/* 105 */     if (this.introspectedTable.getRules().generateDeleteByPrimaryKey()) {
/* 106 */       AbstractJavaMapperMethodGenerator methodGenerator = new DeleteByPrimaryKeyMethodGenerator(true);
/* 107 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertMethod(Interface interfaze) {
/* 112 */     if (this.introspectedTable.getRules().generateInsert()) {
/* 113 */       AbstractJavaMapperMethodGenerator methodGenerator = new InsertMethodGenerator(true);
/* 114 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByPrimaryKeyMethod(Interface interfaze) {
/* 119 */     if (this.introspectedTable.getRules().generateSelectByPrimaryKey()) {
/* 120 */       AbstractJavaMapperMethodGenerator methodGenerator = new SelectByPrimaryKeyMethodGenerator(true);
/* 121 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectAllMethod(Interface interfaze) {
/* 126 */     AbstractJavaMapperMethodGenerator methodGenerator = new SelectAllMethodGenerator();
/* 127 */     initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeyMethod(Interface interfaze) {
/* 131 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeySelective()) {
/* 132 */       AbstractJavaMapperMethodGenerator methodGenerator = new UpdateByPrimaryKeyWithoutBLOBsMethodGenerator();
/* 133 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initializeAndExecuteGenerator(AbstractJavaMapperMethodGenerator methodGenerator, Interface interfaze)
/*     */   {
/* 140 */     methodGenerator.setContext(this.context);
/* 141 */     methodGenerator.setIntrospectedTable(this.introspectedTable);
/* 142 */     methodGenerator.setProgressCallback(this.progressCallback);
/* 143 */     methodGenerator.setWarnings(this.warnings);
/* 144 */     methodGenerator.addInterfaceElements(interfaze);
/*     */   }
/*     */   
/*     */   public List<CompilationUnit> getExtraCompilationUnits() {
/* 148 */     return null;
/*     */   }
/*     */   
/*     */   public AbstractXmlGenerator getMatchedXMLGenerator()
/*     */   {
/* 153 */     return new SimpleXMLMapperGenerator();
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\SimpleJavaClientGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */