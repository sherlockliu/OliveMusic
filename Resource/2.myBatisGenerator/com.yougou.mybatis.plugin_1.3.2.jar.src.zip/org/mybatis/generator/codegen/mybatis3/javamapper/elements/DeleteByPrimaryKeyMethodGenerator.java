/*    */ package org.mybatis.generator.codegen.mybatis3.javamapper.elements;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedColumn;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*    */ import org.mybatis.generator.api.dom.java.Interface;
/*    */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*    */ import org.mybatis.generator.api.dom.java.Method;
/*    */ import org.mybatis.generator.api.dom.java.Parameter;
/*    */ import org.mybatis.generator.config.Context;
/*    */ import org.mybatis.generator.internal.rules.Rules;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeleteByPrimaryKeyMethodGenerator
/*    */   extends AbstractJavaMapperMethodGenerator
/*    */ {
/*    */   private boolean isSimple;
/*    */   
/*    */   public DeleteByPrimaryKeyMethodGenerator(boolean isSimple)
/*    */   {
/* 41 */     this.isSimple = isSimple;
/*    */   }
/*    */   
/*    */   public void addInterfaceElements(Interface interfaze)
/*    */   {
/* 46 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/* 47 */     Method method = new Method();
/* 48 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 49 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 50 */     method.setName(this.introspectedTable.getDeleteByPrimaryKeyStatementId());
/*    */     
/* 52 */     if ((!this.isSimple) && (this.introspectedTable.getRules().generatePrimaryKeyClass())) {
/* 53 */       FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/* 54 */         this.introspectedTable.getPrimaryKeyType());
/* 55 */       importedTypes.add(type);
/* 56 */       method.addParameter(new Parameter(type, "key"));
/*    */ 
/*    */     }
/*    */     else
/*    */     {
/*    */ 
/* 62 */       List<IntrospectedColumn> introspectedColumns = this.introspectedTable
/* 63 */         .getPrimaryKeyColumns();
/* 64 */       boolean annotate = introspectedColumns.size() > 1;
/* 65 */       if (annotate) {
/* 66 */         importedTypes.add(new FullyQualifiedJavaType(
/* 67 */           "org.apache.ibatis.annotations.Param"));
/*    */       }
/* 69 */       StringBuilder sb = new StringBuilder();
/* 70 */       for (IntrospectedColumn introspectedColumn : introspectedColumns) {
/* 71 */         FullyQualifiedJavaType type = introspectedColumn
/* 72 */           .getFullyQualifiedJavaType();
/* 73 */         importedTypes.add(type);
/* 74 */         Parameter parameter = new Parameter(type, introspectedColumn
/* 75 */           .getJavaProperty());
/* 76 */         if (annotate) {
/* 77 */           sb.setLength(0);
/* 78 */           sb.append("@Param(\"");
/* 79 */           sb.append(introspectedColumn.getJavaProperty());
/* 80 */           sb.append("\")");
/* 81 */           parameter.addAnnotation(sb.toString());
/*    */         }
/* 83 */         method.addParameter(parameter);
/*    */       }
/*    */     }
/*    */     
/* 87 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 88 */       this.introspectedTable);
/*    */     
/* 90 */     addMapperAnnotations(interfaze, method);
/*    */     
/* 92 */     if (this.context.getPlugins().clientDeleteByPrimaryKeyMethodGenerated(
/* 93 */       method, interfaze, this.introspectedTable)) {
/* 94 */       interfaze.addImportedTypes(importedTypes);
/* 95 */       interfaze.addMethod(method);
/*    */     }
/*    */   }
/*    */   
/*    */   public void addMapperAnnotations(Interface interfaze, Method method) {}
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\elements\DeleteByPrimaryKeyMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */