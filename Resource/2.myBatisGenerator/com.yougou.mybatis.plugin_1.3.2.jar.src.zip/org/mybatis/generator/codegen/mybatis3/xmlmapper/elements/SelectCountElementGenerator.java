/*    */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*    */ 
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.TextElement;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectCountElementGenerator
/*    */   extends AbstractXmlElementGenerator
/*    */ {
/*    */   public void addElements(XmlElement parentElement)
/*    */   {
/* 38 */     XmlElement answer = new XmlElement("select");
/* 39 */     answer.addAttribute(new Attribute(
/* 40 */       "id", "selectCount"));
/* 41 */     answer.addAttribute(new Attribute(
/* 42 */       "resultType", "java.lang.Integer"));
/*    */     
/* 44 */     StringBuilder sb = new StringBuilder();
/* 45 */     sb.append("SELECT ");
/* 46 */     sb.append("COUNT(1) as s");
/* 47 */     sb.append(" FROM ");
/* 48 */     sb.append(this.introspectedTable
/* 49 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/* 50 */     sb.append(" WHERE 1=1 ");
/* 51 */     answer.addElement(new TextElement(sb.toString()));
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 58 */     XmlElement sqlElement = new XmlElement("include");
/* 59 */     sqlElement.addAttribute(new Attribute("refid", "condition"));
/* 60 */     answer.addElement(sqlElement);
/*    */     
/* 62 */     parentElement.addElement(answer);
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\SelectCountElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */