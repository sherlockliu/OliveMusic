/*     */ package org.mybatis.generator.codegen.mybatis3.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.Plugin.ModelClassType;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*     */ import org.mybatis.generator.codegen.RootClassInfo;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaModelGeneratorConfiguration;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseRecordGenerator
/*     */   extends AbstractJavaGenerator
/*     */ {
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  52 */     FullyQualifiedTable table = this.introspectedTable.getFullyQualifiedTable();
/*  53 */     this.progressCallback.startTask(Messages.getString(
/*  54 */       "Progress.8", table.toString()));
/*  55 */     Plugin plugins = this.context.getPlugins();
/*  56 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/*  58 */     FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/*  59 */       this.introspectedTable.getBaseRecordType());
/*  60 */     TopLevelClass topLevelClass = new TopLevelClass(type);
/*  61 */     topLevelClass.setVisibility(JavaVisibility.PUBLIC);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */     commentGenerator.addClassComment(topLevelClass);
/*     */     
/*  71 */     FullyQualifiedJavaType superClass = getSuperClass();
/*  72 */     if (superClass != null) {
/*  73 */       topLevelClass.setSuperClass(superClass);
/*  74 */       topLevelClass.addImportedType(superClass);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  81 */     String rootInterface = this.introspectedTable
/*  82 */       .getTableConfigurationProperty("rootInterface");
/*  83 */     if (!StringUtility.stringHasValue(rootInterface)) {
/*  84 */       rootInterface = 
/*  85 */         this.context.getJavaModelGeneratorConfiguration().getProperty("rootInterface");
/*     */     }
/*     */     
/*  88 */     if (StringUtility.stringHasValue(rootInterface)) {
/*  89 */       FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
/*  90 */         rootInterface);
/*  91 */       topLevelClass.addSuperInterface(fqjt);
/*  92 */       topLevelClass.addImportedType(fqjt);
/*     */     }
/*     */     
/*  95 */     List<IntrospectedColumn> introspectedColumns = getColumnsInThisClass();
/*     */     
/*  97 */     if (this.introspectedTable.isConstructorBased()) {
/*  98 */       addParameterizedConstructor(topLevelClass);
/*     */       
/* 100 */       if (!this.introspectedTable.isImmutable()) {
/* 101 */         addDefaultConstructor(topLevelClass);
/*     */       }
/*     */     }
/*     */     
/* 105 */     String rootClass = getRootClass();
/* 106 */     for (IntrospectedColumn introspectedColumn : introspectedColumns)
/*     */     {
/* 108 */       if (!RootClassInfo.getInstance(rootClass, this.warnings).containsProperty(introspectedColumn))
/*     */       {
/*     */ 
/*     */ 
/* 112 */         Field field = getJavaBeansField(introspectedColumn);
/* 113 */         if (plugins.modelFieldGenerated(field, topLevelClass, 
/* 114 */           introspectedColumn, this.introspectedTable, 
/* 115 */           Plugin.ModelClassType.BASE_RECORD)) {
/* 116 */           topLevelClass.addField(field);
/* 117 */           topLevelClass.addImportedType(field.getType());
/*     */         }
/*     */         
/* 120 */         Method method = getJavaBeansGetter(introspectedColumn);
/* 121 */         if (plugins.modelGetterMethodGenerated(method, topLevelClass, 
/* 122 */           introspectedColumn, this.introspectedTable, 
/* 123 */           Plugin.ModelClassType.BASE_RECORD)) {
/* 124 */           topLevelClass.addMethod(method);
/*     */         }
/*     */         
/* 127 */         if (!this.introspectedTable.isImmutable()) {
/* 128 */           method = getJavaBeansSetter(introspectedColumn);
/* 129 */           if (plugins.modelSetterMethodGenerated(method, topLevelClass, 
/* 130 */             introspectedColumn, this.introspectedTable, 
/* 131 */             Plugin.ModelClassType.BASE_RECORD)) {
/* 132 */             topLevelClass.addMethod(method);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 137 */     List<CompilationUnit> answer = new ArrayList();
/* 138 */     if (this.context.getPlugins().modelBaseRecordClassGenerated(
/* 139 */       topLevelClass, this.introspectedTable)) {
/* 140 */       answer.add(topLevelClass);
/*     */     }
/* 142 */     return answer;
/*     */   }
/*     */   
/*     */   private FullyQualifiedJavaType getSuperClass() { FullyQualifiedJavaType superClass;
/*     */     FullyQualifiedJavaType superClass;
/* 147 */     if (this.introspectedTable.getRules().generatePrimaryKeyClass()) {
/* 148 */       superClass = new FullyQualifiedJavaType(this.introspectedTable
/* 149 */         .getPrimaryKeyType());
/*     */     } else {
/* 151 */       String rootClass = getRootClass();
/* 152 */       FullyQualifiedJavaType superClass; if (rootClass != null) {
/* 153 */         superClass = new FullyQualifiedJavaType(rootClass);
/*     */       } else {
/* 155 */         superClass = null;
/*     */       }
/*     */     }
/*     */     
/* 159 */     return superClass;
/*     */   }
/*     */   
/*     */   private boolean includePrimaryKeyColumns()
/*     */   {
/* 164 */     return (!this.introspectedTable.getRules().generatePrimaryKeyClass()) && (this.introspectedTable.hasPrimaryKeyColumns());
/*     */   }
/*     */   
/*     */   private boolean includeBLOBColumns()
/*     */   {
/* 169 */     return (!this.introspectedTable.getRules().generateRecordWithBLOBsClass()) && (this.introspectedTable.hasBLOBColumns());
/*     */   }
/*     */   
/*     */   private void addParameterizedConstructor(TopLevelClass topLevelClass) {
/* 173 */     Method method = new Method();
/* 174 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 175 */     method.setConstructor(true);
/* 176 */     method.setName(topLevelClass.getType().getShortName());
/* 177 */     this.context.getCommentGenerator().addGeneralMethodComment(method, this.introspectedTable);
/*     */     
/* 179 */     List<IntrospectedColumn> constructorColumns = 
/* 180 */       includeBLOBColumns() ? this.introspectedTable.getAllColumns() : 
/* 181 */       this.introspectedTable.getNonBLOBColumns();
/*     */     
/* 183 */     for (IntrospectedColumn introspectedColumn : constructorColumns) {
/* 184 */       method.addParameter(new Parameter(introspectedColumn.getFullyQualifiedJavaType(), 
/* 185 */         introspectedColumn.getJavaProperty()));
/*     */     }
/*     */     
/* 188 */     StringBuilder sb = new StringBuilder();
/* 189 */     Iterator localIterator2; if (this.introspectedTable.getRules().generatePrimaryKeyClass()) {
/* 190 */       boolean comma = false;
/* 191 */       sb.append("super(");
/*     */       
/* 193 */       localIterator2 = this.introspectedTable.getPrimaryKeyColumns().iterator();
/* 192 */       while (localIterator2.hasNext()) {
/* 193 */         IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator2.next();
/* 194 */         if (comma) {
/* 195 */           sb.append(", ");
/*     */         } else {
/* 197 */           comma = true;
/*     */         }
/* 199 */         sb.append(introspectedColumn.getJavaProperty());
/*     */       }
/* 201 */       sb.append(");");
/* 202 */       method.addBodyLine(sb.toString());
/*     */     }
/*     */     
/* 205 */     Object introspectedColumns = getColumnsInThisClass();
/*     */     
/* 207 */     for (IntrospectedColumn introspectedColumn : (List)introspectedColumns) {
/* 208 */       sb.setLength(0);
/* 209 */       sb.append("this.");
/* 210 */       sb.append(introspectedColumn.getJavaProperty());
/* 211 */       sb.append(" = ");
/* 212 */       sb.append(introspectedColumn.getJavaProperty());
/* 213 */       sb.append(';');
/* 214 */       method.addBodyLine(sb.toString());
/*     */     }
/*     */     
/* 217 */     topLevelClass.addMethod(method);
/*     */   }
/*     */   
/*     */   private List<IntrospectedColumn> getColumnsInThisClass() { List<IntrospectedColumn> introspectedColumns;
/*     */     List<IntrospectedColumn> introspectedColumns;
/* 222 */     if (includePrimaryKeyColumns()) { List<IntrospectedColumn> introspectedColumns;
/* 223 */       if (includeBLOBColumns()) {
/* 224 */         introspectedColumns = this.introspectedTable.getAllColumns();
/*     */       } else
/* 226 */         introspectedColumns = this.introspectedTable.getNonBLOBColumns();
/*     */     } else {
/*     */       List<IntrospectedColumn> introspectedColumns;
/* 229 */       if (includeBLOBColumns()) {
/* 230 */         introspectedColumns = 
/* 231 */           this.introspectedTable.getNonPrimaryKeyColumns();
/*     */       } else {
/* 233 */         introspectedColumns = this.introspectedTable.getBaseColumns();
/*     */       }
/*     */     }
/*     */     
/* 237 */     return introspectedColumns;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\model\BaseRecordGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */