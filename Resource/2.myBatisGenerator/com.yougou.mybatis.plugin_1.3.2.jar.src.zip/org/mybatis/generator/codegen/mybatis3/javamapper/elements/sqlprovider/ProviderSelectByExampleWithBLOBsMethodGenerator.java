/*    */ package org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.mybatis.generator.api.IntrospectedColumn;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.java.Method;
/*    */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*    */ import org.mybatis.generator.config.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProviderSelectByExampleWithBLOBsMethodGenerator
/*    */   extends ProviderSelectByExampleWithoutBLOBsMethodGenerator
/*    */ {
/*    */   public List<IntrospectedColumn> getColumns()
/*    */   {
/* 38 */     return this.introspectedTable.getAllColumns();
/*    */   }
/*    */   
/*    */   public String getMethodName()
/*    */   {
/* 43 */     return this.introspectedTable.getSelectByExampleWithBLOBsStatementId();
/*    */   }
/*    */   
/*    */   public boolean callPlugins(Method method, TopLevelClass topLevelClass)
/*    */   {
/* 48 */     return this.context.getPlugins().providerSelectByExampleWithBLOBsMethodGenerated(method, topLevelClass, 
/* 49 */       this.introspectedTable);
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\elements\sqlprovider\ProviderSelectByExampleWithBLOBsMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */