/*     */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultMapWithoutBLOBsElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   private boolean isSimple;
/*     */   
/*     */   public ResultMapWithoutBLOBsElementGenerator(boolean isSimple)
/*     */   {
/*  39 */     this.isSimple = isSimple;
/*     */   }
/*     */   
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  44 */     XmlElement answer = new XmlElement("resultMap");
/*  45 */     answer.addAttribute(new Attribute("id", 
/*  46 */       this.introspectedTable.getBaseResultMapId()));
/*     */     String returnType;
/*     */     String returnType;
/*  49 */     if (this.isSimple) {
/*  50 */       returnType = this.introspectedTable.getBaseRecordType();
/*     */     } else { String returnType;
/*  52 */       if (this.introspectedTable.getRules().generateBaseRecordClass()) {
/*  53 */         returnType = this.introspectedTable.getBaseRecordType();
/*     */       } else {
/*  55 */         returnType = this.introspectedTable.getPrimaryKeyType();
/*     */       }
/*     */     }
/*     */     
/*  59 */     answer.addAttribute(new Attribute("type", 
/*  60 */       returnType));
/*     */     
/*  62 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  64 */     if (this.introspectedTable.isConstructorBased()) {
/*  65 */       addResultMapConstructorElements(answer);
/*     */     } else {
/*  67 */       addResultMapElements(answer);
/*     */     }
/*     */     
/*  70 */     if (this.context.getPlugins().sqlMapResultMapWithoutBLOBsElementGenerated(
/*  71 */       answer, this.introspectedTable)) {
/*  72 */       parentElement.addElement(answer);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addResultMapElements(XmlElement answer)
/*     */   {
/*  78 */     Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/*     */     XmlElement resultElement;
/*  77 */     while (localIterator.hasNext()) {
/*  78 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*  79 */       resultElement = new XmlElement("id");
/*     */       
/*  81 */       resultElement
/*  82 */         .addAttribute(new Attribute(
/*  83 */         "column", MyBatis3FormattingUtilities.getRenamedColumnNameForResultMap(introspectedColumn)));
/*  84 */       resultElement.addAttribute(new Attribute(
/*  85 */         "property", introspectedColumn.getJavaProperty()));
/*  86 */       resultElement.addAttribute(new Attribute("jdbcType", 
/*  87 */         introspectedColumn.getJdbcTypeName()));
/*     */       
/*  89 */       if (StringUtility.stringHasValue(introspectedColumn.getTypeHandler())) {
/*  90 */         resultElement.addAttribute(new Attribute(
/*  91 */           "typeHandler", introspectedColumn.getTypeHandler()));
/*     */       }
/*     */       
/*  94 */       answer.addElement(resultElement);
/*     */     }
/*     */     List<IntrospectedColumn> columns;
/*     */     List<IntrospectedColumn> columns;
/*  98 */     if (this.isSimple) {
/*  99 */       columns = this.introspectedTable.getNonPrimaryKeyColumns();
/*     */     } else {
/* 101 */       columns = this.introspectedTable.getBaseColumns();
/*     */     }
/* 103 */     for (IntrospectedColumn introspectedColumn : columns) {
/* 104 */       XmlElement resultElement = new XmlElement("result");
/*     */       
/* 106 */       resultElement
/* 107 */         .addAttribute(new Attribute(
/* 108 */         "column", MyBatis3FormattingUtilities.getRenamedColumnNameForResultMap(introspectedColumn)));
/* 109 */       resultElement.addAttribute(new Attribute(
/* 110 */         "property", introspectedColumn.getJavaProperty()));
/* 111 */       resultElement.addAttribute(new Attribute("jdbcType", 
/* 112 */         introspectedColumn.getJdbcTypeName()));
/*     */       
/* 114 */       if (StringUtility.stringHasValue(introspectedColumn.getTypeHandler())) {
/* 115 */         resultElement.addAttribute(new Attribute(
/* 116 */           "typeHandler", introspectedColumn.getTypeHandler()));
/*     */       }
/*     */       
/* 119 */       answer.addElement(resultElement);
/*     */     }
/*     */   }
/*     */   
/*     */   private void addResultMapConstructorElements(XmlElement answer) {
/* 124 */     XmlElement constructor = new XmlElement("constructor");
/*     */     
/*     */ 
/* 127 */     Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/*     */     XmlElement resultElement;
/* 126 */     while (localIterator.hasNext()) {
/* 127 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/* 128 */       resultElement = new XmlElement("idArg");
/*     */       
/* 130 */       resultElement
/* 131 */         .addAttribute(new Attribute(
/* 132 */         "column", MyBatis3FormattingUtilities.getRenamedColumnNameForResultMap(introspectedColumn)));
/* 133 */       resultElement.addAttribute(new Attribute("jdbcType", 
/* 134 */         introspectedColumn.getJdbcTypeName()));
/* 135 */       resultElement.addAttribute(new Attribute("javaType", 
/* 136 */         introspectedColumn.getFullyQualifiedJavaType()
/* 137 */         .getFullyQualifiedName()));
/*     */       
/* 139 */       if (StringUtility.stringHasValue(introspectedColumn.getTypeHandler())) {
/* 140 */         resultElement.addAttribute(new Attribute(
/* 141 */           "typeHandler", introspectedColumn.getTypeHandler()));
/*     */       }
/*     */       
/* 144 */       constructor.addElement(resultElement);
/*     */     }
/*     */     List<IntrospectedColumn> columns;
/*     */     List<IntrospectedColumn> columns;
/* 148 */     if (this.isSimple) {
/* 149 */       columns = this.introspectedTable.getNonPrimaryKeyColumns();
/*     */     } else {
/* 151 */       columns = this.introspectedTable.getBaseColumns();
/*     */     }
/* 153 */     for (IntrospectedColumn introspectedColumn : columns) {
/* 154 */       XmlElement resultElement = new XmlElement("arg");
/*     */       
/* 156 */       resultElement
/* 157 */         .addAttribute(new Attribute(
/* 158 */         "column", MyBatis3FormattingUtilities.getRenamedColumnNameForResultMap(introspectedColumn)));
/* 159 */       resultElement.addAttribute(new Attribute("jdbcType", 
/* 160 */         introspectedColumn.getJdbcTypeName()));
/* 161 */       resultElement.addAttribute(new Attribute("javaType", 
/* 162 */         introspectedColumn.getFullyQualifiedJavaType()
/* 163 */         .getFullyQualifiedName()));
/*     */       
/* 165 */       if (StringUtility.stringHasValue(introspectedColumn.getTypeHandler())) {
/* 166 */         resultElement.addAttribute(new Attribute(
/* 167 */           "typeHandler", introspectedColumn.getTypeHandler()));
/*     */       }
/*     */       
/* 170 */       constructor.addElement(resultElement);
/*     */     }
/*     */     
/* 173 */     answer.addElement(constructor);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\ResultMapWithoutBLOBsElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */