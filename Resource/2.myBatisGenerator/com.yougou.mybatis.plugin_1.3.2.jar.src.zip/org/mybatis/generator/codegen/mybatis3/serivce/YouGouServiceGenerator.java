/*     */ package org.mybatis.generator.codegen.mybatis3.serivce;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.YouGouServiceGeneratorConfiguration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YouGouServiceGenerator
/*     */   extends AbstractJavaGenerator
/*     */ {
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  30 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/*  32 */     FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/*  33 */       this.introspectedTable.getMyBatis3JavaServiceType());
/*  34 */     Interface interfaze = new Interface(type);
/*  35 */     interfaze.setVisibility(JavaVisibility.PUBLIC);
/*     */     
/*     */ 
/*  38 */     JavaClientGeneratorConfiguration clientConfig = this.context.getJavaClientGeneratorConfiguration();
/*  39 */     YouGouServiceGeneratorConfiguration serviceConfig = this.context.getYouGouServiceGeneratorConfiguration();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  45 */     String modelName = this.introspectedTable.getFullyQualifiedTable().getDomainObjectName();
/*  46 */     if (serviceConfig.getInterFaceExtendSupInterfaceDoMain().length() > 0)
/*     */     {
/*  48 */       interfaze.addImportedType(new FullyQualifiedJavaType(serviceConfig.getInterfaceExtendSupInterface()));
/*  49 */       String base = serviceConfig.getInterFaceExtendSupInterfaceDoMain();
/*  50 */       if (new Boolean(serviceConfig.getEnableInterfaceSupInterfaceGenericity()).booleanValue()) {
/*  51 */         interfaze.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getBaseRecordType()));
/*  52 */         interfaze.addSuperInterface(new FullyQualifiedJavaType(base + "<" + modelName + ">"));
/*     */       } else {
/*  54 */         interfaze.addSuperInterface(new FullyQualifiedJavaType(base));
/*     */       }
/*  56 */       commentGenerator.addClassComment(interfaze);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  61 */     TopLevelClass c = new TopLevelClass(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaServiceImplType()));
/*  62 */     c.addImportedType(new FullyQualifiedJavaType("javax.annotation.Resource"));
/*  63 */     c.addImportedType(new FullyQualifiedJavaType("org.springframework.stereotype.Service"));
/*  64 */     c.addImportedType(new FullyQualifiedJavaType(serviceConfig.getExtendSupClass()));
/*  65 */     c.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaMapperType()));
/*  66 */     c.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaServiceType()));
/*  67 */     if ((clientConfig.getInterfaceExtendSupInterface() != null) && (clientConfig.getInterfaceExtendSupInterface().length() > 0)) {
/*  68 */       c.addImportedType(new FullyQualifiedJavaType(clientConfig.getInterfaceExtendSupInterface()));
/*     */     }
/*     */     
/*  71 */     if (clientConfig.getInterFaceExtendSupInterfaceDoMain().length() > 0) {
/*  72 */       String ServiceName = firstCharToLower(this.introspectedTable.getMyBatis3JavaServiceType().substring(this.introspectedTable.getMyBatis3JavaServiceType().lastIndexOf(".") + 1));
/*  73 */       c.addAnnotation("@Service(\"" + ServiceName + "\")");
/*  74 */       if (new Boolean(serviceConfig.getEnableSupClassGenericity()).booleanValue()) {
/*  75 */         c.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getBaseRecordType()));
/*  76 */         c.setSuperClass(new FullyQualifiedJavaType(serviceConfig.getExtendSupClassDoMain() + "<" + modelName + ">"));
/*     */       } else {
/*  78 */         c.setSuperClass(new FullyQualifiedJavaType(serviceConfig.getExtendSupClassDoMain()));
/*     */       }
/*  80 */       c.addSuperInterface(new FullyQualifiedJavaType(modelName + "Service"));
/*     */     }
/*     */     
/*  83 */     Field field = new Field();
/*  84 */     field.addAnnotation("@Resource");
/*  85 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  86 */     field.setType(new FullyQualifiedJavaType(this.introspectedTable.getMyBatis3JavaMapperType()));
/*  87 */     String fieldName = firstCharToLower(this.introspectedTable.getMyBatis3JavaMapperType().substring(this.introspectedTable.getMyBatis3JavaMapperType().lastIndexOf(".") + 1));
/*  88 */     field.setName(fieldName);
/*  89 */     c.addField(field);
/*     */     
/*     */ 
/*  92 */     Method method = new Method();
/*  93 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  94 */     method.addAnnotation("@Override");
/*  95 */     if (new Boolean(serviceConfig.getEnableSupClassGenericity()).booleanValue()) {
/*  96 */       method.setReturnType(new FullyQualifiedJavaType(clientConfig.getInterFaceExtendSupInterfaceDoMain() + "<" + modelName + ">"));
/*     */     } else {
/*  98 */       method.setReturnType(new FullyQualifiedJavaType(clientConfig.getInterFaceExtendSupInterfaceDoMain()));
/*     */     }
/* 100 */     method.setName("init");
/* 101 */     method.addBodyLine("return " + fieldName + ";");
/* 102 */     c.addMethod(method);
/*     */     
/* 104 */     commentGenerator.addClassComment(c);
/*     */     
/* 106 */     List<CompilationUnit> answer = new ArrayList();
/* 107 */     answer.add(interfaze);
/* 108 */     answer.add(c);
/* 109 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String firstCharToLower(String modelName)
/*     */   {
/* 118 */     if (modelName.length() > 0) {
/* 119 */       modelName = new StringBuilder(String.valueOf(modelName.charAt(0))).toString().toLowerCase() + modelName.substring(1);
/*     */     } else {
/* 121 */       modelName = modelName.charAt(0).toLowerCase();
/*     */     }
/* 123 */     return modelName;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\serivce\YouGouServiceGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */