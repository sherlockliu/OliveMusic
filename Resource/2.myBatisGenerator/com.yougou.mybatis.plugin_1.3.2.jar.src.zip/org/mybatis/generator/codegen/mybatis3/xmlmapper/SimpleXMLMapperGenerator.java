/*     */ package org.mybatis.generator.codegen.mybatis3.xmlmapper;
/*     */ 
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.Document;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.AbstractXmlGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.AbstractXmlElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.DeleteByPrimaryKeyElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.InsertElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.ResultMapWithoutBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.SimpleSelectAllElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.SimpleSelectByPrimaryKeyElementGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.UpdateByPrimaryKeyWithoutBLOBsElementGenerator;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleXMLMapperGenerator
/*     */   extends AbstractXmlGenerator
/*     */ {
/*     */   protected XmlElement getSqlMapElement()
/*     */   {
/*  46 */     FullyQualifiedTable table = this.introspectedTable.getFullyQualifiedTable();
/*  47 */     this.progressCallback.startTask(Messages.getString("Progress.12", table.toString()));
/*  48 */     XmlElement answer = new XmlElement("mapper");
/*  49 */     String namespace = this.introspectedTable.getMyBatis3SqlMapNamespace();
/*  50 */     answer.addAttribute(new Attribute("namespace", 
/*  51 */       namespace));
/*     */     
/*  53 */     this.context.getCommentGenerator().addRootComment(answer);
/*     */     
/*  55 */     addResultMapElement(answer);
/*  56 */     addDeleteByPrimaryKeyElement(answer);
/*  57 */     addInsertElement(answer);
/*  58 */     addUpdateByPrimaryKeyElement(answer);
/*  59 */     addSelectByPrimaryKeyElement(answer);
/*  60 */     addSelectAllElement(answer);
/*     */     
/*  62 */     return answer;
/*     */   }
/*     */   
/*     */   protected void addResultMapElement(XmlElement parentElement) {
/*  66 */     if (this.introspectedTable.getRules().generateBaseResultMap()) {
/*  67 */       AbstractXmlElementGenerator elementGenerator = new ResultMapWithoutBLOBsElementGenerator(
/*  68 */         true);
/*  69 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByPrimaryKeyElement(XmlElement parentElement) {
/*  74 */     if (this.introspectedTable.getRules().generateSelectByPrimaryKey()) {
/*  75 */       AbstractXmlElementGenerator elementGenerator = new SimpleSelectByPrimaryKeyElementGenerator();
/*  76 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectAllElement(XmlElement parentElement) {
/*  81 */     AbstractXmlElementGenerator elementGenerator = new SimpleSelectAllElementGenerator();
/*  82 */     initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */   }
/*     */   
/*     */   protected void addDeleteByPrimaryKeyElement(XmlElement parentElement) {
/*  86 */     if (this.introspectedTable.getRules().generateDeleteByPrimaryKey()) {
/*  87 */       AbstractXmlElementGenerator elementGenerator = new DeleteByPrimaryKeyElementGenerator(true);
/*  88 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertElement(XmlElement parentElement) {
/*  93 */     if (this.introspectedTable.getRules().generateInsert()) {
/*  94 */       AbstractXmlElementGenerator elementGenerator = new InsertElementGenerator(true);
/*  95 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeyElement(XmlElement parentElement) {
/* 100 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeySelective()) {
/* 101 */       AbstractXmlElementGenerator elementGenerator = new UpdateByPrimaryKeyWithoutBLOBsElementGenerator(
/* 102 */         true);
/* 103 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initializeAndExecuteGenerator(AbstractXmlElementGenerator elementGenerator, XmlElement parentElement)
/*     */   {
/* 110 */     elementGenerator.setContext(this.context);
/* 111 */     elementGenerator.setIntrospectedTable(this.introspectedTable);
/* 112 */     elementGenerator.setProgressCallback(this.progressCallback);
/* 113 */     elementGenerator.setWarnings(this.warnings);
/* 114 */     elementGenerator.addElements(parentElement);
/*     */   }
/*     */   
/*     */   public Document getDocument()
/*     */   {
/* 119 */     Document document = new Document(
/* 120 */       "-//mybatis.org//DTD Mapper 3.0//EN", 
/* 121 */       "http://mybatis.org/dtd/mybatis-3-mapper.dtd");
/* 122 */     document.setRootElement(getSqlMapElement());
/*     */     
/* 124 */     if (!this.context.getPlugins().sqlMapDocumentGenerated(document, 
/* 125 */       this.introspectedTable)) {
/* 126 */       document = null;
/*     */     }
/*     */     
/* 129 */     return document;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\SimpleXMLMapperGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */