/*    */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedColumn;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.TextElement;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*    */ import org.mybatis.generator.config.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeleteByPrimarayKeyForModelElementGenerator
/*    */   extends AbstractXmlElementGenerator
/*    */ {
/*    */   public void addElements(XmlElement parentElement)
/*    */   {
/* 39 */     XmlElement answer = new XmlElement("delete");
/*    */     
/* 41 */     answer.addAttribute(new Attribute(
/* 42 */       "id", "deleteByPrimarayKeyForModel"));
/* 43 */     answer.addAttribute(new Attribute("parameterType", this.introspectedTable.getBaseRecordType()));
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 60 */     this.context.getCommentGenerator().addComment(answer);
/*    */     
/* 62 */     StringBuilder sb = new StringBuilder();
/* 63 */     sb.append("DELETE FROM ");
/* 64 */     sb.append(this.introspectedTable.getFullyQualifiedTableNameAtRuntime());
/* 65 */     answer.addElement(new TextElement(sb.toString()));
/*    */     
/* 67 */     boolean and = false;
/*    */     
/* 69 */     Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/* 68 */     while (localIterator.hasNext()) {
/* 69 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/* 70 */       sb.setLength(0);
/* 71 */       if (and) {
/* 72 */         sb.append("  AND ");
/*    */       } else {
/* 74 */         sb.append("WHERE ");
/* 75 */         and = true;
/*    */       }
/*    */       
/* 78 */       sb.append(
/* 79 */         MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn));
/* 80 */       sb.append(" = ");
/* 81 */       sb.append(
/* 82 */         MyBatis3FormattingUtilities.getParameterClause(introspectedColumn));
/* 83 */       answer.addElement(new TextElement(sb.toString()));
/*    */     }
/*    */     
/*    */ 
/* 87 */     if (this.context.getPlugins().sqlMapDeleteByPrimaryKeyElementGenerated(answer, 
/* 88 */       this.introspectedTable)) {
/* 89 */       parentElement.addElement(answer);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\DeleteByPrimarayKeyForModelElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */