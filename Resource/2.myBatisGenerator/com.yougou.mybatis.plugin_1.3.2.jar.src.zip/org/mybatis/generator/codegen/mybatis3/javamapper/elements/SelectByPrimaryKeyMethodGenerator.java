/*     */ package org.mybatis.generator.codegen.mybatis3.javamapper.elements;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectByPrimaryKeyMethodGenerator
/*     */   extends AbstractJavaMapperMethodGenerator
/*     */ {
/*     */   private boolean isSimple;
/*     */   
/*     */   public SelectByPrimaryKeyMethodGenerator(boolean isSimple)
/*     */   {
/*  41 */     this.isSimple = isSimple;
/*     */   }
/*     */   
/*     */   public void addInterfaceElements(Interface interfaze)
/*     */   {
/*  46 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  47 */     Method method = new Method();
/*  48 */     method.setVisibility(JavaVisibility.PUBLIC);
/*     */     
/*  50 */     FullyQualifiedJavaType returnType = this.introspectedTable.getRules()
/*  51 */       .calculateAllFieldsClass();
/*  52 */     method.setReturnType(returnType);
/*  53 */     importedTypes.add(returnType);
/*     */     
/*  55 */     method.setName(this.introspectedTable.getSelectByPrimaryKeyStatementId());
/*     */     
/*  57 */     if ((!this.isSimple) && (this.introspectedTable.getRules().generatePrimaryKeyClass())) {
/*  58 */       FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/*  59 */         this.introspectedTable.getPrimaryKeyType());
/*  60 */       importedTypes.add(type);
/*  61 */       method.addParameter(new Parameter(type, "key"));
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  67 */       List<IntrospectedColumn> introspectedColumns = this.introspectedTable
/*  68 */         .getPrimaryKeyColumns();
/*  69 */       boolean annotate = introspectedColumns.size() > 1;
/*  70 */       if (annotate) {
/*  71 */         importedTypes.add(new FullyQualifiedJavaType(
/*  72 */           "org.apache.ibatis.annotations.Param"));
/*     */       }
/*  74 */       StringBuilder sb = new StringBuilder();
/*  75 */       for (IntrospectedColumn introspectedColumn : introspectedColumns) {
/*  76 */         FullyQualifiedJavaType type = introspectedColumn
/*  77 */           .getFullyQualifiedJavaType();
/*  78 */         importedTypes.add(type);
/*  79 */         Parameter parameter = new Parameter(type, introspectedColumn
/*  80 */           .getJavaProperty());
/*  81 */         if (annotate) {
/*  82 */           sb.setLength(0);
/*  83 */           sb.append("@Param(\"");
/*  84 */           sb.append(introspectedColumn.getJavaProperty());
/*  85 */           sb.append("\")");
/*  86 */           parameter.addAnnotation(sb.toString());
/*     */         }
/*  88 */         method.addParameter(parameter);
/*     */       }
/*     */     }
/*     */     
/*  92 */     addMapperAnnotations(interfaze, method);
/*     */     
/*  94 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/*  95 */       this.introspectedTable);
/*     */     
/*  97 */     if (this.context.getPlugins().clientSelectByPrimaryKeyMethodGenerated(
/*  98 */       method, interfaze, this.introspectedTable)) {
/*  99 */       interfaze.addImportedTypes(importedTypes);
/* 100 */       interfaze.addMethod(method);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addMapperAnnotations(Interface interfaze, Method method) {}
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\elements\SelectByPrimaryKeyMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */