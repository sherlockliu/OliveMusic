/*    */ package org.mybatis.generator.codegen.mybatis3.javamapper;
/*    */ 
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.dom.java.Interface;
/*    */ import org.mybatis.generator.codegen.AbstractXmlGenerator;
/*    */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.AbstractJavaMapperMethodGenerator;
/*    */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedDeleteByPrimaryKeyMethodGenerator;
/*    */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedInsertMethodGenerator;
/*    */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedSelectAllMethodGenerator;
/*    */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedSelectByPrimaryKeyMethodGenerator;
/*    */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.annotated.AnnotatedUpdateByPrimaryKeyWithoutBLOBsMethodGenerator;
/*    */ import org.mybatis.generator.internal.rules.Rules;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleAnnotatedClientGenerator
/*    */   extends SimpleJavaClientGenerator
/*    */ {
/*    */   public SimpleAnnotatedClientGenerator()
/*    */   {
/* 38 */     super(false);
/*    */   }
/*    */   
/*    */   protected void addDeleteByPrimaryKeyMethod(Interface interfaze)
/*    */   {
/* 43 */     if (this.introspectedTable.getRules().generateDeleteByPrimaryKey()) {
/* 44 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedDeleteByPrimaryKeyMethodGenerator(true);
/* 45 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void addInsertMethod(Interface interfaze)
/*    */   {
/* 51 */     if (this.introspectedTable.getRules().generateInsert()) {
/* 52 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedInsertMethodGenerator(true);
/* 53 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void addSelectByPrimaryKeyMethod(Interface interfaze)
/*    */   {
/* 59 */     if (this.introspectedTable.getRules().generateSelectByPrimaryKey()) {
/* 60 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedSelectByPrimaryKeyMethodGenerator(false, true);
/* 61 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void addSelectAllMethod(Interface interfaze)
/*    */   {
/* 67 */     AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedSelectAllMethodGenerator();
/* 68 */     initializeAndExecuteGenerator(methodGenerator, interfaze);
/*    */   }
/*    */   
/*    */   protected void addUpdateByPrimaryKeyMethod(Interface interfaze)
/*    */   {
/* 73 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeySelective()) {
/* 74 */       AbstractJavaMapperMethodGenerator methodGenerator = new AnnotatedUpdateByPrimaryKeyWithoutBLOBsMethodGenerator(true);
/* 75 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*    */     }
/*    */   }
/*    */   
/*    */   public AbstractXmlGenerator getMatchedXMLGenerator()
/*    */   {
/* 81 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\SimpleAnnotatedClientGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */