/*    */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedColumn;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.TextElement;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*    */ import org.mybatis.generator.config.Context;
/*    */ import org.mybatis.generator.internal.rules.Rules;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeleteByPrimaryKeyElementGenerator
/*    */   extends AbstractXmlElementGenerator
/*    */ {
/*    */   private boolean isSimple;
/*    */   
/*    */   public DeleteByPrimaryKeyElementGenerator(boolean isSimple)
/*    */   {
/* 36 */     this.isSimple = isSimple;
/*    */   }
/*    */   
/*    */   public void addElements(XmlElement parentElement)
/*    */   {
/* 41 */     XmlElement answer = new XmlElement("delete");
/*    */     
/* 43 */     answer.addAttribute(new Attribute(
/* 44 */       "id", this.introspectedTable.getDeleteByPrimaryKeyStatementId()));
/*    */     String parameterClass;
/* 46 */     String parameterClass; if ((!this.isSimple) && (this.introspectedTable.getRules().generatePrimaryKeyClass())) {
/* 47 */       parameterClass = this.introspectedTable.getPrimaryKeyType();
/*    */     }
/*    */     else {
/*    */       String parameterClass;
/* 51 */       if (this.introspectedTable.getPrimaryKeyColumns().size() > 1) {
/* 52 */         parameterClass = "map";
/*    */       } else {
/* 54 */         parameterClass = 
/* 55 */           ((IntrospectedColumn)this.introspectedTable.getPrimaryKeyColumns().get(0)).getFullyQualifiedJavaType().toString();
/*    */       }
/*    */     }
/* 58 */     answer.addAttribute(new Attribute("parameterType", 
/* 59 */       parameterClass));
/*    */     
/* 61 */     this.context.getCommentGenerator().addComment(answer);
/*    */     
/* 63 */     StringBuilder sb = new StringBuilder();
/* 64 */     sb.append("DELETE FROM ");
/* 65 */     sb.append(this.introspectedTable.getFullyQualifiedTableNameAtRuntime());
/* 66 */     answer.addElement(new TextElement(sb.toString()));
/*    */     
/* 68 */     boolean and = false;
/*    */     
/* 70 */     Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/* 69 */     while (localIterator.hasNext()) {
/* 70 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/* 71 */       sb.setLength(0);
/* 72 */       if (and) {
/* 73 */         sb.append("  AND ");
/*    */       } else {
/* 75 */         sb.append("WHERE ");
/* 76 */         and = true;
/*    */       }
/*    */       
/* 79 */       sb.append(
/* 80 */         MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn));
/* 81 */       sb.append(" = ");
/* 82 */       sb.append(
/* 83 */         MyBatis3FormattingUtilities.getParameterClause(introspectedColumn));
/* 84 */       answer.addElement(new TextElement(sb.toString()));
/*    */     }
/*    */     
/*    */ 
/* 88 */     if (this.context.getPlugins().sqlMapDeleteByPrimaryKeyElementGenerated(answer, 
/* 89 */       this.introspectedTable)) {
/* 90 */       parentElement.addElement(answer);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\DeleteByPrimaryKeyElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */