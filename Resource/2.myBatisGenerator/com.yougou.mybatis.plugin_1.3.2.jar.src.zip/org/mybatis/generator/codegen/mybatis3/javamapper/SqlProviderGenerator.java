/*     */ package org.mybatis.generator.codegen.mybatis3.javamapper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider.AbstractJavaProviderMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider.ProviderApplyWhereMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider.ProviderCountByExampleMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider.ProviderDeleteByExampleMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider.ProviderInsertSelectiveMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider.ProviderSelectByExampleWithBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider.ProviderSelectByExampleWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider.ProviderUpdateByExampleSelectiveMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider.ProviderUpdateByExampleWithBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider.ProviderUpdateByExampleWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.sqlprovider.ProviderUpdateByPrimaryKeySelectiveMethodGenerator;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlProviderGenerator
/*     */   extends AbstractJavaGenerator
/*     */ {
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  54 */     this.progressCallback.startTask(Messages.getString("Progress.18", 
/*  55 */       this.introspectedTable.getFullyQualifiedTable().toString()));
/*  56 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/*  58 */     FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/*  59 */       this.introspectedTable.getMyBatis3SqlProviderType());
/*  60 */     TopLevelClass topLevelClass = new TopLevelClass(type);
/*  61 */     topLevelClass.setVisibility(JavaVisibility.PUBLIC);
/*  62 */     commentGenerator.addJavaFileComment(topLevelClass);
/*     */     
/*  64 */     boolean addApplyWhereMethod = false;
/*  65 */     addApplyWhereMethod |= addCountByExampleMethod(topLevelClass);
/*  66 */     addApplyWhereMethod |= addDeleteByExampleMethod(topLevelClass);
/*  67 */     addInsertSelectiveMethod(topLevelClass);
/*  68 */     addApplyWhereMethod |= addSelectByExampleWithBLOBsMethod(topLevelClass);
/*  69 */     addApplyWhereMethod |= addSelectByExampleWithoutBLOBsMethod(topLevelClass);
/*  70 */     addApplyWhereMethod |= addUpdateByExampleSelectiveMethod(topLevelClass);
/*  71 */     addApplyWhereMethod |= addUpdateByExampleWithBLOBsMethod(topLevelClass);
/*  72 */     addApplyWhereMethod |= addUpdateByExampleWithoutBLOBsMethod(topLevelClass);
/*  73 */     addUpdateByPrimaryKeySelectiveMethod(topLevelClass);
/*     */     
/*  75 */     if (addApplyWhereMethod) {
/*  76 */       addApplyWhereMethod(topLevelClass);
/*     */     }
/*     */     
/*  79 */     List<CompilationUnit> answer = new ArrayList();
/*     */     
/*  81 */     if ((topLevelClass.getMethods().size() > 0) && 
/*  82 */       (this.context.getPlugins().providerGenerated(topLevelClass, 
/*  83 */       this.introspectedTable))) {
/*  84 */       answer.add(topLevelClass);
/*     */     }
/*     */     
/*     */ 
/*  88 */     return answer;
/*     */   }
/*     */   
/*     */   protected boolean addCountByExampleMethod(TopLevelClass topLevelClass) {
/*  92 */     boolean rc = false;
/*  93 */     if (this.introspectedTable.getRules().generateCountByExample()) {
/*  94 */       AbstractJavaProviderMethodGenerator methodGenerator = new ProviderCountByExampleMethodGenerator();
/*  95 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass);
/*  96 */       rc = true;
/*     */     }
/*     */     
/*  99 */     return rc;
/*     */   }
/*     */   
/*     */   protected boolean addDeleteByExampleMethod(TopLevelClass topLevelClass) {
/* 103 */     boolean rc = false;
/* 104 */     if (this.introspectedTable.getRules().generateDeleteByExample()) {
/* 105 */       AbstractJavaProviderMethodGenerator methodGenerator = new ProviderDeleteByExampleMethodGenerator();
/* 106 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass);
/* 107 */       rc = true;
/*     */     }
/*     */     
/* 110 */     return rc;
/*     */   }
/*     */   
/*     */   protected void addInsertSelectiveMethod(TopLevelClass topLevelClass) {
/* 114 */     if (this.introspectedTable.getRules().generateInsertSelective()) {
/* 115 */       AbstractJavaProviderMethodGenerator methodGenerator = new ProviderInsertSelectiveMethodGenerator();
/* 116 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass);
/*     */     }
/*     */   }
/*     */   
/*     */   protected boolean addSelectByExampleWithBLOBsMethod(TopLevelClass topLevelClass)
/*     */   {
/* 122 */     boolean rc = false;
/* 123 */     if (this.introspectedTable.getRules().generateSelectByExampleWithBLOBs()) {
/* 124 */       AbstractJavaProviderMethodGenerator methodGenerator = new ProviderSelectByExampleWithBLOBsMethodGenerator();
/* 125 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass);
/* 126 */       rc = true;
/*     */     }
/*     */     
/* 129 */     return rc;
/*     */   }
/*     */   
/*     */   protected boolean addSelectByExampleWithoutBLOBsMethod(TopLevelClass topLevelClass)
/*     */   {
/* 134 */     boolean rc = false;
/* 135 */     if (this.introspectedTable.getRules().generateSelectByExampleWithoutBLOBs()) {
/* 136 */       AbstractJavaProviderMethodGenerator methodGenerator = new ProviderSelectByExampleWithoutBLOBsMethodGenerator();
/* 137 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass);
/* 138 */       rc = true;
/*     */     }
/*     */     
/* 141 */     return rc;
/*     */   }
/*     */   
/*     */   protected boolean addUpdateByExampleSelectiveMethod(TopLevelClass topLevelClass)
/*     */   {
/* 146 */     boolean rc = false;
/* 147 */     if (this.introspectedTable.getRules().generateUpdateByExampleSelective()) {
/* 148 */       AbstractJavaProviderMethodGenerator methodGenerator = new ProviderUpdateByExampleSelectiveMethodGenerator();
/* 149 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass);
/* 150 */       rc = true;
/*     */     }
/*     */     
/* 153 */     return rc;
/*     */   }
/*     */   
/*     */   protected boolean addUpdateByExampleWithBLOBsMethod(TopLevelClass topLevelClass)
/*     */   {
/* 158 */     boolean rc = false;
/* 159 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithBLOBs()) {
/* 160 */       AbstractJavaProviderMethodGenerator methodGenerator = new ProviderUpdateByExampleWithBLOBsMethodGenerator();
/* 161 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass);
/* 162 */       rc = true;
/*     */     }
/*     */     
/* 165 */     return rc;
/*     */   }
/*     */   
/*     */   protected boolean addUpdateByExampleWithoutBLOBsMethod(TopLevelClass topLevelClass)
/*     */   {
/* 170 */     boolean rc = false;
/* 171 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithoutBLOBs()) {
/* 172 */       AbstractJavaProviderMethodGenerator methodGenerator = new ProviderUpdateByExampleWithoutBLOBsMethodGenerator();
/* 173 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass);
/* 174 */       rc = true;
/*     */     }
/*     */     
/* 177 */     return rc;
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeySelectiveMethod(TopLevelClass topLevelClass)
/*     */   {
/* 182 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeySelective()) {
/* 183 */       AbstractJavaProviderMethodGenerator methodGenerator = new ProviderUpdateByPrimaryKeySelectiveMethodGenerator();
/* 184 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addApplyWhereMethod(TopLevelClass topLevelClass) {
/* 189 */     AbstractJavaProviderMethodGenerator methodGenerator = new ProviderApplyWhereMethodGenerator();
/* 190 */     initializeAndExecuteGenerator(methodGenerator, topLevelClass);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initializeAndExecuteGenerator(AbstractJavaProviderMethodGenerator methodGenerator, TopLevelClass topLevelClass)
/*     */   {
/* 196 */     methodGenerator.setContext(this.context);
/* 197 */     methodGenerator.setIntrospectedTable(this.introspectedTable);
/* 198 */     methodGenerator.setProgressCallback(this.progressCallback);
/* 199 */     methodGenerator.setWarnings(this.warnings);
/* 200 */     methodGenerator.addClassElements(topLevelClass);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\SqlProviderGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */