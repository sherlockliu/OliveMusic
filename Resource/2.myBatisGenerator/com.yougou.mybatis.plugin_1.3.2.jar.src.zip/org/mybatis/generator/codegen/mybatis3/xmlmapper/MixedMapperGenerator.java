package org.mybatis.generator.codegen.mybatis3.xmlmapper;

import org.mybatis.generator.api.dom.xml.XmlElement;

public class MixedMapperGenerator
  extends XMLMapperGenerator
{
  protected void addSelectByPrimaryKeyElement(XmlElement parentElement) {}
  
  protected void addDeleteByPrimaryKeyElement(XmlElement parentElement) {}
  
  protected void addInsertElement(XmlElement parentElement) {}
  
  protected void addUpdateByPrimaryKeyWithBLOBsElement(XmlElement parentElement) {}
  
  protected void addUpdateByPrimaryKeyWithoutBLOBsElement(XmlElement parentElement) {}
}


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\MixedMapperGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */