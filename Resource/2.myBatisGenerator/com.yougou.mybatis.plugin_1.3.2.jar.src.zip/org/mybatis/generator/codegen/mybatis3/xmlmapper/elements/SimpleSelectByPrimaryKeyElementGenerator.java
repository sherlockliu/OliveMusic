/*     */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleSelectByPrimaryKeyElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  42 */     XmlElement answer = new XmlElement("select");
/*     */     
/*  44 */     answer.addAttribute(new Attribute(
/*  45 */       "id", this.introspectedTable.getSelectByPrimaryKeyStatementId()));
/*  46 */     answer.addAttribute(new Attribute("resultMap", 
/*  47 */       this.introspectedTable.getBaseResultMapId()));
/*     */     
/*     */     String parameterType;
/*     */     
/*     */     String parameterType;
/*  52 */     if (this.introspectedTable.getPrimaryKeyColumns().size() > 1) {
/*  53 */       parameterType = "map";
/*     */     } else {
/*  55 */       parameterType = 
/*  56 */         ((IntrospectedColumn)this.introspectedTable.getPrimaryKeyColumns().get(0)).getFullyQualifiedJavaType().toString();
/*     */     }
/*     */     
/*  59 */     answer.addAttribute(new Attribute("parameterType", 
/*  60 */       parameterType));
/*     */     
/*  62 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  64 */     StringBuilder sb = new StringBuilder();
/*  65 */     sb.append("SELECT ");
/*     */     
/*  67 */     if (StringUtility.stringHasValue(this.introspectedTable.getSelectByPrimaryKeyQueryId())) {
/*  68 */       sb.append('\'');
/*  69 */       sb.append(this.introspectedTable.getSelectByPrimaryKeyQueryId());
/*  70 */       sb.append("' as QUERYID,");
/*     */     }
/*     */     
/*  73 */     Iterator<IntrospectedColumn> iter = this.introspectedTable.getAllColumns()
/*  74 */       .iterator();
/*  75 */     while (iter.hasNext()) {
/*  76 */       sb.append(MyBatis3FormattingUtilities.getSelectListPhrase(
/*  77 */         (IntrospectedColumn)iter.next()));
/*     */       
/*  79 */       if (iter.hasNext()) {
/*  80 */         sb.append(", ");
/*     */       }
/*     */       
/*  83 */       if (sb.length() > 80) {
/*  84 */         answer.addElement(new TextElement(sb.toString()));
/*  85 */         sb.setLength(0);
/*     */       }
/*     */     }
/*     */     
/*  89 */     if (sb.length() > 0) {
/*  90 */       answer.addElement(new TextElement(sb.toString()));
/*     */     }
/*     */     
/*  93 */     sb.setLength(0);
/*  94 */     sb.append("FROM ");
/*  95 */     sb.append(this.introspectedTable
/*  96 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/*  97 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*  99 */     boolean and = false;
/*     */     
/* 101 */     Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/* 100 */     while (localIterator.hasNext()) {
/* 101 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/* 102 */       sb.setLength(0);
/* 103 */       if (and) {
/* 104 */         sb.append("  AND ");
/*     */       } else {
/* 106 */         sb.append("WHERE ");
/* 107 */         and = true;
/*     */       }
/*     */       
/* 110 */       sb.append(
/* 111 */         MyBatis3FormattingUtilities.getAliasedEscapedColumnName(introspectedColumn));
/* 112 */       sb.append(" = ");
/* 113 */       sb.append(
/* 114 */         MyBatis3FormattingUtilities.getParameterClause(introspectedColumn));
/* 115 */       answer.addElement(new TextElement(sb.toString()));
/*     */     }
/*     */     
/* 118 */     if (this.context.getPlugins().sqlMapSelectByPrimaryKeyElementGenerated(
/* 119 */       answer, this.introspectedTable)) {
/* 120 */       parentElement.addElement(answer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\SimpleSelectByPrimaryKeyElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */