/*    */ package org.mybatis.generator.codegen.mybatis3.javamapper.elements;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*    */ import org.mybatis.generator.api.dom.java.Interface;
/*    */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*    */ import org.mybatis.generator.api.dom.java.Method;
/*    */ import org.mybatis.generator.api.dom.java.Parameter;
/*    */ import org.mybatis.generator.config.Context;
/*    */ import org.mybatis.generator.internal.rules.Rules;
/*    */ import org.mybatis.generator.internal.util.messages.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectByExampleWithoutBLOBsMethodGenerator
/*    */   extends AbstractJavaMapperMethodGenerator
/*    */ {
/*    */   public void addInterfaceElements(Interface interfaze)
/*    */   {
/* 43 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/* 44 */     FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/* 45 */       this.introspectedTable.getExampleType());
/* 46 */     importedTypes.add(type);
/* 47 */     importedTypes.add(FullyQualifiedJavaType.getNewListInstance());
/*    */     
/* 49 */     Method method = new Method();
/* 50 */     method.setVisibility(JavaVisibility.PUBLIC);
/*    */     
/* 52 */     FullyQualifiedJavaType returnType = 
/* 53 */       FullyQualifiedJavaType.getNewListInstance();
/*    */     FullyQualifiedJavaType listType;
/* 55 */     if (this.introspectedTable.getRules().generateBaseRecordClass()) {
/* 56 */       listType = new FullyQualifiedJavaType(this.introspectedTable
/* 57 */         .getBaseRecordType()); } else { FullyQualifiedJavaType listType;
/* 58 */       if (this.introspectedTable.getRules().generatePrimaryKeyClass()) {
/* 59 */         listType = new FullyQualifiedJavaType(this.introspectedTable
/* 60 */           .getPrimaryKeyType());
/*    */       } else
/* 62 */         throw new RuntimeException(Messages.getString("RuntimeError.12"));
/*    */     }
/*    */     FullyQualifiedJavaType listType;
/* 65 */     importedTypes.add(listType);
/* 66 */     returnType.addTypeArgument(listType);
/* 67 */     method.setReturnType(returnType);
/*    */     
/* 69 */     method.setName(this.introspectedTable.getSelectByExampleStatementId());
/* 70 */     method.addParameter(new Parameter(type, "example"));
/*    */     
/* 72 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 73 */       this.introspectedTable);
/*    */     
/* 75 */     addMapperAnnotations(interfaze, method);
/*    */     
/*    */ 
/* 78 */     if (this.context.getPlugins().clientSelectByExampleWithoutBLOBsMethodGenerated(method, 
/* 79 */       interfaze, this.introspectedTable)) {
/* 80 */       interfaze.addImportedTypes(importedTypes);
/* 81 */       interfaze.addMethod(method);
/*    */     }
/*    */   }
/*    */   
/*    */   public void addMapperAnnotations(Interface interfaze, Method method) {}
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\elements\SelectByExampleWithoutBLOBsMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */