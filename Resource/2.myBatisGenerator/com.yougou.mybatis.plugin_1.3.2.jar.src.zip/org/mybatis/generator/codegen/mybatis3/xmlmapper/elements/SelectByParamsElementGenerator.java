/*     */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectByParamsElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  41 */     XmlElement answer = new XmlElement("select");
/*     */     
/*  43 */     answer.addAttribute(new Attribute(
/*  44 */       "id", "selectByParams"));
/*  45 */     answer.addAttribute(new Attribute("resultMap", 
/*  46 */       this.introspectedTable.getBaseResultMapId()));
/*     */     
/*  48 */     answer.addAttribute(new Attribute("parameterType", 
/*  49 */       "map"));
/*     */     
/*  51 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  53 */     StringBuilder sb = new StringBuilder();
/*  54 */     sb.append("SELECT ");
/*     */     
/*  56 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */     if (this.introspectedTable.getRules().generateBaseColumnList()) {
/*  63 */       answer.addElement(getBaseColumnListElement());
/*     */     } else {
/*  65 */       sb.setLength(0);
/*  66 */       Iterator<IntrospectedColumn> iter = this.introspectedTable
/*  67 */         .getNonBLOBColumns().iterator();
/*  68 */       while (iter.hasNext()) {
/*  69 */         sb.append(MyBatis3FormattingUtilities.getSelectListPhrase(
/*  70 */           (IntrospectedColumn)iter.next()));
/*     */         
/*  72 */         if (iter.hasNext()) {
/*  73 */           sb.append(", ");
/*     */         }
/*     */         
/*  76 */         if (sb.length() > 80) {
/*  77 */           answer.addElement(new TextElement(sb.toString()));
/*  78 */           sb.setLength(0);
/*     */         }
/*     */       }
/*  81 */       answer.addElement(new TextElement(sb.toString()));
/*     */     }
/*     */     
/*  84 */     if (this.introspectedTable.hasBLOBColumns()) {
/*  85 */       answer.addElement(new TextElement(","));
/*  86 */       answer.addElement(getBlobColumnListElement());
/*     */     }
/*     */     
/*  89 */     sb.setLength(0);
/*  90 */     sb.append(" FROM ");
/*  91 */     sb.append(this.introspectedTable
/*  92 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/*  93 */     sb.append(" WHERE 1=1 ");
/*  94 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     XmlElement sqlElement = new XmlElement("include");
/* 102 */     sqlElement.addAttribute(new Attribute("refid", "condition"));
/* 103 */     answer.addElement(sqlElement);
/*     */     
/* 105 */     parentElement.addElement(answer);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\SelectByParamsElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */