/*      */ package org.mybatis.generator.codegen.mybatis3.model;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import org.mybatis.generator.api.CommentGenerator;
/*      */ import org.mybatis.generator.api.FullyQualifiedTable;
/*      */ import org.mybatis.generator.api.IntrospectedColumn;
/*      */ import org.mybatis.generator.api.IntrospectedTable;
/*      */ import org.mybatis.generator.api.Plugin;
/*      */ import org.mybatis.generator.api.ProgressCallback;
/*      */ import org.mybatis.generator.api.dom.OutputUtilities;
/*      */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*      */ import org.mybatis.generator.api.dom.java.Field;
/*      */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*      */ import org.mybatis.generator.api.dom.java.InnerClass;
/*      */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*      */ import org.mybatis.generator.api.dom.java.Method;
/*      */ import org.mybatis.generator.api.dom.java.Parameter;
/*      */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*      */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*      */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*      */ import org.mybatis.generator.config.Context;
/*      */ import org.mybatis.generator.internal.util.JavaBeansUtil;
/*      */ import org.mybatis.generator.internal.util.StringUtility;
/*      */ import org.mybatis.generator.internal.util.messages.Messages;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ExampleGenerator
/*      */   extends AbstractJavaGenerator
/*      */ {
/*      */   public List<CompilationUnit> getCompilationUnits()
/*      */   {
/*   54 */     FullyQualifiedTable table = this.introspectedTable.getFullyQualifiedTable();
/*   55 */     this.progressCallback.startTask(Messages.getString(
/*   56 */       "Progress.6", table.toString()));
/*   57 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*      */     
/*   59 */     FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/*   60 */       this.introspectedTable.getExampleType());
/*   61 */     TopLevelClass topLevelClass = new TopLevelClass(type);
/*   62 */     topLevelClass.setVisibility(JavaVisibility.PUBLIC);
/*   63 */     commentGenerator.addJavaFileComment(topLevelClass);
/*      */     
/*      */ 
/*   66 */     Method method = new Method();
/*   67 */     method.setVisibility(JavaVisibility.PUBLIC);
/*   68 */     method.setConstructor(true);
/*   69 */     method.setName(type.getShortName());
/*   70 */     method.addBodyLine("oredCriteria = new ArrayList<Criteria>();");
/*      */     
/*   72 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*   73 */     topLevelClass.addMethod(method);
/*      */     
/*      */ 
/*   76 */     Field field = new Field();
/*   77 */     field.setVisibility(JavaVisibility.PROTECTED);
/*   78 */     field.setType(FullyQualifiedJavaType.getStringInstance());
/*   79 */     field.setName("orderByClause");
/*   80 */     commentGenerator.addFieldComment(field, this.introspectedTable);
/*   81 */     topLevelClass.addField(field);
/*      */     
/*   83 */     method = new Method();
/*   84 */     method.setVisibility(JavaVisibility.PUBLIC);
/*   85 */     method.setName("setOrderByClause");
/*   86 */     method.addParameter(new Parameter(
/*   87 */       FullyQualifiedJavaType.getStringInstance(), "orderByClause"));
/*   88 */     method.addBodyLine("this.orderByClause = orderByClause;");
/*   89 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*   90 */     topLevelClass.addMethod(method);
/*      */     
/*   92 */     method = new Method();
/*   93 */     method.setVisibility(JavaVisibility.PUBLIC);
/*   94 */     method.setReturnType(FullyQualifiedJavaType.getStringInstance());
/*   95 */     method.setName("getOrderByClause");
/*   96 */     method.addBodyLine("return orderByClause;");
/*   97 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*   98 */     topLevelClass.addMethod(method);
/*      */     
/*      */ 
/*  101 */     field = new Field();
/*  102 */     field.setVisibility(JavaVisibility.PROTECTED);
/*  103 */     field.setType(FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  104 */     field.setName("distinct");
/*  105 */     commentGenerator.addFieldComment(field, this.introspectedTable);
/*  106 */     topLevelClass.addField(field);
/*      */     
/*  108 */     method = new Method();
/*  109 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  110 */     method.setName("setDistinct");
/*  111 */     method.addParameter(new Parameter(
/*  112 */       FullyQualifiedJavaType.getBooleanPrimitiveInstance(), "distinct"));
/*  113 */     method.addBodyLine("this.distinct = distinct;");
/*  114 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  115 */     topLevelClass.addMethod(method);
/*      */     
/*  117 */     method = new Method();
/*  118 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  119 */     method.setReturnType(
/*  120 */       FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  121 */     method.setName("isDistinct");
/*  122 */     method.addBodyLine("return distinct;");
/*  123 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  124 */     topLevelClass.addMethod(method);
/*      */     
/*      */ 
/*  127 */     field = new Field();
/*  128 */     field.setVisibility(JavaVisibility.PROTECTED);
/*      */     
/*  130 */     FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
/*  131 */       "java.util.List<Criteria>");
/*  132 */     field.setType(fqjt);
/*  133 */     field.setName("oredCriteria");
/*  134 */     commentGenerator.addFieldComment(field, this.introspectedTable);
/*  135 */     topLevelClass.addField(field);
/*      */     
/*  137 */     method = new Method();
/*  138 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  139 */     method.setReturnType(fqjt);
/*  140 */     method.setName("getOredCriteria");
/*  141 */     method.addBodyLine("return oredCriteria;");
/*  142 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  143 */     topLevelClass.addMethod(method);
/*      */     
/*  145 */     method = new Method();
/*  146 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  147 */     method.setName("or");
/*  148 */     method.addParameter(new Parameter(
/*  149 */       FullyQualifiedJavaType.getCriteriaInstance(), "criteria"));
/*  150 */     method.addBodyLine("oredCriteria.add(criteria);");
/*  151 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  152 */     topLevelClass.addMethod(method);
/*      */     
/*  154 */     method = new Method();
/*  155 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  156 */     method.setName("or");
/*  157 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  158 */     method.addBodyLine("Criteria criteria = createCriteriaInternal();");
/*  159 */     method.addBodyLine("oredCriteria.add(criteria);");
/*  160 */     method.addBodyLine("return criteria;");
/*  161 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  162 */     topLevelClass.addMethod(method);
/*      */     
/*  164 */     method = new Method();
/*  165 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  166 */     method.setName("createCriteria");
/*  167 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  168 */     method.addBodyLine("Criteria criteria = createCriteriaInternal();");
/*  169 */     method.addBodyLine("if (oredCriteria.size() == 0) {");
/*  170 */     method.addBodyLine("oredCriteria.add(criteria);");
/*  171 */     method.addBodyLine("}");
/*  172 */     method.addBodyLine("return criteria;");
/*  173 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  174 */     topLevelClass.addMethod(method);
/*      */     
/*  176 */     method = new Method();
/*  177 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  178 */     method.setName("createCriteriaInternal");
/*  179 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  180 */     method.addBodyLine("Criteria criteria = new Criteria();");
/*  181 */     method.addBodyLine("return criteria;");
/*  182 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  183 */     topLevelClass.addMethod(method);
/*      */     
/*  185 */     method = new Method();
/*  186 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  187 */     method.setName("clear");
/*  188 */     method.addBodyLine("oredCriteria.clear();");
/*  189 */     method.addBodyLine("orderByClause = null;");
/*  190 */     method.addBodyLine("distinct = false;");
/*  191 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  192 */     topLevelClass.addMethod(method);
/*      */     
/*      */ 
/*  195 */     topLevelClass
/*  196 */       .addInnerClass(getGeneratedCriteriaInnerClass(topLevelClass));
/*      */     
/*  198 */     topLevelClass.addInnerClass(getCriteriaInnerClass(topLevelClass));
/*      */     
/*  200 */     topLevelClass.addInnerClass(getCriterionInnerClass(topLevelClass));
/*      */     
/*  202 */     List<CompilationUnit> answer = new ArrayList();
/*  203 */     if (this.context.getPlugins().modelExampleClassGenerated(
/*  204 */       topLevelClass, this.introspectedTable)) {
/*  205 */       answer.add(topLevelClass);
/*      */     }
/*  207 */     return answer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private InnerClass getCriterionInnerClass(TopLevelClass topLevelClass)
/*      */   {
/*  214 */     InnerClass answer = new InnerClass(new FullyQualifiedJavaType(
/*  215 */       "Criterion"));
/*  216 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  217 */     answer.setStatic(true);
/*  218 */     this.context.getCommentGenerator().addClassComment(answer, 
/*  219 */       this.introspectedTable);
/*      */     
/*  221 */     Field field = new Field();
/*  222 */     field.setName("condition");
/*  223 */     field.setType(FullyQualifiedJavaType.getStringInstance());
/*  224 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  225 */     answer.addField(field);
/*  226 */     answer.addMethod(getGetter(field));
/*      */     
/*  228 */     field = new Field();
/*  229 */     field.setName("value");
/*  230 */     field.setType(FullyQualifiedJavaType.getObjectInstance());
/*  231 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  232 */     answer.addField(field);
/*  233 */     answer.addMethod(getGetter(field));
/*      */     
/*  235 */     field = new Field();
/*  236 */     field.setName("secondValue");
/*  237 */     field.setType(FullyQualifiedJavaType.getObjectInstance());
/*  238 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  239 */     answer.addField(field);
/*  240 */     answer.addMethod(getGetter(field));
/*      */     
/*  242 */     field = new Field();
/*  243 */     field.setName("noValue");
/*  244 */     field.setType(FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  245 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  246 */     answer.addField(field);
/*  247 */     answer.addMethod(getGetter(field));
/*      */     
/*  249 */     field = new Field();
/*  250 */     field.setName("singleValue");
/*  251 */     field.setType(FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  252 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  253 */     answer.addField(field);
/*  254 */     answer.addMethod(getGetter(field));
/*      */     
/*  256 */     field = new Field();
/*  257 */     field.setName("betweenValue");
/*  258 */     field.setType(FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  259 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  260 */     answer.addField(field);
/*  261 */     answer.addMethod(getGetter(field));
/*      */     
/*  263 */     field = new Field();
/*  264 */     field.setName("listValue");
/*  265 */     field.setType(FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  266 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  267 */     answer.addField(field);
/*  268 */     answer.addMethod(getGetter(field));
/*      */     
/*  270 */     field = new Field();
/*  271 */     field.setName("typeHandler");
/*  272 */     field.setType(FullyQualifiedJavaType.getStringInstance());
/*  273 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  274 */     answer.addField(field);
/*  275 */     answer.addMethod(getGetter(field));
/*      */     
/*  277 */     Method method = new Method();
/*  278 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  279 */     method.setName("Criterion");
/*  280 */     method.setConstructor(true);
/*  281 */     method.addParameter(new Parameter(
/*  282 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  283 */     method.addBodyLine("super();");
/*  284 */     method.addBodyLine("this.condition = condition;");
/*  285 */     method.addBodyLine("this.typeHandler = null;");
/*  286 */     method.addBodyLine("this.noValue = true;");
/*  287 */     answer.addMethod(method);
/*      */     
/*  289 */     method = new Method();
/*  290 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  291 */     method.setName("Criterion");
/*  292 */     method.setConstructor(true);
/*  293 */     method.addParameter(new Parameter(
/*  294 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  295 */     method.addParameter(new Parameter(
/*  296 */       FullyQualifiedJavaType.getObjectInstance(), "value"));
/*  297 */     method.addParameter(new Parameter(
/*  298 */       FullyQualifiedJavaType.getStringInstance(), "typeHandler"));
/*  299 */     method.addBodyLine("super();");
/*  300 */     method.addBodyLine("this.condition = condition;");
/*  301 */     method.addBodyLine("this.value = value;");
/*  302 */     method.addBodyLine("this.typeHandler = typeHandler;");
/*  303 */     method.addBodyLine("if (value instanceof List<?>) {");
/*  304 */     method.addBodyLine("this.listValue = true;");
/*  305 */     method.addBodyLine("} else {");
/*  306 */     method.addBodyLine("this.singleValue = true;");
/*  307 */     method.addBodyLine("}");
/*  308 */     answer.addMethod(method);
/*      */     
/*  310 */     method = new Method();
/*  311 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  312 */     method.setName("Criterion");
/*  313 */     method.setConstructor(true);
/*  314 */     method.addParameter(new Parameter(
/*  315 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  316 */     method.addParameter(new Parameter(
/*  317 */       FullyQualifiedJavaType.getObjectInstance(), "value"));
/*  318 */     method.addBodyLine("this(condition, value, null);");
/*  319 */     answer.addMethod(method);
/*      */     
/*  321 */     method = new Method();
/*  322 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  323 */     method.setName("Criterion");
/*  324 */     method.setConstructor(true);
/*  325 */     method.addParameter(new Parameter(
/*  326 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  327 */     method.addParameter(new Parameter(
/*  328 */       FullyQualifiedJavaType.getObjectInstance(), "value"));
/*  329 */     method.addParameter(new Parameter(
/*  330 */       FullyQualifiedJavaType.getObjectInstance(), "secondValue"));
/*  331 */     method.addParameter(new Parameter(
/*  332 */       FullyQualifiedJavaType.getStringInstance(), "typeHandler"));
/*  333 */     method.addBodyLine("super();");
/*  334 */     method.addBodyLine("this.condition = condition;");
/*  335 */     method.addBodyLine("this.value = value;");
/*  336 */     method.addBodyLine("this.secondValue = secondValue;");
/*  337 */     method.addBodyLine("this.typeHandler = typeHandler;");
/*  338 */     method.addBodyLine("this.betweenValue = true;");
/*  339 */     answer.addMethod(method);
/*      */     
/*  341 */     method = new Method();
/*  342 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  343 */     method.setName("Criterion");
/*  344 */     method.setConstructor(true);
/*  345 */     method.addParameter(new Parameter(
/*  346 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  347 */     method.addParameter(new Parameter(
/*  348 */       FullyQualifiedJavaType.getObjectInstance(), "value"));
/*  349 */     method.addParameter(new Parameter(
/*  350 */       FullyQualifiedJavaType.getObjectInstance(), "secondValue"));
/*  351 */     method.addBodyLine("this(condition, value, secondValue, null);");
/*  352 */     answer.addMethod(method);
/*      */     
/*  354 */     return answer;
/*      */   }
/*      */   
/*      */ 
/*      */   private InnerClass getCriteriaInnerClass(TopLevelClass topLevelClass)
/*      */   {
/*  360 */     InnerClass answer = new InnerClass(
/*  361 */       FullyQualifiedJavaType.getCriteriaInstance());
/*      */     
/*  363 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  364 */     answer.setStatic(true);
/*  365 */     answer.setSuperClass(
/*  366 */       FullyQualifiedJavaType.getGeneratedCriteriaInstance());
/*      */     
/*  368 */     this.context.getCommentGenerator().addClassComment(answer, 
/*  369 */       this.introspectedTable, true);
/*      */     
/*  371 */     Method method = new Method();
/*  372 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  373 */     method.setName("Criteria");
/*  374 */     method.setConstructor(true);
/*  375 */     method.addBodyLine("super();");
/*  376 */     answer.addMethod(method);
/*      */     
/*  378 */     return answer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private InnerClass getGeneratedCriteriaInnerClass(TopLevelClass topLevelClass)
/*      */   {
/*  386 */     InnerClass answer = new InnerClass(
/*  387 */       FullyQualifiedJavaType.getGeneratedCriteriaInstance());
/*      */     
/*  389 */     answer.setVisibility(JavaVisibility.PROTECTED);
/*  390 */     answer.setStatic(true);
/*  391 */     answer.setAbstract(true);
/*  392 */     this.context.getCommentGenerator().addClassComment(answer, 
/*  393 */       this.introspectedTable);
/*      */     
/*  395 */     Method method = new Method();
/*  396 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  397 */     method.setName("GeneratedCriteria");
/*  398 */     method.setConstructor(true);
/*  399 */     method.addBodyLine("super();");
/*  400 */     method.addBodyLine("criteria = new ArrayList<Criterion>();");
/*  401 */     answer.addMethod(method);
/*      */     
/*  403 */     List<String> criteriaLists = new ArrayList();
/*  404 */     criteriaLists.add("criteria");
/*      */     
/*      */ 
/*  407 */     Iterator localIterator1 = this.introspectedTable.getNonBLOBColumns().iterator();
/*  406 */     while (localIterator1.hasNext()) {
/*  407 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator1.next();
/*  408 */       if (StringUtility.stringHasValue(introspectedColumn
/*  409 */         .getTypeHandler())) {
/*  410 */         String name = addtypeHandledObjectsAndMethods(
/*  411 */           introspectedColumn, method, answer);
/*  412 */         criteriaLists.add(name);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  417 */     method = new Method();
/*  418 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  419 */     method.setName("isValid");
/*  420 */     method.setReturnType(
/*  421 */       FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  422 */     StringBuilder sb = new StringBuilder();
/*  423 */     Object strIter = criteriaLists.iterator();
/*  424 */     sb.append("return ");
/*  425 */     sb.append((String)((Iterator)strIter).next());
/*  426 */     sb.append(".size() > 0");
/*  427 */     if (!((Iterator)strIter).hasNext()) {
/*  428 */       sb.append(';');
/*      */     }
/*  430 */     method.addBodyLine(sb.toString());
/*  431 */     while (((Iterator)strIter).hasNext()) {
/*  432 */       sb.setLength(0);
/*  433 */       OutputUtilities.javaIndent(sb, 1);
/*  434 */       sb.append("|| ");
/*  435 */       sb.append((String)((Iterator)strIter).next());
/*  436 */       sb.append(".size() > 0");
/*  437 */       if (!((Iterator)strIter).hasNext()) {
/*  438 */         sb.append(';');
/*      */       }
/*  440 */       method.addBodyLine(sb.toString());
/*      */     }
/*  442 */     answer.addMethod(method);
/*      */     
/*      */ 
/*  445 */     if (criteriaLists.size() > 1) {
/*  446 */       Field field = new Field();
/*  447 */       field.setName("allCriteria");
/*  448 */       field.setType(new FullyQualifiedJavaType("List<Criterion>"));
/*  449 */       field.setVisibility(JavaVisibility.PROTECTED);
/*  450 */       answer.addField(field);
/*      */     }
/*      */     
/*  453 */     method = new Method();
/*  454 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  455 */     method.setName("getAllCriteria");
/*  456 */     method.setReturnType(new FullyQualifiedJavaType("List<Criterion>"));
/*  457 */     if (criteriaLists.size() < 2) {
/*  458 */       method.addBodyLine("return criteria;");
/*      */     } else {
/*  460 */       method.addBodyLine("if (allCriteria == null) {");
/*  461 */       method.addBodyLine("allCriteria = new ArrayList<Criterion>();");
/*      */       
/*  463 */       strIter = criteriaLists.iterator();
/*  464 */       while (((Iterator)strIter).hasNext()) {
/*  465 */         method.addBodyLine(String.format("allCriteria.addAll(%s);", new Object[] { ((Iterator)strIter).next() }));
/*      */       }
/*      */       
/*  468 */       method.addBodyLine("}");
/*  469 */       method.addBodyLine("return allCriteria;");
/*      */     }
/*  471 */     answer.addMethod(method);
/*      */     
/*      */ 
/*      */ 
/*  475 */     topLevelClass.addImportedType(
/*  476 */       FullyQualifiedJavaType.getNewListInstance());
/*  477 */     topLevelClass.addImportedType(
/*  478 */       FullyQualifiedJavaType.getNewArrayListInstance());
/*      */     
/*  480 */     Field field = new Field();
/*  481 */     field.setVisibility(JavaVisibility.PROTECTED);
/*  482 */     FullyQualifiedJavaType listOfCriterion = new FullyQualifiedJavaType(
/*  483 */       "java.util.List<Criterion>");
/*  484 */     field.setType(listOfCriterion);
/*  485 */     field.setName("criteria");
/*  486 */     answer.addField(field);
/*      */     
/*  488 */     method = new Method();
/*  489 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  490 */     method.setReturnType(field.getType());
/*  491 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName(), field
/*  492 */       .getType()));
/*  493 */     method.addBodyLine("return criteria;");
/*  494 */     answer.addMethod(method);
/*      */     
/*      */ 
/*  497 */     method = new Method();
/*  498 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  499 */     method.setName("addCriterion");
/*  500 */     method.addParameter(new Parameter(
/*  501 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  502 */     method.addBodyLine("if (condition == null) {");
/*  503 */     method
/*  504 */       .addBodyLine("throw new RuntimeException(\"Value for condition cannot be null\");");
/*  505 */     method.addBodyLine("}");
/*  506 */     method.addBodyLine("criteria.add(new Criterion(condition));");
/*  507 */     if (criteriaLists.size() > 1) {
/*  508 */       method.addBodyLine("allCriteria = null;");
/*      */     }
/*  510 */     answer.addMethod(method);
/*      */     
/*  512 */     method = new Method();
/*  513 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  514 */     method.setName("addCriterion");
/*  515 */     method.addParameter(new Parameter(
/*  516 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  517 */     method.addParameter(new Parameter(
/*  518 */       FullyQualifiedJavaType.getObjectInstance(), "value"));
/*  519 */     method.addParameter(new Parameter(
/*  520 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/*  521 */     method.addBodyLine("if (value == null) {");
/*  522 */     method
/*  523 */       .addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/*  524 */     method.addBodyLine("}");
/*  525 */     method.addBodyLine("criteria.add(new Criterion(condition, value));");
/*  526 */     if (criteriaLists.size() > 1) {
/*  527 */       method.addBodyLine("allCriteria = null;");
/*      */     }
/*  529 */     answer.addMethod(method);
/*      */     
/*  531 */     method = new Method();
/*  532 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  533 */     method.setName("addCriterion");
/*  534 */     method.addParameter(new Parameter(
/*  535 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  536 */     method.addParameter(new Parameter(
/*  537 */       FullyQualifiedJavaType.getObjectInstance(), "value1"));
/*  538 */     method.addParameter(new Parameter(
/*  539 */       FullyQualifiedJavaType.getObjectInstance(), "value2"));
/*  540 */     method.addParameter(new Parameter(
/*  541 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/*  542 */     method.addBodyLine("if (value1 == null || value2 == null) {");
/*  543 */     method
/*  544 */       .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/*  545 */     method.addBodyLine("}");
/*  546 */     method
/*  547 */       .addBodyLine("criteria.add(new Criterion(condition, value1, value2));");
/*  548 */     if (criteriaLists.size() > 1) {
/*  549 */       method.addBodyLine("allCriteria = null;");
/*      */     }
/*  551 */     answer.addMethod(method);
/*      */     
/*  553 */     FullyQualifiedJavaType listOfDates = new FullyQualifiedJavaType(
/*  554 */       "java.util.List<java.util.Date>");
/*      */     
/*  556 */     if (this.introspectedTable.hasJDBCDateColumns()) {
/*  557 */       topLevelClass.addImportedType(
/*  558 */         FullyQualifiedJavaType.getDateInstance());
/*  559 */       topLevelClass.addImportedType(
/*  560 */         FullyQualifiedJavaType.getNewIteratorInstance());
/*  561 */       method = new Method();
/*  562 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  563 */       method.setName("addCriterionForJDBCDate");
/*  564 */       method.addParameter(new Parameter(
/*  565 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  566 */       method.addParameter(new Parameter(
/*  567 */         FullyQualifiedJavaType.getDateInstance(), "value"));
/*  568 */       method.addParameter(new Parameter(
/*  569 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  570 */       method.addBodyLine("if (value == null) {");
/*  571 */       method
/*  572 */         .addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/*  573 */       method.addBodyLine("}");
/*  574 */       method
/*  575 */         .addBodyLine("addCriterion(condition, new java.sql.Date(value.getTime()), property);");
/*  576 */       answer.addMethod(method);
/*      */       
/*  578 */       method = new Method();
/*  579 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  580 */       method.setName("addCriterionForJDBCDate");
/*  581 */       method.addParameter(new Parameter(
/*  582 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  583 */       method.addParameter(new Parameter(listOfDates, "values"));
/*  584 */       method.addParameter(new Parameter(
/*  585 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  586 */       method.addBodyLine("if (values == null || values.size() == 0) {");
/*  587 */       method
/*  588 */         .addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/*  589 */       method.addBodyLine("}");
/*  590 */       method
/*  591 */         .addBodyLine("List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();");
/*  592 */       method.addBodyLine("Iterator<Date> iter = values.iterator();");
/*  593 */       method.addBodyLine("while (iter.hasNext()) {");
/*  594 */       method
/*  595 */         .addBodyLine("dateList.add(new java.sql.Date(iter.next().getTime()));");
/*  596 */       method.addBodyLine("}");
/*  597 */       method.addBodyLine("addCriterion(condition, dateList, property);");
/*  598 */       answer.addMethod(method);
/*      */       
/*  600 */       method = new Method();
/*  601 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  602 */       method.setName("addCriterionForJDBCDate");
/*  603 */       method.addParameter(new Parameter(
/*  604 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  605 */       method.addParameter(new Parameter(
/*  606 */         FullyQualifiedJavaType.getDateInstance(), "value1"));
/*  607 */       method.addParameter(new Parameter(
/*  608 */         FullyQualifiedJavaType.getDateInstance(), "value2"));
/*  609 */       method.addParameter(new Parameter(
/*  610 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  611 */       method.addBodyLine("if (value1 == null || value2 == null) {");
/*  612 */       method
/*  613 */         .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/*  614 */       method.addBodyLine("}");
/*  615 */       method
/*  616 */         .addBodyLine("addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);");
/*  617 */       answer.addMethod(method);
/*      */     }
/*      */     
/*  620 */     if (this.introspectedTable.hasJDBCTimeColumns()) {
/*  621 */       topLevelClass.addImportedType(
/*  622 */         FullyQualifiedJavaType.getDateInstance());
/*  623 */       topLevelClass.addImportedType(
/*  624 */         FullyQualifiedJavaType.getNewIteratorInstance());
/*  625 */       method = new Method();
/*  626 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  627 */       method.setName("addCriterionForJDBCTime");
/*  628 */       method.addParameter(new Parameter(
/*  629 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  630 */       method.addParameter(new Parameter(
/*  631 */         FullyQualifiedJavaType.getDateInstance(), "value"));
/*  632 */       method.addParameter(new Parameter(
/*  633 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  634 */       method.addBodyLine("if (value == null) {");
/*  635 */       method
/*  636 */         .addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/*  637 */       method.addBodyLine("}");
/*  638 */       method
/*  639 */         .addBodyLine("addCriterion(condition, new java.sql.Time(value.getTime()), property);");
/*  640 */       answer.addMethod(method);
/*      */       
/*  642 */       method = new Method();
/*  643 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  644 */       method.setName("addCriterionForJDBCTime");
/*  645 */       method.addParameter(new Parameter(
/*  646 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  647 */       method.addParameter(new Parameter(listOfDates, "values"));
/*  648 */       method.addParameter(new Parameter(
/*  649 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  650 */       method.addBodyLine("if (values == null || values.size() == 0) {");
/*  651 */       method
/*  652 */         .addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/*  653 */       method.addBodyLine("}");
/*  654 */       method
/*  655 */         .addBodyLine("List<java.sql.Time> timeList = new ArrayList<java.sql.Time>();");
/*  656 */       method.addBodyLine("Iterator<Date> iter = values.iterator();");
/*  657 */       method.addBodyLine("while (iter.hasNext()) {");
/*  658 */       method
/*  659 */         .addBodyLine("timeList.add(new java.sql.Time(iter.next().getTime()));");
/*  660 */       method.addBodyLine("}");
/*  661 */       method.addBodyLine("addCriterion(condition, timeList, property);");
/*  662 */       answer.addMethod(method);
/*      */       
/*  664 */       method = new Method();
/*  665 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  666 */       method.setName("addCriterionForJDBCTime");
/*  667 */       method.addParameter(new Parameter(
/*  668 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  669 */       method.addParameter(new Parameter(
/*  670 */         FullyQualifiedJavaType.getDateInstance(), "value1"));
/*  671 */       method.addParameter(new Parameter(
/*  672 */         FullyQualifiedJavaType.getDateInstance(), "value2"));
/*  673 */       method.addParameter(new Parameter(
/*  674 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  675 */       method.addBodyLine("if (value1 == null || value2 == null) {");
/*  676 */       method
/*  677 */         .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/*  678 */       method.addBodyLine("}");
/*  679 */       method
/*  680 */         .addBodyLine("addCriterion(condition, new java.sql.Time(value1.getTime()), new java.sql.Time(value2.getTime()), property);");
/*  681 */       answer.addMethod(method);
/*      */     }
/*      */     
/*      */ 
/*  685 */     Iterator localIterator2 = this.introspectedTable.getNonBLOBColumns().iterator();
/*  684 */     while (localIterator2.hasNext()) {
/*  685 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator2.next();
/*  686 */       topLevelClass.addImportedType(introspectedColumn
/*  687 */         .getFullyQualifiedJavaType());
/*      */       
/*      */ 
/*      */ 
/*  691 */       answer.addMethod(getSetNullMethod(introspectedColumn));
/*  692 */       answer.addMethod(getSetNotNullMethod(introspectedColumn));
/*  693 */       answer.addMethod(getSetEqualMethod(introspectedColumn));
/*  694 */       answer.addMethod(getSetNotEqualMethod(introspectedColumn));
/*  695 */       answer.addMethod(getSetGreaterThanMethod(introspectedColumn));
/*  696 */       answer
/*  697 */         .addMethod(getSetGreaterThenOrEqualMethod(introspectedColumn));
/*  698 */       answer.addMethod(getSetLessThanMethod(introspectedColumn));
/*  699 */       answer.addMethod(getSetLessThanOrEqualMethod(introspectedColumn));
/*      */       
/*  701 */       if (introspectedColumn.isJdbcCharacterColumn()) {
/*  702 */         answer.addMethod(getSetLikeMethod(introspectedColumn));
/*  703 */         answer.addMethod(getSetNotLikeMethod(introspectedColumn));
/*      */       }
/*      */       
/*  706 */       answer.addMethod(getSetInOrNotInMethod(introspectedColumn, true));
/*  707 */       answer.addMethod(getSetInOrNotInMethod(introspectedColumn, false));
/*  708 */       answer.addMethod(getSetBetweenOrNotBetweenMethod(
/*  709 */         introspectedColumn, true));
/*  710 */       answer.addMethod(getSetBetweenOrNotBetweenMethod(
/*  711 */         introspectedColumn, false));
/*      */     }
/*      */     
/*  714 */     return answer;
/*      */   }
/*      */   
/*      */   private Method getSetNullMethod(IntrospectedColumn introspectedColumn) {
/*  718 */     return getNoValueMethod(introspectedColumn, "IsNull", "is null");
/*      */   }
/*      */   
/*      */   private Method getSetNotNullMethod(IntrospectedColumn introspectedColumn) {
/*  722 */     return getNoValueMethod(introspectedColumn, "IsNotNull", "is not null");
/*      */   }
/*      */   
/*      */   private Method getSetEqualMethod(IntrospectedColumn introspectedColumn) {
/*  726 */     return getSingleValueMethod(introspectedColumn, "EqualTo", "=");
/*      */   }
/*      */   
/*      */   private Method getSetNotEqualMethod(IntrospectedColumn introspectedColumn) {
/*  730 */     return getSingleValueMethod(introspectedColumn, "NotEqualTo", "<>");
/*      */   }
/*      */   
/*      */   private Method getSetGreaterThanMethod(IntrospectedColumn introspectedColumn) {
/*  734 */     return getSingleValueMethod(introspectedColumn, "GreaterThan", ">");
/*      */   }
/*      */   
/*      */   private Method getSetGreaterThenOrEqualMethod(IntrospectedColumn introspectedColumn)
/*      */   {
/*  739 */     return getSingleValueMethod(introspectedColumn, 
/*  740 */       "GreaterThanOrEqualTo", ">=");
/*      */   }
/*      */   
/*      */   private Method getSetLessThanMethod(IntrospectedColumn introspectedColumn) {
/*  744 */     return getSingleValueMethod(introspectedColumn, "LessThan", "<");
/*      */   }
/*      */   
/*      */   private Method getSetLessThanOrEqualMethod(IntrospectedColumn introspectedColumn)
/*      */   {
/*  749 */     return getSingleValueMethod(introspectedColumn, 
/*  750 */       "LessThanOrEqualTo", "<=");
/*      */   }
/*      */   
/*      */   private Method getSetLikeMethod(IntrospectedColumn introspectedColumn) {
/*  754 */     return getSingleValueMethod(introspectedColumn, "Like", "like");
/*      */   }
/*      */   
/*      */   private Method getSetNotLikeMethod(IntrospectedColumn introspectedColumn) {
/*  758 */     return getSingleValueMethod(introspectedColumn, "NotLike", "not like");
/*      */   }
/*      */   
/*      */   private Method getSingleValueMethod(IntrospectedColumn introspectedColumn, String nameFragment, String operator)
/*      */   {
/*  763 */     Method method = new Method();
/*  764 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  765 */     method.addParameter(new Parameter(introspectedColumn
/*  766 */       .getFullyQualifiedJavaType(), "value"));
/*  767 */     StringBuilder sb = new StringBuilder();
/*  768 */     sb.append(introspectedColumn.getJavaProperty());
/*  769 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/*  770 */     sb.insert(0, "and");
/*  771 */     sb.append(nameFragment);
/*  772 */     method.setName(sb.toString());
/*  773 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  774 */     sb.setLength(0);
/*      */     
/*  776 */     if (introspectedColumn.isJDBCDateColumn()) {
/*  777 */       sb.append("addCriterionForJDBCDate(\"");
/*  778 */     } else if (introspectedColumn.isJDBCTimeColumn()) {
/*  779 */       sb.append("addCriterionForJDBCTime(\"");
/*  780 */     } else if (StringUtility.stringHasValue(introspectedColumn
/*  781 */       .getTypeHandler())) {
/*  782 */       sb.append("add");
/*  783 */       sb.append(introspectedColumn.getJavaProperty());
/*  784 */       sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/*  785 */       sb.append("Criterion(\"");
/*      */     } else {
/*  787 */       sb.append("addCriterion(\"");
/*      */     }
/*      */     
/*  790 */     sb.append(
/*  791 */       MyBatis3FormattingUtilities.getAliasedActualColumnName(introspectedColumn));
/*  792 */     sb.append(' ');
/*  793 */     sb.append(operator);
/*  794 */     sb.append("\", ");
/*  795 */     sb.append("value");
/*  796 */     sb.append(", \"");
/*  797 */     sb.append(introspectedColumn.getJavaProperty());
/*  798 */     sb.append("\");");
/*  799 */     method.addBodyLine(sb.toString());
/*  800 */     method.addBodyLine("return (Criteria) this;");
/*      */     
/*  802 */     return method;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Method getSetBetweenOrNotBetweenMethod(IntrospectedColumn introspectedColumn, boolean betweenMethod)
/*      */   {
/*  814 */     Method method = new Method();
/*  815 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  816 */     FullyQualifiedJavaType type = introspectedColumn
/*  817 */       .getFullyQualifiedJavaType();
/*      */     
/*  819 */     method.addParameter(new Parameter(type, "value1"));
/*  820 */     method.addParameter(new Parameter(type, "value2"));
/*  821 */     StringBuilder sb = new StringBuilder();
/*  822 */     sb.append(introspectedColumn.getJavaProperty());
/*  823 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/*  824 */     sb.insert(0, "and");
/*  825 */     if (betweenMethod) {
/*  826 */       sb.append("Between");
/*      */     } else {
/*  828 */       sb.append("NotBetween");
/*      */     }
/*  830 */     method.setName(sb.toString());
/*  831 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  832 */     sb.setLength(0);
/*      */     
/*  834 */     if (introspectedColumn.isJDBCDateColumn()) {
/*  835 */       sb.append("addCriterionForJDBCDate(\"");
/*  836 */     } else if (introspectedColumn.isJDBCTimeColumn()) {
/*  837 */       sb.append("addCriterionForJDBCTime(\"");
/*  838 */     } else if (StringUtility.stringHasValue(introspectedColumn
/*  839 */       .getTypeHandler())) {
/*  840 */       sb.append("add");
/*  841 */       sb.append(introspectedColumn.getJavaProperty());
/*  842 */       sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/*  843 */       sb.append("Criterion(\"");
/*      */     } else {
/*  845 */       sb.append("addCriterion(\"");
/*      */     }
/*      */     
/*  848 */     sb.append(
/*  849 */       MyBatis3FormattingUtilities.getAliasedActualColumnName(introspectedColumn));
/*  850 */     if (betweenMethod) {
/*  851 */       sb.append(" between");
/*      */     } else {
/*  853 */       sb.append(" not between");
/*      */     }
/*  855 */     sb.append("\", ");
/*  856 */     sb.append("value1, value2");
/*  857 */     sb.append(", \"");
/*  858 */     sb.append(introspectedColumn.getJavaProperty());
/*  859 */     sb.append("\");");
/*  860 */     method.addBodyLine(sb.toString());
/*  861 */     method.addBodyLine("return (Criteria) this;");
/*      */     
/*  863 */     return method;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Method getSetInOrNotInMethod(IntrospectedColumn introspectedColumn, boolean inMethod)
/*      */   {
/*  876 */     Method method = new Method();
/*  877 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  878 */     FullyQualifiedJavaType type = 
/*  879 */       FullyQualifiedJavaType.getNewListInstance();
/*  880 */     if (introspectedColumn.getFullyQualifiedJavaType().isPrimitive()) {
/*  881 */       type.addTypeArgument(introspectedColumn.getFullyQualifiedJavaType()
/*  882 */         .getPrimitiveTypeWrapper());
/*      */     }
/*      */     else {
/*  885 */       type.addTypeArgument(introspectedColumn
/*  886 */         .getFullyQualifiedJavaType());
/*      */     }
/*      */     
/*  889 */     method.addParameter(new Parameter(type, "values"));
/*  890 */     StringBuilder sb = new StringBuilder();
/*  891 */     sb.append(introspectedColumn.getJavaProperty());
/*  892 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/*  893 */     sb.insert(0, "and");
/*  894 */     if (inMethod) {
/*  895 */       sb.append("In");
/*      */     } else {
/*  897 */       sb.append("NotIn");
/*      */     }
/*  899 */     method.setName(sb.toString());
/*  900 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  901 */     sb.setLength(0);
/*      */     
/*  903 */     if (introspectedColumn.isJDBCDateColumn()) {
/*  904 */       sb.append("addCriterionForJDBCDate(\"");
/*  905 */     } else if (introspectedColumn.isJDBCTimeColumn()) {
/*  906 */       sb.append("addCriterionForJDBCTime(\"");
/*  907 */     } else if (StringUtility.stringHasValue(introspectedColumn
/*  908 */       .getTypeHandler())) {
/*  909 */       sb.append("add");
/*  910 */       sb.append(introspectedColumn.getJavaProperty());
/*  911 */       sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/*  912 */       sb.append("Criterion(\"");
/*      */     } else {
/*  914 */       sb.append("addCriterion(\"");
/*      */     }
/*      */     
/*  917 */     sb.append(
/*  918 */       MyBatis3FormattingUtilities.getAliasedActualColumnName(introspectedColumn));
/*  919 */     if (inMethod) {
/*  920 */       sb.append(" in");
/*      */     } else {
/*  922 */       sb.append(" not in");
/*      */     }
/*  924 */     sb.append("\", values, \"");
/*  925 */     sb.append(introspectedColumn.getJavaProperty());
/*  926 */     sb.append("\");");
/*  927 */     method.addBodyLine(sb.toString());
/*  928 */     method.addBodyLine("return (Criteria) this;");
/*      */     
/*  930 */     return method;
/*      */   }
/*      */   
/*      */   private Method getNoValueMethod(IntrospectedColumn introspectedColumn, String nameFragment, String operator)
/*      */   {
/*  935 */     Method method = new Method();
/*  936 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  937 */     StringBuilder sb = new StringBuilder();
/*  938 */     sb.append(introspectedColumn.getJavaProperty());
/*  939 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/*  940 */     sb.insert(0, "and");
/*  941 */     sb.append(nameFragment);
/*  942 */     method.setName(sb.toString());
/*  943 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  944 */     sb.setLength(0);
/*  945 */     sb.append("addCriterion(\"");
/*  946 */     sb.append(
/*  947 */       MyBatis3FormattingUtilities.getAliasedActualColumnName(introspectedColumn));
/*  948 */     sb.append(' ');
/*  949 */     sb.append(operator);
/*  950 */     sb.append("\");");
/*  951 */     method.addBodyLine(sb.toString());
/*  952 */     method.addBodyLine("return (Criteria) this;");
/*      */     
/*  954 */     return method;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String addtypeHandledObjectsAndMethods(IntrospectedColumn introspectedColumn, Method constructor, InnerClass innerClass)
/*      */   {
/*  970 */     StringBuilder sb = new StringBuilder();
/*      */     
/*      */ 
/*  973 */     sb.setLength(0);
/*  974 */     sb.append(introspectedColumn.getJavaProperty());
/*  975 */     sb.append("Criteria");
/*  976 */     String answer = sb.toString();
/*      */     
/*  978 */     Field field = new Field();
/*  979 */     field.setVisibility(JavaVisibility.PROTECTED);
/*  980 */     field.setType(new FullyQualifiedJavaType("java.util.List<Criterion>"));
/*  981 */     field.setName(answer);
/*  982 */     innerClass.addField(field);
/*      */     
/*  984 */     Method method = new Method();
/*  985 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  986 */     method.setReturnType(field.getType());
/*  987 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName(), field
/*  988 */       .getType()));
/*  989 */     sb.insert(0, "return ");
/*  990 */     sb.append(';');
/*  991 */     method.addBodyLine(sb.toString());
/*  992 */     innerClass.addMethod(method);
/*      */     
/*      */ 
/*  995 */     sb.setLength(0);
/*  996 */     sb.append(field.getName());
/*  997 */     sb.append(" = new ArrayList<Criterion>();");
/*  998 */     constructor.addBodyLine(sb.toString());
/*      */     
/*      */ 
/* 1001 */     method = new Method();
/* 1002 */     method.setVisibility(JavaVisibility.PROTECTED);
/* 1003 */     sb.setLength(0);
/* 1004 */     sb.append("add");
/* 1005 */     sb.append(introspectedColumn.getJavaProperty());
/* 1006 */     sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 1007 */     sb.append("Criterion");
/*      */     
/* 1009 */     method.setName(sb.toString());
/* 1010 */     method.addParameter(new Parameter(
/* 1011 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 1012 */     method.addParameter(new Parameter(
/* 1013 */       FullyQualifiedJavaType.getObjectInstance(), "value"));
/* 1014 */     method.addParameter(new Parameter(
/* 1015 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/* 1016 */     method.addBodyLine("if (value == null) {");
/* 1017 */     method
/* 1018 */       .addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/* 1019 */     method.addBodyLine("}");
/*      */     
/* 1021 */     method.addBodyLine(
/* 1022 */       String.format("%s.add(new Criterion(condition, value, \"%s\"));", new Object[] {
/* 1023 */       field.getName(), introspectedColumn.getTypeHandler() }));
/* 1024 */     method.addBodyLine("allCriteria = null;");
/* 1025 */     innerClass.addMethod(method);
/*      */     
/* 1027 */     sb.setLength(0);
/* 1028 */     sb.append("add");
/* 1029 */     sb.append(introspectedColumn.getJavaProperty());
/* 1030 */     sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 1031 */     sb.append("Criterion");
/*      */     
/* 1033 */     method = new Method();
/* 1034 */     method.setVisibility(JavaVisibility.PROTECTED);
/* 1035 */     method.setName(sb.toString());
/* 1036 */     method.addParameter(new Parameter(
/* 1037 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/* 1038 */     method.addParameter(new Parameter(introspectedColumn
/* 1039 */       .getFullyQualifiedJavaType(), "value1"));
/* 1040 */     method.addParameter(new Parameter(introspectedColumn
/* 1041 */       .getFullyQualifiedJavaType(), "value2"));
/* 1042 */     method.addParameter(new Parameter(
/* 1043 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/* 1044 */     if (!introspectedColumn.getFullyQualifiedJavaType().isPrimitive()) {
/* 1045 */       method.addBodyLine("if (value1 == null || value2 == null) {");
/* 1046 */       method
/* 1047 */         .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/* 1048 */       method.addBodyLine("}");
/*      */     }
/*      */     
/* 1051 */     method.addBodyLine(
/* 1052 */       String.format("%s.add(new Criterion(condition, value1, value2, \"%s\"));", new Object[] {
/* 1053 */       field.getName(), introspectedColumn.getTypeHandler() }));
/*      */     
/* 1055 */     method.addBodyLine("allCriteria = null;");
/* 1056 */     innerClass.addMethod(method);
/*      */     
/* 1058 */     return answer;
/*      */   }
/*      */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\model\ExampleGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */