/*     */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.OutputUtilities;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*     */ import org.mybatis.generator.config.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateByPrimaryKeyWithoutBLOBsElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   private boolean isSimple;
/*     */   
/*     */   public UpdateByPrimaryKeyWithoutBLOBsElementGenerator(boolean isSimple)
/*     */   {
/*  39 */     this.isSimple = isSimple;
/*     */   }
/*     */   
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  44 */     XmlElement answer = new XmlElement("update");
/*     */     
/*  46 */     answer.addAttribute(new Attribute(
/*  47 */       "id", this.introspectedTable.getUpdateByPrimaryKeyStatementId()));
/*  48 */     answer.addAttribute(new Attribute("parameterType", 
/*  49 */       this.introspectedTable.getBaseRecordType()));
/*     */     
/*  51 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  53 */     StringBuilder sb = new StringBuilder();
/*  54 */     sb.append("UPDATE ");
/*  55 */     sb.append(this.introspectedTable.getFullyQualifiedTableNameAtRuntime());
/*  56 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*     */ 
/*  59 */     sb.setLength(0);
/*  60 */     sb.append("SET ");
/*     */     Iterator<IntrospectedColumn> iter;
/*     */     Iterator<IntrospectedColumn> iter;
/*  63 */     if (this.isSimple) {
/*  64 */       iter = this.introspectedTable.getNonPrimaryKeyColumns().iterator();
/*     */     } else {
/*  66 */       iter = this.introspectedTable.getBaseColumns().iterator();
/*     */     }
/*  68 */     while (iter.hasNext()) {
/*  69 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)iter.next();
/*     */       
/*  71 */       sb.append(
/*  72 */         MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn));
/*  73 */       sb.append(" = ");
/*  74 */       sb.append(
/*  75 */         MyBatis3FormattingUtilities.getParameterClause(introspectedColumn));
/*     */       
/*  77 */       if (iter.hasNext()) {
/*  78 */         sb.append(',');
/*     */       }
/*     */       
/*  81 */       answer.addElement(new TextElement(sb.toString()));
/*     */       
/*     */ 
/*  84 */       if (iter.hasNext()) {
/*  85 */         sb.setLength(0);
/*  86 */         OutputUtilities.xmlIndent(sb, 1);
/*     */       }
/*     */     }
/*     */     
/*  90 */     boolean and = false;
/*     */     
/*  92 */     Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/*  91 */     while (localIterator.hasNext()) {
/*  92 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*  93 */       sb.setLength(0);
/*  94 */       if (and) {
/*  95 */         sb.append("  AND ");
/*     */       } else {
/*  97 */         sb.append("WHERE ");
/*  98 */         and = true;
/*     */       }
/*     */       
/* 101 */       sb.append(
/* 102 */         MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn));
/* 103 */       sb.append(" = ");
/* 104 */       sb.append(
/* 105 */         MyBatis3FormattingUtilities.getParameterClause(introspectedColumn));
/* 106 */       answer.addElement(new TextElement(sb.toString()));
/*     */     }
/*     */     
/*     */ 
/* 110 */     if (this.context.getPlugins().sqlMapUpdateByPrimaryKeyWithoutBLOBsElementGenerated(answer, 
/* 111 */       this.introspectedTable)) {
/* 112 */       parentElement.addElement(answer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\UpdateByPrimaryKeyWithoutBLOBsElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */