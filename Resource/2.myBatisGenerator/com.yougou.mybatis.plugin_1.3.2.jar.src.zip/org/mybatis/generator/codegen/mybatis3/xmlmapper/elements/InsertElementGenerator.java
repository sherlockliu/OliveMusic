/*     */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.OutputUtilities;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.GeneratedKey;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InsertElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   private boolean isSimple;
/*     */   
/*     */   public InsertElementGenerator(boolean isSimple)
/*     */   {
/*  42 */     this.isSimple = isSimple;
/*     */   }
/*     */   
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  47 */     XmlElement answer = new XmlElement("insert");
/*     */     
/*  49 */     answer.addAttribute(new Attribute(
/*  50 */       "id", this.introspectedTable.getInsertStatementId()));
/*     */     FullyQualifiedJavaType parameterType;
/*     */     FullyQualifiedJavaType parameterType;
/*  53 */     if (this.isSimple) {
/*  54 */       parameterType = new FullyQualifiedJavaType(
/*  55 */         this.introspectedTable.getBaseRecordType());
/*     */     } else {
/*  57 */       parameterType = 
/*  58 */         this.introspectedTable.getRules().calculateAllFieldsClass();
/*     */     }
/*     */     
/*  61 */     answer.addAttribute(new Attribute("parameterType", 
/*  62 */       parameterType.getFullyQualifiedName()));
/*     */     
/*  64 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  66 */     GeneratedKey gk = this.introspectedTable.getGeneratedKey();
/*  67 */     if (gk != null) {
/*  68 */       IntrospectedColumn introspectedColumn = this.introspectedTable
/*  69 */         .getColumn(gk.getColumn());
/*     */       
/*     */ 
/*  72 */       if (introspectedColumn != null) {
/*  73 */         if (gk.isJdbcStandard()) {
/*  74 */           answer.addAttribute(new Attribute(
/*  75 */             "useGeneratedKeys", "true"));
/*  76 */           answer.addAttribute(new Attribute(
/*  77 */             "keyProperty", introspectedColumn.getJavaProperty()));
/*     */         } else {
/*  79 */           answer.addElement(getSelectKey(introspectedColumn, gk));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  84 */     StringBuilder insertClause = new StringBuilder();
/*  85 */     StringBuilder valuesClause = new StringBuilder();
/*     */     
/*  87 */     insertClause.append("INSERT INTO ");
/*  88 */     insertClause.append(this.introspectedTable
/*  89 */       .getFullyQualifiedTableNameAtRuntime());
/*  90 */     insertClause.append(" (");
/*     */     
/*  92 */     valuesClause.append("VALUES (");
/*     */     
/*  94 */     List<String> valuesClauses = new ArrayList();
/*  95 */     Iterator<IntrospectedColumn> iter = this.introspectedTable.getAllColumns()
/*  96 */       .iterator();
/*  97 */     while (iter.hasNext()) {
/*  98 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)iter.next();
/*  99 */       if (!introspectedColumn.isIdentity())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 104 */         insertClause.append(
/* 105 */           MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn));
/* 106 */         valuesClause.append(
/* 107 */           MyBatis3FormattingUtilities.getParameterClause(introspectedColumn));
/* 108 */         if (iter.hasNext()) {
/* 109 */           insertClause.append(", ");
/* 110 */           valuesClause.append(", ");
/*     */         }
/*     */         
/* 113 */         if (valuesClause.length() > 80) {
/* 114 */           answer.addElement(new TextElement(insertClause.toString()));
/* 115 */           insertClause.setLength(0);
/* 116 */           OutputUtilities.xmlIndent(insertClause, 1);
/*     */           
/* 118 */           valuesClauses.add(valuesClause.toString());
/* 119 */           valuesClause.setLength(0);
/* 120 */           OutputUtilities.xmlIndent(valuesClause, 1);
/*     */         }
/*     */       }
/*     */     }
/* 124 */     insertClause.append(')');
/* 125 */     answer.addElement(new TextElement(insertClause.toString()));
/*     */     
/* 127 */     valuesClause.append(')');
/* 128 */     valuesClauses.add(valuesClause.toString());
/*     */     
/* 130 */     for (String clause : valuesClauses) {
/* 131 */       answer.addElement(new TextElement(clause));
/*     */     }
/*     */     
/* 134 */     if (this.context.getPlugins().sqlMapInsertElementGenerated(answer, 
/* 135 */       this.introspectedTable)) {
/* 136 */       parentElement.addElement(answer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\InsertElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */