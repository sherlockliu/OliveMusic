/*    */ package org.mybatis.generator.codegen.mybatis3.javamapper.elements;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*    */ import org.mybatis.generator.api.dom.java.Interface;
/*    */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*    */ import org.mybatis.generator.api.dom.java.Method;
/*    */ import org.mybatis.generator.api.dom.java.Parameter;
/*    */ import org.mybatis.generator.config.Context;
/*    */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*    */ import org.mybatis.generator.internal.rules.Rules;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectByPageMethodGenerator
/*    */   extends AbstractJavaMapperMethodGenerator
/*    */ {
/*    */   private Context context;
/*    */   
/*    */   public SelectByPageMethodGenerator(Context context)
/*    */   {
/* 40 */     this.context = context;
/*    */   }
/*    */   
/*    */   public void addInterfaceElements(Interface interfaze)
/*    */   {
/* 45 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/* 46 */     importedTypes.add(FullyQualifiedJavaType.getNewListInstance());
/* 47 */     importedTypes.add(FullyQualifiedJavaType.getNewMapInstance());
/* 48 */     importedTypes.add(FullyQualifiedJavaType.getAnnotateParam());
/* 49 */     importedTypes.add(new FullyQualifiedJavaType("com.yougou.logistics.base.common.utils.SimplePage"));
/* 50 */     String interfaceName = this.context.getJavaClientGeneratorConfiguration().getInterfaceExtendSupInterface();
/* 51 */     if ((interfaceName != null) && (!"".equals(interfaceName))) {
/* 52 */       importedTypes.add(new FullyQualifiedJavaType(interfaceName));
/*    */     }
/*    */     
/* 55 */     Method method = new Method();
/* 56 */     method.setVisibility(JavaVisibility.PUBLIC);
/*    */     
/* 58 */     FullyQualifiedJavaType returnType = 
/* 59 */       FullyQualifiedJavaType.getNewListInstance();
/*    */     FullyQualifiedJavaType listType;
/* 61 */     FullyQualifiedJavaType listType; if (this.introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/* 62 */       listType = new FullyQualifiedJavaType(this.introspectedTable
/* 63 */         .getRecordWithBLOBsType());
/*    */     }
/*    */     else {
/* 66 */       listType = new FullyQualifiedJavaType(this.introspectedTable
/* 67 */         .getBaseRecordType());
/*    */     }
/*    */     
/* 70 */     importedTypes.add(listType);
/* 71 */     returnType.addTypeArgument(listType);
/* 72 */     method.setReturnType(returnType);
/* 73 */     method.setName(this.introspectedTable
/* 74 */       .getSelectByPage());
/*    */     
/*    */ 
/* 77 */     FullyQualifiedJavaType parameterType = new FullyQualifiedJavaType("SimplePage");
/* 78 */     method.addParameter(new Parameter(parameterType, 
/* 79 */       "page", "@Param(\"page\")"));
/* 80 */     parameterType = new FullyQualifiedJavaType("String");
/* 81 */     method.addParameter(new Parameter(parameterType, 
/* 82 */       "orderByField", "@Param(\"orderByField\")"));
/* 83 */     method.addParameter(new Parameter(parameterType, 
/* 84 */       "orderBy", "@Param(\"orderBy\")"));
/*    */     
/* 86 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 87 */       this.introspectedTable);
/*    */     
/* 89 */     addMapperAnnotations(interfaze, method);
/*    */     
/* 91 */     interfaze.addImportedTypes(importedTypes);
/* 92 */     interfaze.addMethod(method);
/*    */   }
/*    */   
/*    */   public void addMapperAnnotations(Interface interfaze, Method method) {}
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\elements\SelectByPageMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */