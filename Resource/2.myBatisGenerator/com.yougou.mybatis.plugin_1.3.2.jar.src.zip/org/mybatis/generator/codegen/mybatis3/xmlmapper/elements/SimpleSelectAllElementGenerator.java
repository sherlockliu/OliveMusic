/*    */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedColumn;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.TextElement;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*    */ import org.mybatis.generator.config.Context;
/*    */ import org.mybatis.generator.internal.util.StringUtility;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleSelectAllElementGenerator
/*    */   extends AbstractXmlElementGenerator
/*    */ {
/*    */   public void addElements(XmlElement parentElement)
/*    */   {
/* 42 */     XmlElement answer = new XmlElement("select");
/*    */     
/* 44 */     answer.addAttribute(new Attribute(
/* 45 */       "id", this.introspectedTable.getSelectAllStatementId()));
/* 46 */     answer.addAttribute(new Attribute("resultMap", 
/* 47 */       this.introspectedTable.getBaseResultMapId()));
/*    */     
/* 49 */     this.context.getCommentGenerator().addComment(answer);
/*    */     
/* 51 */     StringBuilder sb = new StringBuilder();
/* 52 */     sb.append("SELECT ");
/* 53 */     Iterator<IntrospectedColumn> iter = this.introspectedTable.getAllColumns()
/* 54 */       .iterator();
/* 55 */     while (iter.hasNext()) {
/* 56 */       sb.append(MyBatis3FormattingUtilities.getSelectListPhrase(
/* 57 */         (IntrospectedColumn)iter.next()));
/*    */       
/* 59 */       if (iter.hasNext()) {
/* 60 */         sb.append(", ");
/*    */       }
/*    */       
/* 63 */       if (sb.length() > 80) {
/* 64 */         answer.addElement(new TextElement(sb.toString()));
/* 65 */         sb.setLength(0);
/*    */       }
/*    */     }
/*    */     
/* 69 */     if (sb.length() > 0) {
/* 70 */       answer.addElement(new TextElement(sb.toString()));
/*    */     }
/*    */     
/* 73 */     sb.setLength(0);
/* 74 */     sb.append("FROM ");
/* 75 */     sb.append(this.introspectedTable
/* 76 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/* 77 */     answer.addElement(new TextElement(sb.toString()));
/*    */     
/* 79 */     String orderByClause = this.introspectedTable.getTableConfigurationProperty("selectAllOrderByClause");
/* 80 */     boolean hasOrderBy = StringUtility.stringHasValue(orderByClause);
/* 81 */     if (hasOrderBy) {
/* 82 */       sb.setLength(0);
/* 83 */       sb.append("ORDER BY ");
/* 84 */       sb.append(orderByClause);
/* 85 */       answer.addElement(new TextElement(sb.toString()));
/*    */     }
/*    */     
/* 88 */     if (this.context.getPlugins().sqlMapSelectAllElementGenerated(
/* 89 */       answer, this.introspectedTable)) {
/* 90 */       parentElement.addElement(answer);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\SimpleSelectAllElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */