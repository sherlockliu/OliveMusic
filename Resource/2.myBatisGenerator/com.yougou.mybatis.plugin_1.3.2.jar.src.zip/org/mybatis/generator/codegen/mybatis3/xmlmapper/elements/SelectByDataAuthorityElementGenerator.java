/*     */ package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectByDataAuthorityElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  42 */     XmlElement answer = new XmlElement("select");
/*     */     
/*     */ 
/*     */ 
/*  46 */     this.context.getCommentGenerator().addComment(answer, false);
/*     */     
/*  48 */     answer.addAttribute(new Attribute(
/*  49 */       "id", "selectByPageForDataAuthority"));
/*  50 */     answer.addAttribute(new Attribute("resultMap", 
/*  51 */       this.introspectedTable.getBaseResultMapId()));
/*     */     
/*  53 */     answer.addAttribute(new Attribute("parameterType", 
/*  54 */       "map"));
/*     */     
/*  56 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  58 */     StringBuilder sb = new StringBuilder();
/*  59 */     sb.append("SELECT ");
/*     */     
/*  61 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */     if (this.introspectedTable.getRules().generateBaseColumnList()) {
/*  68 */       answer.addElement(getBaseColumnListElement());
/*     */     } else {
/*  70 */       sb.setLength(0);
/*  71 */       Iterator<IntrospectedColumn> iter = this.introspectedTable
/*  72 */         .getNonBLOBColumns().iterator();
/*  73 */       while (iter.hasNext()) {
/*  74 */         sb.append(MyBatis3FormattingUtilities.getSelectListPhrase(
/*  75 */           (IntrospectedColumn)iter.next()));
/*     */         
/*  77 */         if (iter.hasNext()) {
/*  78 */           sb.append(", ");
/*     */         }
/*     */         
/*  81 */         if (sb.length() > 80) {
/*  82 */           answer.addElement(new TextElement(sb.toString()));
/*  83 */           sb.setLength(0);
/*     */         }
/*     */       }
/*  86 */       answer.addElement(new TextElement(sb.toString()));
/*     */     }
/*     */     
/*  89 */     if (this.introspectedTable.hasBLOBColumns()) {
/*  90 */       answer.addElement(new TextElement(","));
/*  91 */       answer.addElement(getBlobColumnListElement());
/*     */     }
/*     */     
/*  94 */     sb.setLength(0);
/*  95 */     sb.append(" FROM ");
/*  96 */     sb.append(this.introspectedTable
/*  97 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/*  98 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */     parentElement.addElement(answer);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\xmlmapper\elements\SelectByDataAuthorityElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */