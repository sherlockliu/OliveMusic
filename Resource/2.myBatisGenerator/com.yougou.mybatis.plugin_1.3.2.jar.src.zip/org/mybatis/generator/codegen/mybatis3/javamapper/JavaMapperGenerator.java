/*     */ package org.mybatis.generator.codegen.mybatis3.javamapper;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.codegen.AbstractJavaClientGenerator;
/*     */ import org.mybatis.generator.codegen.AbstractXmlGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.AbstractJavaMapperMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.CountByExampleMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.DeleteByExampleMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.DeleteByPrimaryKeyMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.InsertMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.InsertSelectiveMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.SelectByExampleWithBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.SelectByExampleWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.SelectByPageMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.SelectByPrimaryKeyMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.SelectCountMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.UpdateByExampleSelectiveMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.UpdateByExampleWithBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.UpdateByExampleWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.UpdateByPrimaryKeySelectiveMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.UpdateByPrimaryKeyWithBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.javamapper.elements.UpdateByPrimaryKeyWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.mybatis3.xmlmapper.XMLMapperGenerator;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaMapperGenerator
/*     */   extends AbstractJavaClientGenerator
/*     */ {
/*     */   public JavaMapperGenerator()
/*     */   {
/*  63 */     super(true);
/*     */   }
/*     */   
/*     */   public JavaMapperGenerator(boolean requiresMatchedXMLGenerator) {
/*  67 */     super(requiresMatchedXMLGenerator);
/*     */   }
/*     */   
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  72 */     this.progressCallback.startTask(Messages.getString("Progress.17", 
/*  73 */       this.introspectedTable.getFullyQualifiedTable().toString()));
/*  74 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/*  76 */     FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/*  77 */       this.introspectedTable.getMyBatis3JavaMapperType());
/*  78 */     Interface interfaze = new Interface(type);
/*  79 */     interfaze.setVisibility(JavaVisibility.PUBLIC);
/*     */     
/*  81 */     commentGenerator.addClassComment(interfaze);
/*     */     
/*  83 */     String rootInterface = this.introspectedTable
/*  84 */       .getTableConfigurationProperty("rootInterface");
/*  85 */     if (!StringUtility.stringHasValue(rootInterface)) {
/*  86 */       rootInterface = 
/*  87 */         this.context.getJavaClientGeneratorConfiguration().getProperty("rootInterface");
/*     */     }
/*     */     
/*  90 */     if (StringUtility.stringHasValue(rootInterface)) {
/*  91 */       FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
/*  92 */         rootInterface);
/*  93 */       interfaze.addSuperInterface(fqjt);
/*  94 */       interfaze.addImportedType(fqjt);
/*     */     }
/*     */     
/*  97 */     JavaClientGeneratorConfiguration clientGenerator = this.context.getJavaClientGeneratorConfiguration();
/*  98 */     if (clientGenerator.exclusionsMethods != null) {
/*  99 */       if (!clientGenerator.exclusionsMethods.contains("countByQuery")) {
/* 100 */         addCountByExampleMethod(interfaze);
/*     */       }
/* 102 */       if (!clientGenerator.exclusionsMethods.contains("deleteByQuery")) {
/* 103 */         addDeleteByExampleMethod(interfaze);
/*     */       }
/* 105 */       if (!clientGenerator.exclusionsMethods.contains("deleteByPrimaryKey")) {
/* 106 */         addDeleteByPrimaryKeyMethod(interfaze);
/*     */       }
/* 108 */       if (!clientGenerator.exclusionsMethods.contains("insert")) {
/* 109 */         addInsertMethod(interfaze);
/*     */       }
/* 111 */       if (!clientGenerator.exclusionsMethods.contains("insertSelective")) {
/* 112 */         addInsertSelectiveMethod(interfaze);
/*     */       }
/* 114 */       if (!clientGenerator.exclusionsMethods.contains("selectByQuery")) {
/* 115 */         addSelectByExampleWithBLOBsMethod(interfaze);
/*     */       }
/* 117 */       if (!clientGenerator.exclusionsMethods.contains("selectByQueryWithBLOBs")) {
/* 118 */         addSelectByExampleWithoutBLOBsMethod(interfaze);
/*     */       }
/* 120 */       if (!clientGenerator.exclusionsMethods.contains("selectByPrimaryKey")) {
/* 121 */         addSelectByPrimaryKeyMethod(interfaze);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 128 */       if (!clientGenerator.exclusionsMethods.contains("selectCount")) {
/* 129 */         addSelectCountMethod(interfaze);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 137 */       if (!clientGenerator.exclusionsMethods.contains("selectByPage")) {
/* 138 */         addSelectByPageMethod(interfaze);
/*     */       }
/*     */       
/* 141 */       if (!clientGenerator.exclusionsMethods.contains("updateByQuery")) {
/* 142 */         addUpdateByExampleSelectiveMethod(interfaze);
/*     */       }
/* 144 */       if (!clientGenerator.exclusionsMethods.contains("updateByQueryWithBLOBs")) {
/* 145 */         addUpdateByExampleWithBLOBsMethod(interfaze);
/*     */       }
/* 147 */       if (!clientGenerator.exclusionsMethods.contains("updateByQueryWithBLOBs")) {
/* 148 */         addUpdateByExampleWithoutBLOBsMethod(interfaze);
/*     */       }
/* 150 */       if (!clientGenerator.exclusionsMethods.contains("updateByPrimaryKeySelective")) {
/* 151 */         addUpdateByPrimaryKeySelectiveMethod(interfaze);
/*     */       }
/* 153 */       if (!clientGenerator.exclusionsMethods.contains("updateByPrimaryKeyWithBLOBs")) {
/* 154 */         addUpdateByPrimaryKeyWithBLOBsMethod(interfaze);
/*     */       }
/* 156 */       if (!clientGenerator.exclusionsMethods.contains("updateByPrimaryKeyWithBLOBs")) {
/* 157 */         addUpdateByPrimaryKeyWithoutBLOBsMethod(interfaze);
/*     */       }
/*     */     } else {
/* 160 */       addDeleteByPrimaryKeyMethod(interfaze);
/* 161 */       addInsertMethod(interfaze);
/* 162 */       addInsertSelectiveMethod(interfaze);
/* 163 */       addSelectByPrimaryKeyMethod(interfaze);
/* 164 */       addSelectCountMethod(interfaze);
/* 165 */       addUpdateByPrimaryKeySelectiveMethod(interfaze);
/* 166 */       addUpdateByPrimaryKeyWithBLOBsMethod(interfaze);
/* 167 */       addUpdateByPrimaryKeyWithoutBLOBsMethod(interfaze);
/*     */     }
/*     */     
/* 170 */     List<CompilationUnit> answer = new ArrayList();
/* 171 */     if (this.context.getPlugins().clientGenerated(interfaze, null, 
/* 172 */       this.introspectedTable)) {
/* 173 */       answer.add(interfaze);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 181 */     JavaClientGeneratorConfiguration config = this.context.getJavaClientGeneratorConfiguration();
/* 182 */     if (config.getInterFaceExtendSupInterfaceDoMain().length() > 0) {
/* 183 */       interfaze.addImportedType(new FullyQualifiedJavaType(config.getInterfaceExtendSupInterface()));
/* 184 */       String basemapper = config.getInterFaceExtendSupInterfaceDoMain();
/* 185 */       String modelName = this.introspectedTable.getFullyQualifiedTable().getDomainObjectName();
/* 186 */       if (new Boolean(config.getEnableInterfaceSupInterfaceGenericity()).booleanValue()) {
/* 187 */         interfaze.addImportedType(new FullyQualifiedJavaType(this.introspectedTable.getBaseRecordType()));
/* 188 */         interfaze.addSuperInterface(new FullyQualifiedJavaType(basemapper + "<" + modelName + ">"));
/*     */       } else {
/* 190 */         interfaze.addSuperInterface(new FullyQualifiedJavaType(basemapper));
/*     */       }
/*     */     }
/*     */     
/* 194 */     List<CompilationUnit> extraCompilationUnits = getExtraCompilationUnits();
/* 195 */     if (extraCompilationUnits != null) {
/* 196 */       answer.addAll(extraCompilationUnits);
/*     */     }
/*     */     
/* 199 */     return answer;
/*     */   }
/*     */   
/*     */   protected void addCountByExampleMethod(Interface interfaze) {
/* 203 */     if (this.introspectedTable.getRules().generateCountByExample()) {
/* 204 */       AbstractJavaMapperMethodGenerator methodGenerator = new CountByExampleMethodGenerator();
/* 205 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addDeleteByExampleMethod(Interface interfaze) {
/* 210 */     if (this.introspectedTable.getRules().generateDeleteByExample()) {
/* 211 */       AbstractJavaMapperMethodGenerator methodGenerator = new DeleteByExampleMethodGenerator();
/* 212 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addDeleteByPrimaryKeyMethod(Interface interfaze) {
/* 217 */     if (this.introspectedTable.getRules().generateDeleteByPrimaryKey()) {
/* 218 */       AbstractJavaMapperMethodGenerator methodGenerator = new DeleteByPrimaryKeyMethodGenerator(false);
/* 219 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertMethod(Interface interfaze) {
/* 224 */     if (this.introspectedTable.getRules().generateInsert()) {
/* 225 */       AbstractJavaMapperMethodGenerator methodGenerator = new InsertMethodGenerator(false);
/* 226 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertSelectiveMethod(Interface interfaze) {
/* 231 */     if (this.introspectedTable.getRules().generateInsertSelective()) {
/* 232 */       AbstractJavaMapperMethodGenerator methodGenerator = new InsertSelectiveMethodGenerator();
/* 233 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByExampleWithBLOBsMethod(Interface interfaze) {
/* 238 */     if (this.introspectedTable.getRules().generateSelectByExampleWithBLOBs()) {
/* 239 */       AbstractJavaMapperMethodGenerator methodGenerator = new SelectByExampleWithBLOBsMethodGenerator();
/* 240 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByExampleWithoutBLOBsMethod(Interface interfaze) {
/* 245 */     if (this.introspectedTable.getRules().generateSelectByExampleWithoutBLOBs()) {
/* 246 */       AbstractJavaMapperMethodGenerator methodGenerator = new SelectByExampleWithoutBLOBsMethodGenerator();
/* 247 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByPrimaryKeyMethod(Interface interfaze) {
/* 252 */     if (this.introspectedTable.getRules().generateSelectByPrimaryKey()) {
/* 253 */       AbstractJavaMapperMethodGenerator methodGenerator = new SelectByPrimaryKeyMethodGenerator(false);
/* 254 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addSelectCountMethod(Interface interfaze)
/*     */   {
/* 265 */     if (this.introspectedTable.getRules().generateSelectCount()) {
/* 266 */       AbstractJavaMapperMethodGenerator methodGenerator = new SelectCountMethodGenerator();
/* 267 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addSelectByPageMethod(Interface interfaze)
/*     */   {
/* 279 */     if (this.introspectedTable.getRules().generateSelectByPage()) {
/* 280 */       AbstractJavaMapperMethodGenerator methodGenerator = new SelectByPageMethodGenerator(this.context);
/* 281 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleSelectiveMethod(Interface interfaze) {
/* 286 */     if (this.introspectedTable.getRules().generateUpdateByExampleSelective()) {
/* 287 */       AbstractJavaMapperMethodGenerator methodGenerator = new UpdateByExampleSelectiveMethodGenerator();
/* 288 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleWithBLOBsMethod(Interface interfaze) {
/* 293 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithBLOBs()) {
/* 294 */       AbstractJavaMapperMethodGenerator methodGenerator = new UpdateByExampleWithBLOBsMethodGenerator();
/* 295 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleWithoutBLOBsMethod(Interface interfaze) {
/* 300 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithoutBLOBs()) {
/* 301 */       AbstractJavaMapperMethodGenerator methodGenerator = new UpdateByExampleWithoutBLOBsMethodGenerator();
/* 302 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeySelectiveMethod(Interface interfaze) {
/* 307 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeySelective()) {
/* 308 */       AbstractJavaMapperMethodGenerator methodGenerator = new UpdateByPrimaryKeySelectiveMethodGenerator();
/* 309 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeyWithBLOBsMethod(Interface interfaze) {
/* 314 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeyWithBLOBs()) {
/* 315 */       AbstractJavaMapperMethodGenerator methodGenerator = new UpdateByPrimaryKeyWithBLOBsMethodGenerator();
/* 316 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeyWithoutBLOBsMethod(Interface interfaze)
/*     */   {
/* 322 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeyWithoutBLOBs()) {
/* 323 */       AbstractJavaMapperMethodGenerator methodGenerator = new UpdateByPrimaryKeyWithoutBLOBsMethodGenerator();
/* 324 */       initializeAndExecuteGenerator(methodGenerator, interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initializeAndExecuteGenerator(AbstractJavaMapperMethodGenerator methodGenerator, Interface interfaze)
/*     */   {
/* 331 */     methodGenerator.setContext(this.context);
/* 332 */     methodGenerator.setIntrospectedTable(this.introspectedTable);
/* 333 */     methodGenerator.setProgressCallback(this.progressCallback);
/* 334 */     methodGenerator.setWarnings(this.warnings);
/* 335 */     methodGenerator.addInterfaceElements(interfaze);
/*     */   }
/*     */   
/*     */   public List<CompilationUnit> getExtraCompilationUnits() {
/* 339 */     return null;
/*     */   }
/*     */   
/*     */   public AbstractXmlGenerator getMatchedXMLGenerator()
/*     */   {
/* 344 */     return new XMLMapperGenerator();
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\JavaMapperGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */