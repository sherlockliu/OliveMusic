/*     */ package org.mybatis.generator.codegen.mybatis3.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.Plugin.ModelClassType;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*     */ import org.mybatis.generator.codegen.RootClassInfo;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordWithBLOBsGenerator
/*     */   extends AbstractJavaGenerator
/*     */ {
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  49 */     FullyQualifiedTable table = this.introspectedTable.getFullyQualifiedTable();
/*  50 */     this.progressCallback.startTask(Messages.getString(
/*  51 */       "Progress.9", table.toString()));
/*  52 */     Plugin plugins = this.context.getPlugins();
/*  53 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/*  55 */     TopLevelClass topLevelClass = new TopLevelClass(this.introspectedTable
/*  56 */       .getRecordWithBLOBsType());
/*  57 */     topLevelClass.setVisibility(JavaVisibility.PUBLIC);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */     commentGenerator.addClassComment(topLevelClass);
/*     */     
/*  67 */     String rootClass = getRootClass();
/*  68 */     if (this.introspectedTable.getRules().generateBaseRecordClass()) {
/*  69 */       topLevelClass.setSuperClass(this.introspectedTable.getBaseRecordType());
/*     */     } else {
/*  71 */       topLevelClass.setSuperClass(this.introspectedTable.getPrimaryKeyType());
/*     */     }
/*     */     
/*  74 */     if (this.introspectedTable.isConstructorBased()) {
/*  75 */       addParameterizedConstructor(topLevelClass);
/*     */       
/*  77 */       if (!this.introspectedTable.isImmutable()) {
/*  78 */         addDefaultConstructor(topLevelClass);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  83 */     Iterator localIterator = this.introspectedTable.getBLOBColumns().iterator();
/*  82 */     while (localIterator.hasNext()) {
/*  83 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*     */       
/*  85 */       if (!RootClassInfo.getInstance(rootClass, this.warnings).containsProperty(introspectedColumn))
/*     */       {
/*     */ 
/*     */ 
/*  89 */         Field field = getJavaBeansField(introspectedColumn);
/*  90 */         if (plugins.modelFieldGenerated(field, topLevelClass, 
/*  91 */           introspectedColumn, this.introspectedTable, 
/*  92 */           Plugin.ModelClassType.RECORD_WITH_BLOBS)) {
/*  93 */           topLevelClass.addField(field);
/*  94 */           topLevelClass.addImportedType(field.getType());
/*     */         }
/*     */         
/*  97 */         Method method = getJavaBeansGetter(introspectedColumn);
/*  98 */         if (plugins.modelGetterMethodGenerated(method, topLevelClass, 
/*  99 */           introspectedColumn, this.introspectedTable, 
/* 100 */           Plugin.ModelClassType.RECORD_WITH_BLOBS)) {
/* 101 */           topLevelClass.addMethod(method);
/*     */         }
/*     */         
/* 104 */         if (!this.introspectedTable.isImmutable()) {
/* 105 */           method = getJavaBeansSetter(introspectedColumn);
/* 106 */           if (plugins.modelSetterMethodGenerated(method, topLevelClass, 
/* 107 */             introspectedColumn, this.introspectedTable, 
/* 108 */             Plugin.ModelClassType.RECORD_WITH_BLOBS)) {
/* 109 */             topLevelClass.addMethod(method);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 114 */     List<CompilationUnit> answer = new ArrayList();
/* 115 */     if (this.context.getPlugins().modelRecordWithBLOBsClassGenerated(
/* 116 */       topLevelClass, this.introspectedTable)) {
/* 117 */       answer.add(topLevelClass);
/*     */     }
/* 119 */     return answer;
/*     */   }
/*     */   
/*     */   private void addParameterizedConstructor(TopLevelClass topLevelClass) {
/* 123 */     Method method = new Method();
/* 124 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 125 */     method.setConstructor(true);
/* 126 */     method.setName(topLevelClass.getType().getShortName());
/* 127 */     this.context.getCommentGenerator().addGeneralMethodComment(method, this.introspectedTable);
/*     */     
/*     */ 
/* 130 */     Iterator localIterator1 = this.introspectedTable.getAllColumns().iterator();
/* 129 */     while (localIterator1.hasNext()) {
/* 130 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator1.next();
/* 131 */       method.addParameter(new Parameter(introspectedColumn.getFullyQualifiedJavaType(), 
/* 132 */         introspectedColumn.getJavaProperty()));
/*     */     }
/*     */     
/* 135 */     boolean comma = false;
/* 136 */     StringBuilder sb = new StringBuilder();
/* 137 */     sb.append("super(");
/*     */     
/* 139 */     Iterator localIterator2 = this.introspectedTable.getNonBLOBColumns().iterator();
/* 138 */     while (localIterator2.hasNext()) {
/* 139 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator2.next();
/* 140 */       if (comma) {
/* 141 */         sb.append(", ");
/*     */       } else {
/* 143 */         comma = true;
/*     */       }
/* 145 */       sb.append(introspectedColumn.getJavaProperty());
/*     */     }
/* 147 */     sb.append(");");
/* 148 */     method.addBodyLine(sb.toString());
/*     */     
/*     */ 
/* 151 */     localIterator2 = this.introspectedTable.getBLOBColumns().iterator();
/* 150 */     while (localIterator2.hasNext()) {
/* 151 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator2.next();
/* 152 */       sb.setLength(0);
/* 153 */       sb.append("this.");
/* 154 */       sb.append(introspectedColumn.getJavaProperty());
/* 155 */       sb.append(" = ");
/* 156 */       sb.append(introspectedColumn.getJavaProperty());
/* 157 */       sb.append(';');
/* 158 */       method.addBodyLine(sb.toString());
/*     */     }
/*     */     
/* 161 */     topLevelClass.addMethod(method);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\model\RecordWithBLOBsGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */