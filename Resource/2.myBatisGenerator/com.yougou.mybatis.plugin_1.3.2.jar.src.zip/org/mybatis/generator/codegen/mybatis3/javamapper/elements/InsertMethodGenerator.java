/*    */ package org.mybatis.generator.codegen.mybatis3.javamapper.elements;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.TreeSet;
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*    */ import org.mybatis.generator.api.dom.java.Interface;
/*    */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*    */ import org.mybatis.generator.api.dom.java.Method;
/*    */ import org.mybatis.generator.api.dom.java.Parameter;
/*    */ import org.mybatis.generator.config.Context;
/*    */ import org.mybatis.generator.internal.rules.Rules;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class InsertMethodGenerator
/*    */   extends AbstractJavaMapperMethodGenerator
/*    */ {
/*    */   boolean isSimple;
/*    */   
/*    */   public InsertMethodGenerator(boolean isSimple)
/*    */   {
/* 38 */     this.isSimple = isSimple;
/*    */   }
/*    */   
/*    */   public void addInterfaceElements(Interface interfaze)
/*    */   {
/* 43 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/* 44 */     Method method = new Method();
/*    */     
/* 46 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 47 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 48 */     method.setName(this.introspectedTable.getInsertStatementId());
/*    */     FullyQualifiedJavaType parameterType;
/*    */     FullyQualifiedJavaType parameterType;
/* 51 */     if (this.isSimple) {
/* 52 */       parameterType = new FullyQualifiedJavaType(
/* 53 */         this.introspectedTable.getBaseRecordType());
/*    */     } else {
/* 55 */       parameterType = 
/* 56 */         this.introspectedTable.getRules().calculateAllFieldsClass();
/*    */     }
/*    */     
/* 59 */     importedTypes.add(parameterType);
/* 60 */     method.addParameter(new Parameter(parameterType, "record"));
/*    */     
/* 62 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 63 */       this.introspectedTable);
/*    */     
/* 65 */     addMapperAnnotations(interfaze, method);
/*    */     
/* 67 */     if (this.context.getPlugins().clientInsertMethodGenerated(method, interfaze, 
/* 68 */       this.introspectedTable)) {
/* 69 */       interfaze.addImportedTypes(importedTypes);
/* 70 */       interfaze.addMethod(method);
/*    */     }
/*    */   }
/*    */   
/*    */   public void addMapperAnnotations(Interface interfaze, Method method) {}
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\javamapper\elements\InsertMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */