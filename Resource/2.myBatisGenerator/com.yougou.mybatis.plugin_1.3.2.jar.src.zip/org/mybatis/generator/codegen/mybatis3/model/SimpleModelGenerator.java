/*     */ package org.mybatis.generator.codegen.mybatis3.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.Plugin.ModelClassType;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*     */ import org.mybatis.generator.codegen.RootClassInfo;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaModelGeneratorConfiguration;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleModelGenerator
/*     */   extends AbstractJavaGenerator
/*     */ {
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  52 */     FullyQualifiedTable table = this.introspectedTable.getFullyQualifiedTable();
/*  53 */     this.progressCallback.startTask(Messages.getString("Progress.8", table.toString()));
/*  54 */     Plugin plugins = this.context.getPlugins();
/*  55 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/*  57 */     FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/*  58 */       this.introspectedTable.getBaseRecordType());
/*  59 */     TopLevelClass topLevelClass = new TopLevelClass(type);
/*  60 */     topLevelClass.setVisibility(JavaVisibility.PUBLIC);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */     commentGenerator.addClassComment(topLevelClass);
/*     */     
/*  70 */     FullyQualifiedJavaType superClass = getSuperClass();
/*  71 */     if (superClass != null) {
/*  72 */       topLevelClass.setSuperClass(superClass);
/*  73 */       topLevelClass.addImportedType(superClass);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */     String rootInterface = this.introspectedTable
/*  81 */       .getTableConfigurationProperty("rootInterface");
/*  82 */     if (!StringUtility.stringHasValue(rootInterface)) {
/*  83 */       rootInterface = 
/*  84 */         this.context.getJavaModelGeneratorConfiguration().getProperty("rootInterface");
/*     */     }
/*     */     
/*  87 */     if (StringUtility.stringHasValue(rootInterface)) {
/*  88 */       FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
/*  89 */         rootInterface);
/*  90 */       topLevelClass.addSuperInterface(fqjt);
/*  91 */       topLevelClass.addImportedType(fqjt);
/*     */     }
/*     */     
/*  94 */     List<IntrospectedColumn> introspectedColumns = this.introspectedTable.getAllColumns();
/*     */     
/*  96 */     if (this.introspectedTable.isConstructorBased()) {
/*  97 */       addParameterizedConstructor(topLevelClass);
/*     */       
/*  99 */       if (!this.introspectedTable.isImmutable()) {
/* 100 */         addDefaultConstructor(topLevelClass);
/*     */       }
/*     */     }
/*     */     
/* 104 */     String rootClass = getRootClass();
/* 105 */     for (IntrospectedColumn introspectedColumn : introspectedColumns)
/*     */     {
/* 107 */       if (!RootClassInfo.getInstance(rootClass, this.warnings).containsProperty(introspectedColumn))
/*     */       {
/*     */ 
/*     */ 
/* 111 */         Field field = getJavaBeansField(introspectedColumn);
/* 112 */         if (plugins.modelFieldGenerated(field, topLevelClass, 
/* 113 */           introspectedColumn, this.introspectedTable, 
/* 114 */           Plugin.ModelClassType.BASE_RECORD)) {
/* 115 */           topLevelClass.addField(field);
/* 116 */           topLevelClass.addImportedType(field.getType());
/*     */         }
/*     */         
/* 119 */         Method method = getJavaBeansGetter(introspectedColumn);
/* 120 */         if (plugins.modelGetterMethodGenerated(method, topLevelClass, 
/* 121 */           introspectedColumn, this.introspectedTable, 
/* 122 */           Plugin.ModelClassType.BASE_RECORD)) {
/* 123 */           topLevelClass.addMethod(method);
/*     */         }
/*     */         
/* 126 */         if (!this.introspectedTable.isImmutable()) {
/* 127 */           method = getJavaBeansSetter(introspectedColumn);
/* 128 */           if (plugins.modelSetterMethodGenerated(method, topLevelClass, 
/* 129 */             introspectedColumn, this.introspectedTable, 
/* 130 */             Plugin.ModelClassType.BASE_RECORD)) {
/* 131 */             topLevelClass.addMethod(method);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 136 */     List<CompilationUnit> answer = new ArrayList();
/* 137 */     if (this.context.getPlugins().modelBaseRecordClassGenerated(topLevelClass, 
/* 138 */       this.introspectedTable)) {
/* 139 */       answer.add(topLevelClass);
/*     */     }
/* 141 */     return answer;
/*     */   }
/*     */   
/*     */   private FullyQualifiedJavaType getSuperClass()
/*     */   {
/* 146 */     String rootClass = getRootClass();
/* 147 */     FullyQualifiedJavaType superClass; FullyQualifiedJavaType superClass; if (rootClass != null) {
/* 148 */       superClass = new FullyQualifiedJavaType(rootClass);
/*     */     } else {
/* 150 */       superClass = null;
/*     */     }
/*     */     
/* 153 */     return superClass;
/*     */   }
/*     */   
/*     */   private void addParameterizedConstructor(TopLevelClass topLevelClass) {
/* 157 */     Method method = new Method();
/* 158 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 159 */     method.setConstructor(true);
/* 160 */     method.setName(topLevelClass.getType().getShortName());
/* 161 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 162 */       this.introspectedTable);
/*     */     
/* 164 */     List<IntrospectedColumn> constructorColumns = this.introspectedTable
/* 165 */       .getAllColumns();
/*     */     
/* 167 */     for (IntrospectedColumn introspectedColumn : constructorColumns) {
/* 168 */       method.addParameter(new Parameter(introspectedColumn
/* 169 */         .getFullyQualifiedJavaType(), introspectedColumn
/* 170 */         .getJavaProperty()));
/*     */     }
/*     */     
/* 173 */     StringBuilder sb = new StringBuilder();
/* 174 */     Iterator localIterator2; if (this.introspectedTable.getRules().generatePrimaryKeyClass()) {
/* 175 */       boolean comma = false;
/* 176 */       sb.append("super(");
/*     */       
/* 178 */       localIterator2 = this.introspectedTable.getPrimaryKeyColumns().iterator();
/* 177 */       while (localIterator2.hasNext()) {
/* 178 */         IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator2.next();
/* 179 */         if (comma) {
/* 180 */           sb.append(", ");
/*     */         } else {
/* 182 */           comma = true;
/*     */         }
/* 184 */         sb.append(introspectedColumn.getJavaProperty());
/*     */       }
/* 186 */       sb.append(");");
/* 187 */       method.addBodyLine(sb.toString());
/*     */     }
/*     */     
/* 190 */     Object introspectedColumns = this.introspectedTable.getAllColumns();
/*     */     
/* 192 */     for (IntrospectedColumn introspectedColumn : (List)introspectedColumns) {
/* 193 */       sb.setLength(0);
/* 194 */       sb.append("this.");
/* 195 */       sb.append(introspectedColumn.getJavaProperty());
/* 196 */       sb.append(" = ");
/* 197 */       sb.append(introspectedColumn.getJavaProperty());
/* 198 */       sb.append(';');
/* 199 */       method.addBodyLine(sb.toString());
/*     */     }
/*     */     
/* 202 */     topLevelClass.addMethod(method);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\mybatis3\model\SimpleModelGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */