/*     */ package org.mybatis.generator.codegen;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.internal.ObjectFactory;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RootClassInfo
/*     */ {
/*  42 */   private static Map<String, RootClassInfo> rootClassInfoMap = Collections.synchronizedMap(new HashMap());
/*     */   private PropertyDescriptor[] propertyDescriptors;
/*     */   private String className;
/*     */   private List<String> warnings;
/*     */   
/*  47 */   public static RootClassInfo getInstance(String className, List<String> warnings) { RootClassInfo classInfo = (RootClassInfo)rootClassInfoMap.get(className);
/*  48 */     if (classInfo == null) {
/*  49 */       classInfo = new RootClassInfo(className, warnings);
/*  50 */       rootClassInfoMap.put(className, classInfo);
/*     */     }
/*     */     
/*  53 */     return classInfo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RootClassInfo(String className, List<String> warnings)
/*     */   {
/*  62 */     this.className = className;
/*  63 */     this.warnings = warnings;
/*     */     
/*  65 */     if (className == null) {
/*  66 */       return;
/*     */     }
/*     */     try
/*     */     {
/*  70 */       Class<?> clazz = ObjectFactory.externalClassForName(className);
/*  71 */       BeanInfo bi = Introspector.getBeanInfo(clazz);
/*  72 */       this.propertyDescriptors = bi.getPropertyDescriptors();
/*     */     } catch (Exception localException) {
/*  74 */       this.propertyDescriptors = null;
/*  75 */       warnings.add(Messages.getString("Warning.20", className));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean containsProperty(IntrospectedColumn introspectedColumn) {
/*  80 */     if (this.propertyDescriptors == null) {
/*  81 */       return false;
/*     */     }
/*     */     
/*  84 */     boolean found = false;
/*  85 */     String propertyName = introspectedColumn.getJavaProperty();
/*  86 */     String propertyType = introspectedColumn.getFullyQualifiedJavaType()
/*  87 */       .getFullyQualifiedName();
/*     */     
/*     */ 
/*     */ 
/*  91 */     for (int i = 0; i < this.propertyDescriptors.length; i++) {
/*  92 */       PropertyDescriptor propertyDescriptor = this.propertyDescriptors[i];
/*     */       
/*  94 */       if (propertyDescriptor.getName().equals(propertyName))
/*     */       {
/*     */ 
/*     */ 
/*  98 */         if (!propertyDescriptor.getPropertyType().getName().equals(
/*  99 */           propertyType)) {
/* 100 */           this.warnings.add(Messages.getString("Warning.21", 
/* 101 */             propertyName, this.className, propertyType));
/* 102 */           break;
/*     */         }
/*     */         
/*     */ 
/* 106 */         if (propertyDescriptor.getReadMethod() == null) {
/* 107 */           this.warnings.add(Messages.getString("Warning.22", 
/* 108 */             propertyName, this.className));
/* 109 */           break;
/*     */         }
/*     */         
/*     */ 
/* 113 */         if (propertyDescriptor.getWriteMethod() == null) {
/* 114 */           this.warnings.add(Messages.getString("Warning.23", 
/* 115 */             propertyName, this.className));
/* 116 */           break;
/*     */         }
/*     */         
/* 119 */         found = true;
/* 120 */         break;
/*     */       }
/*     */     }
/*     */     
/* 124 */     return found;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\RootClassInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */