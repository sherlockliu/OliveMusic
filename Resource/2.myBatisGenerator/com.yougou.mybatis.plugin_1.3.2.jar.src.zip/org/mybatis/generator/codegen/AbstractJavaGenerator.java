/*     */ package org.mybatis.generator.codegen;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaModelGeneratorConfiguration;
/*     */ import org.mybatis.generator.internal.util.JavaBeansUtil;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractJavaGenerator
/*     */   extends AbstractGenerator
/*     */ {
/*     */   public abstract List<CompilationUnit> getCompilationUnits();
/*     */   
/*     */   public static Method getGetter(Field field)
/*     */   {
/*  44 */     Method method = new Method();
/*  45 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName(), field
/*  46 */       .getType()));
/*  47 */     method.setReturnType(field.getType());
/*  48 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  49 */     StringBuilder sb = new StringBuilder();
/*  50 */     sb.append("return ");
/*  51 */     sb.append(field.getName());
/*  52 */     sb.append(';');
/*  53 */     method.addBodyLine(sb.toString());
/*  54 */     return method;
/*     */   }
/*     */   
/*     */   public Method getJavaBeansGetter(IntrospectedColumn introspectedColumn) {
/*  58 */     FullyQualifiedJavaType fqjt = introspectedColumn
/*  59 */       .getFullyQualifiedJavaType();
/*  60 */     String property = introspectedColumn.getJavaProperty();
/*     */     
/*  62 */     Method method = new Method();
/*  63 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  64 */     method.setReturnType(fqjt);
/*  65 */     method.setName(JavaBeansUtil.getGetterMethodName(property, fqjt));
/*  66 */     this.context.getCommentGenerator().addGetterComment(method, 
/*  67 */       this.introspectedTable, introspectedColumn);
/*     */     
/*  69 */     StringBuilder sb = new StringBuilder();
/*  70 */     sb.append("return ");
/*  71 */     sb.append(property);
/*  72 */     sb.append(';');
/*  73 */     method.addBodyLine(sb.toString());
/*     */     
/*  75 */     return method;
/*     */   }
/*     */   
/*     */   public Field getJavaBeansField(IntrospectedColumn introspectedColumn) {
/*  79 */     FullyQualifiedJavaType fqjt = introspectedColumn
/*  80 */       .getFullyQualifiedJavaType();
/*  81 */     String property = introspectedColumn.getJavaProperty();
/*     */     
/*  83 */     Field field = new Field();
/*  84 */     field.setVisibility(JavaVisibility.PRIVATE);
/*  85 */     field.setType(fqjt);
/*  86 */     field.setName(property);
/*  87 */     this.context.getCommentGenerator().addFieldComment(field, 
/*  88 */       this.introspectedTable, introspectedColumn);
/*     */     
/*  90 */     return field;
/*     */   }
/*     */   
/*     */   public Method getJavaBeansSetter(IntrospectedColumn introspectedColumn) {
/*  94 */     FullyQualifiedJavaType fqjt = introspectedColumn
/*  95 */       .getFullyQualifiedJavaType();
/*  96 */     String property = introspectedColumn.getJavaProperty();
/*     */     
/*  98 */     Method method = new Method();
/*  99 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 100 */     method.setName(JavaBeansUtil.getSetterMethodName(property));
/* 101 */     method.addParameter(new Parameter(fqjt, property));
/* 102 */     this.context.getCommentGenerator().addSetterComment(method, 
/* 103 */       this.introspectedTable, introspectedColumn);
/*     */     
/* 105 */     StringBuilder sb = new StringBuilder();
/* 106 */     if ((isTrimStringsEnabled()) && (introspectedColumn.isStringColumn())) {
/* 107 */       sb.append("this.");
/* 108 */       sb.append(property);
/* 109 */       sb.append(" = ");
/* 110 */       sb.append(property);
/* 111 */       sb.append(" == null ? null : ");
/* 112 */       sb.append(property);
/* 113 */       sb.append(".trim();");
/* 114 */       method.addBodyLine(sb.toString());
/*     */     } else {
/* 116 */       sb.append("this.");
/* 117 */       sb.append(property);
/* 118 */       sb.append(" = ");
/* 119 */       sb.append(property);
/* 120 */       sb.append(';');
/* 121 */       method.addBodyLine(sb.toString());
/*     */     }
/*     */     
/* 124 */     return method;
/*     */   }
/*     */   
/*     */   public boolean isTrimStringsEnabled() {
/* 128 */     Properties properties = this.context
/* 129 */       .getJavaModelGeneratorConfiguration().getProperties();
/* 130 */     boolean rc = StringUtility.isTrue(properties
/* 131 */       .getProperty("trimStrings"));
/* 132 */     return rc;
/*     */   }
/*     */   
/*     */   public String getRootClass() {
/* 136 */     String rootClass = this.introspectedTable
/* 137 */       .getTableConfigurationProperty("rootClass");
/* 138 */     if (rootClass == null) {
/* 139 */       Properties properties = this.context
/* 140 */         .getJavaModelGeneratorConfiguration().getProperties();
/* 141 */       rootClass = properties.getProperty("rootClass");
/*     */     }
/*     */     
/* 144 */     return rootClass;
/*     */   }
/*     */   
/*     */   protected void addDefaultConstructor(TopLevelClass topLevelClass) {
/* 148 */     Method method = new Method();
/* 149 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 150 */     method.setConstructor(true);
/* 151 */     method.setName(topLevelClass.getType().getShortName());
/* 152 */     method.addBodyLine("super();");
/* 153 */     this.context.getCommentGenerator().addGeneralMethodComment(method, this.introspectedTable);
/* 154 */     topLevelClass.addMethod(method);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\AbstractJavaGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */