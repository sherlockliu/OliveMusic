/*     */ package org.mybatis.generator.codegen.ibatis2.dao.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.DAOMethodNameCalculator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.AbstractDAOTemplate;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.JavaBeansUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DeleteByPrimaryKeyMethodGenerator
/*     */   extends AbstractDAOElementGenerator
/*     */ {
/*     */   public void addImplementationElements(TopLevelClass topLevelClass)
/*     */   {
/*  45 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  46 */     Method method = getMethodShell(importedTypes);
/*     */     
/*  48 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  50 */     if (!this.introspectedTable.getRules().generatePrimaryKeyClass())
/*     */     {
/*     */ 
/*  53 */       FullyQualifiedJavaType keyType = new FullyQualifiedJavaType(
/*  54 */         this.introspectedTable.getBaseRecordType());
/*  55 */       topLevelClass.addImportedType(keyType);
/*     */       
/*  57 */       sb.setLength(0);
/*  58 */       sb.append(keyType.getShortName());
/*  59 */       sb.append(" _key = new ");
/*  60 */       sb.append(keyType.getShortName());
/*  61 */       sb.append("();");
/*  62 */       method.addBodyLine(sb.toString());
/*     */       
/*     */ 
/*  65 */       Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/*  64 */       while (localIterator.hasNext()) {
/*  65 */         IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*  66 */         sb.setLength(0);
/*  67 */         sb.append("_key.");
/*  68 */         sb.append(JavaBeansUtil.getSetterMethodName(introspectedColumn
/*  69 */           .getJavaProperty()));
/*  70 */         sb.append('(');
/*  71 */         sb.append(introspectedColumn.getJavaProperty());
/*  72 */         sb.append(");");
/*  73 */         method.addBodyLine(sb.toString());
/*     */       }
/*     */     }
/*     */     
/*  77 */     sb.setLength(0);
/*  78 */     sb.append("int rows = ");
/*  79 */     sb.append(this.daoTemplate.getDeleteMethod(this.introspectedTable
/*  80 */       .getIbatis2SqlMapNamespace(), this.introspectedTable
/*  81 */       .getDeleteByPrimaryKeyStatementId(), "_key"));
/*  82 */     method.addBodyLine(sb.toString());
/*  83 */     method.addBodyLine("return rows;");
/*     */     
/*  85 */     if (this.context.getPlugins().clientDeleteByPrimaryKeyMethodGenerated(
/*  86 */       method, topLevelClass, this.introspectedTable)) {
/*  87 */       topLevelClass.addImportedTypes(importedTypes);
/*  88 */       topLevelClass.addMethod(method);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addInterfaceElements(Interface interfaze)
/*     */   {
/*  94 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  95 */     Method method = getMethodShell(importedTypes);
/*     */     
/*  97 */     if (this.context.getPlugins().clientDeleteByPrimaryKeyMethodGenerated(
/*  98 */       method, interfaze, this.introspectedTable)) {
/*  99 */       interfaze.addImportedTypes(importedTypes);
/* 100 */       interfaze.addMethod(method);
/*     */     }
/*     */   }
/*     */   
/*     */   private Method getMethodShell(Set<FullyQualifiedJavaType> importedTypes) {
/* 105 */     Method method = new Method();
/* 106 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 107 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/* 108 */     method.setName(getDAOMethodNameCalculator()
/* 109 */       .getDeleteByPrimaryKeyMethodName(this.introspectedTable));
/*     */     Iterator localIterator;
/* 111 */     if (this.introspectedTable.getRules().generatePrimaryKeyClass()) {
/* 112 */       FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/* 113 */         this.introspectedTable.getPrimaryKeyType());
/* 114 */       importedTypes.add(type);
/* 115 */       method.addParameter(new Parameter(type, "_key"));
/*     */     }
/*     */     else {
/* 118 */       localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/* 117 */       while (localIterator.hasNext()) {
/* 118 */         IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/* 119 */         FullyQualifiedJavaType type = introspectedColumn
/* 120 */           .getFullyQualifiedJavaType();
/* 121 */         importedTypes.add(type);
/* 122 */         method.addParameter(new Parameter(type, introspectedColumn
/* 123 */           .getJavaProperty()));
/*     */       }
/*     */     }
/*     */     
/* 127 */     for (FullyQualifiedJavaType fqjt : this.daoTemplate.getCheckedExceptions()) {
/* 128 */       method.addException(fqjt);
/* 129 */       importedTypes.add(fqjt);
/*     */     }
/*     */     
/* 132 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 133 */       this.introspectedTable);
/*     */     
/* 135 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\dao\elements\DeleteByPrimaryKeyMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */