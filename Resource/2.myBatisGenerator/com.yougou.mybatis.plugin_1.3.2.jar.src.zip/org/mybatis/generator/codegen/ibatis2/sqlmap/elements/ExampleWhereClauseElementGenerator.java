/*     */ package org.mybatis.generator.codegen.ibatis2.sqlmap.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExampleWhereClauseElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  39 */     XmlElement answer = new XmlElement("sql");
/*     */     
/*  41 */     answer.addAttribute(new Attribute(
/*  42 */       "id", this.introspectedTable.getExampleWhereClauseId()));
/*     */     
/*  44 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  46 */     XmlElement outerIterateElement = new XmlElement("iterate");
/*  47 */     outerIterateElement.addAttribute(new Attribute(
/*  48 */       "property", "oredCriteria"));
/*  49 */     outerIterateElement.addAttribute(new Attribute("conjunction", "or"));
/*  50 */     outerIterateElement.addAttribute(new Attribute("prepend", "where"));
/*  51 */     outerIterateElement.addAttribute(new Attribute(
/*  52 */       "removeFirstPrepend", "iterate"));
/*  53 */     answer.addElement(outerIterateElement);
/*     */     
/*  55 */     XmlElement isEqualElement = new XmlElement("isEqual");
/*  56 */     isEqualElement.addAttribute(new Attribute(
/*  57 */       "property", "oredCriteria[].valid"));
/*  58 */     isEqualElement.addAttribute(new Attribute("compareValue", "true"));
/*  59 */     outerIterateElement.addElement(isEqualElement);
/*     */     
/*  61 */     isEqualElement.addElement(new TextElement("("));
/*     */     
/*  63 */     XmlElement innerIterateElement = new XmlElement("iterate");
/*  64 */     innerIterateElement.addAttribute(new Attribute("prepend", "and"));
/*  65 */     innerIterateElement.addAttribute(new Attribute(
/*  66 */       "property", "oredCriteria[].criteriaWithoutValue"));
/*  67 */     innerIterateElement.addAttribute(new Attribute("conjunction", "and"));
/*  68 */     innerIterateElement.addElement(new TextElement(
/*  69 */       "$oredCriteria[].criteriaWithoutValue[]$"));
/*  70 */     isEqualElement.addElement(innerIterateElement);
/*     */     
/*  72 */     innerIterateElement = new XmlElement("iterate");
/*  73 */     innerIterateElement.addAttribute(new Attribute("prepend", "and"));
/*  74 */     innerIterateElement.addAttribute(new Attribute(
/*  75 */       "property", "oredCriteria[].criteriaWithSingleValue"));
/*  76 */     innerIterateElement.addAttribute(new Attribute("conjunction", "and"));
/*  77 */     innerIterateElement
/*  78 */       .addElement(new TextElement(
/*  79 */       "$oredCriteria[].criteriaWithSingleValue[].condition$ #oredCriteria[].criteriaWithSingleValue[].value#"));
/*  80 */     isEqualElement.addElement(innerIterateElement);
/*     */     
/*  82 */     innerIterateElement = new XmlElement("iterate");
/*  83 */     innerIterateElement.addAttribute(new Attribute("prepend", "and"));
/*  84 */     innerIterateElement.addAttribute(new Attribute(
/*  85 */       "property", "oredCriteria[].criteriaWithListValue"));
/*  86 */     innerIterateElement.addAttribute(new Attribute("conjunction", "and"));
/*  87 */     innerIterateElement.addElement(new TextElement(
/*  88 */       "$oredCriteria[].criteriaWithListValue[].condition$"));
/*  89 */     XmlElement innerInnerIterateElement = new XmlElement("iterate");
/*  90 */     innerInnerIterateElement.addAttribute(new Attribute("property", 
/*  91 */       "oredCriteria[].criteriaWithListValue[].values"));
/*  92 */     innerInnerIterateElement.addAttribute(new Attribute("open", "("));
/*  93 */     innerInnerIterateElement.addAttribute(new Attribute("close", ")"));
/*  94 */     innerInnerIterateElement
/*  95 */       .addAttribute(new Attribute("conjunction", ","));
/*  96 */     innerInnerIterateElement.addElement(new TextElement(
/*  97 */       "#oredCriteria[].criteriaWithListValue[].values[]#"));
/*  98 */     innerIterateElement.addElement(innerInnerIterateElement);
/*  99 */     isEqualElement.addElement(innerIterateElement);
/*     */     
/* 101 */     innerIterateElement = new XmlElement("iterate");
/* 102 */     innerIterateElement.addAttribute(new Attribute("prepend", "and"));
/* 103 */     innerIterateElement.addAttribute(new Attribute(
/* 104 */       "property", "oredCriteria[].criteriaWithBetweenValue"));
/* 105 */     innerIterateElement.addAttribute(new Attribute("conjunction", "and"));
/* 106 */     innerIterateElement.addElement(new TextElement(
/* 107 */       "$oredCriteria[].criteriaWithBetweenValue[].condition$"));
/* 108 */     innerIterateElement.addElement(new TextElement(
/* 109 */       "#oredCriteria[].criteriaWithBetweenValue[].values[0]# and"));
/* 110 */     innerIterateElement.addElement(new TextElement(
/* 111 */       "#oredCriteria[].criteriaWithBetweenValue[].values[1]#"));
/* 112 */     isEqualElement.addElement(innerIterateElement);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */     Iterator localIterator = this.introspectedTable.getNonBLOBColumns().iterator();
/* 117 */     while (localIterator.hasNext()) {
/* 118 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/* 119 */       if (StringUtility.stringHasValue(introspectedColumn
/* 120 */         .getTypeHandler()))
/*     */       {
/*     */ 
/* 123 */         StringBuilder sb1 = new StringBuilder();
/* 124 */         StringBuilder sb2 = new StringBuilder();
/* 125 */         innerIterateElement = new XmlElement("iterate");
/* 126 */         innerIterateElement
/* 127 */           .addAttribute(new Attribute("prepend", "and"));
/*     */         
/* 129 */         sb1.append("oredCriteria[].");
/* 130 */         sb1.append(introspectedColumn.getJavaProperty());
/* 131 */         sb1.append("CriteriaWithSingleValue");
/*     */         
/* 133 */         innerIterateElement.addAttribute(new Attribute(
/* 134 */           "property", sb1.toString()));
/* 135 */         innerIterateElement.addAttribute(new Attribute(
/* 136 */           "conjunction", "and"));
/*     */         
/* 138 */         sb2.append(sb1);
/*     */         
/* 140 */         sb1.insert(0, '$');
/* 141 */         sb1.append("[].condition$ ");
/*     */         
/* 143 */         sb2.insert(0, '#');
/* 144 */         sb2.append("[].value,handler=");
/* 145 */         sb2.append(introspectedColumn.getTypeHandler());
/* 146 */         sb2.append('#');
/*     */         
/* 148 */         sb1.append(sb2);
/*     */         
/* 150 */         innerIterateElement.addElement(new TextElement(sb1.toString()));
/* 151 */         isEqualElement.addElement(innerIterateElement);
/*     */         
/* 153 */         sb1.setLength(0);
/* 154 */         sb2.setLength(0);
/* 155 */         sb1.append("oredCriteria[].");
/* 156 */         sb1.append(introspectedColumn.getJavaProperty());
/* 157 */         sb1.append("CriteriaWithListValue");
/*     */         
/* 159 */         innerIterateElement = new XmlElement("iterate");
/* 160 */         innerIterateElement
/* 161 */           .addAttribute(new Attribute("prepend", "and"));
/* 162 */         innerIterateElement.addAttribute(new Attribute(
/* 163 */           "property", sb1.toString()));
/* 164 */         innerIterateElement.addAttribute(new Attribute(
/* 165 */           "conjunction", "and"));
/*     */         
/* 167 */         sb2.append('$');
/* 168 */         sb2.append(sb1);
/* 169 */         sb2.append("[].condition$");
/*     */         
/* 171 */         innerIterateElement.addElement(new TextElement(sb2.toString()));
/*     */         
/* 173 */         sb2.setLength(0);
/* 174 */         sb2.append(sb1);
/* 175 */         sb2.append("[].values");
/*     */         
/* 177 */         innerInnerIterateElement = new XmlElement("iterate");
/* 178 */         innerInnerIterateElement.addAttribute(new Attribute("property", 
/* 179 */           sb2.toString()));
/* 180 */         innerInnerIterateElement
/* 181 */           .addAttribute(new Attribute("open", "("));
/* 182 */         innerInnerIterateElement.addAttribute(new Attribute(
/* 183 */           "close", ")"));
/* 184 */         innerInnerIterateElement.addAttribute(new Attribute(
/* 185 */           "conjunction", ","));
/*     */         
/* 187 */         sb2.setLength(0);
/* 188 */         sb2.append('#');
/* 189 */         sb2.append(sb1);
/* 190 */         sb2.append("[].values[],handler=");
/* 191 */         sb2.append(introspectedColumn.getTypeHandler());
/* 192 */         sb2.append('#');
/*     */         
/* 194 */         innerInnerIterateElement.addElement(new TextElement(sb2
/* 195 */           .toString()));
/* 196 */         innerIterateElement.addElement(innerInnerIterateElement);
/* 197 */         isEqualElement.addElement(innerIterateElement);
/*     */         
/* 199 */         sb1.setLength(0);
/* 200 */         sb2.setLength(0);
/* 201 */         sb1.append("oredCriteria[].");
/* 202 */         sb1.append(introspectedColumn.getJavaProperty());
/* 203 */         sb1.append("CriteriaWithBetweenValue");
/*     */         
/* 205 */         innerIterateElement = new XmlElement("iterate");
/* 206 */         innerIterateElement
/* 207 */           .addAttribute(new Attribute("prepend", "and"));
/* 208 */         innerIterateElement.addAttribute(new Attribute(
/* 209 */           "property", sb1.toString()));
/* 210 */         innerIterateElement.addAttribute(new Attribute(
/* 211 */           "conjunction", "and"));
/*     */         
/* 213 */         sb2.append('$');
/* 214 */         sb2.append(sb1);
/* 215 */         sb2.append("[].condition$");
/*     */         
/* 217 */         innerIterateElement.addElement(new TextElement(sb2.toString()));
/*     */         
/* 219 */         sb2.setLength(0);
/* 220 */         sb2.append(sb1);
/*     */         
/* 222 */         sb1.insert(0, '#');
/* 223 */         sb1.append("[].values[0],handler=");
/* 224 */         sb1.append(introspectedColumn.getTypeHandler());
/* 225 */         sb1.append("# and");
/*     */         
/* 227 */         sb2.insert(0, '#');
/* 228 */         sb2.append("[].values[1],handler=");
/* 229 */         sb2.append(introspectedColumn.getTypeHandler());
/* 230 */         sb2.append('#');
/*     */         
/* 232 */         innerIterateElement.addElement(new TextElement(sb1.toString()));
/* 233 */         innerIterateElement.addElement(new TextElement(sb2.toString()));
/* 234 */         isEqualElement.addElement(innerIterateElement);
/*     */       }
/*     */     }
/*     */     
/* 238 */     isEqualElement.addElement(new TextElement(")"));
/*     */     
/*     */ 
/* 241 */     if (this.context.getPlugins().sqlMapExampleWhereClauseElementGenerated(answer, 
/* 242 */       this.introspectedTable)) {
/* 243 */       parentElement.addElement(answer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\sqlmap\elements\ExampleWhereClauseElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */