/*    */ package org.mybatis.generator.codegen.ibatis2.sqlmap.elements;
/*    */ 
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.TextElement;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ import org.mybatis.generator.config.Context;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DeleteByExampleElementGenerator
/*    */   extends AbstractXmlElementGenerator
/*    */ {
/*    */   public void addElements(XmlElement parentElement)
/*    */   {
/* 36 */     XmlElement answer = new XmlElement("delete");
/*    */     
/* 38 */     answer.addAttribute(new Attribute(
/* 39 */       "id", this.introspectedTable.getDeleteByExampleStatementId()));
/* 40 */     answer.addAttribute(new Attribute(
/* 41 */       "parameterClass", this.introspectedTable.getExampleType()));
/*    */     
/* 43 */     this.context.getCommentGenerator().addComment(answer);
/*    */     
/* 45 */     StringBuilder sb = new StringBuilder();
/* 46 */     sb.append("delete from ");
/* 47 */     sb.append(this.introspectedTable
/* 48 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/* 49 */     answer.addElement(new TextElement(sb.toString()));
/*    */     
/* 51 */     XmlElement includeElement = new XmlElement("include");
/* 52 */     sb.setLength(0);
/* 53 */     sb.append(this.introspectedTable.getIbatis2SqlMapNamespace());
/* 54 */     sb.append('.');
/* 55 */     sb.append(this.introspectedTable.getExampleWhereClauseId());
/* 56 */     includeElement.addAttribute(new Attribute("refid", 
/* 57 */       sb.toString()));
/*    */     
/* 59 */     answer.addElement(includeElement);
/*    */     
/* 61 */     if (this.context.getPlugins().sqlMapDeleteByExampleElementGenerated(
/* 62 */       answer, this.introspectedTable)) {
/* 63 */       parentElement.addElement(answer);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\sqlmap\elements\DeleteByExampleElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */