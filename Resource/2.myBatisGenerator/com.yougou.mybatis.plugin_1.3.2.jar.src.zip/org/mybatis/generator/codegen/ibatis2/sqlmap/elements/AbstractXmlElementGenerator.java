/*    */ package org.mybatis.generator.codegen.ibatis2.sqlmap.elements;
/*    */ 
/*    */ import org.mybatis.generator.api.IntrospectedColumn;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.TextElement;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ import org.mybatis.generator.codegen.AbstractGenerator;
/*    */ import org.mybatis.generator.config.GeneratedKey;
/*    */ import org.mybatis.generator.internal.util.StringUtility;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractXmlElementGenerator
/*    */   extends AbstractGenerator
/*    */ {
/*    */   public abstract void addElements(XmlElement paramXmlElement);
/*    */   
/*    */   protected XmlElement getSelectKey(IntrospectedColumn introspectedColumn, GeneratedKey generatedKey)
/*    */   {
/* 51 */     String identityColumnType = introspectedColumn
/* 52 */       .getFullyQualifiedJavaType().getFullyQualifiedName();
/*    */     
/* 54 */     XmlElement answer = new XmlElement("selectKey");
/* 55 */     answer.addAttribute(new Attribute("resultClass", identityColumnType));
/* 56 */     answer.addAttribute(new Attribute(
/* 57 */       "keyProperty", introspectedColumn.getJavaProperty()));
/* 58 */     if (StringUtility.stringHasValue(generatedKey.getType())) {
/* 59 */       answer.addAttribute(new Attribute("type", generatedKey.getType()));
/*    */     }
/*    */     
/* 62 */     answer.addElement(new TextElement(generatedKey
/* 63 */       .getRuntimeSqlStatement()));
/*    */     
/* 65 */     return answer;
/*    */   }
/*    */   
/*    */   protected XmlElement getBaseColumnListElement() {
/* 69 */     XmlElement answer = new XmlElement("include");
/* 70 */     answer.addAttribute(new Attribute("refid", 
/* 71 */       this.introspectedTable.getIbatis2SqlMapNamespace() + 
/* 72 */       "." + this.introspectedTable.getBaseColumnListId()));
/* 73 */     return answer;
/*    */   }
/*    */   
/*    */   protected XmlElement getBlobColumnListElement() {
/* 77 */     XmlElement answer = new XmlElement("include");
/* 78 */     answer.addAttribute(new Attribute("refid", 
/* 79 */       this.introspectedTable.getIbatis2SqlMapNamespace() + 
/* 80 */       "." + this.introspectedTable.getBlobColumnListId()));
/* 81 */     return answer;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\sqlmap\elements\AbstractXmlElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */