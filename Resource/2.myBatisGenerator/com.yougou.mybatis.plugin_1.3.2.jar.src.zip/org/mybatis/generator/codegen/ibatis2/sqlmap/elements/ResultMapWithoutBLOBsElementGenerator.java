/*    */ package org.mybatis.generator.codegen.ibatis2.sqlmap.elements;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedColumn;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ import org.mybatis.generator.codegen.ibatis2.Ibatis2FormattingUtilities;
/*    */ import org.mybatis.generator.config.Context;
/*    */ import org.mybatis.generator.internal.rules.Rules;
/*    */ import org.mybatis.generator.internal.util.StringUtility;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ResultMapWithoutBLOBsElementGenerator
/*    */   extends AbstractXmlElementGenerator
/*    */ {
/*    */   public void addElements(XmlElement parentElement)
/*    */   {
/* 41 */     boolean useColumnIndex = StringUtility.isTrue(this.introspectedTable
/* 42 */       .getTableConfigurationProperty("useColumnIndexes"));
/* 43 */     XmlElement answer = new XmlElement("resultMap");
/* 44 */     answer.addAttribute(new Attribute("id", 
/* 45 */       this.introspectedTable.getBaseResultMapId()));
/*    */     String returnType;
/*    */     String returnType;
/* 48 */     if (this.introspectedTable.getRules().generateBaseRecordClass()) {
/* 49 */       returnType = this.introspectedTable.getBaseRecordType();
/*    */     } else {
/* 51 */       returnType = this.introspectedTable.getPrimaryKeyType();
/*    */     }
/*    */     
/* 54 */     answer.addAttribute(new Attribute("class", 
/* 55 */       returnType));
/*    */     
/* 57 */     this.context.getCommentGenerator().addComment(answer);
/*    */     
/* 59 */     int i = 1;
/* 60 */     if ((StringUtility.stringHasValue(this.introspectedTable
/* 61 */       .getSelectByPrimaryKeyQueryId())) || 
/* 62 */       (StringUtility.stringHasValue(this.introspectedTable
/* 63 */       .getSelectByExampleQueryId()))) {
/* 64 */       i++;
/*    */     }
/*    */     
/*    */ 
/* 68 */     Iterator localIterator = this.introspectedTable.getNonBLOBColumns().iterator();
/* 67 */     while (localIterator.hasNext()) {
/* 68 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/* 69 */       XmlElement resultElement = new XmlElement("result");
/*    */       
/* 71 */       if (useColumnIndex) {
/* 72 */         resultElement.addAttribute(new Attribute(
/* 73 */           "columnIndex", Integer.toString(i++)));
/*    */       }
/*    */       else {
/* 76 */         resultElement.addAttribute(new Attribute(
/* 77 */           "column", Ibatis2FormattingUtilities.getRenamedColumnNameForResultMap(introspectedColumn)));
/*    */       }
/*    */       
/* 80 */       resultElement.addAttribute(new Attribute(
/* 81 */         "property", introspectedColumn.getJavaProperty()));
/* 82 */       resultElement.addAttribute(new Attribute("jdbcType", 
/* 83 */         introspectedColumn.getJdbcTypeName()));
/*    */       
/* 85 */       if (StringUtility.stringHasValue(introspectedColumn
/* 86 */         .getTypeHandler())) {
/* 87 */         resultElement.addAttribute(new Attribute(
/* 88 */           "typeHandler", introspectedColumn.getTypeHandler()));
/*    */       }
/*    */       
/* 91 */       answer.addElement(resultElement);
/*    */     }
/*    */     
/*    */ 
/* 95 */     if (this.context.getPlugins().sqlMapResultMapWithoutBLOBsElementGenerated(answer, 
/* 96 */       this.introspectedTable)) {
/* 97 */       parentElement.addElement(answer);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\sqlmap\elements\ResultMapWithoutBLOBsElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */