/*     */ package org.mybatis.generator.codegen.ibatis2.sqlmap.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.ibatis2.Ibatis2FormattingUtilities;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResultMapWithBLOBsElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  41 */     boolean useColumnIndex = StringUtility.isTrue(this.introspectedTable
/*  42 */       .getTableConfigurationProperty("useColumnIndexes"));
/*     */     
/*  44 */     XmlElement answer = new XmlElement("resultMap");
/*     */     
/*  46 */     answer.addAttribute(new Attribute("id", 
/*  47 */       this.introspectedTable.getResultMapWithBLOBsId()));
/*     */     String returnType;
/*     */     String returnType;
/*  50 */     if (this.introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/*  51 */       returnType = this.introspectedTable.getRecordWithBLOBsType();
/*     */     }
/*     */     else
/*     */     {
/*  55 */       returnType = this.introspectedTable.getBaseRecordType();
/*     */     }
/*     */     
/*  58 */     answer.addAttribute(new Attribute("class", 
/*  59 */       returnType));
/*     */     
/*  61 */     StringBuilder sb = new StringBuilder();
/*  62 */     sb.append(this.introspectedTable.getIbatis2SqlMapNamespace());
/*  63 */     sb.append('.');
/*  64 */     sb.append(this.introspectedTable.getBaseResultMapId());
/*  65 */     answer.addAttribute(new Attribute("extends", sb.toString()));
/*     */     
/*  67 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  69 */     int i = this.introspectedTable.getNonBLOBColumnCount() + 1;
/*  70 */     if ((StringUtility.stringHasValue(this.introspectedTable
/*  71 */       .getSelectByPrimaryKeyQueryId())) || 
/*  72 */       (StringUtility.stringHasValue(this.introspectedTable
/*  73 */       .getSelectByExampleQueryId()))) {
/*  74 */       i++;
/*     */     }
/*     */     
/*     */ 
/*  78 */     Iterator localIterator = this.introspectedTable.getBLOBColumns().iterator();
/*  77 */     while (localIterator.hasNext()) {
/*  78 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*  79 */       XmlElement resultElement = new XmlElement("result");
/*     */       
/*  81 */       if (useColumnIndex) {
/*  82 */         resultElement.addAttribute(new Attribute(
/*  83 */           "columnIndex", Integer.toString(i++)));
/*     */       }
/*     */       else {
/*  86 */         resultElement.addAttribute(new Attribute(
/*  87 */           "column", Ibatis2FormattingUtilities.getRenamedColumnNameForResultMap(introspectedColumn)));
/*     */       }
/*  89 */       resultElement.addAttribute(new Attribute(
/*  90 */         "property", introspectedColumn.getJavaProperty()));
/*  91 */       resultElement.addAttribute(new Attribute(
/*  92 */         "jdbcType", introspectedColumn.getJdbcTypeName()));
/*     */       
/*  94 */       if (StringUtility.stringHasValue(introspectedColumn
/*  95 */         .getTypeHandler())) {
/*  96 */         resultElement.addAttribute(new Attribute(
/*  97 */           "typeHandler", introspectedColumn.getTypeHandler()));
/*     */       }
/*     */       
/* 100 */       answer.addElement(resultElement);
/*     */     }
/*     */     
/*     */ 
/* 104 */     if (this.context.getPlugins().sqlMapResultMapWithBLOBsElementGenerated(answer, 
/* 105 */       this.introspectedTable)) {
/* 106 */       parentElement.addElement(answer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\sqlmap\elements\ResultMapWithBLOBsElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */