/*     */ package org.mybatis.generator.codegen.ibatis2.dao;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.AbstractJavaClientGenerator;
/*     */ import org.mybatis.generator.codegen.AbstractXmlGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.AbstractDAOElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.CountByExampleMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.DeleteByExampleMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.DeleteByPrimaryKeyMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.InsertMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.InsertSelectiveMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.SelectByExampleWithBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.SelectByExampleWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.SelectByPrimaryKeyMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.UpdateByExampleParmsInnerclassGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.UpdateByExampleSelectiveMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.UpdateByExampleWithBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.UpdateByExampleWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.UpdateByPrimaryKeySelectiveMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.UpdateByPrimaryKeyWithBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.elements.UpdateByPrimaryKeyWithoutBLOBsMethodGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.AbstractDAOTemplate;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DAOGenerator
/*     */   extends AbstractJavaClientGenerator
/*     */ {
/*     */   private AbstractDAOTemplate daoTemplate;
/*     */   private boolean generateForJava5;
/*     */   
/*     */   public DAOGenerator(AbstractDAOTemplate daoTemplate, boolean generateForJava5)
/*     */   {
/*  67 */     super(true);
/*  68 */     this.daoTemplate = daoTemplate;
/*  69 */     this.generateForJava5 = generateForJava5;
/*     */   }
/*     */   
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  74 */     FullyQualifiedTable table = this.introspectedTable.getFullyQualifiedTable();
/*  75 */     this.progressCallback.startTask(Messages.getString(
/*  76 */       "Progress.14", table.toString()));
/*  77 */     TopLevelClass topLevelClass = getTopLevelClassShell();
/*  78 */     Interface interfaze = getInterfaceShell();
/*     */     
/*  80 */     addCountByExampleMethod(topLevelClass, interfaze);
/*  81 */     addDeleteByExampleMethod(topLevelClass, interfaze);
/*  82 */     addDeleteByPrimaryKeyMethod(topLevelClass, interfaze);
/*  83 */     addInsertMethod(topLevelClass, interfaze);
/*  84 */     addInsertSelectiveMethod(topLevelClass, interfaze);
/*  85 */     addSelectByExampleWithBLOBsMethod(topLevelClass, interfaze);
/*  86 */     addSelectByExampleWithoutBLOBsMethod(topLevelClass, interfaze);
/*  87 */     addSelectByPrimaryKeyMethod(topLevelClass, interfaze);
/*  88 */     addUpdateByExampleParmsInnerclass(topLevelClass, interfaze);
/*  89 */     addUpdateByExampleSelectiveMethod(topLevelClass, interfaze);
/*  90 */     addUpdateByExampleWithBLOBsMethod(topLevelClass, interfaze);
/*  91 */     addUpdateByExampleWithoutBLOBsMethod(topLevelClass, interfaze);
/*  92 */     addUpdateByPrimaryKeySelectiveMethod(topLevelClass, interfaze);
/*  93 */     addUpdateByPrimaryKeyWithBLOBsMethod(topLevelClass, interfaze);
/*  94 */     addUpdateByPrimaryKeyWithoutBLOBsMethod(topLevelClass, interfaze);
/*     */     
/*  96 */     List<CompilationUnit> answer = new ArrayList();
/*  97 */     if (this.context.getPlugins().clientGenerated(interfaze, 
/*  98 */       topLevelClass, this.introspectedTable)) {
/*  99 */       answer.add(topLevelClass);
/* 100 */       answer.add(interfaze);
/*     */     }
/*     */     
/* 103 */     return answer;
/*     */   }
/*     */   
/*     */   protected TopLevelClass getTopLevelClassShell() {
/* 107 */     FullyQualifiedJavaType interfaceType = new FullyQualifiedJavaType(
/* 108 */       this.introspectedTable.getDAOInterfaceType());
/* 109 */     FullyQualifiedJavaType implementationType = new FullyQualifiedJavaType(
/* 110 */       this.introspectedTable.getDAOImplementationType());
/*     */     
/* 112 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/* 114 */     TopLevelClass answer = new TopLevelClass(implementationType);
/* 115 */     answer.setVisibility(JavaVisibility.PUBLIC);
/* 116 */     answer.setSuperClass(this.daoTemplate.getSuperClass());
/* 117 */     answer.addImportedType(this.daoTemplate.getSuperClass());
/* 118 */     answer.addSuperInterface(interfaceType);
/* 119 */     answer.addImportedType(interfaceType);
/*     */     
/*     */ 
/* 122 */     Iterator localIterator = this.daoTemplate.getImplementationImports().iterator();
/* 121 */     while (localIterator.hasNext()) {
/* 122 */       FullyQualifiedJavaType fqjt = (FullyQualifiedJavaType)localIterator.next();
/* 123 */       answer.addImportedType(fqjt);
/*     */     }
/*     */     
/* 126 */     commentGenerator.addJavaFileComment(answer);
/*     */     
/*     */ 
/* 129 */     answer.addMethod(this.daoTemplate.getConstructorClone(commentGenerator, 
/* 130 */       implementationType, this.introspectedTable));
/*     */     
/*     */ 
/* 133 */     for (Field field : this.daoTemplate.getFieldClones(commentGenerator, 
/* 134 */       this.introspectedTable)) {
/* 135 */       answer.addField(field);
/*     */     }
/*     */     
/*     */ 
/* 139 */     for (Method method : this.daoTemplate.getMethodClones(commentGenerator, 
/* 140 */       this.introspectedTable)) {
/* 141 */       answer.addMethod(method);
/*     */     }
/*     */     
/* 144 */     return answer;
/*     */   }
/*     */   
/*     */   protected Interface getInterfaceShell() {
/* 148 */     Interface answer = new Interface(new FullyQualifiedJavaType(
/* 149 */       this.introspectedTable.getDAOInterfaceType()));
/* 150 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*     */     
/* 152 */     String rootInterface = this.introspectedTable
/* 153 */       .getTableConfigurationProperty("rootInterface");
/* 154 */     if (!StringUtility.stringHasValue(rootInterface)) {
/* 155 */       rootInterface = 
/* 156 */         this.context.getJavaClientGeneratorConfiguration().getProperty("rootInterface");
/*     */     }
/*     */     
/* 159 */     if (StringUtility.stringHasValue(rootInterface)) {
/* 160 */       FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
/* 161 */         rootInterface);
/* 162 */       answer.addSuperInterface(fqjt);
/* 163 */       answer.addImportedType(fqjt);
/*     */     }
/*     */     
/* 166 */     for (FullyQualifiedJavaType fqjt : this.daoTemplate.getInterfaceImports()) {
/* 167 */       answer.addImportedType(fqjt);
/*     */     }
/*     */     
/* 170 */     this.context.getCommentGenerator().addJavaFileComment(answer);
/*     */     
/* 172 */     return answer;
/*     */   }
/*     */   
/*     */   protected void addCountByExampleMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 177 */     if (this.introspectedTable.getRules().generateCountByExample()) {
/* 178 */       AbstractDAOElementGenerator methodGenerator = new CountByExampleMethodGenerator(
/* 179 */         this.generateForJava5);
/* 180 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 181 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addDeleteByExampleMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 187 */     if (this.introspectedTable.getRules().generateDeleteByExample()) {
/* 188 */       AbstractDAOElementGenerator methodGenerator = new DeleteByExampleMethodGenerator();
/* 189 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 190 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addDeleteByPrimaryKeyMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 196 */     if (this.introspectedTable.getRules().generateDeleteByPrimaryKey()) {
/* 197 */       AbstractDAOElementGenerator methodGenerator = new DeleteByPrimaryKeyMethodGenerator();
/* 198 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 199 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 205 */     if (this.introspectedTable.getRules().generateInsert()) {
/* 206 */       AbstractDAOElementGenerator methodGenerator = new InsertMethodGenerator();
/* 207 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 208 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertSelectiveMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 214 */     if (this.introspectedTable.getRules().generateInsertSelective()) {
/* 215 */       AbstractDAOElementGenerator methodGenerator = new InsertSelectiveMethodGenerator();
/* 216 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 217 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByExampleWithBLOBsMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 223 */     if (this.introspectedTable.getRules().generateSelectByExampleWithBLOBs()) {
/* 224 */       AbstractDAOElementGenerator methodGenerator = new SelectByExampleWithBLOBsMethodGenerator(
/* 225 */         this.generateForJava5);
/* 226 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 227 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByExampleWithoutBLOBsMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 233 */     if (this.introspectedTable.getRules().generateSelectByExampleWithoutBLOBs()) {
/* 234 */       AbstractDAOElementGenerator methodGenerator = new SelectByExampleWithoutBLOBsMethodGenerator(
/* 235 */         this.generateForJava5);
/* 236 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 237 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByPrimaryKeyMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 243 */     if (this.introspectedTable.getRules().generateSelectByPrimaryKey()) {
/* 244 */       AbstractDAOElementGenerator methodGenerator = new SelectByPrimaryKeyMethodGenerator();
/* 245 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 246 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleParmsInnerclass(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 252 */     Rules rules = this.introspectedTable.getRules();
/* 253 */     if ((rules.generateUpdateByExampleSelective()) || 
/* 254 */       (rules.generateUpdateByExampleWithBLOBs()) || 
/* 255 */       (rules.generateUpdateByExampleWithoutBLOBs())) {
/* 256 */       AbstractDAOElementGenerator methodGenerator = new UpdateByExampleParmsInnerclassGenerator();
/* 257 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 258 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleSelectiveMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 264 */     if (this.introspectedTable.getRules().generateUpdateByExampleSelective()) {
/* 265 */       AbstractDAOElementGenerator methodGenerator = new UpdateByExampleSelectiveMethodGenerator();
/* 266 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 267 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleWithBLOBsMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 273 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithBLOBs()) {
/* 274 */       AbstractDAOElementGenerator methodGenerator = new UpdateByExampleWithBLOBsMethodGenerator();
/* 275 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 276 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleWithoutBLOBsMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 282 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithoutBLOBs()) {
/* 283 */       AbstractDAOElementGenerator methodGenerator = new UpdateByExampleWithoutBLOBsMethodGenerator();
/* 284 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 285 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeySelectiveMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 291 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeySelective()) {
/* 292 */       AbstractDAOElementGenerator methodGenerator = new UpdateByPrimaryKeySelectiveMethodGenerator();
/* 293 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 294 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeyWithBLOBsMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 300 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeyWithBLOBs()) {
/* 301 */       AbstractDAOElementGenerator methodGenerator = new UpdateByPrimaryKeyWithBLOBsMethodGenerator();
/* 302 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 303 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addUpdateByPrimaryKeyWithoutBLOBsMethod(TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 310 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeyWithoutBLOBs()) {
/* 311 */       AbstractDAOElementGenerator methodGenerator = new UpdateByPrimaryKeyWithoutBLOBsMethodGenerator();
/* 312 */       initializeAndExecuteGenerator(methodGenerator, topLevelClass, 
/* 313 */         interfaze);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initializeAndExecuteGenerator(AbstractDAOElementGenerator methodGenerator, TopLevelClass topLevelClass, Interface interfaze)
/*     */   {
/* 320 */     methodGenerator.setDAOTemplate(this.daoTemplate);
/* 321 */     methodGenerator.setContext(this.context);
/* 322 */     methodGenerator.setIntrospectedTable(this.introspectedTable);
/* 323 */     methodGenerator.setProgressCallback(this.progressCallback);
/* 324 */     methodGenerator.setWarnings(this.warnings);
/* 325 */     methodGenerator.addImplementationElements(topLevelClass);
/* 326 */     methodGenerator.addInterfaceElements(interfaze);
/*     */   }
/*     */   
/*     */ 
/*     */   public AbstractXmlGenerator getMatchedXMLGenerator()
/*     */   {
/* 332 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\dao\DAOGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */