/*     */ package org.mybatis.generator.codegen.ibatis2.sqlmap.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.ibatis2.Ibatis2FormattingUtilities;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectByPrimaryKeyElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  40 */     XmlElement answer = new XmlElement("select");
/*     */     
/*  42 */     answer.addAttribute(new Attribute(
/*  43 */       "id", this.introspectedTable.getSelectByPrimaryKeyStatementId()));
/*  44 */     if (this.introspectedTable.getRules().generateResultMapWithBLOBs()) {
/*  45 */       answer.addAttribute(new Attribute("resultMap", 
/*  46 */         this.introspectedTable.getResultMapWithBLOBsId()));
/*     */     } else {
/*  48 */       answer.addAttribute(new Attribute("resultMap", 
/*  49 */         this.introspectedTable.getBaseResultMapId()));
/*     */     }
/*     */     String parameterType;
/*     */     String parameterType;
/*  53 */     if (this.introspectedTable.getRules().generatePrimaryKeyClass()) {
/*  54 */       parameterType = this.introspectedTable.getPrimaryKeyType();
/*     */     }
/*     */     else
/*     */     {
/*  58 */       parameterType = this.introspectedTable.getBaseRecordType();
/*     */     }
/*     */     
/*  61 */     answer.addAttribute(new Attribute("parameterClass", 
/*  62 */       parameterType));
/*     */     
/*  64 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  66 */     StringBuilder sb = new StringBuilder();
/*  67 */     sb.append("select ");
/*     */     
/*  69 */     if (StringUtility.stringHasValue(this.introspectedTable
/*  70 */       .getSelectByPrimaryKeyQueryId())) {
/*  71 */       sb.append('\'');
/*  72 */       sb.append(this.introspectedTable.getSelectByPrimaryKeyQueryId());
/*  73 */       sb.append("' as QUERYID,");
/*     */     }
/*  75 */     answer.addElement(new TextElement(sb.toString()));
/*  76 */     answer.addElement(getBaseColumnListElement());
/*  77 */     if (this.introspectedTable.hasBLOBColumns()) {
/*  78 */       answer.addElement(new TextElement(","));
/*  79 */       answer.addElement(getBlobColumnListElement());
/*     */     }
/*     */     
/*  82 */     sb.setLength(0);
/*  83 */     sb.append("from ");
/*  84 */     sb.append(this.introspectedTable
/*  85 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/*  86 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*  88 */     boolean and = false;
/*     */     
/*  90 */     Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/*  89 */     while (localIterator.hasNext()) {
/*  90 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*  91 */       sb.setLength(0);
/*  92 */       if (and) {
/*  93 */         sb.append("  and ");
/*     */       } else {
/*  95 */         sb.append("where ");
/*  96 */         and = true;
/*     */       }
/*     */       
/*  99 */       sb.append(
/* 100 */         Ibatis2FormattingUtilities.getAliasedEscapedColumnName(introspectedColumn));
/* 101 */       sb.append(" = ");
/* 102 */       sb.append(
/* 103 */         Ibatis2FormattingUtilities.getParameterClause(introspectedColumn));
/* 104 */       answer.addElement(new TextElement(sb.toString()));
/*     */     }
/*     */     
/*     */ 
/* 108 */     if (this.context.getPlugins().sqlMapSelectByPrimaryKeyElementGenerated(answer, 
/* 109 */       this.introspectedTable)) {
/* 110 */       parentElement.addElement(answer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\sqlmap\elements\SelectByPrimaryKeyElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */