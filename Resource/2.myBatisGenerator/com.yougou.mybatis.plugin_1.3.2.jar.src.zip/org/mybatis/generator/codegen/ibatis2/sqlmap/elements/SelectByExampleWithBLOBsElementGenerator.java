/*    */ package org.mybatis.generator.codegen.ibatis2.sqlmap.elements;
/*    */ 
/*    */ import org.mybatis.generator.api.CommentGenerator;
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ import org.mybatis.generator.api.Plugin;
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.TextElement;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ import org.mybatis.generator.config.Context;
/*    */ import org.mybatis.generator.internal.util.StringUtility;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectByExampleWithBLOBsElementGenerator
/*    */   extends AbstractXmlElementGenerator
/*    */ {
/*    */   public void addElements(XmlElement parentElement)
/*    */   {
/* 38 */     XmlElement answer = new XmlElement("select");
/* 39 */     answer
/* 40 */       .addAttribute(new Attribute(
/* 41 */       "id", this.introspectedTable.getSelectByExampleWithBLOBsStatementId()));
/* 42 */     answer.addAttribute(new Attribute(
/* 43 */       "resultMap", this.introspectedTable.getResultMapWithBLOBsId()));
/* 44 */     answer.addAttribute(new Attribute(
/* 45 */       "parameterClass", this.introspectedTable.getExampleType()));
/*    */     
/* 47 */     this.context.getCommentGenerator().addComment(answer);
/*    */     
/* 49 */     answer.addElement(new TextElement("select"));
/* 50 */     XmlElement isParameterPresent = new XmlElement("isParameterPresent");
/* 51 */     XmlElement isEqualElement = new XmlElement("isEqual");
/* 52 */     isEqualElement.addAttribute(new Attribute("property", "distinct"));
/* 53 */     isEqualElement.addAttribute(new Attribute("compareValue", "true"));
/* 54 */     isEqualElement.addElement(new TextElement("distinct"));
/* 55 */     isParameterPresent.addElement(isEqualElement);
/* 56 */     answer.addElement(isParameterPresent);
/*    */     
/* 58 */     StringBuilder sb = new StringBuilder();
/* 59 */     if (StringUtility.stringHasValue(this.introspectedTable
/* 60 */       .getSelectByExampleQueryId())) {
/* 61 */       sb.append('\'');
/* 62 */       sb.append(this.introspectedTable.getSelectByExampleQueryId());
/* 63 */       sb.append("' as QUERYID,");
/* 64 */       answer.addElement(new TextElement(sb.toString()));
/*    */     }
/*    */     
/* 67 */     answer.addElement(getBaseColumnListElement());
/* 68 */     answer.addElement(new TextElement(","));
/* 69 */     answer.addElement(getBlobColumnListElement());
/*    */     
/* 71 */     sb.setLength(0);
/* 72 */     sb.append("from ");
/* 73 */     sb.append(this.introspectedTable
/* 74 */       .getAliasedFullyQualifiedTableNameAtRuntime());
/* 75 */     answer.addElement(new TextElement(sb.toString()));
/*    */     
/* 77 */     XmlElement isParameterPresenteElement = new XmlElement(
/* 78 */       "isParameterPresent");
/* 79 */     answer.addElement(isParameterPresenteElement);
/*    */     
/* 81 */     XmlElement includeElement = new XmlElement("include");
/* 82 */     includeElement.addAttribute(new Attribute("refid", 
/* 83 */       this.introspectedTable.getIbatis2SqlMapNamespace() + 
/* 84 */       "." + this.introspectedTable.getExampleWhereClauseId()));
/* 85 */     isParameterPresenteElement.addElement(includeElement);
/*    */     
/* 87 */     XmlElement isNotNullElement = new XmlElement("isNotNull");
/* 88 */     isNotNullElement
/* 89 */       .addAttribute(new Attribute("property", "orderByClause"));
/* 90 */     isNotNullElement
/* 91 */       .addElement(new TextElement("order by $orderByClause$"));
/* 92 */     isParameterPresenteElement.addElement(isNotNullElement);
/*    */     
/*    */ 
/* 95 */     if (this.context.getPlugins().sqlMapSelectByExampleWithBLOBsElementGenerated(answer, 
/* 96 */       this.introspectedTable)) {
/* 97 */       parentElement.addElement(answer);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\sqlmap\elements\SelectByExampleWithBLOBsElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */