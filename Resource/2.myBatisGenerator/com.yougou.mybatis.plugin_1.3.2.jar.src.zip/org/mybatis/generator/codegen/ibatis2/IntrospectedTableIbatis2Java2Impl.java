/*     */ package org.mybatis.generator.codegen.ibatis2;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.GeneratedJavaFile;
/*     */ import org.mybatis.generator.api.GeneratedXmlFile;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable.TargetRuntime;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.xml.Document;
/*     */ import org.mybatis.generator.codegen.AbstractGenerator;
/*     */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*     */ import org.mybatis.generator.codegen.AbstractXmlGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.DAOGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.GenericCIDAOTemplate;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.GenericSIDAOTemplate;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.IbatisDAOTemplate;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.SpringDAOTemplate;
/*     */ import org.mybatis.generator.codegen.ibatis2.model.BaseRecordGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.model.ExampleGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.model.PrimaryKeyGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.model.RecordWithBLOBsGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.SqlMapGenerator;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.JavaModelGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.SqlMapGeneratorConfiguration;
/*     */ import org.mybatis.generator.internal.ObjectFactory;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IntrospectedTableIbatis2Java2Impl
/*     */   extends IntrospectedTable
/*     */ {
/*     */   protected List<AbstractJavaGenerator> javaModelGenerators;
/*     */   protected List<AbstractJavaGenerator> daoGenerators;
/*     */   protected AbstractXmlGenerator sqlMapGenerator;
/*     */   
/*     */   public IntrospectedTableIbatis2Java2Impl()
/*     */   {
/*  54 */     super(IntrospectedTable.TargetRuntime.IBATIS2);
/*  55 */     this.javaModelGenerators = new ArrayList();
/*  56 */     this.daoGenerators = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */   public void calculateGenerators(List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/*  62 */     calculateJavaModelGenerators(warnings, progressCallback);
/*  63 */     calculateDAOGenerators(warnings, progressCallback);
/*  64 */     calculateSqlMapGenerator(warnings, progressCallback);
/*     */   }
/*     */   
/*     */   protected void calculateSqlMapGenerator(List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/*  69 */     this.sqlMapGenerator = new SqlMapGenerator();
/*  70 */     initializeAbstractGenerator(this.sqlMapGenerator, warnings, progressCallback);
/*     */   }
/*     */   
/*     */   protected void calculateDAOGenerators(List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/*  75 */     if (this.context.getJavaClientGeneratorConfiguration() == null) {
/*  76 */       return;
/*     */     }
/*     */     
/*  79 */     String type = this.context.getJavaClientGeneratorConfiguration()
/*  80 */       .getConfigurationType();
/*     */     AbstractJavaGenerator javaGenerator;
/*     */     AbstractJavaGenerator javaGenerator;
/*  83 */     if ("IBATIS".equalsIgnoreCase(type)) {
/*  84 */       javaGenerator = new DAOGenerator(new IbatisDAOTemplate(), 
/*  85 */         isJava5Targeted()); } else { AbstractJavaGenerator javaGenerator;
/*  86 */       if ("SPRING".equalsIgnoreCase(type)) {
/*  87 */         javaGenerator = new DAOGenerator(new SpringDAOTemplate(), 
/*  88 */           isJava5Targeted()); } else { AbstractJavaGenerator javaGenerator;
/*  89 */         if ("GENERIC-CI".equalsIgnoreCase(type)) {
/*  90 */           javaGenerator = new DAOGenerator(new GenericCIDAOTemplate(), 
/*  91 */             isJava5Targeted()); } else { AbstractJavaGenerator javaGenerator;
/*  92 */           if ("GENERIC-SI".equalsIgnoreCase(type)) {
/*  93 */             javaGenerator = new DAOGenerator(new GenericSIDAOTemplate(), 
/*  94 */               isJava5Targeted());
/*     */           } else
/*  96 */             javaGenerator = (AbstractJavaGenerator)
/*  97 */               ObjectFactory.createInternalObject(type);
/*     */         }
/*     */       } }
/* 100 */     initializeAbstractGenerator(javaGenerator, warnings, progressCallback);
/* 101 */     this.daoGenerators.add(javaGenerator);
/*     */   }
/*     */   
/*     */   protected void calculateJavaModelGenerators(List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/* 106 */     if (getRules().generateExampleClass()) {
/* 107 */       AbstractJavaGenerator javaGenerator = new ExampleGenerator(
/* 108 */         isJava5Targeted());
/* 109 */       initializeAbstractGenerator(javaGenerator, warnings, 
/* 110 */         progressCallback);
/* 111 */       this.javaModelGenerators.add(javaGenerator);
/*     */     }
/*     */     
/* 114 */     if (getRules().generatePrimaryKeyClass()) {
/* 115 */       AbstractJavaGenerator javaGenerator = new PrimaryKeyGenerator();
/* 116 */       initializeAbstractGenerator(javaGenerator, warnings, 
/* 117 */         progressCallback);
/* 118 */       this.javaModelGenerators.add(javaGenerator);
/*     */     }
/*     */     
/* 121 */     if (getRules().generateBaseRecordClass()) {
/* 122 */       AbstractJavaGenerator javaGenerator = new BaseRecordGenerator();
/* 123 */       initializeAbstractGenerator(javaGenerator, warnings, 
/* 124 */         progressCallback);
/* 125 */       this.javaModelGenerators.add(javaGenerator);
/*     */     }
/*     */     
/* 128 */     if (getRules().generateRecordWithBLOBsClass()) {
/* 129 */       AbstractJavaGenerator javaGenerator = new RecordWithBLOBsGenerator();
/* 130 */       initializeAbstractGenerator(javaGenerator, warnings, 
/* 131 */         progressCallback);
/* 132 */       this.javaModelGenerators.add(javaGenerator);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initializeAbstractGenerator(AbstractGenerator abstractGenerator, List<String> warnings, ProgressCallback progressCallback)
/*     */   {
/* 139 */     abstractGenerator.setContext(this.context);
/* 140 */     abstractGenerator.setIntrospectedTable(this);
/* 141 */     abstractGenerator.setProgressCallback(progressCallback);
/* 142 */     abstractGenerator.setWarnings(warnings);
/*     */   }
/*     */   
/*     */   public List<GeneratedJavaFile> getGeneratedJavaFiles()
/*     */   {
/* 147 */     List<GeneratedJavaFile> answer = new ArrayList();
/*     */     Iterator localIterator2;
/* 149 */     for (Iterator localIterator1 = this.javaModelGenerators.iterator(); localIterator1.hasNext(); 
/*     */         
/*     */ 
/* 152 */         localIterator2.hasNext())
/*     */     {
/* 149 */       AbstractJavaGenerator javaGenerator = (AbstractJavaGenerator)localIterator1.next();
/* 150 */       List<CompilationUnit> compilationUnits = javaGenerator
/* 151 */         .getCompilationUnits();
/* 152 */       localIterator2 = compilationUnits.iterator(); continue;CompilationUnit compilationUnit = (CompilationUnit)localIterator2.next();
/* 153 */       GeneratedJavaFile gjf = new GeneratedJavaFile(compilationUnit, 
/* 154 */         this.context.getJavaModelGeneratorConfiguration()
/* 155 */         .getTargetProject(), 
/* 156 */         this.context.getProperty("javaFileEncoding"), 
/* 157 */         this.context.getJavaFormatter());
/* 158 */       answer.add(gjf);
/*     */     }
/*     */     
/*     */ 
/* 162 */     for (localIterator1 = this.daoGenerators.iterator(); localIterator1.hasNext(); 
/*     */         
/*     */ 
/* 165 */         localIterator2.hasNext())
/*     */     {
/* 162 */       AbstractJavaGenerator javaGenerator = (AbstractJavaGenerator)localIterator1.next();
/* 163 */       List<CompilationUnit> compilationUnits = javaGenerator
/* 164 */         .getCompilationUnits();
/* 165 */       localIterator2 = compilationUnits.iterator(); continue;CompilationUnit compilationUnit = (CompilationUnit)localIterator2.next();
/* 166 */       GeneratedJavaFile gjf = new GeneratedJavaFile(compilationUnit, 
/* 167 */         this.context.getJavaClientGeneratorConfiguration()
/* 168 */         .getTargetProject(), 
/* 169 */         this.context.getProperty("javaFileEncoding"), 
/* 170 */         this.context.getJavaFormatter());
/* 171 */       answer.add(gjf);
/*     */     }
/*     */     
/*     */ 
/* 175 */     return answer;
/*     */   }
/*     */   
/*     */   public List<GeneratedXmlFile> getGeneratedXmlFiles()
/*     */   {
/* 180 */     List<GeneratedXmlFile> answer = new ArrayList();
/*     */     
/* 182 */     Document document = this.sqlMapGenerator.getDocument();
/* 183 */     GeneratedXmlFile gxf = new GeneratedXmlFile(document, 
/* 184 */       getIbatis2SqlMapFileName(), getIbatis2SqlMapPackage(), this.context
/* 185 */       .getSqlMapGeneratorConfiguration().getTargetProject(), 
/* 186 */       true, this.context.getXmlFormatter());
/* 187 */     if (this.context.getPlugins().sqlMapGenerated(gxf, this)) {
/* 188 */       answer.add(gxf);
/*     */     }
/*     */     
/* 191 */     return answer;
/*     */   }
/*     */   
/*     */   public boolean isJava5Targeted()
/*     */   {
/* 196 */     return false;
/*     */   }
/*     */   
/*     */   public int getGenerationSteps()
/*     */   {
/* 201 */     return this.javaModelGenerators.size() + this.daoGenerators.size() + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean requiresXMLGenerator()
/*     */   {
/* 208 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\IntrospectedTableIbatis2Java2Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */