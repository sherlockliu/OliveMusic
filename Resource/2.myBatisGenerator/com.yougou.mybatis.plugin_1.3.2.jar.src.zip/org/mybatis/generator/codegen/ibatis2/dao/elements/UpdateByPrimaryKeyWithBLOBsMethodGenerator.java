/*     */ package org.mybatis.generator.codegen.ibatis2.dao.elements;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.DAOMethodNameCalculator;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.AbstractDAOTemplate;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateByPrimaryKeyWithBLOBsMethodGenerator
/*     */   extends AbstractDAOElementGenerator
/*     */ {
/*     */   public void addImplementationElements(TopLevelClass topLevelClass)
/*     */   {
/*  42 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  43 */     Method method = getMethodShell(importedTypes);
/*     */     
/*  45 */     StringBuilder sb = new StringBuilder();
/*  46 */     sb.append("int rows = ");
/*  47 */     sb.append(this.daoTemplate.getUpdateMethod(this.introspectedTable
/*  48 */       .getIbatis2SqlMapNamespace(), this.introspectedTable
/*  49 */       .getUpdateByPrimaryKeyWithBLOBsStatementId(), "record"));
/*  50 */     method.addBodyLine(sb.toString());
/*     */     
/*  52 */     method.addBodyLine("return rows;");
/*     */     
/*     */ 
/*  55 */     if (this.context.getPlugins().clientUpdateByPrimaryKeyWithBLOBsMethodGenerated(method, 
/*  56 */       topLevelClass, this.introspectedTable)) {
/*  57 */       topLevelClass.addImportedTypes(importedTypes);
/*  58 */       topLevelClass.addMethod(method);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addInterfaceElements(Interface interfaze)
/*     */   {
/*  64 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  65 */     Method method = getMethodShell(importedTypes);
/*     */     
/*     */ 
/*  68 */     if (this.context.getPlugins().clientUpdateByPrimaryKeyWithBLOBsMethodGenerated(method, 
/*  69 */       interfaze, this.introspectedTable)) {
/*  70 */       interfaze.addImportedTypes(importedTypes);
/*  71 */       interfaze.addMethod(method);
/*     */     }
/*     */   }
/*     */   
/*     */   private Method getMethodShell(Set<FullyQualifiedJavaType> importedTypes) {
/*     */     FullyQualifiedJavaType parameterType;
/*     */     FullyQualifiedJavaType parameterType;
/*  78 */     if (this.introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/*  79 */       parameterType = new FullyQualifiedJavaType(this.introspectedTable
/*  80 */         .getRecordWithBLOBsType());
/*     */     } else {
/*  82 */       parameterType = new FullyQualifiedJavaType(this.introspectedTable
/*  83 */         .getBaseRecordType());
/*     */     }
/*     */     
/*  86 */     importedTypes.add(parameterType);
/*     */     
/*  88 */     Method method = new Method();
/*  89 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  90 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*  91 */     method.setName(getDAOMethodNameCalculator()
/*  92 */       .getUpdateByPrimaryKeyWithBLOBsMethodName(this.introspectedTable));
/*  93 */     method.addParameter(new Parameter(parameterType, "record"));
/*     */     
/*  95 */     for (FullyQualifiedJavaType fqjt : this.daoTemplate.getCheckedExceptions()) {
/*  96 */       method.addException(fqjt);
/*  97 */       importedTypes.add(fqjt);
/*     */     }
/*     */     
/* 100 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 101 */       this.introspectedTable);
/*     */     
/* 103 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\dao\elements\UpdateByPrimaryKeyWithBLOBsMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */