/*     */ package org.mybatis.generator.codegen.ibatis2;
/*     */ 
/*     */ import java.util.StringTokenizer;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Ibatis2FormattingUtilities
/*     */ {
/*     */   public static String getEscapedColumnName(IntrospectedColumn introspectedColumn)
/*     */   {
/*  40 */     StringBuilder sb = new StringBuilder();
/*  41 */     sb.append(escapeStringForIbatis2(introspectedColumn
/*  42 */       .getActualColumnName()));
/*     */     
/*  44 */     if (introspectedColumn.isColumnNameDelimited()) {
/*  45 */       sb.insert(0, introspectedColumn.getContext()
/*  46 */         .getBeginningDelimiter());
/*  47 */       sb.append(introspectedColumn.getContext().getEndingDelimiter());
/*     */     }
/*     */     
/*  50 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAliasedEscapedColumnName(IntrospectedColumn introspectedColumn)
/*     */   {
/*  60 */     if (StringUtility.stringHasValue(introspectedColumn.getTableAlias())) {
/*  61 */       StringBuilder sb = new StringBuilder();
/*     */       
/*  63 */       sb.append(introspectedColumn.getTableAlias());
/*  64 */       sb.append('.');
/*  65 */       sb.append(getEscapedColumnName(introspectedColumn));
/*  66 */       return sb.toString();
/*     */     }
/*  68 */     return getEscapedColumnName(introspectedColumn);
/*     */   }
/*     */   
/*     */ 
/*     */   public static String getParameterClause(IntrospectedColumn introspectedColumn)
/*     */   {
/*  74 */     return getParameterClause(introspectedColumn, null);
/*     */   }
/*     */   
/*     */   public static String getParameterClause(IntrospectedColumn introspectedColumn, String prefix)
/*     */   {
/*  79 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  81 */     sb.append('#');
/*  82 */     sb.append(introspectedColumn.getJavaProperty(prefix));
/*     */     
/*  84 */     if (StringUtility.stringHasValue(introspectedColumn.getTypeHandler())) {
/*  85 */       sb.append(",jdbcType=");
/*  86 */       sb.append(introspectedColumn.getJdbcTypeName());
/*  87 */       sb.append(",handler=");
/*  88 */       sb.append(introspectedColumn.getTypeHandler());
/*     */     } else {
/*  90 */       sb.append(':');
/*  91 */       sb.append(introspectedColumn.getJdbcTypeName());
/*     */     }
/*     */     
/*  94 */     sb.append('#');
/*     */     
/*  96 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getSelectListPhrase(IntrospectedColumn introspectedColumn)
/*     */   {
/* 107 */     if (StringUtility.stringHasValue(introspectedColumn.getTableAlias())) {
/* 108 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 110 */       sb.append(getAliasedEscapedColumnName(introspectedColumn));
/* 111 */       sb.append(" as ");
/* 112 */       if (introspectedColumn.isColumnNameDelimited()) {
/* 113 */         sb.append(introspectedColumn.getContext()
/* 114 */           .getBeginningDelimiter());
/*     */       }
/* 116 */       sb.append(introspectedColumn.getTableAlias());
/* 117 */       sb.append('_');
/* 118 */       sb.append(escapeStringForIbatis2(introspectedColumn
/* 119 */         .getActualColumnName()));
/* 120 */       if (introspectedColumn.isColumnNameDelimited()) {
/* 121 */         sb.append(introspectedColumn.getContext().getEndingDelimiter());
/*     */       }
/* 123 */       return sb.toString();
/*     */     }
/* 125 */     return getEscapedColumnName(introspectedColumn);
/*     */   }
/*     */   
/*     */   public static String escapeStringForIbatis2(String s)
/*     */   {
/* 130 */     StringTokenizer st = new StringTokenizer(s, "$#", true);
/* 131 */     StringBuilder sb = new StringBuilder();
/* 132 */     while (st.hasMoreTokens()) {
/* 133 */       String token = st.nextToken();
/* 134 */       if ("$".equals(token)) {
/* 135 */         sb.append("$$");
/* 136 */       } else if ("#".equals(token)) {
/* 137 */         sb.append("##");
/*     */       } else {
/* 139 */         sb.append(token);
/*     */       }
/*     */     }
/*     */     
/* 143 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getAliasedActualColumnName(IntrospectedColumn introspectedColumn)
/*     */   {
/* 160 */     StringBuilder sb = new StringBuilder();
/* 161 */     if (StringUtility.stringHasValue(introspectedColumn.getTableAlias())) {
/* 162 */       sb.append(introspectedColumn.getTableAlias());
/* 163 */       sb.append('.');
/*     */     }
/*     */     
/* 166 */     if (introspectedColumn.isColumnNameDelimited()) {
/* 167 */       sb.append(StringUtility.escapeStringForJava(introspectedColumn
/* 168 */         .getContext().getBeginningDelimiter()));
/*     */     }
/*     */     
/* 171 */     sb.append(introspectedColumn.getActualColumnName());
/*     */     
/* 173 */     if (introspectedColumn.isColumnNameDelimited()) {
/* 174 */       sb.append(StringUtility.escapeStringForJava(introspectedColumn
/* 175 */         .getContext().getEndingDelimiter()));
/*     */     }
/*     */     
/* 178 */     return sb.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getRenamedColumnNameForResultMap(IntrospectedColumn introspectedColumn)
/*     */   {
/* 190 */     if (StringUtility.stringHasValue(introspectedColumn.getTableAlias())) {
/* 191 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 193 */       sb.append(introspectedColumn.getTableAlias());
/* 194 */       sb.append('_');
/* 195 */       sb.append(introspectedColumn.getActualColumnName());
/* 196 */       return sb.toString();
/*     */     }
/* 198 */     return introspectedColumn.getActualColumnName();
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\Ibatis2FormattingUtilities.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */