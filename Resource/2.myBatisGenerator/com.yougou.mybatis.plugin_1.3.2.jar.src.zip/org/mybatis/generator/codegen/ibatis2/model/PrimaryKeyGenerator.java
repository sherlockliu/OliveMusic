/*     */ package org.mybatis.generator.codegen.ibatis2.model;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.Plugin.ModelClassType;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*     */ import org.mybatis.generator.codegen.RootClassInfo;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PrimaryKeyGenerator
/*     */   extends AbstractJavaGenerator
/*     */ {
/*     */   public List<CompilationUnit> getCompilationUnits()
/*     */   {
/*  49 */     FullyQualifiedTable table = this.introspectedTable.getFullyQualifiedTable();
/*  50 */     this.progressCallback.startTask(Messages.getString(
/*  51 */       "Progress.7", table.toString()));
/*  52 */     Plugin plugins = this.context.getPlugins();
/*  53 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*     */     
/*  55 */     TopLevelClass topLevelClass = new TopLevelClass(this.introspectedTable
/*  56 */       .getPrimaryKeyType());
/*  57 */     topLevelClass.setVisibility(JavaVisibility.PUBLIC);
/*  58 */     commentGenerator.addJavaFileComment(topLevelClass);
/*     */     
/*  60 */     String rootClass = getRootClass();
/*  61 */     if (rootClass != null) {
/*  62 */       topLevelClass.setSuperClass(new FullyQualifiedJavaType(rootClass));
/*  63 */       topLevelClass.addImportedType(topLevelClass.getSuperClass());
/*     */     }
/*     */     
/*     */ 
/*  67 */     Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/*  66 */     while (localIterator.hasNext()) {
/*  67 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*     */       
/*  69 */       if (!RootClassInfo.getInstance(rootClass, this.warnings).containsProperty(introspectedColumn))
/*     */       {
/*     */ 
/*     */ 
/*  73 */         Field field = getJavaBeansField(introspectedColumn);
/*  74 */         if (plugins.modelFieldGenerated(field, topLevelClass, 
/*  75 */           introspectedColumn, this.introspectedTable, 
/*  76 */           Plugin.ModelClassType.PRIMARY_KEY)) {
/*  77 */           topLevelClass.addField(field);
/*  78 */           topLevelClass.addImportedType(field.getType());
/*     */         }
/*     */         
/*  81 */         Method method = getJavaBeansGetter(introspectedColumn);
/*  82 */         if (plugins.modelGetterMethodGenerated(method, topLevelClass, 
/*  83 */           introspectedColumn, this.introspectedTable, 
/*  84 */           Plugin.ModelClassType.PRIMARY_KEY)) {
/*  85 */           topLevelClass.addMethod(method);
/*     */         }
/*     */         
/*  88 */         method = getJavaBeansSetter(introspectedColumn);
/*  89 */         if (plugins.modelSetterMethodGenerated(method, topLevelClass, 
/*  90 */           introspectedColumn, this.introspectedTable, 
/*  91 */           Plugin.ModelClassType.PRIMARY_KEY)) {
/*  92 */           topLevelClass.addMethod(method);
/*     */         }
/*     */       }
/*     */     }
/*  96 */     List<CompilationUnit> answer = new ArrayList();
/*  97 */     if (this.context.getPlugins().modelPrimaryKeyClassGenerated(
/*  98 */       topLevelClass, this.introspectedTable)) {
/*  99 */       answer.add(topLevelClass);
/*     */     }
/* 101 */     return answer;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\model\PrimaryKeyGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */