/*     */ package org.mybatis.generator.codegen.ibatis2.dao.elements;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.DAOMethodNameCalculator;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.AbstractDAOTemplate;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectByExampleWithoutBLOBsMethodGenerator
/*     */   extends AbstractDAOElementGenerator
/*     */ {
/*     */   private boolean generateForJava5;
/*     */   
/*     */   public SelectByExampleWithoutBLOBsMethodGenerator(boolean generateForJava5)
/*     */   {
/*  42 */     this.generateForJava5 = generateForJava5;
/*     */   }
/*     */   
/*     */   public void addImplementationElements(TopLevelClass topLevelClass)
/*     */   {
/*  47 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  48 */     Method method = getMethodShell(importedTypes);
/*     */     
/*  50 */     if (this.generateForJava5) {
/*  51 */       method.addSuppressTypeWarningsAnnotation();
/*     */     }
/*     */     
/*  54 */     StringBuilder sb = new StringBuilder();
/*  55 */     sb.append(method.getReturnType().getShortName());
/*  56 */     sb.append(" list = ");
/*  57 */     sb.append(this.daoTemplate.getQueryForListMethod(this.introspectedTable
/*  58 */       .getIbatis2SqlMapNamespace(), this.introspectedTable
/*  59 */       .getSelectByExampleStatementId(), "example"));
/*  60 */     method.addBodyLine(sb.toString());
/*  61 */     method.addBodyLine("return list;");
/*     */     
/*     */ 
/*  64 */     if (this.context.getPlugins().clientSelectByExampleWithoutBLOBsMethodGenerated(method, 
/*  65 */       topLevelClass, this.introspectedTable)) {
/*  66 */       topLevelClass.addImportedTypes(importedTypes);
/*  67 */       topLevelClass.addMethod(method);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addInterfaceElements(Interface interfaze)
/*     */   {
/*  73 */     if (getExampleMethodVisibility() == JavaVisibility.PUBLIC) {
/*  74 */       Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  75 */       Method method = getMethodShell(importedTypes);
/*     */       
/*     */ 
/*  78 */       if (this.context.getPlugins().clientSelectByExampleWithoutBLOBsMethodGenerated(method, 
/*  79 */         interfaze, this.introspectedTable)) {
/*  80 */         interfaze.addImportedTypes(importedTypes);
/*  81 */         interfaze.addMethod(method);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Method getMethodShell(Set<FullyQualifiedJavaType> importedTypes) {
/*  87 */     FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/*  88 */       this.introspectedTable.getExampleType());
/*  89 */     importedTypes.add(type);
/*  90 */     importedTypes.add(FullyQualifiedJavaType.getNewListInstance());
/*     */     
/*  92 */     Method method = new Method();
/*  93 */     method.setVisibility(getExampleMethodVisibility());
/*     */     
/*  95 */     FullyQualifiedJavaType returnType = 
/*  96 */       FullyQualifiedJavaType.getNewListInstance();
/*     */     
/*  98 */     if (this.generateForJava5) {
/*     */       FullyQualifiedJavaType fqjt;
/* 100 */       if (this.introspectedTable.getRules().generateBaseRecordClass()) {
/* 101 */         fqjt = new FullyQualifiedJavaType(this.introspectedTable
/* 102 */           .getBaseRecordType()); } else { FullyQualifiedJavaType fqjt;
/* 103 */         if (this.introspectedTable.getRules().generatePrimaryKeyClass()) {
/* 104 */           fqjt = new FullyQualifiedJavaType(this.introspectedTable
/* 105 */             .getPrimaryKeyType());
/*     */         } else
/* 107 */           throw new RuntimeException(Messages.getString("RuntimeError.12"));
/*     */       }
/*     */       FullyQualifiedJavaType fqjt;
/* 110 */       importedTypes.add(fqjt);
/* 111 */       returnType.addTypeArgument(fqjt);
/*     */     }
/*     */     
/* 114 */     method.setReturnType(returnType);
/*     */     
/* 116 */     method.setName(getDAOMethodNameCalculator()
/* 117 */       .getSelectByExampleWithoutBLOBsMethodName(this.introspectedTable));
/* 118 */     method.addParameter(new Parameter(type, "example"));
/*     */     
/* 120 */     for (FullyQualifiedJavaType fqjt : this.daoTemplate.getCheckedExceptions()) {
/* 121 */       method.addException(fqjt);
/* 122 */       importedTypes.add(fqjt);
/*     */     }
/*     */     
/* 125 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 126 */       this.introspectedTable);
/*     */     
/* 128 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\dao\elements\SelectByExampleWithoutBLOBsMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */