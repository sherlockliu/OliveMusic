/*      */ package org.mybatis.generator.codegen.ibatis2.model;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import org.mybatis.generator.api.CommentGenerator;
/*      */ import org.mybatis.generator.api.FullyQualifiedTable;
/*      */ import org.mybatis.generator.api.IntrospectedColumn;
/*      */ import org.mybatis.generator.api.IntrospectedTable;
/*      */ import org.mybatis.generator.api.Plugin;
/*      */ import org.mybatis.generator.api.ProgressCallback;
/*      */ import org.mybatis.generator.api.dom.OutputUtilities;
/*      */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*      */ import org.mybatis.generator.api.dom.java.Field;
/*      */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*      */ import org.mybatis.generator.api.dom.java.InnerClass;
/*      */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*      */ import org.mybatis.generator.api.dom.java.Method;
/*      */ import org.mybatis.generator.api.dom.java.Parameter;
/*      */ import org.mybatis.generator.api.dom.java.PrimitiveTypeWrapper;
/*      */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*      */ import org.mybatis.generator.codegen.AbstractJavaGenerator;
/*      */ import org.mybatis.generator.codegen.ibatis2.Ibatis2FormattingUtilities;
/*      */ import org.mybatis.generator.config.Context;
/*      */ import org.mybatis.generator.internal.rules.Rules;
/*      */ import org.mybatis.generator.internal.util.JavaBeansUtil;
/*      */ import org.mybatis.generator.internal.util.StringUtility;
/*      */ import org.mybatis.generator.internal.util.messages.Messages;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ExampleGenerator
/*      */   extends AbstractJavaGenerator
/*      */ {
/*      */   private boolean generateForJava5;
/*      */   
/*      */   public ExampleGenerator(boolean generateForJava5)
/*      */   {
/*   53 */     this.generateForJava5 = generateForJava5;
/*      */   }
/*      */   
/*      */   public List<CompilationUnit> getCompilationUnits()
/*      */   {
/*   58 */     FullyQualifiedTable table = this.introspectedTable.getFullyQualifiedTable();
/*   59 */     this.progressCallback.startTask(Messages.getString(
/*   60 */       "Progress.6", table.toString()));
/*   61 */     CommentGenerator commentGenerator = this.context.getCommentGenerator();
/*      */     
/*   63 */     FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/*   64 */       this.introspectedTable.getExampleType());
/*   65 */     TopLevelClass topLevelClass = new TopLevelClass(type);
/*   66 */     topLevelClass.setVisibility(JavaVisibility.PUBLIC);
/*   67 */     commentGenerator.addJavaFileComment(topLevelClass);
/*      */     
/*      */ 
/*   70 */     Method method = new Method();
/*   71 */     method.setVisibility(JavaVisibility.PUBLIC);
/*   72 */     method.setConstructor(true);
/*   73 */     method.setName(type.getShortName());
/*   74 */     if (this.generateForJava5) {
/*   75 */       method.addBodyLine("oredCriteria = new ArrayList<Criteria>();");
/*      */     } else {
/*   77 */       method.addBodyLine("oredCriteria = new ArrayList();");
/*      */     }
/*      */     
/*   80 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*   81 */     topLevelClass.addMethod(method);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*   86 */     Rules rules = this.introspectedTable.getRules();
/*   87 */     if ((rules.generateUpdateByExampleSelective()) || 
/*   88 */       (rules.generateUpdateByExampleWithBLOBs()) || 
/*   89 */       (rules.generateUpdateByExampleWithoutBLOBs())) {
/*   90 */       method = new Method();
/*   91 */       method.setVisibility(JavaVisibility.PROTECTED);
/*   92 */       method.setConstructor(true);
/*   93 */       method.setName(type.getShortName());
/*   94 */       method.addParameter(new Parameter(type, "example"));
/*   95 */       method.addBodyLine("this.orderByClause = example.orderByClause;");
/*   96 */       method.addBodyLine("this.oredCriteria = example.oredCriteria;");
/*   97 */       method.addBodyLine("this.distinct = example.distinct;");
/*   98 */       commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*   99 */       topLevelClass.addMethod(method);
/*      */     }
/*      */     
/*      */ 
/*  103 */     Field field = new Field();
/*  104 */     field.setVisibility(JavaVisibility.PROTECTED);
/*  105 */     field.setType(FullyQualifiedJavaType.getStringInstance());
/*  106 */     field.setName("orderByClause");
/*  107 */     commentGenerator.addFieldComment(field, this.introspectedTable);
/*  108 */     topLevelClass.addField(field);
/*      */     
/*  110 */     method = new Method();
/*  111 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  112 */     method.setName("setOrderByClause");
/*  113 */     method.addParameter(new Parameter(
/*  114 */       FullyQualifiedJavaType.getStringInstance(), "orderByClause"));
/*  115 */     method.addBodyLine("this.orderByClause = orderByClause;");
/*  116 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  117 */     topLevelClass.addMethod(method);
/*      */     
/*  119 */     method = new Method();
/*  120 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  121 */     method.setReturnType(FullyQualifiedJavaType.getStringInstance());
/*  122 */     method.setName("getOrderByClause");
/*  123 */     method.addBodyLine("return orderByClause;");
/*  124 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  125 */     topLevelClass.addMethod(method);
/*      */     
/*      */ 
/*  128 */     field = new Field();
/*  129 */     field.setVisibility(JavaVisibility.PROTECTED);
/*  130 */     field.setType(FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  131 */     field.setName("distinct");
/*  132 */     commentGenerator.addFieldComment(field, this.introspectedTable);
/*  133 */     topLevelClass.addField(field);
/*      */     
/*  135 */     method = new Method();
/*  136 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  137 */     method.setName("setDistinct");
/*  138 */     method.addParameter(new Parameter(
/*  139 */       FullyQualifiedJavaType.getBooleanPrimitiveInstance(), "distinct"));
/*  140 */     method.addBodyLine("this.distinct = distinct;");
/*  141 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  142 */     topLevelClass.addMethod(method);
/*      */     
/*  144 */     method = new Method();
/*  145 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  146 */     method.setReturnType(
/*  147 */       FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  148 */     method.setName("isDistinct");
/*  149 */     method.addBodyLine("return distinct;");
/*  150 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  151 */     topLevelClass.addMethod(method);
/*      */     
/*      */ 
/*  154 */     field = new Field();
/*  155 */     field.setVisibility(JavaVisibility.PROTECTED);
/*      */     FullyQualifiedJavaType fqjt;
/*      */     FullyQualifiedJavaType fqjt;
/*  158 */     if (this.generateForJava5) {
/*  159 */       fqjt = new FullyQualifiedJavaType("java.util.List<Criteria>");
/*      */     } else {
/*  161 */       fqjt = new FullyQualifiedJavaType("java.util.List");
/*      */     }
/*      */     
/*  164 */     field.setType(fqjt);
/*  165 */     field.setName("oredCriteria");
/*  166 */     commentGenerator.addFieldComment(field, this.introspectedTable);
/*  167 */     topLevelClass.addField(field);
/*      */     
/*  169 */     method = new Method();
/*  170 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  171 */     method.setReturnType(fqjt);
/*  172 */     method.setName("getOredCriteria");
/*  173 */     method.addBodyLine("return oredCriteria;");
/*  174 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  175 */     topLevelClass.addMethod(method);
/*      */     
/*  177 */     method = new Method();
/*  178 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  179 */     method.setName("or");
/*  180 */     method.addParameter(new Parameter(
/*  181 */       FullyQualifiedJavaType.getCriteriaInstance(), "criteria"));
/*  182 */     method.addBodyLine("oredCriteria.add(criteria);");
/*  183 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  184 */     topLevelClass.addMethod(method);
/*      */     
/*  186 */     method = new Method();
/*  187 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  188 */     method.setName("or");
/*  189 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  190 */     method.addBodyLine("Criteria criteria = createCriteriaInternal();");
/*  191 */     method.addBodyLine("oredCriteria.add(criteria);");
/*  192 */     method.addBodyLine("return criteria;");
/*  193 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  194 */     topLevelClass.addMethod(method);
/*      */     
/*  196 */     method = new Method();
/*  197 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  198 */     method.setName("createCriteria");
/*  199 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  200 */     method.addBodyLine("Criteria criteria = createCriteriaInternal();");
/*  201 */     method.addBodyLine("if (oredCriteria.size() == 0) {");
/*  202 */     method.addBodyLine("oredCriteria.add(criteria);");
/*  203 */     method.addBodyLine("}");
/*  204 */     method.addBodyLine("return criteria;");
/*  205 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  206 */     topLevelClass.addMethod(method);
/*      */     
/*  208 */     method = new Method();
/*  209 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  210 */     method.setName("createCriteriaInternal");
/*  211 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/*  212 */     method.addBodyLine("Criteria criteria = new Criteria();");
/*  213 */     method.addBodyLine("return criteria;");
/*  214 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  215 */     topLevelClass.addMethod(method);
/*      */     
/*  217 */     method = new Method();
/*  218 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  219 */     method.setName("clear");
/*  220 */     method.addBodyLine("oredCriteria.clear();");
/*  221 */     method.addBodyLine("orderByClause = null;");
/*  222 */     method.addBodyLine("distinct = false;");
/*  223 */     commentGenerator.addGeneralMethodComment(method, this.introspectedTable);
/*  224 */     topLevelClass.addMethod(method);
/*      */     
/*      */ 
/*  227 */     topLevelClass
/*  228 */       .addInnerClass(getGeneratedCriteriaInnerClass(topLevelClass));
/*      */     
/*  230 */     topLevelClass.addInnerClass(getCriteriaInnerClass(topLevelClass));
/*      */     
/*  232 */     List<CompilationUnit> answer = new ArrayList();
/*  233 */     if (this.context.getPlugins().modelExampleClassGenerated(
/*  234 */       topLevelClass, this.introspectedTable)) {
/*  235 */       answer.add(topLevelClass);
/*      */     }
/*  237 */     return answer;
/*      */   }
/*      */   
/*      */ 
/*      */   private InnerClass getCriteriaInnerClass(TopLevelClass topLevelClass)
/*      */   {
/*  243 */     InnerClass answer = new InnerClass(
/*  244 */       FullyQualifiedJavaType.getCriteriaInstance());
/*      */     
/*  246 */     answer.setVisibility(JavaVisibility.PUBLIC);
/*  247 */     answer.setStatic(true);
/*  248 */     answer.setSuperClass(
/*  249 */       FullyQualifiedJavaType.getGeneratedCriteriaInstance());
/*      */     
/*  251 */     this.context.getCommentGenerator().addClassComment(answer, 
/*  252 */       this.introspectedTable, true);
/*      */     
/*  254 */     Method method = new Method();
/*  255 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  256 */     method.setName("Criteria");
/*  257 */     method.setConstructor(true);
/*  258 */     method.addBodyLine("super();");
/*  259 */     answer.addMethod(method);
/*      */     
/*  261 */     return answer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private InnerClass getGeneratedCriteriaInnerClass(TopLevelClass topLevelClass)
/*      */   {
/*  269 */     InnerClass answer = new InnerClass(
/*  270 */       FullyQualifiedJavaType.getGeneratedCriteriaInstance());
/*      */     
/*  272 */     answer.setVisibility(JavaVisibility.PROTECTED);
/*  273 */     answer.setStatic(true);
/*  274 */     answer.setAbstract(true);
/*  275 */     this.context.getCommentGenerator().addClassComment(answer, 
/*  276 */       this.introspectedTable);
/*      */     
/*  278 */     Method method = new Method();
/*  279 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  280 */     method.setName("GeneratedCriteria");
/*  281 */     method.setConstructor(true);
/*  282 */     method.addBodyLine("super();");
/*  283 */     if (this.generateForJava5)
/*      */     {
/*  285 */       method.addBodyLine("criteriaWithoutValue = new ArrayList<String>();");
/*  286 */       method
/*  287 */         .addBodyLine("criteriaWithSingleValue = new ArrayList<Map<String, Object>>();");
/*  288 */       method
/*  289 */         .addBodyLine("criteriaWithListValue = new ArrayList<Map<String, Object>>();");
/*  290 */       method
/*  291 */         .addBodyLine("criteriaWithBetweenValue = new ArrayList<Map<String, Object>>();");
/*      */     }
/*      */     else {
/*  294 */       method.addBodyLine("criteriaWithoutValue = new ArrayList();");
/*  295 */       method.addBodyLine("criteriaWithSingleValue = new ArrayList();");
/*  296 */       method.addBodyLine("criteriaWithListValue = new ArrayList();");
/*  297 */       method.addBodyLine("criteriaWithBetweenValue = new ArrayList();");
/*      */     }
/*  299 */     answer.addMethod(method);
/*      */     
/*  301 */     List<String> criteriaLists = new ArrayList();
/*  302 */     criteriaLists.add("criteriaWithoutValue");
/*  303 */     criteriaLists.add("criteriaWithSingleValue");
/*  304 */     criteriaLists.add("criteriaWithListValue");
/*  305 */     criteriaLists.add("criteriaWithBetweenValue");
/*      */     
/*      */ 
/*  308 */     Iterator localIterator1 = this.introspectedTable.getNonBLOBColumns().iterator();
/*  307 */     while (localIterator1.hasNext()) {
/*  308 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator1.next();
/*  309 */       if (StringUtility.stringHasValue(introspectedColumn
/*  310 */         .getTypeHandler())) {
/*  311 */         criteriaLists.addAll(addtypeHandledObjectsAndMethods(
/*  312 */           introspectedColumn, method, answer));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  317 */     method = new Method();
/*  318 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  319 */     method.setName("isValid");
/*  320 */     method.setReturnType(
/*  321 */       FullyQualifiedJavaType.getBooleanPrimitiveInstance());
/*  322 */     StringBuilder sb = new StringBuilder();
/*  323 */     Object strIter = criteriaLists.iterator();
/*  324 */     sb.append("return ");
/*  325 */     sb.append((String)((Iterator)strIter).next());
/*  326 */     sb.append(".size() > 0");
/*  327 */     method.addBodyLine(sb.toString());
/*  328 */     while (((Iterator)strIter).hasNext()) {
/*  329 */       sb.setLength(0);
/*  330 */       OutputUtilities.javaIndent(sb, 1);
/*  331 */       sb.append("|| ");
/*  332 */       sb.append((String)((Iterator)strIter).next());
/*  333 */       sb.append(".size() > 0");
/*  334 */       if (!((Iterator)strIter).hasNext()) {
/*  335 */         sb.append(';');
/*      */       }
/*  337 */       method.addBodyLine(sb.toString());
/*      */     }
/*  339 */     answer.addMethod(method);
/*      */     
/*      */ 
/*      */ 
/*  343 */     topLevelClass.addImportedType(
/*  344 */       FullyQualifiedJavaType.getNewMapInstance());
/*  345 */     topLevelClass.addImportedType(
/*  346 */       FullyQualifiedJavaType.getNewListInstance());
/*  347 */     topLevelClass.addImportedType(
/*  348 */       FullyQualifiedJavaType.getNewHashMapInstance());
/*  349 */     topLevelClass.addImportedType(
/*  350 */       FullyQualifiedJavaType.getNewArrayListInstance());
/*      */     
/*  352 */     Field field = new Field();
/*  353 */     field.setVisibility(JavaVisibility.PROTECTED);
/*      */     FullyQualifiedJavaType listOfStrings;
/*  355 */     FullyQualifiedJavaType listOfStrings; if (this.generateForJava5) {
/*  356 */       listOfStrings = new FullyQualifiedJavaType(
/*  357 */         "java.util.List<java.lang.String>");
/*      */     } else {
/*  359 */       listOfStrings = new FullyQualifiedJavaType("java.util.List");
/*      */     }
/*  361 */     field.setType(listOfStrings);
/*  362 */     field.setName("criteriaWithoutValue");
/*  363 */     answer.addField(field);
/*      */     
/*  365 */     method = new Method();
/*  366 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  367 */     method.setReturnType(field.getType());
/*  368 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName(), field
/*  369 */       .getType()));
/*  370 */     method.addBodyLine("return criteriaWithoutValue;");
/*  371 */     answer.addMethod(method);
/*      */     FullyQualifiedJavaType listOfMaps;
/*      */     FullyQualifiedJavaType listOfMaps;
/*  374 */     if (this.generateForJava5) {
/*  375 */       listOfMaps = new FullyQualifiedJavaType(
/*  376 */         "java.util.List<java.util.Map<java.lang.String, java.lang.Object>>");
/*      */     } else {
/*  378 */       listOfMaps = new FullyQualifiedJavaType("java.util.List");
/*      */     }
/*      */     
/*  381 */     field = new Field();
/*  382 */     field.setVisibility(JavaVisibility.PROTECTED);
/*  383 */     field.setType(listOfMaps);
/*  384 */     field.setName("criteriaWithSingleValue");
/*  385 */     answer.addField(field);
/*      */     
/*  387 */     method = new Method();
/*  388 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  389 */     method.setReturnType(field.getType());
/*  390 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName(), field
/*  391 */       .getType()));
/*  392 */     method.addBodyLine("return criteriaWithSingleValue;");
/*  393 */     answer.addMethod(method);
/*      */     
/*  395 */     field = new Field();
/*  396 */     field.setVisibility(JavaVisibility.PROTECTED);
/*  397 */     field.setType(listOfMaps);
/*  398 */     field.setName("criteriaWithListValue");
/*  399 */     answer.addField(field);
/*      */     
/*  401 */     method = new Method();
/*  402 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  403 */     method.setReturnType(field.getType());
/*  404 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName(), field
/*  405 */       .getType()));
/*  406 */     method.addBodyLine("return criteriaWithListValue;");
/*  407 */     answer.addMethod(method);
/*      */     
/*  409 */     field = new Field();
/*  410 */     field.setVisibility(JavaVisibility.PROTECTED);
/*  411 */     field.setType(listOfMaps);
/*  412 */     field.setName("criteriaWithBetweenValue");
/*  413 */     answer.addField(field);
/*      */     
/*  415 */     method = new Method();
/*  416 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  417 */     method.setReturnType(field.getType());
/*  418 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName(), field
/*  419 */       .getType()));
/*  420 */     method.addBodyLine("return criteriaWithBetweenValue;");
/*  421 */     answer.addMethod(method);
/*      */     
/*      */ 
/*  424 */     method = new Method();
/*  425 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  426 */     method.setName("addCriterion");
/*  427 */     method.addParameter(new Parameter(
/*  428 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  429 */     method.addBodyLine("if (condition == null) {");
/*  430 */     method
/*  431 */       .addBodyLine("throw new RuntimeException(\"Value for condition cannot be null\");");
/*  432 */     method.addBodyLine("}");
/*  433 */     method.addBodyLine("criteriaWithoutValue.add(condition);");
/*  434 */     answer.addMethod(method);
/*      */     
/*  436 */     method = new Method();
/*  437 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  438 */     method.setName("addCriterion");
/*  439 */     method.addParameter(new Parameter(
/*  440 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  441 */     method.addParameter(new Parameter(
/*  442 */       FullyQualifiedJavaType.getObjectInstance(), "value"));
/*  443 */     method.addParameter(new Parameter(
/*  444 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/*  445 */     method.addBodyLine("if (value == null) {");
/*  446 */     method
/*  447 */       .addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/*  448 */     method.addBodyLine("}");
/*  449 */     if (this.generateForJava5)
/*      */     {
/*  451 */       method.addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/*      */     } else {
/*  453 */       method.addBodyLine("Map map = new HashMap();");
/*      */     }
/*      */     
/*  456 */     method.addBodyLine("map.put(\"condition\", condition);");
/*  457 */     method.addBodyLine("map.put(\"value\", value);");
/*  458 */     method.addBodyLine("criteriaWithSingleValue.add(map);");
/*  459 */     answer.addMethod(method);
/*      */     FullyQualifiedJavaType listOfObjects;
/*      */     FullyQualifiedJavaType listOfObjects;
/*  462 */     if (this.generateForJava5) {
/*  463 */       listOfObjects = new FullyQualifiedJavaType(
/*  464 */         "java.util.List<? extends java.lang.Object>");
/*      */     } else {
/*  466 */       listOfObjects = new FullyQualifiedJavaType("java.util.List");
/*      */     }
/*      */     
/*  469 */     method = new Method();
/*  470 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  471 */     method.setName("addCriterion");
/*  472 */     method.addParameter(new Parameter(
/*  473 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  474 */     method.addParameter(new Parameter(listOfObjects, "values"));
/*  475 */     method.addParameter(new Parameter(
/*  476 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/*  477 */     method.addBodyLine("if (values == null || values.size() == 0) {");
/*  478 */     method
/*  479 */       .addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/*  480 */     method.addBodyLine("}");
/*  481 */     if (this.generateForJava5)
/*      */     {
/*  483 */       method.addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/*      */     } else {
/*  485 */       method.addBodyLine("Map map = new HashMap();");
/*      */     }
/*      */     
/*  488 */     method.addBodyLine("map.put(\"condition\", condition);");
/*  489 */     method.addBodyLine("map.put(\"values\", values);");
/*  490 */     method.addBodyLine("criteriaWithListValue.add(map);");
/*  491 */     answer.addMethod(method);
/*      */     
/*  493 */     method = new Method();
/*  494 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  495 */     method.setName("addCriterion");
/*  496 */     method.addParameter(new Parameter(
/*  497 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  498 */     method.addParameter(new Parameter(
/*  499 */       FullyQualifiedJavaType.getObjectInstance(), "value1"));
/*  500 */     method.addParameter(new Parameter(
/*  501 */       FullyQualifiedJavaType.getObjectInstance(), "value2"));
/*  502 */     method.addParameter(new Parameter(
/*  503 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/*  504 */     method.addBodyLine("if (value1 == null || value2 == null) {");
/*  505 */     method
/*  506 */       .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/*  507 */     method.addBodyLine("}");
/*  508 */     if (this.generateForJava5) {
/*  509 */       method.addBodyLine("List<Object> list = new ArrayList<Object>();");
/*      */     } else {
/*  511 */       method.addBodyLine("List list = new ArrayList();");
/*      */     }
/*      */     
/*  514 */     method.addBodyLine("list.add(value1);");
/*  515 */     method.addBodyLine("list.add(value2);");
/*  516 */     if (this.generateForJava5)
/*      */     {
/*  518 */       method.addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/*      */     } else {
/*  520 */       method.addBodyLine("Map map = new HashMap();");
/*      */     }
/*  522 */     method.addBodyLine("map.put(\"condition\", condition);");
/*  523 */     method.addBodyLine("map.put(\"values\", list);");
/*  524 */     method.addBodyLine("criteriaWithBetweenValue.add(map);");
/*  525 */     answer.addMethod(method);
/*      */     FullyQualifiedJavaType listOfDates;
/*      */     FullyQualifiedJavaType listOfDates;
/*  528 */     if (this.generateForJava5) {
/*  529 */       listOfDates = new FullyQualifiedJavaType(
/*  530 */         "java.util.List<java.util.Date>");
/*      */     } else {
/*  532 */       listOfDates = new FullyQualifiedJavaType("java.util.List");
/*      */     }
/*      */     
/*  535 */     if (this.introspectedTable.hasJDBCDateColumns()) {
/*  536 */       topLevelClass.addImportedType(
/*  537 */         FullyQualifiedJavaType.getDateInstance());
/*  538 */       topLevelClass.addImportedType(
/*  539 */         FullyQualifiedJavaType.getNewIteratorInstance());
/*  540 */       method = new Method();
/*  541 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  542 */       method.setName("addCriterionForJDBCDate");
/*  543 */       method.addParameter(new Parameter(
/*  544 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  545 */       method.addParameter(new Parameter(
/*  546 */         FullyQualifiedJavaType.getDateInstance(), "value"));
/*  547 */       method.addParameter(new Parameter(
/*  548 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  549 */       method.addBodyLine("if (value == null) {");
/*  550 */       method
/*  551 */         .addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/*  552 */       method.addBodyLine("}");
/*  553 */       method
/*  554 */         .addBodyLine("addCriterion(condition, new java.sql.Date(value.getTime()), property);");
/*  555 */       answer.addMethod(method);
/*      */       
/*  557 */       method = new Method();
/*  558 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  559 */       method.setName("addCriterionForJDBCDate");
/*  560 */       method.addParameter(new Parameter(
/*  561 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  562 */       method.addParameter(new Parameter(listOfDates, "values"));
/*  563 */       method.addParameter(new Parameter(
/*  564 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  565 */       method.addBodyLine("if (values == null || values.size() == 0) {");
/*  566 */       method
/*  567 */         .addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/*  568 */       method.addBodyLine("}");
/*  569 */       if (this.generateForJava5)
/*      */       {
/*  571 */         method.addBodyLine("List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();");
/*  572 */         method.addBodyLine("Iterator<Date> iter = values.iterator();");
/*  573 */         method.addBodyLine("while (iter.hasNext()) {");
/*  574 */         method
/*  575 */           .addBodyLine("dateList.add(new java.sql.Date(iter.next().getTime()));");
/*  576 */         method.addBodyLine("}");
/*      */       } else {
/*  578 */         method.addBodyLine("List dateList = new ArrayList();");
/*  579 */         method.addBodyLine("Iterator iter = values.iterator();");
/*  580 */         method.addBodyLine("while (iter.hasNext()) {");
/*  581 */         method
/*  582 */           .addBodyLine("dateList.add(new java.sql.Date(((Date)iter.next()).getTime()));");
/*  583 */         method.addBodyLine("}");
/*      */       }
/*  585 */       method.addBodyLine("addCriterion(condition, dateList, property);");
/*  586 */       answer.addMethod(method);
/*      */       
/*  588 */       method = new Method();
/*  589 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  590 */       method.setName("addCriterionForJDBCDate");
/*  591 */       method.addParameter(new Parameter(
/*  592 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  593 */       method.addParameter(new Parameter(
/*  594 */         FullyQualifiedJavaType.getDateInstance(), "value1"));
/*  595 */       method.addParameter(new Parameter(
/*  596 */         FullyQualifiedJavaType.getDateInstance(), "value2"));
/*  597 */       method.addParameter(new Parameter(
/*  598 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  599 */       method.addBodyLine("if (value1 == null || value2 == null) {");
/*  600 */       method
/*  601 */         .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/*  602 */       method.addBodyLine("}");
/*  603 */       method
/*  604 */         .addBodyLine("addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);");
/*  605 */       answer.addMethod(method);
/*      */     }
/*      */     
/*  608 */     if (this.introspectedTable.hasJDBCTimeColumns()) {
/*  609 */       topLevelClass.addImportedType(
/*  610 */         FullyQualifiedJavaType.getDateInstance());
/*  611 */       topLevelClass.addImportedType(
/*  612 */         FullyQualifiedJavaType.getNewIteratorInstance());
/*  613 */       method = new Method();
/*  614 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  615 */       method.setName("addCriterionForJDBCTime");
/*  616 */       method.addParameter(new Parameter(
/*  617 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  618 */       method.addParameter(new Parameter(
/*  619 */         FullyQualifiedJavaType.getDateInstance(), "value"));
/*  620 */       method.addParameter(new Parameter(
/*  621 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  622 */       method.addBodyLine("if (value == null) {");
/*  623 */       method
/*  624 */         .addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/*  625 */       method.addBodyLine("}");
/*  626 */       method
/*  627 */         .addBodyLine("addCriterion(condition, new java.sql.Time(value.getTime()), property);");
/*  628 */       answer.addMethod(method);
/*      */       
/*  630 */       method = new Method();
/*  631 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  632 */       method.setName("addCriterionForJDBCTime");
/*  633 */       method.addParameter(new Parameter(
/*  634 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  635 */       method.addParameter(new Parameter(listOfDates, "values"));
/*  636 */       method.addParameter(new Parameter(
/*  637 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  638 */       method.addBodyLine("if (values == null || values.size() == 0) {");
/*  639 */       method
/*  640 */         .addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/*  641 */       method.addBodyLine("}");
/*  642 */       if (this.generateForJava5)
/*      */       {
/*  644 */         method.addBodyLine("List<java.sql.Time> timeList = new ArrayList<java.sql.Time>();");
/*  645 */         method.addBodyLine("Iterator<Date> iter = values.iterator();");
/*  646 */         method.addBodyLine("while (iter.hasNext()) {");
/*  647 */         method
/*  648 */           .addBodyLine("timeList.add(new java.sql.Time(iter.next().getTime()));");
/*  649 */         method.addBodyLine("}");
/*      */       } else {
/*  651 */         method.addBodyLine("List timeList = new ArrayList();");
/*  652 */         method.addBodyLine("Iterator iter = values.iterator();");
/*  653 */         method.addBodyLine("while (iter.hasNext()) {");
/*  654 */         method
/*  655 */           .addBodyLine("timeList.add(new java.sql.Time(((Date)iter.next()).getTime()));");
/*  656 */         method.addBodyLine("}");
/*      */       }
/*  658 */       method.addBodyLine("addCriterion(condition, timeList, property);");
/*  659 */       answer.addMethod(method);
/*      */       
/*  661 */       method = new Method();
/*  662 */       method.setVisibility(JavaVisibility.PROTECTED);
/*  663 */       method.setName("addCriterionForJDBCTime");
/*  664 */       method.addParameter(new Parameter(
/*  665 */         FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  666 */       method.addParameter(new Parameter(
/*  667 */         FullyQualifiedJavaType.getDateInstance(), "value1"));
/*  668 */       method.addParameter(new Parameter(
/*  669 */         FullyQualifiedJavaType.getDateInstance(), "value2"));
/*  670 */       method.addParameter(new Parameter(
/*  671 */         FullyQualifiedJavaType.getStringInstance(), "property"));
/*  672 */       method.addBodyLine("if (value1 == null || value2 == null) {");
/*  673 */       method
/*  674 */         .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/*  675 */       method.addBodyLine("}");
/*  676 */       method
/*  677 */         .addBodyLine("addCriterion(condition, new java.sql.Time(value1.getTime()), new java.sql.Time(value2.getTime()), property);");
/*  678 */       answer.addMethod(method);
/*      */     }
/*      */     
/*      */ 
/*  682 */     Iterator localIterator2 = this.introspectedTable.getNonBLOBColumns().iterator();
/*  681 */     while (localIterator2.hasNext()) {
/*  682 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator2.next();
/*  683 */       topLevelClass.addImportedType(introspectedColumn
/*  684 */         .getFullyQualifiedJavaType());
/*      */       
/*      */ 
/*      */ 
/*  688 */       answer.addMethod(getSetNullMethod(introspectedColumn));
/*  689 */       answer.addMethod(getSetNotNullMethod(introspectedColumn));
/*  690 */       answer.addMethod(getSetEqualMethod(introspectedColumn));
/*  691 */       answer.addMethod(getSetNotEqualMethod(introspectedColumn));
/*  692 */       answer.addMethod(getSetGreaterThanMethod(introspectedColumn));
/*  693 */       answer
/*  694 */         .addMethod(getSetGreaterThenOrEqualMethod(introspectedColumn));
/*  695 */       answer.addMethod(getSetLessThanMethod(introspectedColumn));
/*  696 */       answer.addMethod(getSetLessThanOrEqualMethod(introspectedColumn));
/*      */       
/*  698 */       if (introspectedColumn.isJdbcCharacterColumn()) {
/*  699 */         answer.addMethod(getSetLikeMethod(introspectedColumn));
/*  700 */         answer.addMethod(getSetNotLikeMethod(introspectedColumn));
/*      */       }
/*      */       
/*  703 */       answer.addMethod(getSetInOrNotInMethod(introspectedColumn, true));
/*  704 */       answer.addMethod(getSetInOrNotInMethod(introspectedColumn, false));
/*  705 */       answer.addMethod(getSetBetweenOrNotBetweenMethod(
/*  706 */         introspectedColumn, true));
/*  707 */       answer.addMethod(getSetBetweenOrNotBetweenMethod(
/*  708 */         introspectedColumn, false));
/*      */     }
/*      */     
/*  711 */     return answer;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private List<String> addtypeHandledObjectsAndMethods(IntrospectedColumn introspectedColumn, Method constructor, InnerClass innerClass)
/*      */   {
/*  727 */     List<String> answer = new ArrayList();
/*  728 */     StringBuilder sb = new StringBuilder();
/*      */     
/*      */     FullyQualifiedJavaType listOfMaps;
/*      */     FullyQualifiedJavaType listOfMaps;
/*  732 */     if (this.generateForJava5) {
/*  733 */       listOfMaps = new FullyQualifiedJavaType(
/*  734 */         "java.util.List<java.util.Map<java.lang.String, java.lang.Object>>");
/*      */     } else {
/*  736 */       listOfMaps = new FullyQualifiedJavaType("java.util.List");
/*      */     }
/*      */     
/*  739 */     sb.setLength(0);
/*  740 */     sb.append(introspectedColumn.getJavaProperty());
/*  741 */     sb.append("CriteriaWithSingleValue");
/*  742 */     answer.add(sb.toString());
/*      */     
/*  744 */     Field field = new Field();
/*  745 */     field.setVisibility(JavaVisibility.PROTECTED);
/*  746 */     field.setType(listOfMaps);
/*  747 */     field.setName(sb.toString());
/*  748 */     innerClass.addField(field);
/*      */     
/*  750 */     Method method = new Method();
/*  751 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  752 */     method.setReturnType(field.getType());
/*  753 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName(), field
/*  754 */       .getType()));
/*  755 */     sb.insert(0, "return ");
/*  756 */     sb.append(';');
/*  757 */     method.addBodyLine(sb.toString());
/*  758 */     innerClass.addMethod(method);
/*      */     
/*  760 */     sb.setLength(0);
/*  761 */     sb.append(introspectedColumn.getJavaProperty());
/*  762 */     sb.append("CriteriaWithListValue");
/*  763 */     answer.add(sb.toString());
/*      */     
/*  765 */     field = new Field();
/*  766 */     field.setVisibility(JavaVisibility.PROTECTED);
/*  767 */     field.setType(listOfMaps);
/*  768 */     field.setName(sb.toString());
/*  769 */     innerClass.addField(field);
/*      */     
/*  771 */     method = new Method();
/*  772 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  773 */     method.setReturnType(field.getType());
/*  774 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName(), field
/*  775 */       .getType()));
/*  776 */     sb.insert(0, "return ");
/*  777 */     sb.append(';');
/*  778 */     method.addBodyLine(sb.toString());
/*  779 */     innerClass.addMethod(method);
/*      */     
/*  781 */     sb.setLength(0);
/*  782 */     sb.append(introspectedColumn.getJavaProperty());
/*  783 */     sb.append("CriteriaWithBetweenValue");
/*  784 */     answer.add(sb.toString());
/*      */     
/*  786 */     field = new Field();
/*  787 */     field.setVisibility(JavaVisibility.PROTECTED);
/*  788 */     field.setType(listOfMaps);
/*  789 */     field.setName(sb.toString());
/*  790 */     innerClass.addField(field);
/*      */     
/*  792 */     method = new Method();
/*  793 */     method.setVisibility(JavaVisibility.PUBLIC);
/*  794 */     method.setReturnType(field.getType());
/*  795 */     method.setName(JavaBeansUtil.getGetterMethodName(field.getName(), field
/*  796 */       .getType()));
/*  797 */     sb.insert(0, "return ");
/*  798 */     sb.append(';');
/*  799 */     method.addBodyLine(sb.toString());
/*  800 */     innerClass.addMethod(method);
/*      */     
/*      */ 
/*  803 */     sb.setLength(0);
/*  804 */     sb.append(introspectedColumn.getJavaProperty());
/*  805 */     if (this.generateForJava5)
/*      */     {
/*  807 */       sb.append("CriteriaWithSingleValue = new ArrayList<Map<String, Object>>();");
/*      */     } else {
/*  809 */       sb.append("CriteriaWithSingleValue = new ArrayList();");
/*      */     }
/*  811 */     constructor.addBodyLine(sb.toString());
/*      */     
/*  813 */     sb.setLength(0);
/*  814 */     sb.append(introspectedColumn.getJavaProperty());
/*  815 */     if (this.generateForJava5)
/*      */     {
/*  817 */       sb.append("CriteriaWithListValue = new ArrayList<Map<String, Object>>();");
/*      */     } else {
/*  819 */       sb.append("CriteriaWithListValue = new ArrayList();");
/*      */     }
/*  821 */     constructor.addBodyLine(sb.toString());
/*      */     
/*  823 */     sb.setLength(0);
/*  824 */     sb.append(introspectedColumn.getJavaProperty());
/*  825 */     if (this.generateForJava5)
/*      */     {
/*  827 */       sb.append("CriteriaWithBetweenValue = new ArrayList<Map<String, Object>>();");
/*      */     } else {
/*  829 */       sb.append("CriteriaWithBetweenValue = new ArrayList();");
/*      */     }
/*  831 */     constructor.addBodyLine(sb.toString());
/*      */     
/*      */ 
/*  834 */     method = new Method();
/*  835 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  836 */     sb.setLength(0);
/*  837 */     sb.append("add");
/*  838 */     sb.append(introspectedColumn.getJavaProperty());
/*  839 */     sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/*  840 */     sb.append("Criterion");
/*      */     
/*  842 */     method.setName(sb.toString());
/*  843 */     method.addParameter(new Parameter(
/*  844 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  845 */     if (introspectedColumn.getFullyQualifiedJavaType().isPrimitive()) {
/*  846 */       method.addParameter(new Parameter(introspectedColumn
/*  847 */         .getFullyQualifiedJavaType().getPrimitiveTypeWrapper(), 
/*  848 */         "value"));
/*      */     } else {
/*  850 */       method.addParameter(new Parameter(introspectedColumn
/*  851 */         .getFullyQualifiedJavaType(), "value"));
/*      */     }
/*  853 */     method.addParameter(new Parameter(
/*  854 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/*  855 */     if (!introspectedColumn.getFullyQualifiedJavaType().isPrimitive()) {
/*  856 */       method.addBodyLine("if (value == null) {");
/*  857 */       method
/*  858 */         .addBodyLine("throw new RuntimeException(\"Value for \" + property + \" cannot be null\");");
/*  859 */       method.addBodyLine("}");
/*      */     }
/*  861 */     if (this.generateForJava5)
/*      */     {
/*  863 */       method.addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/*      */     } else {
/*  865 */       method.addBodyLine("Map map = new HashMap();");
/*      */     }
/*  867 */     method.addBodyLine("map.put(\"condition\", condition);");
/*  868 */     method.addBodyLine("map.put(\"value\", value);");
/*      */     
/*  870 */     sb.setLength(0);
/*  871 */     sb.append(introspectedColumn.getJavaProperty());
/*  872 */     sb.append("CriteriaWithSingleValue.add(map);");
/*  873 */     method.addBodyLine(sb.toString());
/*  874 */     innerClass.addMethod(method);
/*      */     
/*  876 */     FullyQualifiedJavaType listOfObjects = 
/*  877 */       FullyQualifiedJavaType.getNewListInstance();
/*  878 */     if (this.generateForJava5) {
/*  879 */       if (introspectedColumn.getFullyQualifiedJavaType().isPrimitive()) {
/*  880 */         listOfObjects.addTypeArgument(introspectedColumn
/*  881 */           .getFullyQualifiedJavaType().getPrimitiveTypeWrapper());
/*      */       } else {
/*  883 */         listOfObjects.addTypeArgument(introspectedColumn
/*  884 */           .getFullyQualifiedJavaType());
/*      */       }
/*      */     }
/*      */     
/*  888 */     sb.setLength(0);
/*  889 */     sb.append("add");
/*  890 */     sb.append(introspectedColumn.getJavaProperty());
/*  891 */     sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/*  892 */     sb.append("Criterion");
/*      */     
/*  894 */     method = new Method();
/*  895 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  896 */     method.setName(sb.toString());
/*  897 */     method.addParameter(new Parameter(
/*  898 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  899 */     method.addParameter(new Parameter(listOfObjects, "values"));
/*  900 */     method.addParameter(new Parameter(
/*  901 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/*  902 */     method.addBodyLine("if (values == null || values.size() == 0) {");
/*  903 */     method
/*  904 */       .addBodyLine("throw new RuntimeException(\"Value list for \" + property + \" cannot be null or empty\");");
/*  905 */     method.addBodyLine("}");
/*  906 */     if (this.generateForJava5)
/*      */     {
/*  908 */       method.addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/*      */     } else {
/*  910 */       method.addBodyLine("Map map = new HashMap();");
/*      */     }
/*  912 */     method.addBodyLine("map.put(\"condition\", condition);");
/*  913 */     method.addBodyLine("map.put(\"values\", values);");
/*      */     
/*  915 */     sb.setLength(0);
/*  916 */     sb.append(introspectedColumn.getJavaProperty());
/*  917 */     sb.append("CriteriaWithListValue.add(map);");
/*  918 */     method.addBodyLine(sb.toString());
/*  919 */     innerClass.addMethod(method);
/*      */     
/*  921 */     sb.setLength(0);
/*  922 */     sb.append("add");
/*  923 */     sb.append(introspectedColumn.getJavaProperty());
/*  924 */     sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/*  925 */     sb.append("Criterion");
/*      */     
/*  927 */     method = new Method();
/*  928 */     method.setVisibility(JavaVisibility.PROTECTED);
/*  929 */     method.setName(sb.toString());
/*  930 */     method.addParameter(new Parameter(
/*  931 */       FullyQualifiedJavaType.getStringInstance(), "condition"));
/*  932 */     if (introspectedColumn.getFullyQualifiedJavaType().isPrimitive()) {
/*  933 */       method.addParameter(new Parameter(introspectedColumn
/*  934 */         .getFullyQualifiedJavaType().getPrimitiveTypeWrapper(), 
/*  935 */         "value1"));
/*  936 */       method.addParameter(new Parameter(introspectedColumn
/*  937 */         .getFullyQualifiedJavaType().getPrimitiveTypeWrapper(), 
/*  938 */         "value2"));
/*      */     } else {
/*  940 */       method.addParameter(new Parameter(introspectedColumn
/*  941 */         .getFullyQualifiedJavaType(), "value1"));
/*  942 */       method.addParameter(new Parameter(introspectedColumn
/*  943 */         .getFullyQualifiedJavaType(), "value2"));
/*      */     }
/*  945 */     method.addParameter(new Parameter(
/*  946 */       FullyQualifiedJavaType.getStringInstance(), "property"));
/*  947 */     method.addBodyLine("if (value1 == null || value2 == null) {");
/*  948 */     method
/*  949 */       .addBodyLine("throw new RuntimeException(\"Between values for \" + property + \" cannot be null\");");
/*  950 */     method.addBodyLine("}");
/*  951 */     if (this.generateForJava5) { String shortName;
/*      */       String shortName;
/*  953 */       if (introspectedColumn.getFullyQualifiedJavaType().isPrimitive()) {
/*  954 */         shortName = 
/*  955 */           introspectedColumn.getFullyQualifiedJavaType().getPrimitiveTypeWrapper().getShortName();
/*      */       } else {
/*  957 */         shortName = 
/*  958 */           introspectedColumn.getFullyQualifiedJavaType().getShortName();
/*      */       }
/*  960 */       sb.setLength(0);
/*  961 */       sb.append("List<");
/*  962 */       sb.append(shortName);
/*  963 */       sb.append("> list = new ArrayList<");
/*  964 */       sb.append(shortName);
/*  965 */       sb.append(">();");
/*  966 */       method.addBodyLine(sb.toString());
/*      */     } else {
/*  968 */       method.addBodyLine("List list = new ArrayList();");
/*      */     }
/*  970 */     method.addBodyLine("list.add(value1);");
/*  971 */     method.addBodyLine("list.add(value2);");
/*  972 */     if (this.generateForJava5)
/*      */     {
/*  974 */       method.addBodyLine("Map<String, Object> map = new HashMap<String, Object>();");
/*      */     } else {
/*  976 */       method.addBodyLine("Map map = new HashMap();");
/*      */     }
/*  978 */     method.addBodyLine("map.put(\"condition\", condition);");
/*  979 */     method.addBodyLine("map.put(\"values\", list);");
/*      */     
/*  981 */     sb.setLength(0);
/*  982 */     sb.append(introspectedColumn.getJavaProperty());
/*  983 */     sb.append("CriteriaWithBetweenValue.add(map);");
/*  984 */     method.addBodyLine(sb.toString());
/*  985 */     innerClass.addMethod(method);
/*      */     
/*  987 */     return answer;
/*      */   }
/*      */   
/*      */   private Method getSetNullMethod(IntrospectedColumn introspectedColumn) {
/*  991 */     return getNoValueMethod(introspectedColumn, "IsNull", "is null");
/*      */   }
/*      */   
/*      */   private Method getSetNotNullMethod(IntrospectedColumn introspectedColumn) {
/*  995 */     return getNoValueMethod(introspectedColumn, "IsNotNull", "is not null");
/*      */   }
/*      */   
/*      */   private Method getSetEqualMethod(IntrospectedColumn introspectedColumn) {
/*  999 */     return getSingleValueMethod(introspectedColumn, "EqualTo", "=");
/*      */   }
/*      */   
/*      */   private Method getSetNotEqualMethod(IntrospectedColumn introspectedColumn) {
/* 1003 */     return getSingleValueMethod(introspectedColumn, "NotEqualTo", "<>");
/*      */   }
/*      */   
/*      */   private Method getSetGreaterThanMethod(IntrospectedColumn introspectedColumn) {
/* 1007 */     return getSingleValueMethod(introspectedColumn, "GreaterThan", ">");
/*      */   }
/*      */   
/*      */   private Method getSetGreaterThenOrEqualMethod(IntrospectedColumn introspectedColumn)
/*      */   {
/* 1012 */     return getSingleValueMethod(introspectedColumn, 
/* 1013 */       "GreaterThanOrEqualTo", ">=");
/*      */   }
/*      */   
/*      */   private Method getSetLessThanMethod(IntrospectedColumn introspectedColumn) {
/* 1017 */     return getSingleValueMethod(introspectedColumn, "LessThan", "<");
/*      */   }
/*      */   
/*      */   private Method getSetLessThanOrEqualMethod(IntrospectedColumn introspectedColumn)
/*      */   {
/* 1022 */     return getSingleValueMethod(introspectedColumn, 
/* 1023 */       "LessThanOrEqualTo", "<=");
/*      */   }
/*      */   
/*      */   private Method getSetLikeMethod(IntrospectedColumn introspectedColumn) {
/* 1027 */     return getSingleValueMethod(introspectedColumn, "Like", "like");
/*      */   }
/*      */   
/*      */   private Method getSetNotLikeMethod(IntrospectedColumn introspectedColumn) {
/* 1031 */     return getSingleValueMethod(introspectedColumn, "NotLike", "not like");
/*      */   }
/*      */   
/*      */   private Method getSingleValueMethod(IntrospectedColumn introspectedColumn, String nameFragment, String operator)
/*      */   {
/* 1036 */     Method method = new Method();
/* 1037 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1038 */     method.addParameter(new Parameter(introspectedColumn
/* 1039 */       .getFullyQualifiedJavaType(), "value"));
/* 1040 */     StringBuilder sb = new StringBuilder();
/* 1041 */     sb.append(introspectedColumn.getJavaProperty());
/* 1042 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/* 1043 */     sb.insert(0, "and");
/* 1044 */     sb.append(nameFragment);
/* 1045 */     method.setName(sb.toString());
/* 1046 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/* 1047 */     sb.setLength(0);
/*      */     
/* 1049 */     if (introspectedColumn.isJDBCDateColumn()) {
/* 1050 */       sb.append("addCriterionForJDBCDate(\"");
/* 1051 */     } else if (introspectedColumn.isJDBCTimeColumn()) {
/* 1052 */       sb.append("addCriterionForJDBCTime(\"");
/* 1053 */     } else if (StringUtility.stringHasValue(introspectedColumn
/* 1054 */       .getTypeHandler())) {
/* 1055 */       sb.append("add");
/* 1056 */       sb.append(introspectedColumn.getJavaProperty());
/* 1057 */       sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 1058 */       sb.append("Criterion(\"");
/*      */     } else {
/* 1060 */       sb.append("addCriterion(\"");
/*      */     }
/*      */     
/* 1063 */     sb.append(
/* 1064 */       Ibatis2FormattingUtilities.getAliasedActualColumnName(introspectedColumn));
/* 1065 */     sb.append(' ');
/* 1066 */     sb.append(operator);
/* 1067 */     sb.append("\", ");
/*      */     
/* 1069 */     if ((introspectedColumn.getFullyQualifiedJavaType().isPrimitive()) && (!this.introspectedTable.isJava5Targeted())) {
/* 1070 */       sb.append("new ");
/* 1071 */       sb.append(introspectedColumn.getFullyQualifiedJavaType()
/* 1072 */         .getPrimitiveTypeWrapper().getShortName());
/* 1073 */       sb.append("(value)");
/*      */     } else {
/* 1075 */       sb.append("value");
/*      */     }
/*      */     
/* 1078 */     sb.append(", \"");
/* 1079 */     sb.append(introspectedColumn.getJavaProperty());
/* 1080 */     sb.append("\");");
/* 1081 */     method.addBodyLine(sb.toString());
/* 1082 */     method.addBodyLine("return (Criteria) this;");
/*      */     
/* 1084 */     return method;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Method getSetBetweenOrNotBetweenMethod(IntrospectedColumn introspectedColumn, boolean betweenMethod)
/*      */   {
/* 1096 */     Method method = new Method();
/* 1097 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1098 */     FullyQualifiedJavaType type = introspectedColumn
/* 1099 */       .getFullyQualifiedJavaType();
/*      */     
/* 1101 */     method.addParameter(new Parameter(type, "value1"));
/* 1102 */     method.addParameter(new Parameter(type, "value2"));
/* 1103 */     StringBuilder sb = new StringBuilder();
/* 1104 */     sb.append(introspectedColumn.getJavaProperty());
/* 1105 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/* 1106 */     sb.insert(0, "and");
/* 1107 */     if (betweenMethod) {
/* 1108 */       sb.append("Between");
/*      */     } else {
/* 1110 */       sb.append("NotBetween");
/*      */     }
/* 1112 */     method.setName(sb.toString());
/* 1113 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/* 1114 */     sb.setLength(0);
/*      */     
/* 1116 */     if (introspectedColumn.isJDBCDateColumn()) {
/* 1117 */       sb.append("addCriterionForJDBCDate(\"");
/* 1118 */     } else if (introspectedColumn.isJDBCTimeColumn()) {
/* 1119 */       sb.append("addCriterionForJDBCTime(\"");
/* 1120 */     } else if (StringUtility.stringHasValue(introspectedColumn
/* 1121 */       .getTypeHandler())) {
/* 1122 */       sb.append("add");
/* 1123 */       sb.append(introspectedColumn.getJavaProperty());
/* 1124 */       sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 1125 */       sb.append("Criterion(\"");
/*      */     } else {
/* 1127 */       sb.append("addCriterion(\"");
/*      */     }
/*      */     
/* 1130 */     sb.append(
/* 1131 */       Ibatis2FormattingUtilities.getAliasedActualColumnName(introspectedColumn));
/* 1132 */     if (betweenMethod) {
/* 1133 */       sb.append(" between");
/*      */     } else {
/* 1135 */       sb.append(" not between");
/*      */     }
/* 1137 */     sb.append("\", ");
/* 1138 */     if ((introspectedColumn.getFullyQualifiedJavaType().isPrimitive()) && (!this.introspectedTable.isJava5Targeted())) {
/* 1139 */       sb.append("new ");
/* 1140 */       sb.append(introspectedColumn.getFullyQualifiedJavaType()
/* 1141 */         .getPrimitiveTypeWrapper().getShortName());
/* 1142 */       sb.append("(value1), ");
/* 1143 */       sb.append("new ");
/* 1144 */       sb.append(introspectedColumn.getFullyQualifiedJavaType()
/* 1145 */         .getPrimitiveTypeWrapper().getShortName());
/* 1146 */       sb.append("(value2)");
/*      */     } else {
/* 1148 */       sb.append("value1, value2");
/*      */     }
/*      */     
/* 1151 */     sb.append(", \"");
/* 1152 */     sb.append(introspectedColumn.getJavaProperty());
/* 1153 */     sb.append("\");");
/* 1154 */     method.addBodyLine(sb.toString());
/* 1155 */     method.addBodyLine("return (Criteria) this;");
/*      */     
/* 1157 */     return method;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private Method getSetInOrNotInMethod(IntrospectedColumn introspectedColumn, boolean inMethod)
/*      */   {
/* 1170 */     Method method = new Method();
/* 1171 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1172 */     FullyQualifiedJavaType type = 
/* 1173 */       FullyQualifiedJavaType.getNewListInstance();
/* 1174 */     if (this.generateForJava5) {
/* 1175 */       if (introspectedColumn.getFullyQualifiedJavaType().isPrimitive()) {
/* 1176 */         type.addTypeArgument(introspectedColumn
/* 1177 */           .getFullyQualifiedJavaType().getPrimitiveTypeWrapper());
/*      */       } else {
/* 1179 */         type.addTypeArgument(introspectedColumn
/* 1180 */           .getFullyQualifiedJavaType());
/*      */       }
/*      */     }
/*      */     
/* 1184 */     method.addParameter(new Parameter(type, "values"));
/* 1185 */     StringBuilder sb = new StringBuilder();
/* 1186 */     sb.append(introspectedColumn.getJavaProperty());
/* 1187 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/* 1188 */     sb.insert(0, "and");
/* 1189 */     if (inMethod) {
/* 1190 */       sb.append("In");
/*      */     } else {
/* 1192 */       sb.append("NotIn");
/*      */     }
/* 1194 */     method.setName(sb.toString());
/* 1195 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/* 1196 */     sb.setLength(0);
/*      */     
/* 1198 */     if (introspectedColumn.isJDBCDateColumn()) {
/* 1199 */       sb.append("addCriterionForJDBCDate(\"");
/* 1200 */     } else if (introspectedColumn.isJDBCTimeColumn()) {
/* 1201 */       sb.append("addCriterionForJDBCTime(\"");
/* 1202 */     } else if (StringUtility.stringHasValue(introspectedColumn
/* 1203 */       .getTypeHandler())) {
/* 1204 */       sb.append("add");
/* 1205 */       sb.append(introspectedColumn.getJavaProperty());
/* 1206 */       sb.setCharAt(3, Character.toUpperCase(sb.charAt(3)));
/* 1207 */       sb.append("Criterion(\"");
/*      */     } else {
/* 1209 */       sb.append("addCriterion(\"");
/*      */     }
/*      */     
/* 1212 */     sb.append(
/* 1213 */       Ibatis2FormattingUtilities.getAliasedActualColumnName(introspectedColumn));
/* 1214 */     if (inMethod) {
/* 1215 */       sb.append(" in");
/*      */     } else {
/* 1217 */       sb.append(" not in");
/*      */     }
/* 1219 */     sb.append("\", values, \"");
/* 1220 */     sb.append(introspectedColumn.getJavaProperty());
/* 1221 */     sb.append("\");");
/* 1222 */     method.addBodyLine(sb.toString());
/* 1223 */     method.addBodyLine("return (Criteria) this;");
/*      */     
/* 1225 */     return method;
/*      */   }
/*      */   
/*      */   private Method getNoValueMethod(IntrospectedColumn introspectedColumn, String nameFragment, String operator)
/*      */   {
/* 1230 */     Method method = new Method();
/* 1231 */     method.setVisibility(JavaVisibility.PUBLIC);
/* 1232 */     StringBuilder sb = new StringBuilder();
/* 1233 */     sb.append(introspectedColumn.getJavaProperty());
/* 1234 */     sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
/* 1235 */     sb.insert(0, "and");
/* 1236 */     sb.append(nameFragment);
/* 1237 */     method.setName(sb.toString());
/* 1238 */     method.setReturnType(FullyQualifiedJavaType.getCriteriaInstance());
/* 1239 */     sb.setLength(0);
/* 1240 */     sb.append("addCriterion(\"");
/* 1241 */     sb.append(
/* 1242 */       Ibatis2FormattingUtilities.getAliasedActualColumnName(introspectedColumn));
/* 1243 */     sb.append(' ');
/* 1244 */     sb.append(operator);
/* 1245 */     sb.append("\");");
/* 1246 */     method.addBodyLine(sb.toString());
/* 1247 */     method.addBodyLine("return (Criteria) this;");
/*      */     
/* 1249 */     return method;
/*      */   }
/*      */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\model\ExampleGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */