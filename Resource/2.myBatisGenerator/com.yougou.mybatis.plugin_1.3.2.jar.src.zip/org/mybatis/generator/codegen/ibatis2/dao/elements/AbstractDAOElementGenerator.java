/*     */ package org.mybatis.generator.codegen.ibatis2.dao.elements;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.DAOMethodNameCalculator;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.AbstractGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.AbstractDAOTemplate;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*     */ import org.mybatis.generator.internal.DefaultDAOMethodNameCalculator;
/*     */ import org.mybatis.generator.internal.ExtendedDAOMethodNameCalculator;
/*     */ import org.mybatis.generator.internal.ObjectFactory;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractDAOElementGenerator
/*     */   extends AbstractGenerator
/*     */ {
/*     */   protected AbstractDAOTemplate daoTemplate;
/*     */   private DAOMethodNameCalculator dAOMethodNameCalculator;
/*     */   private JavaVisibility exampleMethodVisibility;
/*     */   
/*     */   public abstract void addInterfaceElements(Interface paramInterface);
/*     */   
/*     */   public abstract void addImplementationElements(TopLevelClass paramTopLevelClass);
/*     */   
/*     */   public void setDAOTemplate(AbstractDAOTemplate abstractDAOTemplate)
/*     */   {
/*  50 */     this.daoTemplate = abstractDAOTemplate;
/*     */   }
/*     */   
/*     */   public DAOMethodNameCalculator getDAOMethodNameCalculator() {
/*  54 */     if (this.dAOMethodNameCalculator == null) {
/*  55 */       String type = this.context.getJavaClientGeneratorConfiguration()
/*  56 */         .getProperty("methodNameCalculator");
/*  57 */       if (StringUtility.stringHasValue(type)) {
/*  58 */         if ("extended".equalsIgnoreCase(type)) {
/*  59 */           type = ExtendedDAOMethodNameCalculator.class.getName();
/*  60 */         } else if ("default".equalsIgnoreCase(type)) {
/*  61 */           type = DefaultDAOMethodNameCalculator.class.getName();
/*     */         }
/*     */       } else {
/*  64 */         type = DefaultDAOMethodNameCalculator.class.getName();
/*     */       }
/*     */       try
/*     */       {
/*  68 */         this.dAOMethodNameCalculator = ((DAOMethodNameCalculator)
/*  69 */           ObjectFactory.createInternalObject(type));
/*     */       } catch (Exception e) {
/*  71 */         this.dAOMethodNameCalculator = new DefaultDAOMethodNameCalculator();
/*  72 */         this.warnings.add(Messages.getString(
/*  73 */           "Warning.17", type, e.getMessage()));
/*     */       }
/*     */     }
/*     */     
/*  77 */     return this.dAOMethodNameCalculator;
/*     */   }
/*     */   
/*     */   public JavaVisibility getExampleMethodVisibility() {
/*  81 */     if (this.exampleMethodVisibility == null) {
/*  82 */       String type = this.context
/*  83 */         .getJavaClientGeneratorConfiguration()
/*  84 */         .getProperty("exampleMethodVisibility");
/*  85 */       if (StringUtility.stringHasValue(type)) {
/*  86 */         if ("public".equalsIgnoreCase(type)) {
/*  87 */           this.exampleMethodVisibility = JavaVisibility.PUBLIC;
/*  88 */         } else if ("private".equalsIgnoreCase(type)) {
/*  89 */           this.exampleMethodVisibility = JavaVisibility.PRIVATE;
/*  90 */         } else if ("protected".equalsIgnoreCase(type)) {
/*  91 */           this.exampleMethodVisibility = JavaVisibility.PROTECTED;
/*  92 */         } else if ("default".equalsIgnoreCase(type)) {
/*  93 */           this.exampleMethodVisibility = JavaVisibility.DEFAULT;
/*     */         } else {
/*  95 */           this.exampleMethodVisibility = JavaVisibility.PUBLIC;
/*  96 */           this.warnings.add(Messages.getString("Warning.16", type));
/*     */         }
/*     */       } else {
/*  99 */         this.exampleMethodVisibility = JavaVisibility.PUBLIC;
/*     */       }
/*     */     }
/*     */     
/* 103 */     return this.exampleMethodVisibility;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\dao\elements\AbstractDAOElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */