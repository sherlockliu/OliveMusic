/*     */ package org.mybatis.generator.codegen.ibatis2.dao.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.DAOMethodNameCalculator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.AbstractDAOTemplate;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.JavaBeansUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SelectByPrimaryKeyMethodGenerator
/*     */   extends AbstractDAOElementGenerator
/*     */ {
/*     */   public void addImplementationElements(TopLevelClass topLevelClass)
/*     */   {
/*  45 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  46 */     Method method = getMethodShell(importedTypes);
/*     */     
/*     */ 
/*  49 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  51 */     if (!this.introspectedTable.getRules().generatePrimaryKeyClass())
/*     */     {
/*     */ 
/*  54 */       FullyQualifiedJavaType keyType = new FullyQualifiedJavaType(
/*  55 */         this.introspectedTable.getBaseRecordType());
/*  56 */       topLevelClass.addImportedType(keyType);
/*     */       
/*  58 */       sb.setLength(0);
/*  59 */       sb.append(keyType.getShortName());
/*  60 */       sb.append(" _key = new ");
/*  61 */       sb.append(keyType.getShortName());
/*  62 */       sb.append("();");
/*  63 */       method.addBodyLine(sb.toString());
/*     */       
/*     */ 
/*  66 */       Iterator localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/*  65 */       while (localIterator.hasNext()) {
/*  66 */         IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*  67 */         sb.setLength(0);
/*  68 */         sb.append("_key.");
/*  69 */         sb.append(JavaBeansUtil.getSetterMethodName(introspectedColumn
/*  70 */           .getJavaProperty()));
/*  71 */         sb.append('(');
/*  72 */         sb.append(introspectedColumn.getJavaProperty());
/*  73 */         sb.append(");");
/*  74 */         method.addBodyLine(sb.toString());
/*     */       }
/*     */     }
/*     */     
/*  78 */     FullyQualifiedJavaType returnType = method.getReturnType();
/*     */     
/*  80 */     sb.setLength(0);
/*  81 */     sb.append(returnType.getShortName());
/*  82 */     sb.append(" record = (");
/*  83 */     sb.append(returnType.getShortName());
/*  84 */     sb.append(") ");
/*  85 */     sb.append(this.daoTemplate.getQueryForObjectMethod(this.introspectedTable
/*  86 */       .getIbatis2SqlMapNamespace(), this.introspectedTable
/*  87 */       .getSelectByPrimaryKeyStatementId(), "_key"));
/*  88 */     method.addBodyLine(sb.toString());
/*  89 */     method.addBodyLine("return record;");
/*     */     
/*  91 */     if (this.context.getPlugins().clientSelectByPrimaryKeyMethodGenerated(
/*  92 */       method, topLevelClass, this.introspectedTable)) {
/*  93 */       topLevelClass.addImportedTypes(importedTypes);
/*  94 */       topLevelClass.addMethod(method);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addInterfaceElements(Interface interfaze)
/*     */   {
/* 100 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/* 101 */     Method method = getMethodShell(importedTypes);
/*     */     
/* 103 */     if (this.context.getPlugins().clientSelectByPrimaryKeyMethodGenerated(
/* 104 */       method, interfaze, this.introspectedTable)) {
/* 105 */       interfaze.addImportedTypes(importedTypes);
/* 106 */       interfaze.addMethod(method);
/*     */     }
/*     */   }
/*     */   
/*     */   private Method getMethodShell(Set<FullyQualifiedJavaType> importedTypes) {
/* 111 */     Method method = new Method();
/* 112 */     method.setVisibility(JavaVisibility.PUBLIC);
/*     */     
/* 114 */     FullyQualifiedJavaType returnType = this.introspectedTable.getRules()
/* 115 */       .calculateAllFieldsClass();
/* 116 */     method.setReturnType(returnType);
/* 117 */     importedTypes.add(returnType);
/*     */     
/* 119 */     method.setName(getDAOMethodNameCalculator()
/* 120 */       .getSelectByPrimaryKeyMethodName(this.introspectedTable));
/*     */     Iterator localIterator;
/* 122 */     if (this.introspectedTable.getRules().generatePrimaryKeyClass()) {
/* 123 */       FullyQualifiedJavaType type = new FullyQualifiedJavaType(
/* 124 */         this.introspectedTable.getPrimaryKeyType());
/* 125 */       importedTypes.add(type);
/* 126 */       method.addParameter(new Parameter(type, "_key"));
/*     */     }
/*     */     else {
/* 129 */       localIterator = this.introspectedTable.getPrimaryKeyColumns().iterator();
/* 128 */       while (localIterator.hasNext()) {
/* 129 */         IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/* 130 */         FullyQualifiedJavaType type = introspectedColumn
/* 131 */           .getFullyQualifiedJavaType();
/* 132 */         importedTypes.add(type);
/* 133 */         method.addParameter(new Parameter(type, introspectedColumn
/* 134 */           .getJavaProperty()));
/*     */       }
/*     */     }
/*     */     
/* 138 */     for (FullyQualifiedJavaType fqjt : this.daoTemplate.getCheckedExceptions()) {
/* 139 */       method.addException(fqjt);
/* 140 */       importedTypes.add(fqjt);
/*     */     }
/*     */     
/* 143 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 144 */       this.introspectedTable);
/*     */     
/* 146 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\dao\elements\SelectByPrimaryKeyMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */