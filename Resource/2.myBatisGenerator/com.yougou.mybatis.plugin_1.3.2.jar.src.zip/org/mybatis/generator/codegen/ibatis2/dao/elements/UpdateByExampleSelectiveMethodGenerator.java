/*     */ package org.mybatis.generator.codegen.ibatis2.dao.elements;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.DAOMethodNameCalculator;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.AbstractDAOTemplate;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateByExampleSelectiveMethodGenerator
/*     */   extends AbstractDAOElementGenerator
/*     */ {
/*     */   public void addImplementationElements(TopLevelClass topLevelClass)
/*     */   {
/*  38 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  39 */     Method method = getMethodShell(importedTypes);
/*     */     
/*  41 */     method
/*  42 */       .addBodyLine("UpdateByExampleParms parms = new UpdateByExampleParms(record, example);");
/*     */     
/*  44 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  46 */     sb.append("int rows = ");
/*     */     
/*  48 */     sb.append(this.daoTemplate.getUpdateMethod(this.introspectedTable
/*  49 */       .getIbatis2SqlMapNamespace(), this.introspectedTable
/*  50 */       .getUpdateByExampleSelectiveStatementId(), "parms"));
/*  51 */     method.addBodyLine(sb.toString());
/*     */     
/*  53 */     method.addBodyLine("return rows;");
/*     */     
/*     */ 
/*  56 */     if (this.context.getPlugins().clientUpdateByExampleSelectiveMethodGenerated(method, 
/*  57 */       topLevelClass, this.introspectedTable)) {
/*  58 */       topLevelClass.addImportedTypes(importedTypes);
/*  59 */       topLevelClass.addMethod(method);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addInterfaceElements(Interface interfaze)
/*     */   {
/*  65 */     if (getExampleMethodVisibility() == JavaVisibility.PUBLIC) {
/*  66 */       Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  67 */       Method method = getMethodShell(importedTypes);
/*     */       
/*     */ 
/*  70 */       if (this.context.getPlugins().clientUpdateByExampleSelectiveMethodGenerated(method, 
/*  71 */         interfaze, this.introspectedTable)) {
/*  72 */         interfaze.addImportedTypes(importedTypes);
/*  73 */         interfaze.addMethod(method);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Method getMethodShell(Set<FullyQualifiedJavaType> importedTypes) {
/*     */     FullyQualifiedJavaType parameterType;
/*     */     FullyQualifiedJavaType parameterType;
/*  81 */     if (this.introspectedTable.getRules().generateRecordWithBLOBsClass()) {
/*  82 */       parameterType = new FullyQualifiedJavaType(this.introspectedTable
/*  83 */         .getRecordWithBLOBsType()); } else { FullyQualifiedJavaType parameterType;
/*  84 */       if (this.introspectedTable.getRules().generateBaseRecordClass()) {
/*  85 */         parameterType = new FullyQualifiedJavaType(this.introspectedTable
/*  86 */           .getBaseRecordType());
/*     */       } else {
/*  88 */         parameterType = new FullyQualifiedJavaType(this.introspectedTable
/*  89 */           .getPrimaryKeyType());
/*     */       }
/*     */     }
/*  92 */     importedTypes.add(parameterType);
/*     */     
/*  94 */     Method method = new Method();
/*  95 */     method.setVisibility(getExampleMethodVisibility());
/*  96 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*  97 */     method.setName(getDAOMethodNameCalculator()
/*  98 */       .getUpdateByExampleSelectiveMethodName(this.introspectedTable));
/*  99 */     method.addParameter(new Parameter(parameterType, "record"));
/* 100 */     method.addParameter(new Parameter(new FullyQualifiedJavaType(
/* 101 */       this.introspectedTable.getExampleType()), "example"));
/*     */     
/* 103 */     for (FullyQualifiedJavaType fqjt : this.daoTemplate.getCheckedExceptions()) {
/* 104 */       method.addException(fqjt);
/* 105 */       importedTypes.add(fqjt);
/*     */     }
/*     */     
/* 108 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 109 */       this.introspectedTable);
/*     */     
/* 111 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\dao\elements\UpdateByExampleSelectiveMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */