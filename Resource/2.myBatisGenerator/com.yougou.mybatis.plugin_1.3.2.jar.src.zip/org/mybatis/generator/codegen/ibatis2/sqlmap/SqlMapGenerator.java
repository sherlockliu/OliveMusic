/*     */ package org.mybatis.generator.codegen.ibatis2.sqlmap;
/*     */ 
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.Document;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.AbstractXmlGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.AbstractXmlElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.BaseColumnListElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.BlobColumnListElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.CountByExampleElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.DeleteByExampleElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.DeleteByPrimaryKeyElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.ExampleWhereClauseElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.InsertElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.InsertSelectiveElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.ResultMapWithBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.ResultMapWithoutBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.SelectByExampleWithBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.SelectByExampleWithoutBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.SelectByPrimaryKeyElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.UpdateByExampleSelectiveElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.UpdateByExampleWithBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.UpdateByExampleWithoutBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.UpdateByPrimaryKeySelectiveElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.UpdateByPrimaryKeyWithBLOBsElementGenerator;
/*     */ import org.mybatis.generator.codegen.ibatis2.sqlmap.elements.UpdateByPrimaryKeyWithoutBLOBsElementGenerator;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SqlMapGenerator
/*     */   extends AbstractXmlGenerator
/*     */ {
/*     */   protected XmlElement getSqlMapElement()
/*     */   {
/*  59 */     FullyQualifiedTable table = this.introspectedTable.getFullyQualifiedTable();
/*  60 */     this.progressCallback.startTask(Messages.getString(
/*  61 */       "Progress.12", table.toString()));
/*  62 */     XmlElement answer = new XmlElement("sqlMap");
/*  63 */     answer.addAttribute(new Attribute("namespace", 
/*  64 */       this.introspectedTable.getIbatis2SqlMapNamespace()));
/*     */     
/*  66 */     this.context.getCommentGenerator().addRootComment(answer);
/*     */     
/*  68 */     addResultMapWithoutBLOBsElement(answer);
/*  69 */     addResultMapWithBLOBsElement(answer);
/*  70 */     addExampleWhereClauseElement(answer);
/*  71 */     addBaseColumnListElement(answer);
/*  72 */     addBlobColumnListElement(answer);
/*  73 */     addSelectByExampleWithBLOBsElement(answer);
/*  74 */     addSelectByExampleWithoutBLOBsElement(answer);
/*  75 */     addSelectByPrimaryKeyElement(answer);
/*  76 */     addDeleteByPrimaryKeyElement(answer);
/*  77 */     addDeleteByExampleElement(answer);
/*  78 */     addInsertElement(answer);
/*  79 */     addInsertSelectiveElement(answer);
/*  80 */     addCountByExampleElement(answer);
/*  81 */     addUpdateByExampleSelectiveElement(answer);
/*  82 */     addUpdateByExampleWithBLOBsElement(answer);
/*  83 */     addUpdateByExampleWithoutBLOBsElement(answer);
/*  84 */     addUpdateByPrimaryKeySelectiveElement(answer);
/*  85 */     addUpdateByPrimaryKeyWithBLOBsElement(answer);
/*  86 */     addUpdateByPrimaryKeyWithoutBLOBsElement(answer);
/*     */     
/*  88 */     return answer;
/*     */   }
/*     */   
/*     */   protected void addResultMapWithoutBLOBsElement(XmlElement parentElement) {
/*  92 */     if (this.introspectedTable.getRules().generateBaseResultMap()) {
/*  93 */       AbstractXmlElementGenerator elementGenerator = new ResultMapWithoutBLOBsElementGenerator();
/*  94 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addResultMapWithBLOBsElement(XmlElement parentElement) {
/*  99 */     if (this.introspectedTable.getRules().generateResultMapWithBLOBs()) {
/* 100 */       AbstractXmlElementGenerator elementGenerator = new ResultMapWithBLOBsElementGenerator();
/* 101 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addExampleWhereClauseElement(XmlElement parentElement) {
/* 106 */     if (this.introspectedTable.getRules().generateSQLExampleWhereClause()) {
/* 107 */       AbstractXmlElementGenerator elementGenerator = new ExampleWhereClauseElementGenerator();
/* 108 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addBaseColumnListElement(XmlElement parentElement) {
/* 113 */     if (this.introspectedTable.getRules().generateBaseColumnList()) {
/* 114 */       AbstractXmlElementGenerator elementGenerator = new BaseColumnListElementGenerator();
/* 115 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addBlobColumnListElement(XmlElement parentElement) {
/* 120 */     if (this.introspectedTable.getRules().generateBlobColumnList()) {
/* 121 */       AbstractXmlElementGenerator elementGenerator = new BlobColumnListElementGenerator();
/* 122 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByExampleWithoutBLOBsElement(XmlElement parentElement)
/*     */   {
/* 128 */     if (this.introspectedTable.getRules().generateSelectByExampleWithoutBLOBs()) {
/* 129 */       AbstractXmlElementGenerator elementGenerator = new SelectByExampleWithoutBLOBsElementGenerator();
/* 130 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByExampleWithBLOBsElement(XmlElement parentElement) {
/* 135 */     if (this.introspectedTable.getRules().generateSelectByExampleWithBLOBs()) {
/* 136 */       AbstractXmlElementGenerator elementGenerator = new SelectByExampleWithBLOBsElementGenerator();
/* 137 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addSelectByPrimaryKeyElement(XmlElement parentElement) {
/* 142 */     if (this.introspectedTable.getRules().generateSelectByPrimaryKey()) {
/* 143 */       AbstractXmlElementGenerator elementGenerator = new SelectByPrimaryKeyElementGenerator();
/* 144 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addDeleteByExampleElement(XmlElement parentElement) {
/* 149 */     if (this.introspectedTable.getRules().generateDeleteByExample()) {
/* 150 */       AbstractXmlElementGenerator elementGenerator = new DeleteByExampleElementGenerator();
/* 151 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addDeleteByPrimaryKeyElement(XmlElement parentElement) {
/* 156 */     if (this.introspectedTable.getRules().generateDeleteByPrimaryKey()) {
/* 157 */       AbstractXmlElementGenerator elementGenerator = new DeleteByPrimaryKeyElementGenerator();
/* 158 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertElement(XmlElement parentElement) {
/* 163 */     if (this.introspectedTable.getRules().generateInsert()) {
/* 164 */       AbstractXmlElementGenerator elementGenerator = new InsertElementGenerator();
/* 165 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addInsertSelectiveElement(XmlElement parentElement) {
/* 170 */     if (this.introspectedTable.getRules().generateInsertSelective()) {
/* 171 */       AbstractXmlElementGenerator elementGenerator = new InsertSelectiveElementGenerator();
/* 172 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addCountByExampleElement(XmlElement parentElement) {
/* 177 */     if (this.introspectedTable.getRules().generateCountByExample()) {
/* 178 */       AbstractXmlElementGenerator elementGenerator = new CountByExampleElementGenerator();
/* 179 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleSelectiveElement(XmlElement parentElement) {
/* 184 */     if (this.introspectedTable.getRules().generateUpdateByExampleSelective()) {
/* 185 */       AbstractXmlElementGenerator elementGenerator = new UpdateByExampleSelectiveElementGenerator();
/* 186 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleWithBLOBsElement(XmlElement parentElement) {
/* 191 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithBLOBs()) {
/* 192 */       AbstractXmlElementGenerator elementGenerator = new UpdateByExampleWithBLOBsElementGenerator();
/* 193 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByExampleWithoutBLOBsElement(XmlElement parentElement)
/*     */   {
/* 199 */     if (this.introspectedTable.getRules().generateUpdateByExampleWithoutBLOBs()) {
/* 200 */       AbstractXmlElementGenerator elementGenerator = new UpdateByExampleWithoutBLOBsElementGenerator();
/* 201 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeySelectiveElement(XmlElement parentElement)
/*     */   {
/* 207 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeySelective()) {
/* 208 */       AbstractXmlElementGenerator elementGenerator = new UpdateByPrimaryKeySelectiveElementGenerator();
/* 209 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addUpdateByPrimaryKeyWithBLOBsElement(XmlElement parentElement)
/*     */   {
/* 215 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeyWithBLOBs()) {
/* 216 */       AbstractXmlElementGenerator elementGenerator = new UpdateByPrimaryKeyWithBLOBsElementGenerator();
/* 217 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addUpdateByPrimaryKeyWithoutBLOBsElement(XmlElement parentElement)
/*     */   {
/* 224 */     if (this.introspectedTable.getRules().generateUpdateByPrimaryKeyWithoutBLOBs()) {
/* 225 */       AbstractXmlElementGenerator elementGenerator = new UpdateByPrimaryKeyWithoutBLOBsElementGenerator();
/* 226 */       initializeAndExecuteGenerator(elementGenerator, parentElement);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected void initializeAndExecuteGenerator(AbstractXmlElementGenerator elementGenerator, XmlElement parentElement)
/*     */   {
/* 233 */     elementGenerator.setContext(this.context);
/* 234 */     elementGenerator.setIntrospectedTable(this.introspectedTable);
/* 235 */     elementGenerator.setProgressCallback(this.progressCallback);
/* 236 */     elementGenerator.setWarnings(this.warnings);
/* 237 */     elementGenerator.addElements(parentElement);
/*     */   }
/*     */   
/*     */   public Document getDocument()
/*     */   {
/* 242 */     Document document = new Document(
/* 243 */       "-//ibatis.apache.org//DTD SQL Map 2.0//EN", 
/* 244 */       "http://ibatis.apache.org/dtd/sql-map-2.dtd");
/* 245 */     document.setRootElement(getSqlMapElement());
/*     */     
/* 247 */     if (!this.context.getPlugins().sqlMapDocumentGenerated(document, 
/* 248 */       this.introspectedTable)) {
/* 249 */       document = null;
/*     */     }
/*     */     
/* 252 */     return document;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\sqlmap\SqlMapGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */