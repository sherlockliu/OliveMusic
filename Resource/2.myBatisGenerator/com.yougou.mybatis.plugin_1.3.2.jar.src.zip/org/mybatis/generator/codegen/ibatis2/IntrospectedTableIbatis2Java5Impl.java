/*    */ package org.mybatis.generator.codegen.ibatis2;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntrospectedTableIbatis2Java5Impl
/*    */   extends IntrospectedTableIbatis2Java2Impl
/*    */ {
/*    */   public boolean isJava5Targeted()
/*    */   {
/* 27 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\IntrospectedTableIbatis2Java5Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */