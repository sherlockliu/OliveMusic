/*     */ package org.mybatis.generator.codegen.ibatis2.sqlmap.elements;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.codegen.ibatis2.Ibatis2FormattingUtilities;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.GeneratedKey;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class InsertSelectiveElementGenerator
/*     */   extends AbstractXmlElementGenerator
/*     */ {
/*     */   public void addElements(XmlElement parentElement)
/*     */   {
/*  40 */     XmlElement answer = new XmlElement("insert");
/*     */     
/*  42 */     answer.addAttribute(new Attribute(
/*  43 */       "id", this.introspectedTable.getInsertSelectiveStatementId()));
/*     */     
/*  45 */     FullyQualifiedJavaType parameterType = this.introspectedTable.getRules()
/*  46 */       .calculateAllFieldsClass();
/*     */     
/*  48 */     answer.addAttribute(new Attribute("parameterClass", 
/*  49 */       parameterType.getFullyQualifiedName()));
/*     */     
/*  51 */     this.context.getCommentGenerator().addComment(answer);
/*     */     
/*  53 */     GeneratedKey gk = this.introspectedTable.getGeneratedKey();
/*     */     
/*  55 */     if ((gk != null) && (gk.isPlacedBeforeInsertInIbatis2())) {
/*  56 */       IntrospectedColumn introspectedColumn = this.introspectedTable
/*  57 */         .getColumn(gk.getColumn());
/*     */       
/*     */ 
/*  60 */       if (introspectedColumn != null)
/*     */       {
/*  62 */         answer.addElement(getSelectKey(introspectedColumn, gk));
/*     */       }
/*     */     }
/*     */     
/*  66 */     StringBuilder sb = new StringBuilder();
/*     */     
/*  68 */     sb.append("insert into ");
/*  69 */     sb.append(this.introspectedTable.getFullyQualifiedTableNameAtRuntime());
/*  70 */     answer.addElement(new TextElement(sb.toString()));
/*     */     
/*  72 */     XmlElement insertElement = new XmlElement("dynamic");
/*  73 */     insertElement.addAttribute(new Attribute("prepend", "("));
/*  74 */     answer.addElement(insertElement);
/*     */     
/*  76 */     answer.addElement(new TextElement("values"));
/*     */     
/*  78 */     XmlElement valuesElement = new XmlElement("dynamic");
/*  79 */     valuesElement.addAttribute(new Attribute("prepend", "("));
/*  80 */     answer.addElement(valuesElement);
/*     */     
/*     */ 
/*  83 */     Iterator localIterator = this.introspectedTable.getAllColumns().iterator();
/*  82 */     while (localIterator.hasNext()) {
/*  83 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator.next();
/*  84 */       if (!introspectedColumn.isIdentity())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*  89 */         XmlElement insertNotNullElement = new XmlElement("isNotNull");
/*  90 */         insertNotNullElement.addAttribute(new Attribute("prepend", ","));
/*  91 */         insertNotNullElement.addAttribute(new Attribute(
/*  92 */           "property", introspectedColumn.getJavaProperty()));
/*  93 */         insertNotNullElement.addElement(new TextElement(
/*     */         
/*  95 */           Ibatis2FormattingUtilities.getEscapedColumnName(introspectedColumn)));
/*  96 */         insertElement.addElement(insertNotNullElement);
/*     */         
/*  98 */         XmlElement valuesNotNullElement = new XmlElement("isNotNull");
/*  99 */         valuesNotNullElement.addAttribute(new Attribute("prepend", ","));
/* 100 */         valuesNotNullElement.addAttribute(new Attribute(
/* 101 */           "property", introspectedColumn.getJavaProperty()));
/* 102 */         valuesNotNullElement.addElement(new TextElement(
/*     */         
/* 104 */           Ibatis2FormattingUtilities.getParameterClause(introspectedColumn)));
/* 105 */         valuesElement.addElement(valuesNotNullElement);
/*     */       }
/*     */     }
/* 108 */     insertElement.addElement(new TextElement(")"));
/* 109 */     valuesElement.addElement(new TextElement(")"));
/*     */     
/* 111 */     if ((gk != null) && (!gk.isPlacedBeforeInsertInIbatis2())) {
/* 112 */       IntrospectedColumn introspectedColumn = this.introspectedTable
/* 113 */         .getColumn(gk.getColumn());
/*     */       
/*     */ 
/* 116 */       if (introspectedColumn != null)
/*     */       {
/* 118 */         answer.addElement(getSelectKey(introspectedColumn, gk));
/*     */       }
/*     */     }
/*     */     
/* 122 */     if (this.context.getPlugins().sqlMapInsertSelectiveElementGenerated(
/* 123 */       answer, this.introspectedTable)) {
/* 124 */       parentElement.addElement(answer);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\sqlmap\elements\InsertSelectiveElementGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */