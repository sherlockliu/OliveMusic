/*     */ package org.mybatis.generator.codegen.ibatis2.dao.elements;
/*     */ 
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.DAOMethodNameCalculator;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.Interface;
/*     */ import org.mybatis.generator.api.dom.java.JavaVisibility;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*     */ import org.mybatis.generator.codegen.ibatis2.dao.templates.AbstractDAOTemplate;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.rules.Rules;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UpdateByExampleWithoutBLOBsMethodGenerator
/*     */   extends AbstractDAOElementGenerator
/*     */ {
/*     */   public void addImplementationElements(TopLevelClass topLevelClass)
/*     */   {
/*  42 */     Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  43 */     Method method = getMethodShell(importedTypes);
/*     */     
/*  45 */     method
/*  46 */       .addBodyLine("UpdateByExampleParms parms = new UpdateByExampleParms(record, example);");
/*     */     
/*  48 */     StringBuilder sb = new StringBuilder();
/*  49 */     sb.append("int rows = ");
/*  50 */     sb.append(this.daoTemplate.getUpdateMethod(this.introspectedTable
/*  51 */       .getIbatis2SqlMapNamespace(), this.introspectedTable
/*  52 */       .getUpdateByExampleStatementId(), "parms"));
/*  53 */     method.addBodyLine(sb.toString());
/*     */     
/*  55 */     method.addBodyLine("return rows;");
/*     */     
/*     */ 
/*  58 */     if (this.context.getPlugins().clientUpdateByExampleWithoutBLOBsMethodGenerated(method, 
/*  59 */       topLevelClass, this.introspectedTable)) {
/*  60 */       topLevelClass.addImportedTypes(importedTypes);
/*  61 */       topLevelClass.addMethod(method);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addInterfaceElements(Interface interfaze)
/*     */   {
/*  67 */     if (getExampleMethodVisibility() == JavaVisibility.PUBLIC) {
/*  68 */       Set<FullyQualifiedJavaType> importedTypes = new TreeSet();
/*  69 */       Method method = getMethodShell(importedTypes);
/*     */       
/*     */ 
/*  72 */       if (this.context.getPlugins().clientUpdateByExampleWithoutBLOBsMethodGenerated(method, 
/*  73 */         interfaze, this.introspectedTable)) {
/*  74 */         interfaze.addImportedTypes(importedTypes);
/*  75 */         interfaze.addMethod(method);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Method getMethodShell(Set<FullyQualifiedJavaType> importedTypes) { FullyQualifiedJavaType parameterType;
/*     */     FullyQualifiedJavaType parameterType;
/*  82 */     if (this.introspectedTable.getRules().generateBaseRecordClass()) {
/*  83 */       parameterType = new FullyQualifiedJavaType(this.introspectedTable
/*  84 */         .getBaseRecordType());
/*     */     } else {
/*  86 */       parameterType = new FullyQualifiedJavaType(this.introspectedTable
/*  87 */         .getPrimaryKeyType());
/*     */     }
/*     */     
/*  90 */     importedTypes.add(parameterType);
/*     */     
/*  92 */     Method method = new Method();
/*  93 */     method.setVisibility(getExampleMethodVisibility());
/*  94 */     method.setReturnType(FullyQualifiedJavaType.getIntInstance());
/*  95 */     method.setName(getDAOMethodNameCalculator()
/*  96 */       .getUpdateByExampleWithoutBLOBsMethodName(this.introspectedTable));
/*  97 */     method.addParameter(new Parameter(parameterType, "record"));
/*  98 */     method.addParameter(new Parameter(new FullyQualifiedJavaType(
/*  99 */       this.introspectedTable.getExampleType()), "example"));
/*     */     
/* 101 */     for (FullyQualifiedJavaType fqjt : this.daoTemplate.getCheckedExceptions()) {
/* 102 */       method.addException(fqjt);
/* 103 */       importedTypes.add(fqjt);
/*     */     }
/*     */     
/* 106 */     this.context.getCommentGenerator().addGeneralMethodComment(method, 
/* 107 */       this.introspectedTable);
/*     */     
/* 109 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\ibatis2\dao\elements\UpdateByExampleWithoutBLOBsMethodGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */