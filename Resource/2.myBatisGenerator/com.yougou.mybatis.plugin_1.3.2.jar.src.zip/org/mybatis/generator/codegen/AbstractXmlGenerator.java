package org.mybatis.generator.codegen;

import org.mybatis.generator.api.dom.xml.Document;

public abstract class AbstractXmlGenerator
  extends AbstractGenerator
{
  public abstract Document getDocument();
}


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\codegen\AbstractXmlGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */