/*    */ package org.mybatis.generator.internal.rules;
/*    */ 
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HierarchicalModelRules
/*    */   extends BaseRules
/*    */ {
/*    */   public HierarchicalModelRules(IntrospectedTable introspectedTable)
/*    */   {
/* 34 */     super(introspectedTable);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean generatePrimaryKeyClass()
/*    */   {
/* 45 */     return this.introspectedTable.hasPrimaryKeyColumns();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean generateBaseRecordClass()
/*    */   {
/* 56 */     return this.introspectedTable.hasBaseColumns();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean generateRecordWithBLOBsClass()
/*    */   {
/* 66 */     return this.introspectedTable.hasBLOBColumns();
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\rules\HierarchicalModelRules.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */