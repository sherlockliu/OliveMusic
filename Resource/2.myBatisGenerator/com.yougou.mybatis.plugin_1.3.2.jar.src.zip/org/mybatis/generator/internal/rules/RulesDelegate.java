/*     */ package org.mybatis.generator.internal.rules;
/*     */ 
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RulesDelegate
/*     */   implements Rules
/*     */ {
/*     */   protected Rules rules;
/*     */   
/*     */   public RulesDelegate(Rules rules)
/*     */   {
/*  65 */     this.rules = rules;
/*     */   }
/*     */   
/*     */   public FullyQualifiedJavaType calculateAllFieldsClass() {
/*  69 */     return this.rules.calculateAllFieldsClass();
/*     */   }
/*     */   
/*     */   public boolean generateBaseRecordClass() {
/*  73 */     return this.rules.generateBaseRecordClass();
/*     */   }
/*     */   
/*     */   public boolean generateBaseResultMap() {
/*  77 */     return this.rules.generateBaseResultMap();
/*     */   }
/*     */   
/*     */   public boolean generateCountByExample() {
/*  81 */     return this.rules.generateCountByExample();
/*     */   }
/*     */   
/*     */   public boolean generateDeleteByExample() {
/*  85 */     return this.rules.generateDeleteByExample();
/*     */   }
/*     */   
/*     */   public boolean generateDeleteByPrimaryKey() {
/*  89 */     return this.rules.generateDeleteByPrimaryKey();
/*     */   }
/*     */   
/*     */   public boolean generateExampleClass() {
/*  93 */     return this.rules.generateExampleClass();
/*     */   }
/*     */   
/*     */   public boolean generateInsert() {
/*  97 */     return this.rules.generateInsert();
/*     */   }
/*     */   
/*     */   public boolean generateInsertSelective() {
/* 101 */     return this.rules.generateInsertSelective();
/*     */   }
/*     */   
/*     */   public boolean generatePrimaryKeyClass() {
/* 105 */     return this.rules.generatePrimaryKeyClass();
/*     */   }
/*     */   
/*     */   public boolean generateRecordWithBLOBsClass() {
/* 109 */     return this.rules.generateRecordWithBLOBsClass();
/*     */   }
/*     */   
/*     */   public boolean generateResultMapWithBLOBs() {
/* 113 */     return this.rules.generateResultMapWithBLOBs();
/*     */   }
/*     */   
/*     */   public boolean generateSelectByExampleWithBLOBs() {
/* 117 */     return this.rules.generateSelectByExampleWithBLOBs();
/*     */   }
/*     */   
/*     */   public boolean generateSelectByExampleWithoutBLOBs() {
/* 121 */     return this.rules.generateSelectByExampleWithoutBLOBs();
/*     */   }
/*     */   
/*     */   public boolean generateSelectByPrimaryKey() {
/* 125 */     return this.rules.generateSelectByPrimaryKey();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateSelectCount()
/*     */   {
/* 134 */     return this.rules.generateSelectCount();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateSelectByPage()
/*     */   {
/* 143 */     return this.rules.generateSelectByPage();
/*     */   }
/*     */   
/*     */   public boolean generateSQLExampleWhereClause() {
/* 147 */     return this.rules.generateSQLExampleWhereClause();
/*     */   }
/*     */   
/*     */   public boolean generateMyBatis3UpdateByExampleWhereClause() {
/* 151 */     return this.rules.generateMyBatis3UpdateByExampleWhereClause();
/*     */   }
/*     */   
/*     */   public boolean generateUpdateByExampleSelective() {
/* 155 */     return this.rules.generateUpdateByExampleSelective();
/*     */   }
/*     */   
/*     */   public boolean generateUpdateByExampleWithBLOBs() {
/* 159 */     return this.rules.generateUpdateByExampleWithBLOBs();
/*     */   }
/*     */   
/*     */   public boolean generateUpdateByExampleWithoutBLOBs() {
/* 163 */     return this.rules.generateUpdateByExampleWithoutBLOBs();
/*     */   }
/*     */   
/*     */   public boolean generateUpdateByPrimaryKeySelective() {
/* 167 */     return this.rules.generateUpdateByPrimaryKeySelective();
/*     */   }
/*     */   
/*     */   public boolean generateUpdateByPrimaryKeyWithBLOBs() {
/* 171 */     return this.rules.generateUpdateByPrimaryKeyWithBLOBs();
/*     */   }
/*     */   
/*     */   public boolean generateUpdateByPrimaryKeyWithoutBLOBs() {
/* 175 */     return this.rules.generateUpdateByPrimaryKeyWithoutBLOBs();
/*     */   }
/*     */   
/*     */   public IntrospectedTable getIntrospectedTable() {
/* 179 */     return this.rules.getIntrospectedTable();
/*     */   }
/*     */   
/*     */   public boolean generateBaseColumnList() {
/* 183 */     return this.rules.generateBaseColumnList();
/*     */   }
/*     */   
/*     */   public boolean generateBlobColumnList() {
/* 187 */     return this.rules.generateBlobColumnList();
/*     */   }
/*     */   
/*     */   public boolean generateJavaClient() {
/* 191 */     return this.rules.generateJavaClient();
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\rules\RulesDelegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */