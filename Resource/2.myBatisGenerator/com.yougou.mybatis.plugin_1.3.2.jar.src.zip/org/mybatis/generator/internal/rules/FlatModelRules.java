/*    */ package org.mybatis.generator.internal.rules;
/*    */ 
/*    */ import org.mybatis.generator.api.IntrospectedTable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatModelRules
/*    */   extends BaseRules
/*    */ {
/*    */   public FlatModelRules(IntrospectedTable introspectedTable)
/*    */   {
/* 34 */     super(introspectedTable);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean generatePrimaryKeyClass()
/*    */   {
/* 43 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean generateBaseRecordClass()
/*    */   {
/* 52 */     return true;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean generateRecordWithBLOBsClass()
/*    */   {
/* 61 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\rules\FlatModelRules.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */