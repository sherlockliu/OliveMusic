/*     */ package org.mybatis.generator.internal.rules;
/*     */ 
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.IntrospectedTable.TargetRuntime;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.TableConfiguration;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseRules
/*     */   implements Rules
/*     */ {
/*     */   protected TableConfiguration tableConfiguration;
/*     */   protected IntrospectedTable introspectedTable;
/*     */   protected final boolean isModelOnly;
/*     */   
/*     */   public BaseRules(IntrospectedTable introspectedTable)
/*     */   {
/*  43 */     this.introspectedTable = introspectedTable;
/*  44 */     this.tableConfiguration = introspectedTable.getTableConfiguration();
/*  45 */     String modelOnly = this.tableConfiguration.getProperty("modelOnly");
/*  46 */     this.isModelOnly = StringUtility.isTrue(modelOnly);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateInsert()
/*     */   {
/*  57 */     if (this.isModelOnly) {
/*  58 */       return false;
/*     */     }
/*     */     
/*  61 */     return this.tableConfiguration.isInsertStatementEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateInsertSelective()
/*     */   {
/*  72 */     if (this.isModelOnly) {
/*  73 */       return false;
/*     */     }
/*     */     
/*  76 */     return this.tableConfiguration.isInsertStatementEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FullyQualifiedJavaType calculateAllFieldsClass()
/*     */   {
/*     */     String answer;
/*     */     
/*     */ 
/*     */ 
/*     */     String answer;
/*     */     
/*     */ 
/*  91 */     if (generateRecordWithBLOBsClass()) {
/*  92 */       answer = this.introspectedTable.getRecordWithBLOBsType(); } else { String answer;
/*  93 */       if (generateBaseRecordClass()) {
/*  94 */         answer = this.introspectedTable.getBaseRecordType();
/*     */       } else {
/*  96 */         answer = this.introspectedTable.getPrimaryKeyType();
/*     */       }
/*     */     }
/*  99 */     return new FullyQualifiedJavaType(answer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateUpdateByPrimaryKeyWithoutBLOBs()
/*     */   {
/* 111 */     if (this.isModelOnly) {
/* 112 */       return false;
/*     */     }
/*     */     
/* 115 */     boolean rc = (this.tableConfiguration.isUpdateByPrimaryKeyStatementEnabled()) && 
/* 116 */       (this.introspectedTable.hasPrimaryKeyColumns()) && 
/* 117 */       (this.introspectedTable.hasBaseColumns());
/*     */     
/* 119 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateUpdateByPrimaryKeyWithBLOBs()
/*     */   {
/* 131 */     if (this.isModelOnly) {
/* 132 */       return false;
/*     */     }
/*     */     
/* 135 */     boolean rc = (this.tableConfiguration.isUpdateByPrimaryKeyStatementEnabled()) && 
/* 136 */       (this.introspectedTable.hasPrimaryKeyColumns()) && 
/* 137 */       (this.introspectedTable.hasBLOBColumns());
/*     */     
/* 139 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateUpdateByPrimaryKeySelective()
/*     */   {
/* 151 */     if (this.isModelOnly) {
/* 152 */       return false;
/*     */     }
/*     */     
/* 155 */     boolean rc = (this.tableConfiguration.isUpdateByPrimaryKeyStatementEnabled()) && 
/* 156 */       (this.introspectedTable.hasPrimaryKeyColumns()) && (
/* 157 */       (this.introspectedTable.hasBLOBColumns()) || 
/* 158 */       (this.introspectedTable.hasBaseColumns()));
/*     */     
/* 160 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateDeleteByPrimaryKey()
/*     */   {
/* 172 */     if (this.isModelOnly) {
/* 173 */       return false;
/*     */     }
/*     */     
/* 176 */     boolean rc = (this.tableConfiguration.isDeleteByPrimaryKeyStatementEnabled()) && 
/* 177 */       (this.introspectedTable.hasPrimaryKeyColumns());
/*     */     
/* 179 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateDeleteByExample()
/*     */   {
/* 190 */     if (this.isModelOnly) {
/* 191 */       return false;
/*     */     }
/*     */     
/* 194 */     boolean rc = this.tableConfiguration.isDeleteByExampleStatementEnabled();
/*     */     
/* 196 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateBaseResultMap()
/*     */   {
/* 206 */     if (this.isModelOnly) {
/* 207 */       return true;
/*     */     }
/*     */     
/* 210 */     boolean rc = (this.tableConfiguration.isSelectByExampleStatementEnabled()) || 
/* 211 */       (this.tableConfiguration.isSelectByPrimaryKeyStatementEnabled());
/*     */     
/* 213 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean generateResultMapWithBLOBs()
/*     */   {
/*     */     boolean rc;
/*     */     
/*     */ 
/*     */     boolean rc;
/*     */     
/*     */ 
/* 226 */     if (this.introspectedTable.hasBLOBColumns()) { boolean rc;
/* 227 */       if (this.isModelOnly) {
/* 228 */         rc = true;
/*     */       } else {
/* 230 */         rc = (this.tableConfiguration.isSelectByExampleStatementEnabled()) || 
/* 231 */           (this.tableConfiguration.isSelectByPrimaryKeyStatementEnabled());
/*     */       }
/*     */     } else {
/* 234 */       rc = false;
/*     */     }
/*     */     
/* 237 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateSQLExampleWhereClause()
/*     */   {
/* 252 */     if (this.isModelOnly) {
/* 253 */       return false;
/*     */     }
/*     */     
/* 256 */     boolean rc = (this.tableConfiguration.isSelectByExampleStatementEnabled()) || 
/* 257 */       (this.tableConfiguration.isDeleteByExampleStatementEnabled()) || 
/* 258 */       (this.tableConfiguration.isCountByExampleStatementEnabled());
/*     */     
/* 260 */     if (this.introspectedTable.getTargetRuntime() == IntrospectedTable.TargetRuntime.IBATIS2) {
/* 261 */       rc |= this.tableConfiguration.isUpdateByExampleStatementEnabled();
/*     */     }
/*     */     
/* 264 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateMyBatis3UpdateByExampleWhereClause()
/*     */   {
/* 279 */     if (this.isModelOnly) {
/* 280 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 284 */     return (this.introspectedTable.getTargetRuntime() == IntrospectedTable.TargetRuntime.MYBATIS3) && (this.tableConfiguration.isUpdateByExampleStatementEnabled());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateSelectByPrimaryKey()
/*     */   {
/* 296 */     if (this.isModelOnly) {
/* 297 */       return false;
/*     */     }
/*     */     
/* 300 */     boolean rc = (this.tableConfiguration.isSelectByPrimaryKeyStatementEnabled()) && 
/* 301 */       (this.introspectedTable.hasPrimaryKeyColumns()) && (
/* 302 */       (this.introspectedTable.hasBaseColumns()) || 
/* 303 */       (this.introspectedTable.hasBLOBColumns()));
/*     */     
/* 305 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateSelectCount()
/*     */   {
/* 315 */     boolean rc = this.tableConfiguration.isSelectByPrimaryKeyStatementEnabled();
/* 316 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateSelectByPage()
/*     */   {
/* 325 */     boolean rc = this.tableConfiguration.isSelectByPrimaryKeyStatementEnabled();
/* 326 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateSelectByExampleWithoutBLOBs()
/*     */   {
/* 337 */     if (this.isModelOnly) {
/* 338 */       return false;
/*     */     }
/*     */     
/* 341 */     return this.tableConfiguration.isSelectByExampleStatementEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateSelectByExampleWithBLOBs()
/*     */   {
/* 353 */     if (this.isModelOnly) {
/* 354 */       return false;
/*     */     }
/*     */     
/* 357 */     boolean rc = (this.tableConfiguration.isSelectByExampleStatementEnabled()) && 
/* 358 */       (this.introspectedTable.hasBLOBColumns());
/*     */     
/* 360 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean generateExampleClass()
/*     */   {
/* 371 */     if ((this.introspectedTable.getContext().getSqlMapGeneratorConfiguration() == null) && 
/* 372 */       (this.introspectedTable.getContext().getJavaClientGeneratorConfiguration() == null))
/*     */     {
/* 374 */       return false;
/*     */     }
/*     */     
/* 377 */     if (this.isModelOnly) {
/* 378 */       return false;
/*     */     }
/*     */     
/* 381 */     boolean rc = (this.tableConfiguration.isSelectByExampleStatementEnabled()) || 
/* 382 */       (this.tableConfiguration.isDeleteByExampleStatementEnabled()) || 
/* 383 */       (this.tableConfiguration.isCountByExampleStatementEnabled()) || 
/* 384 */       (this.tableConfiguration.isUpdateByExampleStatementEnabled());
/*     */     
/* 386 */     return rc;
/*     */   }
/*     */   
/*     */   public boolean generateCountByExample() {
/* 390 */     if (this.isModelOnly) {
/* 391 */       return false;
/*     */     }
/*     */     
/* 394 */     boolean rc = this.tableConfiguration.isCountByExampleStatementEnabled();
/*     */     
/* 396 */     return rc;
/*     */   }
/*     */   
/*     */   public boolean generateUpdateByExampleSelective() {
/* 400 */     if (this.isModelOnly) {
/* 401 */       return false;
/*     */     }
/*     */     
/* 404 */     boolean rc = this.tableConfiguration.isUpdateByExampleStatementEnabled();
/*     */     
/* 406 */     return rc;
/*     */   }
/*     */   
/*     */   public boolean generateUpdateByExampleWithoutBLOBs() {
/* 410 */     if (this.isModelOnly) {
/* 411 */       return false;
/*     */     }
/*     */     
/* 414 */     boolean rc = (this.tableConfiguration.isUpdateByExampleStatementEnabled()) && (
/* 415 */       (this.introspectedTable.hasPrimaryKeyColumns()) || 
/* 416 */       (this.introspectedTable.hasBaseColumns()));
/*     */     
/* 418 */     return rc;
/*     */   }
/*     */   
/*     */   public boolean generateUpdateByExampleWithBLOBs() {
/* 422 */     if (this.isModelOnly) {
/* 423 */       return false;
/*     */     }
/*     */     
/* 426 */     boolean rc = (this.tableConfiguration.isUpdateByExampleStatementEnabled()) && 
/* 427 */       (this.introspectedTable.hasBLOBColumns());
/*     */     
/* 429 */     return rc;
/*     */   }
/*     */   
/*     */   public IntrospectedTable getIntrospectedTable() {
/* 433 */     return this.introspectedTable;
/*     */   }
/*     */   
/*     */   public boolean generateBaseColumnList() {
/* 437 */     if (this.isModelOnly) {
/* 438 */       return false;
/*     */     }
/*     */     
/*     */ 
/* 442 */     return (generateSelectByPrimaryKey()) || (generateSelectByExampleWithoutBLOBs());
/*     */   }
/*     */   
/*     */   public boolean generateBlobColumnList() {
/* 446 */     if (this.isModelOnly) {
/* 447 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 452 */     return (this.introspectedTable.hasBLOBColumns()) && ((this.tableConfiguration.isSelectByExampleStatementEnabled()) || (this.tableConfiguration.isSelectByPrimaryKeyStatementEnabled()));
/*     */   }
/*     */   
/*     */   public boolean generateJavaClient() {
/* 456 */     return !this.isModelOnly;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\rules\BaseRules.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */