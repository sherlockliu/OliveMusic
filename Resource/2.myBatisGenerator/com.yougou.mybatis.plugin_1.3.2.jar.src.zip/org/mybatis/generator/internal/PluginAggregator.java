/*      */ package org.mybatis.generator.internal;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import org.mybatis.generator.api.GeneratedJavaFile;
/*      */ import org.mybatis.generator.api.GeneratedXmlFile;
/*      */ import org.mybatis.generator.api.IntrospectedColumn;
/*      */ import org.mybatis.generator.api.IntrospectedTable;
/*      */ import org.mybatis.generator.api.Plugin;
/*      */ import org.mybatis.generator.api.Plugin.ModelClassType;
/*      */ import org.mybatis.generator.api.dom.java.Field;
/*      */ import org.mybatis.generator.api.dom.java.Interface;
/*      */ import org.mybatis.generator.api.dom.java.Method;
/*      */ import org.mybatis.generator.api.dom.java.TopLevelClass;
/*      */ import org.mybatis.generator.api.dom.xml.Document;
/*      */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*      */ import org.mybatis.generator.config.Context;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class PluginAggregator
/*      */   implements Plugin
/*      */ {
/*      */   private List<Plugin> plugins;
/*      */   
/*      */   public PluginAggregator()
/*      */   {
/*   51 */     this.plugins = new ArrayList();
/*      */   }
/*      */   
/*      */   public void addPlugin(Plugin plugin) {
/*   55 */     this.plugins.add(plugin);
/*      */   }
/*      */   
/*      */   public void setContext(Context context) {
/*   59 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public void setProperties(Properties properties) {
/*   63 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public boolean validate(List<String> warnings) {
/*   67 */     throw new UnsupportedOperationException();
/*      */   }
/*      */   
/*      */   public boolean modelBaseRecordClassGenerated(TopLevelClass tlc, IntrospectedTable introspectedTable)
/*      */   {
/*   72 */     boolean rc = true;
/*      */     
/*   74 */     for (Plugin plugin : this.plugins) {
/*   75 */       if (!plugin.modelBaseRecordClassGenerated(tlc, introspectedTable)) {
/*   76 */         rc = false;
/*   77 */         break;
/*      */       }
/*      */     }
/*      */     
/*   81 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean modelRecordWithBLOBsClassGenerated(TopLevelClass tlc, IntrospectedTable introspectedTable)
/*      */   {
/*   86 */     boolean rc = true;
/*      */     
/*   88 */     for (Plugin plugin : this.plugins) {
/*   89 */       if (!plugin.modelRecordWithBLOBsClassGenerated(tlc, 
/*   90 */         introspectedTable)) {
/*   91 */         rc = false;
/*   92 */         break;
/*      */       }
/*      */     }
/*      */     
/*   96 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapCountByExampleElementGenerated(XmlElement element, IntrospectedTable table)
/*      */   {
/*  101 */     boolean rc = true;
/*      */     
/*  103 */     for (Plugin plugin : this.plugins) {
/*  104 */       if (!plugin.sqlMapCountByExampleElementGenerated(element, table)) {
/*  105 */         rc = false;
/*  106 */         break;
/*      */       }
/*      */     }
/*      */     
/*  110 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapDeleteByExampleElementGenerated(XmlElement element, IntrospectedTable table)
/*      */   {
/*  115 */     boolean rc = true;
/*      */     
/*  117 */     for (Plugin plugin : this.plugins) {
/*  118 */       if (!plugin.sqlMapDeleteByExampleElementGenerated(element, table)) {
/*  119 */         rc = false;
/*  120 */         break;
/*      */       }
/*      */     }
/*      */     
/*  124 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapDeleteByPrimaryKeyElementGenerated(XmlElement element, IntrospectedTable table)
/*      */   {
/*  129 */     boolean rc = true;
/*      */     
/*  131 */     for (Plugin plugin : this.plugins)
/*      */     {
/*  133 */       if (!plugin.sqlMapDeleteByPrimaryKeyElementGenerated(element, table)) {
/*  134 */         rc = false;
/*  135 */         break;
/*      */       }
/*      */     }
/*      */     
/*  139 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean modelExampleClassGenerated(TopLevelClass tlc, IntrospectedTable introspectedTable)
/*      */   {
/*  144 */     boolean rc = true;
/*      */     
/*  146 */     for (Plugin plugin : this.plugins) {
/*  147 */       if (!plugin.modelExampleClassGenerated(tlc, introspectedTable)) {
/*  148 */         rc = false;
/*  149 */         break;
/*      */       }
/*      */     }
/*      */     
/*  153 */     return rc;
/*      */   }
/*      */   
/*      */   public List<GeneratedJavaFile> contextGenerateAdditionalJavaFiles(IntrospectedTable introspectedTable)
/*      */   {
/*  158 */     List<GeneratedJavaFile> answer = new ArrayList();
/*  159 */     for (Plugin plugin : this.plugins) {
/*  160 */       List<GeneratedJavaFile> temp = plugin
/*  161 */         .contextGenerateAdditionalJavaFiles(introspectedTable);
/*  162 */       if (temp != null) {
/*  163 */         answer.addAll(temp);
/*      */       }
/*      */     }
/*  166 */     return answer;
/*      */   }
/*      */   
/*      */   public List<GeneratedXmlFile> contextGenerateAdditionalXmlFiles(IntrospectedTable introspectedTable)
/*      */   {
/*  171 */     List<GeneratedXmlFile> answer = new ArrayList();
/*  172 */     for (Plugin plugin : this.plugins) {
/*  173 */       List<GeneratedXmlFile> temp = plugin
/*  174 */         .contextGenerateAdditionalXmlFiles(introspectedTable);
/*  175 */       if (temp != null) {
/*  176 */         answer.addAll(temp);
/*      */       }
/*      */     }
/*  179 */     return answer;
/*      */   }
/*      */   
/*      */   public boolean modelPrimaryKeyClassGenerated(TopLevelClass tlc, IntrospectedTable introspectedTable)
/*      */   {
/*  184 */     boolean rc = true;
/*      */     
/*  186 */     for (Plugin plugin : this.plugins) {
/*  187 */       if (!plugin.modelPrimaryKeyClassGenerated(tlc, introspectedTable)) {
/*  188 */         rc = false;
/*  189 */         break;
/*      */       }
/*      */     }
/*      */     
/*  193 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapResultMapWithoutBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  198 */     boolean rc = true;
/*      */     
/*  200 */     for (Plugin plugin : this.plugins) {
/*  201 */       if (!plugin.sqlMapResultMapWithoutBLOBsElementGenerated(element, 
/*  202 */         introspectedTable)) {
/*  203 */         rc = false;
/*  204 */         break;
/*      */       }
/*      */     }
/*      */     
/*  208 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapExampleWhereClauseElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  213 */     boolean rc = true;
/*      */     
/*  215 */     for (Plugin plugin : this.plugins) {
/*  216 */       if (!plugin.sqlMapExampleWhereClauseElementGenerated(element, 
/*  217 */         introspectedTable)) {
/*  218 */         rc = false;
/*  219 */         break;
/*      */       }
/*      */     }
/*      */     
/*  223 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapInsertElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  228 */     boolean rc = true;
/*      */     
/*  230 */     for (Plugin plugin : this.plugins)
/*      */     {
/*  232 */       if (!plugin.sqlMapInsertElementGenerated(element, introspectedTable)) {
/*  233 */         rc = false;
/*  234 */         break;
/*      */       }
/*      */     }
/*      */     
/*  238 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapResultMapWithBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  243 */     boolean rc = true;
/*      */     
/*  245 */     for (Plugin plugin : this.plugins) {
/*  246 */       if (!plugin.sqlMapResultMapWithBLOBsElementGenerated(element, 
/*  247 */         introspectedTable)) {
/*  248 */         rc = false;
/*  249 */         break;
/*      */       }
/*      */     }
/*      */     
/*  253 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapSelectByExampleWithoutBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  258 */     boolean rc = true;
/*      */     
/*  260 */     for (Plugin plugin : this.plugins) {
/*  261 */       if (!plugin.sqlMapSelectByExampleWithoutBLOBsElementGenerated(
/*  262 */         element, introspectedTable)) {
/*  263 */         rc = false;
/*  264 */         break;
/*      */       }
/*      */     }
/*      */     
/*  268 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapSelectByExampleWithBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  273 */     boolean rc = true;
/*      */     
/*  275 */     for (Plugin plugin : this.plugins) {
/*  276 */       if (!plugin.sqlMapSelectByExampleWithBLOBsElementGenerated(element, 
/*  277 */         introspectedTable)) {
/*  278 */         rc = false;
/*  279 */         break;
/*      */       }
/*      */     }
/*      */     
/*  283 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapSelectByPrimaryKeyElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  288 */     boolean rc = true;
/*      */     
/*  290 */     for (Plugin plugin : this.plugins) {
/*  291 */       if (!plugin.sqlMapSelectByPrimaryKeyElementGenerated(element, 
/*  292 */         introspectedTable)) {
/*  293 */         rc = false;
/*  294 */         break;
/*      */       }
/*      */     }
/*      */     
/*  298 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapGenerated(GeneratedXmlFile sqlMap, IntrospectedTable introspectedTable)
/*      */   {
/*  303 */     boolean rc = true;
/*      */     
/*  305 */     for (Plugin plugin : this.plugins) {
/*  306 */       if (!plugin.sqlMapGenerated(sqlMap, introspectedTable)) {
/*  307 */         rc = false;
/*  308 */         break;
/*      */       }
/*      */     }
/*      */     
/*  312 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapUpdateByExampleSelectiveElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  317 */     boolean rc = true;
/*      */     
/*  319 */     for (Plugin plugin : this.plugins) {
/*  320 */       if (!plugin.sqlMapUpdateByExampleSelectiveElementGenerated(element, 
/*  321 */         introspectedTable)) {
/*  322 */         rc = false;
/*  323 */         break;
/*      */       }
/*      */     }
/*      */     
/*  327 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapUpdateByExampleWithBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  332 */     boolean rc = true;
/*      */     
/*  334 */     for (Plugin plugin : this.plugins) {
/*  335 */       if (!plugin.sqlMapUpdateByExampleWithBLOBsElementGenerated(element, 
/*  336 */         introspectedTable)) {
/*  337 */         rc = false;
/*  338 */         break;
/*      */       }
/*      */     }
/*      */     
/*  342 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapUpdateByExampleWithoutBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  347 */     boolean rc = true;
/*      */     
/*  349 */     for (Plugin plugin : this.plugins) {
/*  350 */       if (!plugin.sqlMapUpdateByExampleWithoutBLOBsElementGenerated(
/*  351 */         element, introspectedTable)) {
/*  352 */         rc = false;
/*  353 */         break;
/*      */       }
/*      */     }
/*      */     
/*  357 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapUpdateByPrimaryKeySelectiveElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  362 */     boolean rc = true;
/*      */     
/*  364 */     for (Plugin plugin : this.plugins) {
/*  365 */       if (!plugin.sqlMapUpdateByPrimaryKeySelectiveElementGenerated(
/*  366 */         element, introspectedTable)) {
/*  367 */         rc = false;
/*  368 */         break;
/*      */       }
/*      */     }
/*      */     
/*  372 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapUpdateByPrimaryKeyWithBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  377 */     boolean rc = true;
/*      */     
/*  379 */     for (Plugin plugin : this.plugins) {
/*  380 */       if (!plugin.sqlMapUpdateByPrimaryKeyWithBLOBsElementGenerated(
/*  381 */         element, introspectedTable)) {
/*  382 */         rc = false;
/*  383 */         break;
/*      */       }
/*      */     }
/*      */     
/*  387 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapUpdateByPrimaryKeyWithoutBLOBsElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  392 */     boolean rc = true;
/*      */     
/*  394 */     for (Plugin plugin : this.plugins) {
/*  395 */       if (!plugin.sqlMapUpdateByPrimaryKeyWithoutBLOBsElementGenerated(
/*  396 */         element, introspectedTable)) {
/*  397 */         rc = false;
/*  398 */         break;
/*      */       }
/*      */     }
/*      */     
/*  402 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientCountByExampleMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  407 */     boolean rc = true;
/*      */     
/*  409 */     for (Plugin plugin : this.plugins) {
/*  410 */       if (!plugin.clientCountByExampleMethodGenerated(method, interfaze, 
/*  411 */         introspectedTable)) {
/*  412 */         rc = false;
/*  413 */         break;
/*      */       }
/*      */     }
/*      */     
/*  417 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientCountByExampleMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  422 */     boolean rc = true;
/*      */     
/*  424 */     for (Plugin plugin : this.plugins) {
/*  425 */       if (!plugin.clientCountByExampleMethodGenerated(method, topLevelClass, 
/*  426 */         introspectedTable)) {
/*  427 */         rc = false;
/*  428 */         break;
/*      */       }
/*      */     }
/*      */     
/*  432 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientDeleteByExampleMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  437 */     boolean rc = true;
/*      */     
/*  439 */     for (Plugin plugin : this.plugins) {
/*  440 */       if (!plugin.clientDeleteByExampleMethodGenerated(method, interfaze, 
/*  441 */         introspectedTable)) {
/*  442 */         rc = false;
/*  443 */         break;
/*      */       }
/*      */     }
/*      */     
/*  447 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientDeleteByExampleMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  452 */     boolean rc = true;
/*      */     
/*  454 */     for (Plugin plugin : this.plugins) {
/*  455 */       if (!plugin.clientDeleteByExampleMethodGenerated(method, 
/*  456 */         topLevelClass, introspectedTable)) {
/*  457 */         rc = false;
/*  458 */         break;
/*      */       }
/*      */     }
/*      */     
/*  462 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientDeleteByPrimaryKeyMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  467 */     boolean rc = true;
/*      */     
/*  469 */     for (Plugin plugin : this.plugins) {
/*  470 */       if (!plugin.clientDeleteByPrimaryKeyMethodGenerated(method, interfaze, 
/*  471 */         introspectedTable)) {
/*  472 */         rc = false;
/*  473 */         break;
/*      */       }
/*      */     }
/*      */     
/*  477 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientDeleteByPrimaryKeyMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  482 */     boolean rc = true;
/*      */     
/*  484 */     for (Plugin plugin : this.plugins) {
/*  485 */       if (!plugin.clientDeleteByPrimaryKeyMethodGenerated(method, 
/*  486 */         topLevelClass, introspectedTable)) {
/*  487 */         rc = false;
/*  488 */         break;
/*      */       }
/*      */     }
/*      */     
/*  492 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientInsertMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  497 */     boolean rc = true;
/*      */     
/*  499 */     for (Plugin plugin : this.plugins) {
/*  500 */       if (!plugin.clientInsertMethodGenerated(method, interfaze, 
/*  501 */         introspectedTable)) {
/*  502 */         rc = false;
/*  503 */         break;
/*      */       }
/*      */     }
/*      */     
/*  507 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientInsertMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  512 */     boolean rc = true;
/*      */     
/*  514 */     for (Plugin plugin : this.plugins) {
/*  515 */       if (!plugin.clientInsertMethodGenerated(method, topLevelClass, 
/*  516 */         introspectedTable)) {
/*  517 */         rc = false;
/*  518 */         break;
/*      */       }
/*      */     }
/*      */     
/*  522 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean clientGenerated(Interface interfaze, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  528 */     boolean rc = true;
/*      */     
/*  530 */     for (Plugin plugin : this.plugins) {
/*  531 */       if (!plugin.clientGenerated(interfaze, topLevelClass, introspectedTable)) {
/*  532 */         rc = false;
/*  533 */         break;
/*      */       }
/*      */     }
/*      */     
/*  537 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientSelectAllMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  542 */     boolean rc = true;
/*      */     
/*  544 */     for (Plugin plugin : this.plugins) {
/*  545 */       if (!plugin.clientSelectAllMethodGenerated(method, 
/*  546 */         topLevelClass, introspectedTable)) {
/*  547 */         rc = false;
/*  548 */         break;
/*      */       }
/*      */     }
/*      */     
/*  552 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientSelectAllMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  557 */     boolean rc = true;
/*      */     
/*  559 */     for (Plugin plugin : this.plugins) {
/*  560 */       if (!plugin.clientSelectAllMethodGenerated(method, 
/*  561 */         interfaze, introspectedTable)) {
/*  562 */         rc = false;
/*  563 */         break;
/*      */       }
/*      */     }
/*      */     
/*  567 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientSelectByExampleWithBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  572 */     boolean rc = true;
/*      */     
/*  574 */     for (Plugin plugin : this.plugins) {
/*  575 */       if (!plugin.clientSelectByExampleWithBLOBsMethodGenerated(method, 
/*  576 */         interfaze, introspectedTable)) {
/*  577 */         rc = false;
/*  578 */         break;
/*      */       }
/*      */     }
/*      */     
/*  582 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientSelectByExampleWithBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  587 */     boolean rc = true;
/*      */     
/*  589 */     for (Plugin plugin : this.plugins) {
/*  590 */       if (!plugin.clientSelectByExampleWithBLOBsMethodGenerated(method, 
/*  591 */         topLevelClass, introspectedTable)) {
/*  592 */         rc = false;
/*  593 */         break;
/*      */       }
/*      */     }
/*      */     
/*  597 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientSelectByExampleWithoutBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  602 */     boolean rc = true;
/*      */     
/*  604 */     for (Plugin plugin : this.plugins) {
/*  605 */       if (!plugin.clientSelectByExampleWithoutBLOBsMethodGenerated(method, 
/*  606 */         interfaze, introspectedTable)) {
/*  607 */         rc = false;
/*  608 */         break;
/*      */       }
/*      */     }
/*      */     
/*  612 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientSelectByExampleWithoutBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  617 */     boolean rc = true;
/*      */     
/*  619 */     for (Plugin plugin : this.plugins) {
/*  620 */       if (!plugin.clientSelectByExampleWithoutBLOBsMethodGenerated(method, 
/*  621 */         topLevelClass, introspectedTable)) {
/*  622 */         rc = false;
/*  623 */         break;
/*      */       }
/*      */     }
/*      */     
/*  627 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientSelectByPrimaryKeyMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  632 */     boolean rc = true;
/*      */     
/*  634 */     for (Plugin plugin : this.plugins) {
/*  635 */       if (!plugin.clientSelectByPrimaryKeyMethodGenerated(method, interfaze, 
/*  636 */         introspectedTable)) {
/*  637 */         rc = false;
/*  638 */         break;
/*      */       }
/*      */     }
/*      */     
/*  642 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean clientSelectCountMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  653 */     boolean rc = true;
/*      */     
/*  655 */     for (Plugin plugin : this.plugins) {
/*  656 */       if (!plugin.clientSelectCountMethodGenerated(method, interfaze, introspectedTable)) {
/*  657 */         rc = false;
/*  658 */         break;
/*      */       }
/*      */     }
/*      */     
/*  662 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientSelectByPrimaryKeyMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  667 */     boolean rc = true;
/*      */     
/*  669 */     for (Plugin plugin : this.plugins) {
/*  670 */       if (!plugin.clientSelectByPrimaryKeyMethodGenerated(method, 
/*  671 */         topLevelClass, introspectedTable)) {
/*  672 */         rc = false;
/*  673 */         break;
/*      */       }
/*      */     }
/*      */     
/*  677 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientUpdateByExampleSelectiveMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  682 */     boolean rc = true;
/*      */     
/*  684 */     for (Plugin plugin : this.plugins) {
/*  685 */       if (!plugin.clientUpdateByExampleSelectiveMethodGenerated(method, 
/*  686 */         interfaze, introspectedTable)) {
/*  687 */         rc = false;
/*  688 */         break;
/*      */       }
/*      */     }
/*      */     
/*  692 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientUpdateByExampleSelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  697 */     boolean rc = true;
/*      */     
/*  699 */     for (Plugin plugin : this.plugins) {
/*  700 */       if (!plugin.clientUpdateByExampleSelectiveMethodGenerated(method, 
/*  701 */         topLevelClass, introspectedTable)) {
/*  702 */         rc = false;
/*  703 */         break;
/*      */       }
/*      */     }
/*      */     
/*  707 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientUpdateByExampleWithBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  712 */     boolean rc = true;
/*      */     
/*  714 */     for (Plugin plugin : this.plugins) {
/*  715 */       if (!plugin.clientUpdateByExampleWithBLOBsMethodGenerated(method, 
/*  716 */         interfaze, introspectedTable)) {
/*  717 */         rc = false;
/*  718 */         break;
/*      */       }
/*      */     }
/*      */     
/*  722 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientUpdateByExampleWithBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  727 */     boolean rc = true;
/*      */     
/*  729 */     for (Plugin plugin : this.plugins) {
/*  730 */       if (!plugin.clientUpdateByExampleWithBLOBsMethodGenerated(method, 
/*  731 */         topLevelClass, introspectedTable)) {
/*  732 */         rc = false;
/*  733 */         break;
/*      */       }
/*      */     }
/*      */     
/*  737 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientUpdateByExampleWithoutBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  742 */     boolean rc = true;
/*      */     
/*  744 */     for (Plugin plugin : this.plugins) {
/*  745 */       if (!plugin.clientUpdateByExampleWithoutBLOBsMethodGenerated(method, 
/*  746 */         interfaze, introspectedTable)) {
/*  747 */         rc = false;
/*  748 */         break;
/*      */       }
/*      */     }
/*      */     
/*  752 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientUpdateByExampleWithoutBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  757 */     boolean rc = true;
/*      */     
/*  759 */     for (Plugin plugin : this.plugins) {
/*  760 */       if (!plugin.clientUpdateByExampleWithoutBLOBsMethodGenerated(method, 
/*  761 */         topLevelClass, introspectedTable)) {
/*  762 */         rc = false;
/*  763 */         break;
/*      */       }
/*      */     }
/*      */     
/*  767 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientUpdateByPrimaryKeySelectiveMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  772 */     boolean rc = true;
/*      */     
/*  774 */     for (Plugin plugin : this.plugins) {
/*  775 */       if (!plugin.clientUpdateByPrimaryKeySelectiveMethodGenerated(method, 
/*  776 */         interfaze, introspectedTable)) {
/*  777 */         rc = false;
/*  778 */         break;
/*      */       }
/*      */     }
/*      */     
/*  782 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientUpdateByPrimaryKeySelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  787 */     boolean rc = true;
/*      */     
/*  789 */     for (Plugin plugin : this.plugins) {
/*  790 */       if (!plugin.clientUpdateByPrimaryKeySelectiveMethodGenerated(method, 
/*  791 */         topLevelClass, introspectedTable)) {
/*  792 */         rc = false;
/*  793 */         break;
/*      */       }
/*      */     }
/*      */     
/*  797 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientUpdateByPrimaryKeyWithBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  802 */     boolean rc = true;
/*      */     
/*  804 */     for (Plugin plugin : this.plugins) {
/*  805 */       if (!plugin.clientUpdateByPrimaryKeyWithBLOBsMethodGenerated(method, 
/*  806 */         interfaze, introspectedTable)) {
/*  807 */         rc = false;
/*  808 */         break;
/*      */       }
/*      */     }
/*      */     
/*  812 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientUpdateByPrimaryKeyWithBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  817 */     boolean rc = true;
/*      */     
/*  819 */     for (Plugin plugin : this.plugins) {
/*  820 */       if (!plugin.clientUpdateByPrimaryKeyWithBLOBsMethodGenerated(method, 
/*  821 */         topLevelClass, introspectedTable)) {
/*  822 */         rc = false;
/*  823 */         break;
/*      */       }
/*      */     }
/*      */     
/*  827 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean clientUpdateByPrimaryKeyWithoutBLOBsMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  833 */     boolean rc = true;
/*      */     
/*  835 */     for (Plugin plugin : this.plugins) {
/*  836 */       if (!plugin.clientUpdateByPrimaryKeyWithoutBLOBsMethodGenerated(
/*  837 */         method, interfaze, introspectedTable)) {
/*  838 */         rc = false;
/*  839 */         break;
/*      */       }
/*      */     }
/*      */     
/*  843 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean clientUpdateByPrimaryKeyWithoutBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  849 */     boolean rc = true;
/*      */     
/*  851 */     for (Plugin plugin : this.plugins) {
/*  852 */       if (!plugin.clientUpdateByPrimaryKeyWithoutBLOBsMethodGenerated(
/*  853 */         method, topLevelClass, introspectedTable)) {
/*  854 */         rc = false;
/*  855 */         break;
/*      */       }
/*      */     }
/*      */     
/*  859 */     return rc;
/*      */   }
/*      */   
/*      */   public List<GeneratedJavaFile> contextGenerateAdditionalJavaFiles() {
/*  863 */     List<GeneratedJavaFile> answer = new ArrayList();
/*  864 */     for (Plugin plugin : this.plugins) {
/*  865 */       List<GeneratedJavaFile> temp = plugin
/*  866 */         .contextGenerateAdditionalJavaFiles();
/*  867 */       if (temp != null) {
/*  868 */         answer.addAll(temp);
/*      */       }
/*      */     }
/*  871 */     return answer;
/*      */   }
/*      */   
/*      */   public List<GeneratedXmlFile> contextGenerateAdditionalXmlFiles() {
/*  875 */     List<GeneratedXmlFile> answer = new ArrayList();
/*  876 */     for (Plugin plugin : this.plugins) {
/*  877 */       List<GeneratedXmlFile> temp = plugin
/*  878 */         .contextGenerateAdditionalXmlFiles();
/*  879 */       if (temp != null) {
/*  880 */         answer.addAll(temp);
/*      */       }
/*      */     }
/*  883 */     return answer;
/*      */   }
/*      */   
/*      */   public boolean sqlMapDocumentGenerated(Document document, IntrospectedTable introspectedTable)
/*      */   {
/*  888 */     boolean rc = true;
/*      */     
/*  890 */     for (Plugin plugin : this.plugins) {
/*  891 */       if (!plugin.sqlMapDocumentGenerated(document, introspectedTable)) {
/*  892 */         rc = false;
/*  893 */         break;
/*      */       }
/*      */     }
/*      */     
/*  897 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean modelFieldGenerated(Field field, TopLevelClass topLevelClass, IntrospectedColumn introspectedColumn, IntrospectedTable introspectedTable, Plugin.ModelClassType modelClassType)
/*      */   {
/*  904 */     boolean rc = true;
/*      */     
/*  906 */     for (Plugin plugin : this.plugins) {
/*  907 */       if (!plugin.modelFieldGenerated(field, topLevelClass, 
/*  908 */         introspectedColumn, introspectedTable, modelClassType)) {
/*  909 */         rc = false;
/*  910 */         break;
/*      */       }
/*      */     }
/*      */     
/*  914 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean modelGetterMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedColumn introspectedColumn, IntrospectedTable introspectedTable, Plugin.ModelClassType modelClassType)
/*      */   {
/*  921 */     boolean rc = true;
/*      */     
/*  923 */     for (Plugin plugin : this.plugins) {
/*  924 */       if (!plugin.modelGetterMethodGenerated(method, topLevelClass, 
/*  925 */         introspectedColumn, introspectedTable, modelClassType)) {
/*  926 */         rc = false;
/*  927 */         break;
/*      */       }
/*      */     }
/*      */     
/*  931 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public boolean modelSetterMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedColumn introspectedColumn, IntrospectedTable introspectedTable, Plugin.ModelClassType modelClassType)
/*      */   {
/*  938 */     boolean rc = true;
/*      */     
/*  940 */     for (Plugin plugin : this.plugins) {
/*  941 */       if (!plugin.modelSetterMethodGenerated(method, topLevelClass, 
/*  942 */         introspectedColumn, introspectedTable, modelClassType)) {
/*  943 */         rc = false;
/*  944 */         break;
/*      */       }
/*      */     }
/*      */     
/*  948 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapInsertSelectiveElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/*  953 */     boolean rc = true;
/*      */     
/*  955 */     for (Plugin plugin : this.plugins) {
/*  956 */       if (!plugin.sqlMapInsertSelectiveElementGenerated(element, 
/*  957 */         introspectedTable)) {
/*  958 */         rc = false;
/*  959 */         break;
/*      */       }
/*      */     }
/*      */     
/*  963 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientInsertSelectiveMethodGenerated(Method method, Interface interfaze, IntrospectedTable introspectedTable)
/*      */   {
/*  968 */     boolean rc = true;
/*      */     
/*  970 */     for (Plugin plugin : this.plugins) {
/*  971 */       if (!plugin.clientInsertSelectiveMethodGenerated(method, interfaze, 
/*  972 */         introspectedTable)) {
/*  973 */         rc = false;
/*  974 */         break;
/*      */       }
/*      */     }
/*      */     
/*  978 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean clientInsertSelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/*  983 */     boolean rc = true;
/*      */     
/*  985 */     for (Plugin plugin : this.plugins) {
/*  986 */       if (!plugin.clientInsertSelectiveMethodGenerated(method, 
/*  987 */         topLevelClass, introspectedTable)) {
/*  988 */         rc = false;
/*  989 */         break;
/*      */       }
/*      */     }
/*      */     
/*  993 */     return rc;
/*      */   }
/*      */   
/*      */   public void initialized(IntrospectedTable introspectedTable) {
/*  997 */     for (Plugin plugin : this.plugins) {
/*  998 */       plugin.initialized(introspectedTable);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean sqlMapBaseColumnListElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/* 1004 */     boolean rc = true;
/*      */     
/* 1006 */     for (Plugin plugin : this.plugins) {
/* 1007 */       if (!plugin.sqlMapBaseColumnListElementGenerated(element, 
/* 1008 */         introspectedTable)) {
/* 1009 */         rc = false;
/* 1010 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1014 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapBlobColumnListElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/* 1019 */     boolean rc = true;
/*      */     
/* 1021 */     for (Plugin plugin : this.plugins) {
/* 1022 */       if (!plugin.sqlMapBlobColumnListElementGenerated(element, 
/* 1023 */         introspectedTable)) {
/* 1024 */         rc = false;
/* 1025 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1029 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean providerGenerated(TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/* 1034 */     boolean rc = true;
/*      */     
/* 1036 */     for (Plugin plugin : this.plugins) {
/* 1037 */       if (!plugin.providerGenerated(topLevelClass, introspectedTable)) {
/* 1038 */         rc = false;
/* 1039 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1043 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean providerApplyWhereMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/* 1048 */     boolean rc = true;
/*      */     
/* 1050 */     for (Plugin plugin : this.plugins) {
/* 1051 */       if (!plugin.providerApplyWhereMethodGenerated(method, 
/* 1052 */         topLevelClass, introspectedTable)) {
/* 1053 */         rc = false;
/* 1054 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1058 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean providerCountByExampleMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/* 1063 */     boolean rc = true;
/*      */     
/* 1065 */     for (Plugin plugin : this.plugins) {
/* 1066 */       if (!plugin.providerCountByExampleMethodGenerated(method, 
/* 1067 */         topLevelClass, introspectedTable)) {
/* 1068 */         rc = false;
/* 1069 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1073 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean providerDeleteByExampleMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/* 1078 */     boolean rc = true;
/*      */     
/* 1080 */     for (Plugin plugin : this.plugins) {
/* 1081 */       if (!plugin.providerDeleteByExampleMethodGenerated(method, 
/* 1082 */         topLevelClass, introspectedTable)) {
/* 1083 */         rc = false;
/* 1084 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1088 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean providerInsertSelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/* 1093 */     boolean rc = true;
/*      */     
/* 1095 */     for (Plugin plugin : this.plugins) {
/* 1096 */       if (!plugin.providerInsertSelectiveMethodGenerated(method, 
/* 1097 */         topLevelClass, introspectedTable)) {
/* 1098 */         rc = false;
/* 1099 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1103 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean providerSelectByExampleWithBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/* 1109 */     boolean rc = true;
/*      */     
/* 1111 */     for (Plugin plugin : this.plugins) {
/* 1112 */       if (!plugin.providerSelectByExampleWithBLOBsMethodGenerated(method, 
/* 1113 */         topLevelClass, introspectedTable)) {
/* 1114 */         rc = false;
/* 1115 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1119 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean providerSelectByExampleWithoutBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/* 1125 */     boolean rc = true;
/*      */     
/* 1127 */     for (Plugin plugin : this.plugins) {
/* 1128 */       if (!plugin.providerSelectByExampleWithoutBLOBsMethodGenerated(method, 
/* 1129 */         topLevelClass, introspectedTable)) {
/* 1130 */         rc = false;
/* 1131 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1135 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean providerUpdateByExampleSelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/* 1141 */     boolean rc = true;
/*      */     
/* 1143 */     for (Plugin plugin : this.plugins) {
/* 1144 */       if (!plugin.providerUpdateByExampleSelectiveMethodGenerated(method, 
/* 1145 */         topLevelClass, introspectedTable)) {
/* 1146 */         rc = false;
/* 1147 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1151 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean providerUpdateByExampleWithBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/* 1157 */     boolean rc = true;
/*      */     
/* 1159 */     for (Plugin plugin : this.plugins) {
/* 1160 */       if (!plugin.providerUpdateByExampleWithBLOBsMethodGenerated(method, 
/* 1161 */         topLevelClass, introspectedTable)) {
/* 1162 */         rc = false;
/* 1163 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1167 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean providerUpdateByExampleWithoutBLOBsMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/* 1173 */     boolean rc = true;
/*      */     
/* 1175 */     for (Plugin plugin : this.plugins) {
/* 1176 */       if (!plugin.providerUpdateByExampleWithoutBLOBsMethodGenerated(method, 
/* 1177 */         topLevelClass, introspectedTable)) {
/* 1178 */         rc = false;
/* 1179 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1183 */     return rc;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean providerUpdateByPrimaryKeySelectiveMethodGenerated(Method method, TopLevelClass topLevelClass, IntrospectedTable introspectedTable)
/*      */   {
/* 1189 */     boolean rc = true;
/*      */     
/* 1191 */     for (Plugin plugin : this.plugins) {
/* 1192 */       if (!plugin.providerUpdateByPrimaryKeySelectiveMethodGenerated(method, 
/* 1193 */         topLevelClass, introspectedTable)) {
/* 1194 */         rc = false;
/* 1195 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1199 */     return rc;
/*      */   }
/*      */   
/*      */   public boolean sqlMapSelectAllElementGenerated(XmlElement element, IntrospectedTable introspectedTable)
/*      */   {
/* 1204 */     boolean rc = true;
/*      */     
/* 1206 */     for (Plugin plugin : this.plugins) {
/* 1207 */       if (!plugin.sqlMapSelectAllElementGenerated(element, introspectedTable)) {
/* 1208 */         rc = false;
/* 1209 */         break;
/*      */       }
/*      */     }
/*      */     
/* 1213 */     return rc;
/*      */   }
/*      */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\PluginAggregator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */