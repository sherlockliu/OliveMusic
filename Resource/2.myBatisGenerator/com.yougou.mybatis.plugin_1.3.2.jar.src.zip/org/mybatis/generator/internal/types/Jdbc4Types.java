package org.mybatis.generator.internal.types;

public class Jdbc4Types
{
  public static final int LONGNVARCHAR = -16;
  public static final int NVARCHAR = -9;
  public static final int NCHAR = -15;
  public static final int NCLOB = 2011;
}


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\types\Jdbc4Types.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */