/*     */ package org.mybatis.generator.internal.types;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.JavaTypeResolver;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaTypeResolverDefaultImpl
/*     */   implements JavaTypeResolver
/*     */ {
/*     */   protected List<String> warnings;
/*     */   protected Properties properties;
/*     */   protected Context context;
/*     */   protected boolean forceBigDecimals;
/*     */   protected Map<Integer, JdbcTypeInformation> typeMap;
/*     */   
/*     */   public JavaTypeResolverDefaultImpl()
/*     */   {
/*  51 */     this.properties = new Properties();
/*  52 */     this.typeMap = new HashMap();
/*     */     
/*  54 */     this.typeMap.put(Integer.valueOf(2003), new JdbcTypeInformation("ARRAY", 
/*  55 */       new FullyQualifiedJavaType(Object.class.getName())));
/*  56 */     this.typeMap.put(Integer.valueOf(-5), new JdbcTypeInformation("BIGINT", 
/*  57 */       new FullyQualifiedJavaType(Long.class.getName())));
/*  58 */     this.typeMap.put(Integer.valueOf(-2), new JdbcTypeInformation("BINARY", 
/*  59 */       new FullyQualifiedJavaType("byte[]")));
/*  60 */     this.typeMap.put(Integer.valueOf(-7), new JdbcTypeInformation("BIT", 
/*  61 */       new FullyQualifiedJavaType(Boolean.class.getName())));
/*  62 */     this.typeMap.put(Integer.valueOf(2004), new JdbcTypeInformation("BLOB", 
/*  63 */       new FullyQualifiedJavaType("byte[]")));
/*  64 */     this.typeMap.put(Integer.valueOf(16), new JdbcTypeInformation("BOOLEAN", 
/*  65 */       new FullyQualifiedJavaType(Boolean.class.getName())));
/*  66 */     this.typeMap.put(Integer.valueOf(1), new JdbcTypeInformation("CHAR", 
/*  67 */       new FullyQualifiedJavaType(String.class.getName())));
/*  68 */     this.typeMap.put(Integer.valueOf(2005), new JdbcTypeInformation("CLOB", 
/*  69 */       new FullyQualifiedJavaType(String.class.getName())));
/*  70 */     this.typeMap.put(Integer.valueOf(70), new JdbcTypeInformation("DATALINK", 
/*  71 */       new FullyQualifiedJavaType(Object.class.getName())));
/*  72 */     this.typeMap.put(Integer.valueOf(91), new JdbcTypeInformation("DATE", 
/*  73 */       new FullyQualifiedJavaType(Date.class.getName())));
/*  74 */     this.typeMap.put(Integer.valueOf(2001), new JdbcTypeInformation("DISTINCT", 
/*  75 */       new FullyQualifiedJavaType(Object.class.getName())));
/*  76 */     this.typeMap.put(Integer.valueOf(8), new JdbcTypeInformation("DOUBLE", 
/*  77 */       new FullyQualifiedJavaType(Double.class.getName())));
/*  78 */     this.typeMap.put(Integer.valueOf(6), new JdbcTypeInformation("FLOAT", 
/*  79 */       new FullyQualifiedJavaType(Double.class.getName())));
/*  80 */     this.typeMap.put(Integer.valueOf(4), new JdbcTypeInformation("INTEGER", 
/*  81 */       new FullyQualifiedJavaType(Integer.class.getName())));
/*  82 */     this.typeMap.put(Integer.valueOf(2000), new JdbcTypeInformation("JAVA_OBJECT", 
/*  83 */       new FullyQualifiedJavaType(Object.class.getName())));
/*  84 */     this.typeMap.put(Integer.valueOf(-16), new JdbcTypeInformation("LONGNVARCHAR", 
/*  85 */       new FullyQualifiedJavaType(String.class.getName())));
/*  86 */     this.typeMap.put(Integer.valueOf(-4), new JdbcTypeInformation(
/*  87 */       "LONGVARBINARY", 
/*  88 */       new FullyQualifiedJavaType("byte[]")));
/*  89 */     this.typeMap.put(Integer.valueOf(-1), new JdbcTypeInformation("LONGVARCHAR", 
/*  90 */       new FullyQualifiedJavaType(String.class.getName())));
/*  91 */     this.typeMap.put(Integer.valueOf(-15), new JdbcTypeInformation("NCHAR", 
/*  92 */       new FullyQualifiedJavaType(String.class.getName())));
/*  93 */     this.typeMap.put(Integer.valueOf(2011), new JdbcTypeInformation("NCLOB", 
/*  94 */       new FullyQualifiedJavaType(String.class.getName())));
/*  95 */     this.typeMap.put(Integer.valueOf(-9), new JdbcTypeInformation("NVARCHAR", 
/*  96 */       new FullyQualifiedJavaType(String.class.getName())));
/*  97 */     this.typeMap.put(Integer.valueOf(0), new JdbcTypeInformation("NULL", 
/*  98 */       new FullyQualifiedJavaType(Object.class.getName())));
/*  99 */     this.typeMap.put(Integer.valueOf(1111), new JdbcTypeInformation("OTHER", 
/* 100 */       new FullyQualifiedJavaType(Object.class.getName())));
/* 101 */     this.typeMap.put(Integer.valueOf(7), new JdbcTypeInformation("REAL", 
/* 102 */       new FullyQualifiedJavaType(Float.class.getName())));
/* 103 */     this.typeMap.put(Integer.valueOf(2006), new JdbcTypeInformation("REF", 
/* 104 */       new FullyQualifiedJavaType(Object.class.getName())));
/* 105 */     this.typeMap.put(Integer.valueOf(5), new JdbcTypeInformation("SMALLINT", 
/* 106 */       new FullyQualifiedJavaType(Short.class.getName())));
/* 107 */     this.typeMap.put(Integer.valueOf(2002), new JdbcTypeInformation("STRUCT", 
/* 108 */       new FullyQualifiedJavaType(Object.class.getName())));
/* 109 */     this.typeMap.put(Integer.valueOf(92), new JdbcTypeInformation("TIME", 
/* 110 */       new FullyQualifiedJavaType(Date.class.getName())));
/* 111 */     this.typeMap.put(Integer.valueOf(93), new JdbcTypeInformation("TIMESTAMP", 
/* 112 */       new FullyQualifiedJavaType(Date.class.getName())));
/* 113 */     this.typeMap.put(Integer.valueOf(-6), new JdbcTypeInformation("TINYINT", 
/* 114 */       new FullyQualifiedJavaType(Byte.class.getName())));
/* 115 */     this.typeMap.put(Integer.valueOf(-3), new JdbcTypeInformation("VARBINARY", 
/* 116 */       new FullyQualifiedJavaType("byte[]")));
/* 117 */     this.typeMap.put(Integer.valueOf(12), new JdbcTypeInformation("VARCHAR", 
/* 118 */       new FullyQualifiedJavaType(String.class.getName())));
/*     */   }
/*     */   
/*     */   public void addConfigurationProperties(Properties properties)
/*     */   {
/* 123 */     this.properties.putAll(properties);
/* 124 */     this.forceBigDecimals = 
/* 125 */       StringUtility.isTrue(properties
/* 126 */       .getProperty("forceBigDecimals"));
/*     */   }
/*     */   
/*     */ 
/*     */   public FullyQualifiedJavaType calculateJavaType(IntrospectedColumn introspectedColumn)
/*     */   {
/* 132 */     JdbcTypeInformation jdbcTypeInformation = 
/* 133 */       (JdbcTypeInformation)this.typeMap.get(Integer.valueOf(introspectedColumn.getJdbcType()));
/*     */     FullyQualifiedJavaType answer;
/* 135 */     if (jdbcTypeInformation == null) { FullyQualifiedJavaType answer;
/* 136 */       FullyQualifiedJavaType answer; switch (introspectedColumn.getJdbcType()) {
/*     */       case 2: case 3: 
/*     */         FullyQualifiedJavaType answer;
/* 139 */         if ((introspectedColumn.getScale() > 0) || 
/* 140 */           (introspectedColumn.getLength() > 18) || 
/* 141 */           (this.forceBigDecimals)) {
/* 142 */           answer = new FullyQualifiedJavaType(BigDecimal.class
/* 143 */             .getName()); } else { FullyQualifiedJavaType answer;
/* 144 */           if (introspectedColumn.getLength() > 9) {
/* 145 */             answer = new FullyQualifiedJavaType(Long.class.getName()); } else { FullyQualifiedJavaType answer;
/* 146 */             if (introspectedColumn.getLength() > 4) {
/* 147 */               answer = new FullyQualifiedJavaType(Integer.class.getName());
/*     */             } else
/* 149 */               answer = new FullyQualifiedJavaType(Short.class.getName());
/*     */           } }
/* 151 */         break;
/*     */       
/*     */       default: 
/* 154 */         answer = null;
/* 155 */         break;
/*     */       }
/*     */     } else {
/* 158 */       answer = jdbcTypeInformation.getFullyQualifiedJavaType();
/*     */     }
/*     */     
/* 161 */     return answer;
/*     */   }
/*     */   
/*     */   public String calculateJdbcTypeName(IntrospectedColumn introspectedColumn)
/*     */   {
/* 166 */     JdbcTypeInformation jdbcTypeInformation = 
/* 167 */       (JdbcTypeInformation)this.typeMap.get(Integer.valueOf(introspectedColumn.getJdbcType()));
/*     */     String answer;
/* 169 */     if (jdbcTypeInformation == null) { String answer;
/* 170 */       String answer; String answer; switch (introspectedColumn.getJdbcType()) {
/*     */       case 3: 
/* 172 */         answer = "DECIMAL";
/* 173 */         break;
/*     */       case 2: 
/* 175 */         answer = "NUMERIC";
/* 176 */         break;
/*     */       default: 
/* 178 */         answer = null;
/* 179 */         break;
/*     */       }
/*     */     } else {
/* 182 */       answer = jdbcTypeInformation.getJdbcTypeName();
/*     */     }
/*     */     
/* 185 */     return answer;
/*     */   }
/*     */   
/*     */   public void setWarnings(List<String> warnings) {
/* 189 */     this.warnings = warnings;
/*     */   }
/*     */   
/*     */   public void setContext(Context context) {
/* 193 */     this.context = context;
/*     */   }
/*     */   
/*     */   public static class JdbcTypeInformation
/*     */   {
/*     */     private String jdbcTypeName;
/*     */     private FullyQualifiedJavaType fullyQualifiedJavaType;
/*     */     
/*     */     public JdbcTypeInformation(String jdbcTypeName, FullyQualifiedJavaType fullyQualifiedJavaType)
/*     */     {
/* 203 */       this.jdbcTypeName = jdbcTypeName;
/* 204 */       this.fullyQualifiedJavaType = fullyQualifiedJavaType;
/*     */     }
/*     */     
/*     */     public String getJdbcTypeName() {
/* 208 */       return this.jdbcTypeName;
/*     */     }
/*     */     
/*     */     public FullyQualifiedJavaType getFullyQualifiedJavaType() {
/* 212 */       return this.fullyQualifiedJavaType;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\types\JavaTypeResolverDefaultImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */