/*     */ package org.mybatis.generator.internal.types;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JdbcTypeNameTranslator
/*     */ {
/*  33 */   private static Map<Integer, String> typeToName = new HashMap();
/*  34 */   static { typeToName.put(Integer.valueOf(2003), "ARRAY");
/*  35 */     typeToName.put(Integer.valueOf(-5), "BIGINT");
/*  36 */     typeToName.put(Integer.valueOf(-2), "BINARY");
/*  37 */     typeToName.put(Integer.valueOf(-7), "BIT");
/*  38 */     typeToName.put(Integer.valueOf(2004), "BLOB");
/*  39 */     typeToName.put(Integer.valueOf(16), "BOOLEAN");
/*  40 */     typeToName.put(Integer.valueOf(1), "CHAR");
/*  41 */     typeToName.put(Integer.valueOf(2005), "CLOB");
/*  42 */     typeToName.put(Integer.valueOf(70), "DATALINK");
/*  43 */     typeToName.put(Integer.valueOf(91), "DATE");
/*  44 */     typeToName.put(Integer.valueOf(3), "DECIMAL");
/*  45 */     typeToName.put(Integer.valueOf(2001), "DISTINCT");
/*  46 */     typeToName.put(Integer.valueOf(8), "DOUBLE");
/*  47 */     typeToName.put(Integer.valueOf(6), "FLOAT");
/*  48 */     typeToName.put(Integer.valueOf(4), "INTEGER");
/*  49 */     typeToName.put(Integer.valueOf(2000), "JAVA_OBJECT");
/*  50 */     typeToName.put(Integer.valueOf(-4), "LONGVARBINARY");
/*  51 */     typeToName.put(Integer.valueOf(-1), "LONGVARCHAR");
/*  52 */     typeToName.put(Integer.valueOf(-15), "NCHAR");
/*  53 */     typeToName.put(Integer.valueOf(2011), "NCLOB");
/*  54 */     typeToName.put(Integer.valueOf(-9), "NVARCHAR");
/*  55 */     typeToName.put(Integer.valueOf(-16), "LONGNVARCHAR");
/*  56 */     typeToName.put(Integer.valueOf(0), "NULL");
/*  57 */     typeToName.put(Integer.valueOf(2), "NUMERIC");
/*  58 */     typeToName.put(Integer.valueOf(1111), "OTHER");
/*  59 */     typeToName.put(Integer.valueOf(7), "REAL");
/*  60 */     typeToName.put(Integer.valueOf(2006), "REF");
/*  61 */     typeToName.put(Integer.valueOf(5), "SMALLINT");
/*  62 */     typeToName.put(Integer.valueOf(2002), "STRUCT");
/*  63 */     typeToName.put(Integer.valueOf(92), "TIME");
/*  64 */     typeToName.put(Integer.valueOf(93), "TIMESTAMP");
/*  65 */     typeToName.put(Integer.valueOf(-6), "TINYINT");
/*  66 */     typeToName.put(Integer.valueOf(-3), "VARBINARY");
/*  67 */     typeToName.put(Integer.valueOf(12), "VARCHAR");
/*     */     
/*  69 */     nameToType = new HashMap();
/*  70 */     nameToType.put("ARRAY", Integer.valueOf(2003));
/*  71 */     nameToType.put("BIGINT", Integer.valueOf(-5));
/*  72 */     nameToType.put("BINARY", Integer.valueOf(-2));
/*  73 */     nameToType.put("BIT", Integer.valueOf(-7));
/*  74 */     nameToType.put("BLOB", Integer.valueOf(2004));
/*  75 */     nameToType.put("BOOLEAN", Integer.valueOf(16));
/*  76 */     nameToType.put("CHAR", Integer.valueOf(1));
/*  77 */     nameToType.put("CLOB", Integer.valueOf(2005));
/*  78 */     nameToType.put("DATALINK", Integer.valueOf(70));
/*  79 */     nameToType.put("DATE", Integer.valueOf(91));
/*  80 */     nameToType.put("DECIMAL", Integer.valueOf(3));
/*  81 */     nameToType.put("DISTINCT", Integer.valueOf(2001));
/*  82 */     nameToType.put("DOUBLE", Integer.valueOf(8));
/*  83 */     nameToType.put("FLOAT", Integer.valueOf(6));
/*  84 */     nameToType.put("INTEGER", Integer.valueOf(4));
/*  85 */     nameToType.put("JAVA_OBJECT", Integer.valueOf(2000));
/*  86 */     nameToType.put("LONGVARBINARY", Integer.valueOf(-4));
/*  87 */     nameToType.put("LONGVARCHAR", Integer.valueOf(-1));
/*  88 */     nameToType.put("NCHAR", Integer.valueOf(-15));
/*  89 */     nameToType.put("NCLOB", Integer.valueOf(2011));
/*  90 */     nameToType.put("NVARCHAR", Integer.valueOf(-9));
/*  91 */     nameToType.put("LONGNVARCHAR", Integer.valueOf(-16));
/*  92 */     nameToType.put("NULL", Integer.valueOf(0));
/*  93 */     nameToType.put("NUMERIC", Integer.valueOf(2));
/*  94 */     nameToType.put("OTHER", Integer.valueOf(1111));
/*  95 */     nameToType.put("REAL", Integer.valueOf(7));
/*  96 */     nameToType.put("REF", Integer.valueOf(2006));
/*  97 */     nameToType.put("SMALLINT", Integer.valueOf(5));
/*  98 */     nameToType.put("STRUCT", Integer.valueOf(2002));
/*  99 */     nameToType.put("TIME", Integer.valueOf(92));
/* 100 */     nameToType.put("TIMESTAMP", Integer.valueOf(93));
/* 101 */     nameToType.put("TINYINT", Integer.valueOf(-6));
/* 102 */     nameToType.put("VARBINARY", Integer.valueOf(-3));
/* 103 */     nameToType.put("VARCHAR", Integer.valueOf(12));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static Map<String, Integer> nameToType;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getJdbcTypeName(int jdbcType)
/*     */   {
/* 122 */     String answer = (String)typeToName.get(Integer.valueOf(jdbcType));
/* 123 */     if (answer == null) {
/* 124 */       answer = "OTHER";
/*     */     }
/*     */     
/* 127 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int getJdbcType(String jdbcTypeName)
/*     */   {
/* 139 */     Integer answer = (Integer)nameToType.get(jdbcTypeName);
/* 140 */     if (answer == null) {
/* 141 */       answer = Integer.valueOf(1111);
/*     */     }
/*     */     
/* 144 */     return answer.intValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\types\JdbcTypeNameTranslator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */