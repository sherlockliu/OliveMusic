/*     */ package org.mybatis.generator.internal.db;
/*     */ 
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.JavaTypeResolver;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.config.ColumnOverride;
/*     */ import org.mybatis.generator.config.ColumnRenamingRule;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.GeneratedKey;
/*     */ import org.mybatis.generator.config.TableConfiguration;
/*     */ import org.mybatis.generator.config.YouGouTableSettingConfiguration;
/*     */ import org.mybatis.generator.internal.ObjectFactory;
/*     */ import org.mybatis.generator.internal.util.JavaBeansUtil;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ import org.mybatis.generator.logging.Log;
/*     */ import org.mybatis.generator.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DatabaseIntrospector
/*     */ {
/*     */   private DatabaseMetaData databaseMetaData;
/*     */   private JavaTypeResolver javaTypeResolver;
/*     */   private List<String> warnings;
/*     */   private Context context;
/*     */   private Log logger;
/*     */   
/*     */   public DatabaseIntrospector(Context context, DatabaseMetaData databaseMetaData, JavaTypeResolver javaTypeResolver, List<String> warnings)
/*     */   {
/*  72 */     this.context = context;
/*  73 */     this.databaseMetaData = databaseMetaData;
/*  74 */     this.javaTypeResolver = javaTypeResolver;
/*  75 */     this.warnings = warnings;
/*  76 */     this.logger = LogFactory.getLog(getClass());
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   private void calculatePrimaryKey(FullyQualifiedTable table, IntrospectedTable introspectedTable)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_3
/*     */     //   2: aload_0
/*     */     //   3: getfield 26	org/mybatis/generator/internal/db/DatabaseIntrospector:databaseMetaData	Ljava/sql/DatabaseMetaData;
/*     */     //   6: aload_1
/*     */     //   7: invokevirtual 51	org/mybatis/generator/api/FullyQualifiedTable:getIntrospectedCatalog	()Ljava/lang/String;
/*     */     //   10: aload_1
/*     */     //   11: invokevirtual 57	org/mybatis/generator/api/FullyQualifiedTable:getIntrospectedSchema	()Ljava/lang/String;
/*     */     //   14: aload_1
/*     */     //   15: invokevirtual 60	org/mybatis/generator/api/FullyQualifiedTable:getIntrospectedTableName	()Ljava/lang/String;
/*     */     //   18: invokeinterface 63 4 0
/*     */     //   23: astore_3
/*     */     //   24: goto +25 -> 49
/*     */     //   27: pop
/*     */     //   28: aload_0
/*     */     //   29: aload_3
/*     */     //   30: invokespecial 69	org/mybatis/generator/internal/db/DatabaseIntrospector:closeResultSet	(Ljava/sql/ResultSet;)V
/*     */     //   33: aload_0
/*     */     //   34: getfield 30	org/mybatis/generator/internal/db/DatabaseIntrospector:warnings	Ljava/util/List;
/*     */     //   37: ldc 73
/*     */     //   39: invokestatic 75	org/mybatis/generator/internal/util/messages/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   42: invokeinterface 81 2 0
/*     */     //   47: pop
/*     */     //   48: return
/*     */     //   49: new 87	java/util/TreeMap
/*     */     //   52: dup
/*     */     //   53: invokespecial 89	java/util/TreeMap:<init>	()V
/*     */     //   56: astore 4
/*     */     //   58: goto +38 -> 96
/*     */     //   61: aload_3
/*     */     //   62: ldc 90
/*     */     //   64: invokeinterface 92 2 0
/*     */     //   69: astore 5
/*     */     //   71: aload_3
/*     */     //   72: ldc 95
/*     */     //   74: invokeinterface 97 2 0
/*     */     //   79: istore 6
/*     */     //   81: aload 4
/*     */     //   83: iload 6
/*     */     //   85: invokestatic 101	java/lang/Short:valueOf	(S)Ljava/lang/Short;
/*     */     //   88: aload 5
/*     */     //   90: invokeinterface 107 3 0
/*     */     //   95: pop
/*     */     //   96: aload_3
/*     */     //   97: invokeinterface 113 1 0
/*     */     //   102: ifne -41 -> 61
/*     */     //   105: aload 4
/*     */     //   107: invokeinterface 117 1 0
/*     */     //   112: invokeinterface 121 1 0
/*     */     //   117: astore 6
/*     */     //   119: goto +21 -> 140
/*     */     //   122: aload 6
/*     */     //   124: invokeinterface 127 1 0
/*     */     //   129: checkcast 132	java/lang/String
/*     */     //   132: astore 5
/*     */     //   134: aload_2
/*     */     //   135: aload 5
/*     */     //   137: invokevirtual 134	org/mybatis/generator/api/IntrospectedTable:addPrimaryKeyColumn	(Ljava/lang/String;)V
/*     */     //   140: aload 6
/*     */     //   142: invokeinterface 140 1 0
/*     */     //   147: ifne -25 -> 122
/*     */     //   150: goto +22 -> 172
/*     */     //   153: pop
/*     */     //   154: aload_0
/*     */     //   155: aload_3
/*     */     //   156: invokespecial 69	org/mybatis/generator/internal/db/DatabaseIntrospector:closeResultSet	(Ljava/sql/ResultSet;)V
/*     */     //   159: goto +18 -> 177
/*     */     //   162: astore 7
/*     */     //   164: aload_0
/*     */     //   165: aload_3
/*     */     //   166: invokespecial 69	org/mybatis/generator/internal/db/DatabaseIntrospector:closeResultSet	(Ljava/sql/ResultSet;)V
/*     */     //   169: aload 7
/*     */     //   171: athrow
/*     */     //   172: aload_0
/*     */     //   173: aload_3
/*     */     //   174: invokespecial 69	org/mybatis/generator/internal/db/DatabaseIntrospector:closeResultSet	(Ljava/sql/ResultSet;)V
/*     */     //   177: return
/*     */     // Line number table:
/*     */     //   Java source line #81	-> byte code offset #0
/*     */     //   Java source line #84	-> byte code offset #2
/*     */     //   Java source line #85	-> byte code offset #6
/*     */     //   Java source line #86	-> byte code offset #11
/*     */     //   Java source line #87	-> byte code offset #15
/*     */     //   Java source line #84	-> byte code offset #18
/*     */     //   Java source line #88	-> byte code offset #27
/*     */     //   Java source line #89	-> byte code offset #28
/*     */     //   Java source line #90	-> byte code offset #33
/*     */     //   Java source line #91	-> byte code offset #48
/*     */     //   Java source line #96	-> byte code offset #49
/*     */     //   Java source line #97	-> byte code offset #58
/*     */     //   Java source line #98	-> byte code offset #61
/*     */     //   Java source line #99	-> byte code offset #71
/*     */     //   Java source line #100	-> byte code offset #81
/*     */     //   Java source line #97	-> byte code offset #96
/*     */     //   Java source line #103	-> byte code offset #105
/*     */     //   Java source line #104	-> byte code offset #134
/*     */     //   Java source line #103	-> byte code offset #140
/*     */     //   Java source line #106	-> byte code offset #153
/*     */     //   Java source line #109	-> byte code offset #154
/*     */     //   Java source line #108	-> byte code offset #162
/*     */     //   Java source line #109	-> byte code offset #164
/*     */     //   Java source line #110	-> byte code offset #169
/*     */     //   Java source line #109	-> byte code offset #172
/*     */     //   Java source line #111	-> byte code offset #177
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	178	0	this	DatabaseIntrospector
/*     */     //   0	178	1	table	FullyQualifiedTable
/*     */     //   0	178	2	introspectedTable	IntrospectedTable
/*     */     //   1	173	3	rs	ResultSet
/*     */     //   56	50	4	keyColumns	Map<Short, String>
/*     */     //   69	20	5	columnName	String
/*     */     //   132	4	5	columnName	String
/*     */     //   79	62	6	keySeq	short
/*     */     //   162	8	7	localObject	Object
/*     */     //   27	1	9	localSQLException1	SQLException
/*     */     //   153	1	10	localSQLException2	SQLException
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   2	24	27	java/sql/SQLException
/*     */     //   49	150	153	java/sql/SQLException
/*     */     //   49	154	162	finally
/*     */   }
/*     */   
/*     */   private void closeResultSet(ResultSet rs)
/*     */   {
/* 114 */     if (rs != null) {
/*     */       try {
/* 116 */         rs.close();
/*     */       }
/*     */       catch (SQLException localSQLException) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void reportIntrospectionWarnings(IntrospectedTable introspectedTable, TableConfiguration tableConfiguration, FullyQualifiedTable table)
/*     */   {
/* 130 */     Iterator localIterator = tableConfiguration.getColumnOverrides().iterator();
/* 129 */     while (localIterator.hasNext()) {
/* 130 */       ColumnOverride columnOverride = (ColumnOverride)localIterator.next();
/* 131 */       if (introspectedTable.getColumn(columnOverride.getColumnName()) == null) {
/* 132 */         this.warnings.add(Messages.getString("Warning.3", 
/* 133 */           columnOverride.getColumnName(), table.toString()));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 139 */     for (String string : tableConfiguration.getIgnoredColumnsInError()) {
/* 140 */       this.warnings.add(Messages.getString("Warning.4", 
/* 141 */         string, table.toString()));
/*     */     }
/*     */     
/* 144 */     GeneratedKey generatedKey = tableConfiguration.getGeneratedKey();
/* 145 */     if ((generatedKey != null) && 
/* 146 */       (introspectedTable.getColumn(generatedKey.getColumn()) == null)) {
/* 147 */       if (generatedKey.isIdentity()) {
/* 148 */         this.warnings.add(Messages.getString("Warning.5", 
/* 149 */           generatedKey.getColumn(), table.toString()));
/*     */       } else {
/* 151 */         this.warnings.add(Messages.getString("Warning.6", 
/* 152 */           generatedKey.getColumn(), table.toString()));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<IntrospectedTable> introspectTables(TableConfiguration tc)
/*     */     throws SQLException
/*     */   {
/* 169 */     Map<ActualTableName, List<IntrospectedColumn>> columns = getColumns(tc);
/*     */     
/* 171 */     if (columns.isEmpty()) {
/* 172 */       this.warnings.add(Messages.getString("Warning.19", tc.getCatalog(), 
/* 173 */         tc.getSchema(), tc.getTableName()));
/* 174 */       return null;
/*     */     }
/*     */     
/* 177 */     removeIgnoredColumns(tc, columns);
/* 178 */     calculateExtraColumnInformation(tc, columns);
/* 179 */     applyColumnOverrides(tc, columns);
/* 180 */     calculateIdentityColumns(tc, columns);
/*     */     
/* 182 */     List<IntrospectedTable> introspectedTables = calculateIntrospectedTables(
/* 183 */       tc, columns);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 188 */     Iterator<IntrospectedTable> iter = introspectedTables.iterator();
/* 189 */     while (iter.hasNext()) {
/* 190 */       IntrospectedTable introspectedTable = (IntrospectedTable)iter.next();
/*     */       
/* 192 */       if (!introspectedTable.hasAnyColumns())
/*     */       {
/*     */ 
/* 195 */         String warning = Messages.getString(
/* 196 */           "Warning.1", introspectedTable.getFullyQualifiedTable().toString());
/* 197 */         this.warnings.add(warning);
/* 198 */         iter.remove();
/* 199 */       } else if ((!introspectedTable.hasPrimaryKeyColumns()) && 
/* 200 */         (!introspectedTable.hasBaseColumns()))
/*     */       {
/*     */ 
/* 203 */         String warning = Messages.getString(
/* 204 */           "Warning.18", introspectedTable.getFullyQualifiedTable().toString());
/* 205 */         this.warnings.add(warning);
/* 206 */         iter.remove();
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 211 */         reportIntrospectionWarnings(introspectedTable, tc, 
/* 212 */           introspectedTable.getFullyQualifiedTable());
/*     */       }
/*     */     }
/*     */     
/* 216 */     return introspectedTables;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void removeIgnoredColumns(TableConfiguration tc, Map<ActualTableName, List<IntrospectedColumn>> columns)
/*     */   {
/* 226 */     Iterator localIterator = columns.entrySet().iterator();
/*     */     Iterator<IntrospectedColumn> tableColumns;
/* 225 */     for (; localIterator.hasNext(); 
/*     */         
/*     */ 
/*     */ 
/* 229 */         tableColumns.hasNext())
/*     */     {
/* 226 */       Map.Entry<ActualTableName, List<IntrospectedColumn>> entry = (Map.Entry)localIterator.next();
/* 227 */       tableColumns = ((List)entry.getValue())
/* 228 */         .iterator();
/* 229 */       continue;
/* 230 */       IntrospectedColumn introspectedColumn = (IntrospectedColumn)tableColumns.next();
/*     */       
/* 232 */       if (tc.isColumnIgnored(introspectedColumn
/* 233 */         .getActualColumnName())) {
/* 234 */         tableColumns.remove();
/* 235 */         if (this.logger.isDebugEnabled()) {
/* 236 */           this.logger.debug(Messages.getString("Tracing.3", 
/* 237 */             introspectedColumn.getActualColumnName(), 
/* 238 */             ((ActualTableName)entry.getKey()).toString()));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void calculateExtraColumnInformation(TableConfiguration tc, Map<ActualTableName, List<IntrospectedColumn>> columns)
/*     */   {
/* 247 */     StringBuilder sb = new StringBuilder();
/* 248 */     Pattern pattern = null;
/* 249 */     String replaceString = null;
/* 250 */     if (tc.getColumnRenamingRule() != null) {
/* 251 */       pattern = Pattern.compile(tc.getColumnRenamingRule()
/* 252 */         .getSearchString());
/* 253 */       replaceString = tc.getColumnRenamingRule().getReplaceString();
/* 254 */       replaceString = replaceString == null ? "" : replaceString;
/*     */     }
/*     */     
/*     */ 
/* 258 */     Iterator localIterator1 = columns.entrySet().iterator();
/*     */     Iterator localIterator2;
/* 257 */     for (; localIterator1.hasNext(); 
/*     */         
/* 259 */         localIterator2.hasNext())
/*     */     {
/* 258 */       Map.Entry<ActualTableName, List<IntrospectedColumn>> entry = (Map.Entry)localIterator1.next();
/* 259 */       localIterator2 = ((List)entry.getValue()).iterator(); continue;IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator2.next();
/*     */       String calculatedColumnName;
/* 261 */       String calculatedColumnName; if (pattern == null) {
/* 262 */         calculatedColumnName = 
/* 263 */           introspectedColumn.getActualColumnName();
/*     */       } else {
/* 265 */         Matcher matcher = pattern.matcher(introspectedColumn
/* 266 */           .getActualColumnName());
/* 267 */         calculatedColumnName = matcher.replaceAll(replaceString);
/*     */       }
/*     */       
/* 270 */       if (StringUtility.isTrue(tc
/* 271 */         .getProperty("useActualColumnNames"))) {
/* 272 */         introspectedColumn.setJavaProperty(
/* 273 */           JavaBeansUtil.getValidPropertyName(calculatedColumnName));
/* 274 */       } else if (StringUtility.isTrue(tc
/* 275 */         .getProperty("useCompoundPropertyNames"))) {
/* 276 */         sb.setLength(0);
/* 277 */         sb.append(calculatedColumnName);
/* 278 */         sb.append('_');
/* 279 */         sb.append(JavaBeansUtil.getCamelCaseString(
/* 280 */           introspectedColumn.getRemarks(), true));
/* 281 */         introspectedColumn.setJavaProperty(
/* 282 */           JavaBeansUtil.getValidPropertyName(sb.toString()));
/*     */       } else {
/* 284 */         introspectedColumn.setJavaProperty(
/* 285 */           JavaBeansUtil.getCamelCaseString(calculatedColumnName, false));
/*     */       }
/*     */       
/* 288 */       FullyQualifiedJavaType fullyQualifiedJavaType = this.javaTypeResolver
/* 289 */         .calculateJavaType(introspectedColumn);
/*     */       
/* 291 */       if (fullyQualifiedJavaType != null)
/*     */       {
/* 293 */         introspectedColumn.setFullyQualifiedJavaType(fullyQualifiedJavaType);
/* 294 */         introspectedColumn.setJdbcTypeName(this.javaTypeResolver
/* 295 */           .calculateJdbcTypeName(introspectedColumn));
/*     */       }
/*     */       else {
/* 298 */         boolean warn = true;
/* 299 */         if (tc.isColumnIgnored(introspectedColumn
/* 300 */           .getActualColumnName())) {
/* 301 */           warn = false;
/*     */         }
/*     */         
/* 304 */         ColumnOverride co = tc.getColumnOverride(introspectedColumn
/* 305 */           .getActualColumnName());
/* 306 */         if ((co != null) && 
/* 307 */           (StringUtility.stringHasValue(co.getJavaType())) && 
/* 308 */           (StringUtility.stringHasValue(co.getJavaType()))) {
/* 309 */           warn = false;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 314 */         if (warn)
/*     */         {
/* 316 */           introspectedColumn.setFullyQualifiedJavaType(
/* 317 */             FullyQualifiedJavaType.getObjectInstance());
/* 318 */           introspectedColumn.setJdbcTypeName("OTHER");
/*     */           
/* 320 */           String warning = Messages.getString("Warning.14", 
/* 321 */             Integer.toString(introspectedColumn.getJdbcType()), 
/* 322 */             ((ActualTableName)entry.getKey()).toString(), 
/* 323 */             introspectedColumn.getActualColumnName());
/*     */           
/* 325 */           this.warnings.add(warning);
/*     */         }
/*     */       }
/*     */       
/* 329 */       if ((this.context.autoDelimitKeywords()) && 
/* 330 */         (SqlReservedWords.containsWord(introspectedColumn
/* 331 */         .getActualColumnName()))) {
/* 332 */         introspectedColumn.setColumnNameDelimited(true);
/*     */       }
/*     */       
/*     */ 
/* 336 */       if (tc.isAllColumnDelimitingEnabled()) {
/* 337 */         introspectedColumn.setColumnNameDelimited(true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void calculateIdentityColumns(TableConfiguration tc, Map<ActualTableName, List<IntrospectedColumn>> columns)
/*     */   {
/* 345 */     GeneratedKey gk = tc.getGeneratedKey();
/* 346 */     if (gk == null)
/*     */     {
/* 348 */       return;
/*     */     }
/*     */     
/*     */ 
/* 352 */     Iterator localIterator1 = columns.entrySet().iterator();
/*     */     Iterator localIterator2;
/* 351 */     for (; localIterator1.hasNext(); 
/*     */         
/* 353 */         localIterator2.hasNext())
/*     */     {
/* 352 */       Map.Entry<ActualTableName, List<IntrospectedColumn>> entry = (Map.Entry)localIterator1.next();
/* 353 */       localIterator2 = ((List)entry.getValue()).iterator(); continue;IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator2.next();
/* 354 */       if (isMatchedColumn(introspectedColumn, gk)) {
/* 355 */         if ((gk.isIdentity()) || (gk.isJdbcStandard())) {
/* 356 */           introspectedColumn.setIdentity(true);
/* 357 */           introspectedColumn.setSequenceColumn(false);
/*     */         } else {
/* 359 */           introspectedColumn.setIdentity(false);
/* 360 */           introspectedColumn.setSequenceColumn(true);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isMatchedColumn(IntrospectedColumn introspectedColumn, GeneratedKey gk)
/*     */   {
/* 368 */     if (introspectedColumn.isColumnNameDelimited()) {
/* 369 */       return introspectedColumn.getActualColumnName().equals(gk.getColumn());
/*     */     }
/* 371 */     return introspectedColumn.getActualColumnName().equalsIgnoreCase(gk.getColumn());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void applyColumnOverrides(TableConfiguration tc, Map<ActualTableName, List<IntrospectedColumn>> columns)
/*     */   {
/* 378 */     Iterator localIterator1 = columns.entrySet().iterator();
/*     */     Iterator localIterator2;
/* 377 */     for (; localIterator1.hasNext(); 
/*     */         
/* 379 */         localIterator2.hasNext())
/*     */     {
/* 378 */       Map.Entry<ActualTableName, List<IntrospectedColumn>> entry = (Map.Entry)localIterator1.next();
/* 379 */       localIterator2 = ((List)entry.getValue()).iterator(); continue;IntrospectedColumn introspectedColumn = (IntrospectedColumn)localIterator2.next();
/* 380 */       ColumnOverride columnOverride = tc
/* 381 */         .getColumnOverride(introspectedColumn
/* 382 */         .getActualColumnName());
/*     */       
/* 384 */       if (columnOverride != null) {
/* 385 */         if (this.logger.isDebugEnabled()) {
/* 386 */           this.logger.debug(Messages.getString("Tracing.4", 
/* 387 */             introspectedColumn.getActualColumnName(), 
/* 388 */             ((ActualTableName)entry.getKey()).toString()));
/*     */         }
/*     */         
/* 391 */         if (StringUtility.stringHasValue(columnOverride
/* 392 */           .getJavaProperty())) {
/* 393 */           introspectedColumn.setJavaProperty(columnOverride
/* 394 */             .getJavaProperty());
/*     */         }
/*     */         
/* 397 */         if (StringUtility.stringHasValue(columnOverride
/* 398 */           .getJavaType()))
/*     */         {
/* 400 */           introspectedColumn.setFullyQualifiedJavaType(new FullyQualifiedJavaType(
/* 401 */             columnOverride.getJavaType()));
/*     */         }
/*     */         
/* 404 */         if (StringUtility.stringHasValue(columnOverride
/* 405 */           .getJdbcType())) {
/* 406 */           introspectedColumn.setJdbcTypeName(columnOverride
/* 407 */             .getJdbcType());
/*     */         }
/*     */         
/* 410 */         if (StringUtility.stringHasValue(columnOverride
/* 411 */           .getTypeHandler())) {
/* 412 */           introspectedColumn.setTypeHandler(columnOverride
/* 413 */             .getTypeHandler());
/*     */         }
/*     */         
/* 416 */         if (columnOverride.isColumnNameDelimited()) {
/* 417 */           introspectedColumn.setColumnNameDelimited(true);
/*     */         }
/*     */         
/* 420 */         introspectedColumn.setProperties(columnOverride
/* 421 */           .getProperties());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Map<ActualTableName, List<IntrospectedColumn>> getColumns(TableConfiguration tc)
/*     */     throws SQLException
/*     */   {
/* 441 */     boolean delimitIdentifiers = (tc.isDelimitIdentifiers()) || 
/* 442 */       (StringUtility.stringContainsSpace(tc.getCatalog())) || 
/* 443 */       (StringUtility.stringContainsSpace(tc.getSchema())) || 
/* 444 */       (StringUtility.stringContainsSpace(tc.getTableName()));
/*     */     String localTableName;
/* 446 */     String localCatalog; String localSchema; String localTableName; if (delimitIdentifiers) {
/* 447 */       String localCatalog = tc.getCatalog();
/* 448 */       String localSchema = tc.getSchema();
/* 449 */       localTableName = tc.getTableName(); } else { String localTableName;
/* 450 */       if (this.databaseMetaData.storesLowerCaseIdentifiers()) {
/* 451 */         String localCatalog = tc.getCatalog() == null ? null : tc.getCatalog()
/* 452 */           .toLowerCase();
/* 453 */         String localSchema = tc.getSchema() == null ? null : tc.getSchema()
/* 454 */           .toLowerCase();
/* 455 */         localTableName = tc.getTableName() == null ? null : tc
/* 456 */           .getTableName().toLowerCase(); } else { String localTableName;
/* 457 */         if (this.databaseMetaData.storesUpperCaseIdentifiers()) {
/* 458 */           String localCatalog = tc.getCatalog() == null ? null : tc.getCatalog()
/* 459 */             .toUpperCase();
/* 460 */           String localSchema = tc.getSchema() == null ? null : tc.getSchema()
/* 461 */             .toUpperCase();
/* 462 */           localTableName = tc.getTableName() == null ? null : tc
/* 463 */             .getTableName().toUpperCase();
/*     */         } else {
/* 465 */           localCatalog = tc.getCatalog();
/* 466 */           localSchema = tc.getSchema();
/* 467 */           localTableName = tc.getTableName();
/*     */         }
/*     */       } }
/* 470 */     if (tc.isWildcardEscapingEnabled()) {
/* 471 */       String escapeString = this.databaseMetaData.getSearchStringEscape();
/*     */       
/* 473 */       StringBuilder sb = new StringBuilder();
/*     */       
/* 475 */       if (localSchema != null) {
/* 476 */         StringTokenizer st = new StringTokenizer(localSchema, "_%", true);
/* 477 */         while (st.hasMoreTokens()) {
/* 478 */           String token = st.nextToken();
/* 479 */           if ((token.equals("_")) || 
/* 480 */             (token.equals("%"))) {
/* 481 */             sb.append(escapeString);
/*     */           }
/* 483 */           sb.append(token);
/*     */         }
/* 485 */         localSchema = sb.toString();
/*     */       }
/*     */       
/* 488 */       sb.setLength(0);
/* 489 */       StringTokenizer st = new StringTokenizer(localTableName, "_%", true);
/* 490 */       while (st.hasMoreTokens()) {
/* 491 */         String token = st.nextToken();
/* 492 */         if ((token.equals("_")) || 
/* 493 */           (token.equals("%"))) {
/* 494 */           sb.append(escapeString);
/*     */         }
/* 496 */         sb.append(token);
/*     */       }
/* 498 */       localTableName = sb.toString();
/*     */     }
/*     */     
/* 501 */     Map<ActualTableName, List<IntrospectedColumn>> answer = new HashMap();
/*     */     
/* 503 */     if (this.logger.isDebugEnabled()) {
/* 504 */       String fullTableName = StringUtility.composeFullyQualifiedTableName(localCatalog, localSchema, 
/* 505 */         localTableName, '.');
/* 506 */       this.logger.debug(Messages.getString("Tracing.1", fullTableName));
/*     */     }
/*     */     
/* 509 */     ResultSet rs = this.databaseMetaData.getColumns(localCatalog, localSchema, 
/* 510 */       localTableName, null);
/*     */     
/* 512 */     while (rs.next()) {
/* 513 */       IntrospectedColumn introspectedColumn = 
/* 514 */         ObjectFactory.createIntrospectedColumn(this.context);
/*     */       
/* 516 */       introspectedColumn.setTableAlias(tc.getAlias());
/* 517 */       introspectedColumn.setJdbcType(rs.getInt("DATA_TYPE"));
/* 518 */       introspectedColumn.setLength(rs.getInt("COLUMN_SIZE"));
/* 519 */       introspectedColumn.setActualColumnName(rs.getString("COLUMN_NAME"));
/* 520 */       introspectedColumn
/* 521 */         .setNullable(rs.getInt("NULLABLE") == 1);
/* 522 */       introspectedColumn.setScale(rs.getInt("DECIMAL_DIGITS"));
/* 523 */       introspectedColumn.setRemarks(rs.getString("REMARKS"));
/* 524 */       introspectedColumn.setDefaultValue(rs.getString("COLUMN_DEF"));
/*     */       
/* 526 */       ActualTableName atn = new ActualTableName(
/* 527 */         rs.getString("TABLE_CAT"), 
/* 528 */         rs.getString("TABLE_SCHEM"), 
/* 529 */         rs.getString("TABLE_NAME"));
/*     */       
/* 531 */       List<IntrospectedColumn> columns = (List)answer.get(atn);
/* 532 */       if (columns == null) {
/* 533 */         columns = new ArrayList();
/* 534 */         answer.put(atn, columns);
/*     */       }
/*     */       
/* 537 */       columns.add(introspectedColumn);
/*     */       
/* 539 */       if (this.logger.isDebugEnabled()) {
/* 540 */         this.logger.debug(Messages.getString(
/* 541 */           "Tracing.2", 
/* 542 */           introspectedColumn.getActualColumnName(), 
/* 543 */           Integer.toString(introspectedColumn.getJdbcType()), 
/* 544 */           atn.toString()));
/*     */       }
/*     */     }
/*     */     
/* 548 */     closeResultSet(rs);
/*     */     
/* 550 */     if ((answer.size() > 1) && 
/* 551 */       (!StringUtility.stringContainsSQLWildcard(localSchema)) && 
/* 552 */       (!StringUtility.stringContainsSQLWildcard(localTableName)))
/*     */     {
/*     */ 
/* 555 */       ActualTableName inputAtn = new ActualTableName(tc.getCatalog(), tc
/* 556 */         .getSchema(), tc.getTableName());
/*     */       
/* 558 */       StringBuilder sb = new StringBuilder();
/* 559 */       boolean comma = false;
/* 560 */       for (ActualTableName atn : answer.keySet()) {
/* 561 */         if (comma) {
/* 562 */           sb.append(',');
/*     */         } else {
/* 564 */           comma = true;
/*     */         }
/* 566 */         sb.append(atn.toString());
/*     */       }
/*     */       
/* 569 */       this.warnings.add(Messages.getString("Warning.25", 
/* 570 */         inputAtn.toString(), sb.toString()));
/*     */     }
/*     */     
/* 573 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */   private List<IntrospectedTable> calculateIntrospectedTables(TableConfiguration tc, Map<ActualTableName, List<IntrospectedColumn>> columns)
/*     */   {
/* 579 */     boolean delimitIdentifiers = (tc.isDelimitIdentifiers()) || 
/* 580 */       (StringUtility.stringContainsSpace(tc.getCatalog())) || 
/* 581 */       (StringUtility.stringContainsSpace(tc.getSchema())) || 
/* 582 */       (StringUtility.stringContainsSpace(tc.getTableName()));
/*     */     
/* 584 */     List<IntrospectedTable> answer = new ArrayList();
/*     */     
/*     */ 
/* 587 */     Iterator localIterator1 = columns.entrySet().iterator();
/* 586 */     while (localIterator1.hasNext()) {
/* 587 */       Map.Entry<ActualTableName, List<IntrospectedColumn>> entry = (Map.Entry)localIterator1.next();
/* 588 */       ActualTableName atn = (ActualTableName)entry.getKey();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 602 */       String domainObjectName = tc.getDomainObjectName();
/* 603 */       YouGouTableSettingConfiguration settingConfig = this.context.getYouGouTableSettingConfiguration();
/* 604 */       String temp; if (settingConfig != null) {
/* 605 */         for (Map.Entry<String, String> e : settingConfig.getReplaceTablePrefixMap().entrySet()) {
/* 606 */           if (domainObjectName != null) {
/* 607 */             temp = domainObjectName.replaceFirst((String)e.getKey(), (String)e.getValue());
/* 608 */             if (!temp.equals(domainObjectName)) {
/* 609 */               domainObjectName = temp;
/* 610 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 621 */       String runtimeTableName = tc.getTableName().toLowerCase();
/* 622 */       if (settingConfig != null) {
/* 623 */         for (Object e : settingConfig.getReplaceTablePrefixMap().entrySet()) {
/* 624 */           if (runtimeTableName != null) {
/* 625 */             String temp = runtimeTableName.replaceFirst((String)((Map.Entry)e).getKey(), (String)((Map.Entry)e).getValue());
/* 626 */             if (!temp.equals(runtimeTableName)) {
/* 627 */               runtimeTableName = temp;
/* 628 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 635 */       FullyQualifiedTable table = new FullyQualifiedTable(
/* 636 */         StringUtility.stringHasValue(tc.getCatalog()) ? atn
/* 637 */         .getCatalog() : null, 
/* 638 */         StringUtility.stringHasValue(tc.getSchema()) ? atn
/* 639 */         .getSchema() : null, 
/* 640 */         tc.getTableName(), 
/* 641 */         domainObjectName, 
/* 642 */         tc.getAlias(), 
/* 643 */         StringUtility.isTrue(tc.getProperty("ignoreQualifiersAtRuntime")), 
/* 644 */         tc.getProperty("runtimeCatalog"), 
/* 645 */         tc.getProperty("runtimeSchema"), 
/* 646 */         runtimeTableName, 
/* 647 */         delimitIdentifiers, this.context);
/*     */       
/* 649 */       IntrospectedTable introspectedTable = 
/* 650 */         ObjectFactory.createIntrospectedTable(tc, table, this.context);
/*     */       
/* 652 */       for (IntrospectedColumn introspectedColumn : (List)entry.getValue()) {
/* 653 */         introspectedTable.addColumn(introspectedColumn);
/*     */       }
/*     */       
/* 656 */       calculatePrimaryKey(table, introspectedTable);
/*     */       
/* 658 */       answer.add(introspectedTable);
/*     */     }
/*     */     
/* 661 */     return answer;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\db\DatabaseIntrospector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */