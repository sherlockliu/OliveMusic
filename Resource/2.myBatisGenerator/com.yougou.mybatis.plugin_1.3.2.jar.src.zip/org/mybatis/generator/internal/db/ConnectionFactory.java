/*    */ package org.mybatis.generator.internal.db;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.Driver;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ import org.mybatis.generator.config.JDBCConnectionConfiguration;
/*    */ import org.mybatis.generator.internal.ObjectFactory;
/*    */ import org.mybatis.generator.internal.util.StringUtility;
/*    */ import org.mybatis.generator.internal.util.messages.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConnectionFactory
/*    */ {
/* 39 */   private static ConnectionFactory instance = new ConnectionFactory();
/*    */   
/*    */   public static ConnectionFactory getInstance() {
/* 42 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Connection getConnection(JDBCConnectionConfiguration config)
/*    */     throws SQLException
/*    */   {
/* 54 */     Driver driver = getDriver(config);
/*    */     
/* 56 */     Properties props = new Properties();
/*    */     
/*    */ 
/*    */ 
/* 60 */     props.put("remarksReporting", "true");
/*    */     
/* 62 */     if (StringUtility.stringHasValue(config.getUserId())) {
/* 63 */       props.setProperty("user", config.getUserId());
/*    */     }
/*    */     
/* 66 */     if (StringUtility.stringHasValue(config.getPassword())) {
/* 67 */       props.setProperty("password", config.getPassword());
/*    */     }
/*    */     
/* 70 */     props.putAll(config.getProperties());
/*    */     
/* 72 */     Connection conn = driver.connect(config.getConnectionURL(), props);
/*    */     
/* 74 */     if (conn == null) {
/* 75 */       throw new SQLException(Messages.getString("RuntimeError.7"));
/*    */     }
/*    */     
/* 78 */     return conn;
/*    */   }
/*    */   
/*    */   private Driver getDriver(JDBCConnectionConfiguration connectionInformation) {
/* 82 */     String driverClass = connectionInformation.getDriverClass();
/*    */     
/*    */     try
/*    */     {
/* 86 */       Class<?> clazz = ObjectFactory.externalClassForName(driverClass);
/* 87 */       driver = (Driver)clazz.newInstance();
/*    */     } catch (Exception e) { Driver driver;
/* 89 */       throw new RuntimeException(Messages.getString("RuntimeError.8"), e);
/*    */     }
/*    */     Driver driver;
/* 92 */     return driver;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\db\ConnectionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */