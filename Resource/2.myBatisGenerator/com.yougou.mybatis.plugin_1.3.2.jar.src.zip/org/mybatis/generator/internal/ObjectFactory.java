/*     */ package org.mybatis.generator.internal;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.FullyQualifiedTable;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.JavaFormatter;
/*     */ import org.mybatis.generator.api.JavaTypeResolver;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.XmlFormatter;
/*     */ import org.mybatis.generator.api.dom.DefaultJavaFormatter;
/*     */ import org.mybatis.generator.api.dom.DefaultXmlFormatter;
/*     */ import org.mybatis.generator.codegen.ibatis2.IntrospectedTableIbatis2Java2Impl;
/*     */ import org.mybatis.generator.codegen.ibatis2.IntrospectedTableIbatis2Java5Impl;
/*     */ import org.mybatis.generator.codegen.mybatis3.IntrospectedTableMyBatis3Impl;
/*     */ import org.mybatis.generator.codegen.mybatis3.IntrospectedTableMyBatis3SimpleImpl;
/*     */ import org.mybatis.generator.config.CommentGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.JavaTypeResolverConfiguration;
/*     */ import org.mybatis.generator.config.PluginConfiguration;
/*     */ import org.mybatis.generator.config.TableConfiguration;
/*     */ import org.mybatis.generator.internal.types.JavaTypeResolverDefaultImpl;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjectFactory
/*     */ {
/*  58 */   private static List<ClassLoader> externalClassLoaders = new ArrayList();
/*  59 */   private static List<ClassLoader> resourceClassLoaders = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void addResourceClassLoader(ClassLoader classLoader)
/*     */   {
/*  79 */     resourceClassLoaders.add(classLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static synchronized void addExternalClassLoader(ClassLoader classLoader)
/*     */   {
/*  93 */     externalClassLoaders.add(classLoader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Class<?> externalClassForName(String type)
/*     */     throws ClassNotFoundException
/*     */   {
/* 111 */     for (ClassLoader classLoader : externalClassLoaders) {
/*     */       try {
/* 113 */         return Class.forName(type, true, classLoader);
/*     */       }
/*     */       catch (Throwable localThrowable) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 121 */     return internalClassForName(type);
/*     */   }
/*     */   
/*     */   public static Object createExternalObject(String type)
/*     */   {
/*     */     try
/*     */     {
/* 128 */       Class<?> clazz = externalClassForName(type);
/* 129 */       answer = clazz.newInstance();
/*     */     } catch (Exception e) { Object answer;
/* 131 */       throw new RuntimeException(Messages.getString(
/* 132 */         "RuntimeError.6", type), e);
/*     */     }
/*     */     Object answer;
/* 135 */     return answer;
/*     */   }
/*     */   
/*     */   public static Class<?> internalClassForName(String type) throws ClassNotFoundException
/*     */   {
/* 140 */     Class<?> clazz = null;
/*     */     try
/*     */     {
/* 143 */       ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 144 */       clazz = Class.forName(type, true, cl);
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*     */ 
/* 149 */     if (clazz == null) {
/* 150 */       clazz = Class.forName(type, true, ObjectFactory.class.getClassLoader());
/*     */     }
/*     */     
/* 153 */     return clazz;
/*     */   }
/*     */   
/*     */ 
/*     */   public static URL getResource(String resource)
/*     */   {
/* 159 */     for (ClassLoader classLoader : resourceClassLoaders) {
/* 160 */       URL url = classLoader.getResource(resource);
/* 161 */       if (url != null) {
/* 162 */         return url;
/*     */       }
/*     */     }
/*     */     
/* 166 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 167 */     URL url = cl.getResource(resource);
/*     */     
/* 169 */     if (url == null) {
/* 170 */       url = ObjectFactory.class.getClassLoader().getResource(resource);
/*     */     }
/*     */     
/* 173 */     return url;
/*     */   }
/*     */   
/*     */   public static Object createInternalObject(String type)
/*     */   {
/*     */     try
/*     */     {
/* 180 */       Class<?> clazz = internalClassForName(type);
/*     */       
/* 182 */       answer = clazz.newInstance();
/*     */     } catch (Exception e) { Object answer;
/* 184 */       throw new RuntimeException(Messages.getString(
/* 185 */         "RuntimeError.6", type), e);
/*     */     }
/*     */     
/*     */     Object answer;
/* 189 */     return answer;
/*     */   }
/*     */   
/*     */   public static JavaTypeResolver createJavaTypeResolver(Context context, List<String> warnings)
/*     */   {
/* 194 */     JavaTypeResolverConfiguration config = context
/* 195 */       .getJavaTypeResolverConfiguration();
/*     */     
/*     */     String type;
/* 198 */     if ((config != null) && (config.getConfigurationType() != null)) {
/* 199 */       String type = config.getConfigurationType();
/* 200 */       if ("DEFAULT".equalsIgnoreCase(type)) {
/* 201 */         type = JavaTypeResolverDefaultImpl.class.getName();
/*     */       }
/*     */     } else {
/* 204 */       type = JavaTypeResolverDefaultImpl.class.getName();
/*     */     }
/*     */     
/* 207 */     JavaTypeResolver answer = (JavaTypeResolver)createInternalObject(type);
/* 208 */     answer.setWarnings(warnings);
/*     */     
/* 210 */     if (config != null) {
/* 211 */       answer.addConfigurationProperties(config.getProperties());
/*     */     }
/*     */     
/* 214 */     answer.setContext(context);
/*     */     
/* 216 */     return answer;
/*     */   }
/*     */   
/*     */   public static Plugin createPlugin(Context context, PluginConfiguration pluginConfiguration)
/*     */   {
/* 221 */     Plugin plugin = (Plugin)createInternalObject(pluginConfiguration
/* 222 */       .getConfigurationType());
/* 223 */     plugin.setContext(context);
/* 224 */     plugin.setProperties(pluginConfiguration.getProperties());
/* 225 */     return plugin;
/*     */   }
/*     */   
/*     */   public static CommentGenerator createCommentGenerator(Context context)
/*     */   {
/* 230 */     CommentGeneratorConfiguration config = context
/* 231 */       .getCommentGeneratorConfiguration();
/*     */     
/*     */     String type;
/*     */     String type;
/* 235 */     if ((config == null) || (config.getConfigurationType() == null))
/*     */     {
/* 237 */       type = YougouCommentGenerator.class.getName();
/*     */     } else {
/* 239 */       type = config.getConfigurationType();
/*     */     }
/*     */     
/* 242 */     CommentGenerator answer = (CommentGenerator)createInternalObject(type);
/*     */     
/* 244 */     if (config != null) {
/* 245 */       answer.addConfigurationProperties(config.getProperties());
/*     */     }
/*     */     
/* 248 */     return answer;
/*     */   }
/*     */   
/*     */   public static JavaFormatter createJavaFormatter(Context context) {
/* 252 */     String type = context.getProperty("javaFormatter");
/* 253 */     if (!StringUtility.stringHasValue(type)) {
/* 254 */       type = DefaultJavaFormatter.class.getName();
/*     */     }
/*     */     
/* 257 */     JavaFormatter answer = (JavaFormatter)createInternalObject(type);
/*     */     
/* 259 */     answer.setContext(context);
/*     */     
/* 261 */     return answer;
/*     */   }
/*     */   
/*     */   public static XmlFormatter createXmlFormatter(Context context) {
/* 265 */     String type = context.getProperty("xmlFormatter");
/* 266 */     if (!StringUtility.stringHasValue(type)) {
/* 267 */       type = DefaultXmlFormatter.class.getName();
/*     */     }
/*     */     
/* 270 */     XmlFormatter answer = (XmlFormatter)createInternalObject(type);
/*     */     
/* 272 */     answer.setContext(context);
/*     */     
/* 274 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static IntrospectedTable createIntrospectedTable(TableConfiguration tableConfiguration, FullyQualifiedTable table, Context context)
/*     */   {
/* 281 */     IntrospectedTable answer = createIntrospectedTableForValidation(context);
/* 282 */     answer.setFullyQualifiedTable(table);
/* 283 */     answer.setTableConfiguration(tableConfiguration);
/*     */     
/* 285 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IntrospectedTable createIntrospectedTableForValidation(Context context)
/*     */   {
/* 297 */     String type = context.getTargetRuntime();
/* 298 */     if (!StringUtility.stringHasValue(type)) {
/* 299 */       type = IntrospectedTableMyBatis3Impl.class.getName();
/* 300 */     } else if ("Ibatis2Java2".equalsIgnoreCase(type)) {
/* 301 */       type = IntrospectedTableIbatis2Java2Impl.class.getName();
/* 302 */     } else if ("Ibatis2Java5".equalsIgnoreCase(type)) {
/* 303 */       type = IntrospectedTableIbatis2Java5Impl.class.getName();
/* 304 */     } else if ("Ibatis3".equalsIgnoreCase(type)) {
/* 305 */       type = IntrospectedTableMyBatis3Impl.class.getName();
/* 306 */     } else if ("MyBatis3".equalsIgnoreCase(type)) {
/* 307 */       type = IntrospectedTableMyBatis3Impl.class.getName();
/* 308 */     } else if ("MyBatis3Simple".equalsIgnoreCase(type)) {
/* 309 */       type = IntrospectedTableMyBatis3SimpleImpl.class.getName();
/*     */     }
/*     */     
/* 312 */     IntrospectedTable answer = (IntrospectedTable)createInternalObject(type);
/* 313 */     answer.setContext(context);
/*     */     
/* 315 */     return answer;
/*     */   }
/*     */   
/*     */   public static IntrospectedColumn createIntrospectedColumn(Context context) {
/* 319 */     String type = context.getIntrospectedColumnImpl();
/* 320 */     if (!StringUtility.stringHasValue(type)) {
/* 321 */       type = IntrospectedColumn.class.getName();
/*     */     }
/*     */     
/* 324 */     IntrospectedColumn answer = (IntrospectedColumn)createInternalObject(type);
/* 325 */     answer.setContext(context);
/*     */     
/* 327 */     return answer;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\ObjectFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */