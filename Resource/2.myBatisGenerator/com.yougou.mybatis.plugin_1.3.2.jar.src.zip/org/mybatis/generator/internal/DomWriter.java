/*     */ package org.mybatis.generator.internal;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Method;
/*     */ import org.mybatis.generator.exception.ShellException;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.CDATASection;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.EntityReference;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.ProcessingInstruction;
/*     */ import org.w3c.dom.Text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DomWriter
/*     */ {
/*     */   protected PrintWriter printWriter;
/*     */   protected boolean isXML11;
/*     */   
/*     */   public synchronized String toString(Document document)
/*     */     throws ShellException
/*     */   {
/*  57 */     StringWriter sw = new StringWriter();
/*  58 */     this.printWriter = new PrintWriter(sw);
/*  59 */     write(document);
/*  60 */     String s = sw.toString();
/*  61 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */   protected Attr[] sortAttributes(NamedNodeMap attrs)
/*     */   {
/*  67 */     int len = attrs != null ? attrs.getLength() : 0;
/*  68 */     Attr[] array = new Attr[len];
/*  69 */     for (int i = 0; i < len; i++) {
/*  70 */       array[i] = ((Attr)attrs.item(i));
/*     */     }
/*  72 */     for (int i = 0; i < len - 1; i++) {
/*  73 */       String name = array[i].getNodeName();
/*  74 */       int index = i;
/*  75 */       for (int j = i + 1; j < len; j++) {
/*  76 */         String curName = array[j].getNodeName();
/*  77 */         if (curName.compareTo(name) < 0) {
/*  78 */           name = curName;
/*  79 */           index = j;
/*     */         }
/*     */       }
/*  82 */       if (index != i) {
/*  83 */         Attr temp = array[i];
/*  84 */         array[i] = array[index];
/*  85 */         array[index] = temp;
/*     */       }
/*     */     }
/*     */     
/*  89 */     return array;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void normalizeAndPrint(String s, boolean isAttValue)
/*     */   {
/*  96 */     int len = s != null ? s.length() : 0;
/*  97 */     for (int i = 0; i < len; i++) {
/*  98 */       char c = s.charAt(i);
/*  99 */       normalizeAndPrint(c, isAttValue);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void normalizeAndPrint(char c, boolean isAttValue)
/*     */   {
/* 107 */     switch (c) {
/*     */     case '<': 
/* 109 */       this.printWriter.print("&lt;");
/* 110 */       break;
/*     */     
/*     */     case '>': 
/* 113 */       this.printWriter.print("&gt;");
/* 114 */       break;
/*     */     
/*     */     case '&': 
/* 117 */       this.printWriter.print("&amp;");
/* 118 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */     case '"': 
/* 123 */       if (isAttValue) {
/* 124 */         this.printWriter.print("&quot;");
/*     */       } else {
/* 126 */         this.printWriter.print('"');
/*     */       }
/* 128 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case '\r': 
/* 135 */       this.printWriter.print("&#xD;");
/* 136 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     default: 
/* 149 */       if (((this.isXML11) && (
/* 150 */         ((c >= '\001') && (c <= '\037') && (c != '\t') && (c != '\n')) || 
/* 151 */         ((c >= '') && (c <= '')) || (c == ' '))) || (
/* 152 */         (isAttValue) && ((c == '\t') || (c == '\n')))) {
/* 153 */         this.printWriter.print("&#x");
/* 154 */         this.printWriter.print(Integer.toHexString(c).toUpperCase());
/* 155 */         this.printWriter.print(';');
/*     */       } else {
/* 157 */         this.printWriter.print(c);
/*     */       }
/*     */       break;
/*     */     }
/*     */   }
/*     */   
/*     */   protected String getVersion(Document document)
/*     */   {
/* 165 */     if (document == null) {
/* 166 */       return null;
/*     */     }
/* 168 */     String version = null;
/* 169 */     Method getXMLVersion = null;
/*     */     try {
/* 171 */       getXMLVersion = document.getClass().getMethod("getXmlVersion", 
/* 172 */         new Class[0]);
/*     */       
/* 174 */       if (getXMLVersion != null) {
/* 175 */         version = (String)getXMLVersion.invoke(document, 
/* 176 */           null);
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*     */ 
/* 182 */     return version;
/*     */   }
/*     */   
/*     */   protected void writeAnyNode(Node node) throws ShellException
/*     */   {
/* 187 */     if (node == null) {
/* 188 */       return;
/*     */     }
/*     */     
/* 191 */     short type = node.getNodeType();
/* 192 */     switch (type) {
/*     */     case 9: 
/* 194 */       write((Document)node);
/* 195 */       break;
/*     */     
/*     */     case 10: 
/* 198 */       write((DocumentType)node);
/* 199 */       break;
/*     */     
/*     */     case 1: 
/* 202 */       write((Element)node);
/* 203 */       break;
/*     */     
/*     */     case 5: 
/* 206 */       write((EntityReference)node);
/* 207 */       break;
/*     */     
/*     */     case 4: 
/* 210 */       write((CDATASection)node);
/* 211 */       break;
/*     */     
/*     */     case 3: 
/* 214 */       write((Text)node);
/* 215 */       break;
/*     */     
/*     */     case 7: 
/* 218 */       write((ProcessingInstruction)node);
/* 219 */       break;
/*     */     
/*     */     case 8: 
/* 222 */       write((Comment)node);
/* 223 */       break;
/*     */     case 2: case 6: 
/*     */     default: 
/* 226 */       throw new ShellException(Messages.getString(
/* 227 */         "RuntimeError.18", Short.toString(type)));
/*     */     }
/*     */   }
/*     */   
/*     */   protected void write(Document node) throws ShellException {
/* 232 */     this.isXML11 = "1.1".equals(getVersion(node));
/* 233 */     if (this.isXML11) {
/* 234 */       this.printWriter.println("<?xml version=\"1.1\" encoding=\"UTF-8\"?>");
/*     */     } else {
/* 236 */       this.printWriter.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
/*     */     }
/* 238 */     this.printWriter.flush();
/* 239 */     write(node.getDoctype());
/* 240 */     write(node.getDocumentElement());
/*     */   }
/*     */   
/*     */   protected void write(DocumentType node) throws ShellException {
/* 244 */     this.printWriter.print("<!DOCTYPE ");
/* 245 */     this.printWriter.print(node.getName());
/* 246 */     String publicId = node.getPublicId();
/* 247 */     String systemId = node.getSystemId();
/* 248 */     if (publicId != null) {
/* 249 */       this.printWriter.print(" PUBLIC \"");
/* 250 */       this.printWriter.print(publicId);
/* 251 */       this.printWriter.print("\" \"");
/* 252 */       this.printWriter.print(systemId);
/* 253 */       this.printWriter.print('"');
/* 254 */     } else if (systemId != null) {
/* 255 */       this.printWriter.print(" SYSTEM \"");
/* 256 */       this.printWriter.print(systemId);
/* 257 */       this.printWriter.print('"');
/*     */     }
/*     */     
/* 260 */     String internalSubset = node.getInternalSubset();
/* 261 */     if (internalSubset != null) {
/* 262 */       this.printWriter.println(" [");
/* 263 */       this.printWriter.print(internalSubset);
/* 264 */       this.printWriter.print(']');
/*     */     }
/* 266 */     this.printWriter.println('>');
/*     */   }
/*     */   
/*     */   protected void write(Element node) throws ShellException {
/* 270 */     this.printWriter.print('<');
/* 271 */     this.printWriter.print(node.getNodeName());
/* 272 */     Attr[] attrs = sortAttributes(node.getAttributes());
/* 273 */     Attr[] arrayOfAttr1; int j = (arrayOfAttr1 = attrs).length; for (int i = 0; i < j; i++) { Attr attr = arrayOfAttr1[i];
/* 274 */       this.printWriter.print(' ');
/* 275 */       this.printWriter.print(attr.getNodeName());
/* 276 */       this.printWriter.print("=\"");
/* 277 */       normalizeAndPrint(attr.getNodeValue(), true);
/* 278 */       this.printWriter.print('"');
/*     */     }
/*     */     
/* 281 */     if (node.getChildNodes().getLength() == 0) {
/* 282 */       this.printWriter.print(" />");
/* 283 */       this.printWriter.flush();
/*     */     } else {
/* 285 */       this.printWriter.print('>');
/* 286 */       this.printWriter.flush();
/*     */       
/* 288 */       Node child = node.getFirstChild();
/* 289 */       while (child != null) {
/* 290 */         writeAnyNode(child);
/* 291 */         child = child.getNextSibling();
/*     */       }
/*     */       
/* 294 */       this.printWriter.print("</");
/* 295 */       this.printWriter.print(node.getNodeName());
/* 296 */       this.printWriter.print('>');
/* 297 */       this.printWriter.flush();
/*     */     }
/*     */   }
/*     */   
/*     */   protected void write(EntityReference node) {
/* 302 */     this.printWriter.print('&');
/* 303 */     this.printWriter.print(node.getNodeName());
/* 304 */     this.printWriter.print(';');
/* 305 */     this.printWriter.flush();
/*     */   }
/*     */   
/*     */   protected void write(CDATASection node) {
/* 309 */     this.printWriter.print("<![CDATA[");
/* 310 */     this.printWriter.print(node.getNodeValue());
/* 311 */     this.printWriter.print("]]>");
/* 312 */     this.printWriter.flush();
/*     */   }
/*     */   
/*     */   protected void write(Text node) {
/* 316 */     normalizeAndPrint(node.getNodeValue(), false);
/* 317 */     this.printWriter.flush();
/*     */   }
/*     */   
/*     */   protected void write(ProcessingInstruction node) {
/* 321 */     this.printWriter.print("<?");
/* 322 */     this.printWriter.print(node.getNodeName());
/* 323 */     String data = node.getNodeValue();
/* 324 */     if ((data != null) && (data.length() > 0)) {
/* 325 */       this.printWriter.print(' ');
/* 326 */       this.printWriter.print(data);
/*     */     }
/* 328 */     this.printWriter.print("?>");
/* 329 */     this.printWriter.flush();
/*     */   }
/*     */   
/*     */   protected void write(Comment node) {
/* 333 */     this.printWriter.print("<!--");
/* 334 */     String comment = node.getNodeValue();
/* 335 */     if ((comment != null) && (comment.length() > 0)) {
/* 336 */       this.printWriter.print(comment);
/*     */     }
/* 338 */     this.printWriter.print("-->");
/* 339 */     this.printWriter.flush();
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\DomWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */