package org.mybatis.generator.internal;

import org.mybatis.generator.api.ProgressCallback;

public class NullProgressCallback
  implements ProgressCallback
{
  public void generationStarted(int totalTasks) {}
  
  public void introspectionStarted(int totalTasks) {}
  
  public void saveStarted(int totalTasks) {}
  
  public void startTask(String taskName) {}
  
  public void checkCancel()
    throws InterruptedException
  {}
  
  public void done() {}
}


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\NullProgressCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */