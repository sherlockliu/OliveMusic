/*    */ package org.mybatis.generator.internal.util;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URI;
/*    */ import java.net.URL;
/*    */ import java.net.URLClassLoader;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.mybatis.generator.internal.util.messages.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ClassloaderUtility
/*    */ {
/*    */   public static ClassLoader getCustomClassloader(List<String> entries)
/*    */   {
/* 43 */     List<URL> urls = new ArrayList();
/*    */     
/*    */ 
/* 46 */     if (entries != null) {
/* 47 */       for (String classPathEntry : entries) {
/* 48 */         File file = new File(classPathEntry);
/* 49 */         if (!file.exists()) {
/* 50 */           throw new RuntimeException(Messages.getString(
/* 51 */             "RuntimeError.9", classPathEntry));
/*    */         }
/*    */         try
/*    */         {
/* 55 */           urls.add(file.toURI().toURL());
/*    */         }
/*    */         catch (MalformedURLException localMalformedURLException) {
/* 58 */           throw new RuntimeException(Messages.getString(
/* 59 */             "RuntimeError.9", classPathEntry));
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 64 */     ClassLoader parent = Thread.currentThread().getContextClassLoader();
/*    */     
/* 66 */     URLClassLoader ucl = new URLClassLoader((URL[])urls.toArray(
/* 67 */       new URL[urls.size()]), parent);
/*    */     
/* 69 */     return ucl;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\util\ClassloaderUtility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */