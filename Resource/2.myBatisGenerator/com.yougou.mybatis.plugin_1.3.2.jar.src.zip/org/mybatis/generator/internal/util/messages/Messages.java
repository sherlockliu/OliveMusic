/*    */ package org.mybatis.generator.internal.util.messages;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.MissingResourceException;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Messages
/*    */ {
/*    */   private static final String BUNDLE_NAME = "org.mybatis.generator.internal.util.messages.messages";
/* 29 */   private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle("org.mybatis.generator.internal.util.messages.messages");
/*    */   
/*    */ 
/*    */   public static String getString(String key)
/*    */   {
/*    */     try
/*    */     {
/* 36 */       return RESOURCE_BUNDLE.getString(key);
/*    */     } catch (MissingResourceException localMissingResourceException) {}
/* 38 */     return '!' + key + '!';
/*    */   }
/*    */   
/*    */   public static String getString(String key, String parm1)
/*    */   {
/*    */     try {
/* 44 */       return MessageFormat.format(RESOURCE_BUNDLE.getString(key), 
/* 45 */         new Object[] { parm1 });
/*    */     } catch (MissingResourceException localMissingResourceException) {}
/* 47 */     return '!' + key + '!';
/*    */   }
/*    */   
/*    */   public static String getString(String key, String parm1, String parm2)
/*    */   {
/*    */     try {
/* 53 */       return MessageFormat.format(RESOURCE_BUNDLE.getString(key), 
/* 54 */         new Object[] { parm1, parm2 });
/*    */     } catch (MissingResourceException localMissingResourceException) {}
/* 56 */     return '!' + key + '!';
/*    */   }
/*    */   
/*    */   public static String getString(String key, String parm1, String parm2, String parm3)
/*    */   {
/*    */     try
/*    */     {
/* 63 */       return MessageFormat.format(RESOURCE_BUNDLE.getString(key), 
/* 64 */         new Object[] { parm1, parm2, parm3 });
/*    */     } catch (MissingResourceException localMissingResourceException) {}
/* 66 */     return '!' + key + '!';
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\util\messages\Messages.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */