/*     */ package org.mybatis.generator.internal;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.mybatis.generator.api.GeneratedXmlFile;
/*     */ import org.mybatis.generator.config.MergeConstants;
/*     */ import org.mybatis.generator.exception.ShellException;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ import org.w3c.dom.Comment;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.w3c.dom.Text;
/*     */ import org.xml.sax.EntityResolver;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlFileMergerJaxp
/*     */ {
/*     */   private static class NullEntityResolver
/*     */     implements EntityResolver
/*     */   {
/*     */     public InputSource resolveEntity(String publicId, String systemId)
/*     */       throws SAXException, IOException
/*     */     {
/*  62 */       StringReader sr = new StringReader("");
/*     */       
/*  64 */       return new InputSource(sr);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getMergedSource(GeneratedXmlFile generatedXmlFile, File existingFile)
/*     */     throws ShellException
/*     */   {
/*     */     try
/*     */     {
/*  79 */       return getMergedSource(new InputSource(new StringReader(generatedXmlFile.getFormattedContent())), 
/*  80 */         new InputSource(new InputStreamReader(new FileInputStream(existingFile), "UTF-8")), 
/*  81 */         existingFile.getName());
/*     */     } catch (IOException e) {
/*  83 */       throw new ShellException(Messages.getString("Warning.13", 
/*  84 */         existingFile.getName()), e);
/*     */     } catch (SAXException e) {
/*  86 */       throw new ShellException(Messages.getString("Warning.13", 
/*  87 */         existingFile.getName()), e);
/*     */     } catch (ParserConfigurationException e) {
/*  89 */       throw new ShellException(Messages.getString("Warning.13", 
/*  90 */         existingFile.getName()), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static String getMergedSource(InputSource newFile, InputSource existingFile, String existingFileName)
/*     */     throws IOException, SAXException, ParserConfigurationException, ShellException
/*     */   {
/*  98 */     DocumentBuilderFactory factory = 
/*  99 */       DocumentBuilderFactory.newInstance();
/* 100 */     factory.setExpandEntityReferences(false);
/* 101 */     DocumentBuilder builder = factory.newDocumentBuilder();
/* 102 */     builder.setEntityResolver(new NullEntityResolver(null));
/*     */     
/* 104 */     Document existingDocument = builder.parse(existingFile);
/* 105 */     Document newDocument = builder.parse(newFile);
/*     */     
/* 107 */     DocumentType newDocType = newDocument.getDoctype();
/* 108 */     DocumentType existingDocType = existingDocument.getDoctype();
/*     */     
/* 110 */     if (!newDocType.getName().equals(existingDocType.getName())) {
/* 111 */       throw new ShellException(Messages.getString("Warning.12", 
/* 112 */         existingFileName));
/*     */     }
/*     */     
/* 115 */     Element existingRootElement = existingDocument.getDocumentElement();
/* 116 */     Element newRootElement = newDocument.getDocumentElement();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */     NamedNodeMap attributes = existingRootElement.getAttributes();
/* 124 */     int attributeCount = attributes.getLength();
/* 125 */     for (int i = attributeCount - 1; i >= 0; i--) {
/* 126 */       Node node = attributes.item(i);
/* 127 */       existingRootElement.removeAttribute(node.getNodeName());
/*     */     }
/*     */     
/*     */ 
/* 131 */     attributes = newRootElement.getAttributes();
/* 132 */     attributeCount = attributes.getLength();
/* 133 */     for (int i = 0; i < attributeCount; i++) {
/* 134 */       Node node = attributes.item(i);
/* 135 */       existingRootElement.setAttribute(node.getNodeName(), node
/* 136 */         .getNodeValue());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 141 */     List<Node> nodesToDelete = new ArrayList();
/* 142 */     NodeList children = existingRootElement.getChildNodes();
/* 143 */     int length = children.getLength();
/* 144 */     Node node; for (int i = 0; i < length; i++) {
/* 145 */       node = children.item(i);
/* 146 */       if (isGeneratedNode(node)) {
/* 147 */         nodesToDelete.add(node);
/* 148 */       } else if ((isWhiteSpace(node)) && 
/* 149 */         (isGeneratedNode(children.item(i + 1)))) {
/* 150 */         nodesToDelete.add(node);
/*     */       }
/*     */     }
/*     */     
/* 154 */     for (Node node : nodesToDelete) {
/* 155 */       existingRootElement.removeChild(node);
/*     */     }
/*     */     
/*     */ 
/* 159 */     children = newRootElement.getChildNodes();
/* 160 */     length = children.getLength();
/* 161 */     Node firstChild = existingRootElement.getFirstChild();
/* 162 */     for (int i = 0; i < length; i++) {
/* 163 */       Node node = children.item(i);
/*     */       
/* 165 */       if ((i == length - 1) && 
/* 166 */         (isWhiteSpace(node))) {
/*     */         break;
/*     */       }
/*     */       
/*     */ 
/* 171 */       Node newNode = existingDocument.importNode(node, true);
/* 172 */       if (firstChild == null) {
/* 173 */         existingRootElement.appendChild(newNode);
/*     */       } else {
/* 175 */         existingRootElement.insertBefore(newNode, firstChild);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 180 */     return prettyPrint(existingDocument);
/*     */   }
/*     */   
/*     */   private static String prettyPrint(Document document) throws ShellException {
/* 184 */     DomWriter dw = new DomWriter();
/* 185 */     String s = dw.toString(document);
/* 186 */     return s;
/*     */   }
/*     */   
/*     */   private static boolean isGeneratedNode(Node node) {
/* 190 */     boolean rc = false;
/*     */     
/* 192 */     if ((node != null) && (node.getNodeType() == 1)) {
/* 193 */       Element element = (Element)node;
/* 194 */       String id = element.getAttribute("id");
/* 195 */       if (id != null) { String[] arrayOfString1;
/* 196 */         int j = (arrayOfString1 = MergeConstants.OLD_XML_ELEMENT_PREFIXES).length; for (int i = 0; i < j; i++) { String prefix = arrayOfString1[i];
/* 197 */           if (id.startsWith(prefix)) {
/* 198 */             rc = true;
/* 199 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 204 */       if (!rc)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 209 */         NodeList children = node.getChildNodes();
/* 210 */         int length = children.getLength();
/* 211 */         for (int i = 0; i < length; i++) {
/* 212 */           Node childNode = children.item(i);
/* 213 */           if (!isWhiteSpace(childNode))
/*     */           {
/* 215 */             if (childNode.getNodeType() != 8) break;
/* 216 */             Comment comment = (Comment)childNode;
/* 217 */             String commentData = comment.getData();
/* 218 */             String[] arrayOfString2; int m = (arrayOfString2 = MergeConstants.OLD_ELEMENT_TAGS).length; for (int k = 0; k < m; k++) { String tag = arrayOfString2[k];
/* 219 */               if (commentData.contains(tag)) {
/* 220 */                 rc = true;
/* 221 */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 231 */     return rc;
/*     */   }
/*     */   
/*     */   private static boolean isWhiteSpace(Node node) {
/* 235 */     boolean rc = false;
/*     */     
/* 237 */     if ((node != null) && (node.getNodeType() == 3)) {
/* 238 */       Text tn = (Text)node;
/* 239 */       if (tn.getData().trim().length() == 0) {
/* 240 */         rc = true;
/*     */       }
/*     */     }
/*     */     
/* 244 */     return rc;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\XmlFileMergerJaxp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */