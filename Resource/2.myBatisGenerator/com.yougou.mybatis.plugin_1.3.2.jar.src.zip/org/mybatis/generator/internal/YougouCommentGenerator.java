/*     */ package org.mybatis.generator.internal;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.IntrospectedColumn;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.dom.java.CompilationUnit;
/*     */ import org.mybatis.generator.api.dom.java.Field;
/*     */ import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
/*     */ import org.mybatis.generator.api.dom.java.JavaElement;
/*     */ import org.mybatis.generator.api.dom.java.Method;
/*     */ import org.mybatis.generator.api.dom.java.Parameter;
/*     */ import org.mybatis.generator.api.dom.xml.TextElement;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.config.Context;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YougouCommentGenerator
/*     */   extends DefaultCommentGenerator
/*     */ {
/*  38 */   private static SimpleDateFormat sdf = new SimpleDateFormat(
/*  39 */     "yyyy-MM-dd HH:mm:ss");
/*     */   
/*     */   public void addClassComment(JavaElement javaElement)
/*     */   {
/*  43 */     javaElement.addJavaDocLine("/**");
/*  44 */     javaElement.addJavaDocLine(" * 请写出类的用途 ");
/*  45 */     javaElement.addJavaDocLine(" * @author " + 
/*  46 */       System.getProperty("user.name"));
/*  47 */     javaElement.addJavaDocLine(" * @date  " + sdf.format(new Date()));
/*  48 */     javaElement.addJavaDocLine(" * @version " + Context.getCodeVersion());
/*  49 */     javaElement
/*  50 */       .addJavaDocLine(" * @copyright (C) 2013 WonHigh Information Technology Co.,Ltd ");
/*  51 */     javaElement.addJavaDocLine(" * All Rights Reserved. ");
/*  52 */     javaElement.addJavaDocLine(" * ");
/*  53 */     javaElement
/*  54 */       .addJavaDocLine(" * The software for the WonHigh technology development, without the ");
/*  55 */     javaElement
/*  56 */       .addJavaDocLine(" * company's written consent, and any other individuals and ");
/*  57 */     javaElement
/*  58 */       .addJavaDocLine(" * organizations shall not be used, Copying, Modify or distribute ");
/*  59 */     javaElement.addJavaDocLine(" * the software.");
/*  60 */     javaElement.addJavaDocLine(" * ");
/*  61 */     javaElement.addJavaDocLine(" */");
/*     */   }
/*     */   
/*     */ 
/*     */   public void addJavaFileComment(CompilationUnit compilationUnit)
/*     */   {
/*  67 */     compilationUnit.addFileCommentLine("/**");
/*  68 */     compilationUnit.addFileCommentLine(" * 类名 " + 
/*  69 */       compilationUnit.getType().getFullyQualifiedName());
/*  70 */     compilationUnit.addFileCommentLine(" * @author " + 
/*  71 */       System.getProperty("user.name"));
/*  72 */     compilationUnit
/*  73 */       .addFileCommentLine(" * @date  " + new Date().toString());
/*  74 */     compilationUnit.addFileCommentLine(" * @version " + 
/*  75 */       Context.getCodeVersion());
/*  76 */     compilationUnit
/*  77 */       .addFileCommentLine(" * @copyright (C) 2013 YouGou Information Technology Co.,Ltd ");
/*  78 */     compilationUnit.addFileCommentLine(" * All Rights Reserved. ");
/*  79 */     compilationUnit.addFileCommentLine(" * ");
/*  80 */     compilationUnit
/*  81 */       .addFileCommentLine(" * The software for the YouGou technology development, without the ");
/*  82 */     compilationUnit
/*  83 */       .addFileCommentLine(" * company's written consent, and any other individuals and ");
/*  84 */     compilationUnit
/*  85 */       .addFileCommentLine(" * organizations shall not be used, Copying, Modify or distribute ");
/*  86 */     compilationUnit.addFileCommentLine(" * the software.");
/*  87 */     compilationUnit.addFileCommentLine(" * ");
/*  88 */     compilationUnit.addFileCommentLine(" */");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addFieldComment(Field field, IntrospectedTable introspectedTable, IntrospectedColumn introspectedColumn)
/*     */   {
/*  99 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 101 */     field.addJavaDocLine("/**");
/* 102 */     sb.append(" * " + (introspectedColumn.getRemarks() == null ? "" : introspectedColumn.getRemarks()));
/* 103 */     field.addJavaDocLine(sb.toString());
/*     */     
/*     */ 
/*     */ 
/* 107 */     field.addJavaDocLine(" */");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addGeneralMethodComment(Method method, IntrospectedTable introspectedTable) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addGetterComment(Method method, IntrospectedTable introspectedTable, IntrospectedColumn introspectedColumn)
/*     */   {
/* 122 */     addGetterComment(method, introspectedTable, introspectedColumn, "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addGetterComment(Method method, IntrospectedTable introspectedTable, IntrospectedColumn introspectedColumn, String comment)
/*     */   {
/* 132 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 134 */     method.addJavaDocLine("/**");
/* 135 */     if ((comment != null) && ("".equals(comment))) {
/* 136 */       sb.append(" * ");
/* 137 */       sb.append(comment);
/* 138 */       method.addJavaDocLine(sb.toString());
/* 139 */       sb.setLength(0);
/*     */     }
/* 141 */     sb.append(" * {@linkplain #");
/* 142 */     sb.append(introspectedColumn.getJavaProperty());
/* 143 */     sb.append("}");
/* 144 */     method.addJavaDocLine(sb.toString());
/*     */     
/* 146 */     method.addJavaDocLine(" *");
/*     */     
/* 148 */     sb.setLength(0);
/* 149 */     sb.append(" * @return the value of ");
/* 150 */     sb.append(introspectedTable.getFullyQualifiedTable());
/* 151 */     sb.append('.');
/* 152 */     sb.append(introspectedColumn.getActualColumnName());
/* 153 */     method.addJavaDocLine(sb.toString());
/*     */     
/*     */ 
/*     */ 
/* 157 */     method.addJavaDocLine(" */");
/*     */   }
/*     */   
/*     */   public void addSetterComment(Method method, IntrospectedTable introspectedTable, IntrospectedColumn introspectedColumn)
/*     */   {
/* 162 */     addSetterComment(method, introspectedTable, introspectedColumn, "");
/*     */   }
/*     */   
/*     */ 
/*     */   public void addComment(XmlElement xmlElement, boolean suppressComments)
/*     */   {
/* 168 */     if (suppressComments) {
/* 169 */       return;
/*     */     }
/* 171 */     xmlElement.addElement(new TextElement("<!--"));
/* 172 */     StringBuilder sb = new StringBuilder();
/* 173 */     sb.append("  WARNING -");
/* 174 */     sb.append("  SQL是带逻辑性的表达式，数据权限目前只支持一级SQL，无法支持SQL嵌套或union、union all语句,推荐语句见如下,详细介绍见wiki ");
/* 175 */     xmlElement.addElement(new TextElement(sb.toString()));
/* 176 */     xmlElement.addElement(new TextElement("  wiki:http://10.0.30.57:8090/pages/viewpage.action?pageId=5111962"));
/* 177 */     xmlElement.addElement(new TextElement("  e.g.:"));
/* 178 */     xmlElement.addElement(new TextElement("  select u.userId,u.userName from user u "));
/* 179 */     xmlElement.addElement(new TextElement("  inner join company c on (u.companyId=c.companyId) "));
/* 180 */     xmlElement.addElement(new TextElement("  where append_condition=? "));
/* 181 */     xmlElement.addElement(new TextElement("-->"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addSetterComment(Method method, IntrospectedTable introspectedTable, IntrospectedColumn introspectedColumn, String comment)
/*     */   {
/* 188 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 190 */     method.addJavaDocLine("/**");
/* 191 */     if ((comment != null) && ("".equals(comment))) {
/* 192 */       sb.append(" * ");
/* 193 */       sb.append(comment);
/* 194 */       method.addJavaDocLine(sb.toString());
/* 195 */       sb.setLength(0);
/*     */     }
/* 197 */     sb.append(" * {@linkplain #");
/* 198 */     sb.append(introspectedColumn.getJavaProperty());
/* 199 */     sb.append("}");
/* 200 */     method.addJavaDocLine(sb.toString());
/*     */     
/* 202 */     Parameter parm = (Parameter)method.getParameters().get(0);
/* 203 */     sb.setLength(0);
/* 204 */     sb.append(" * @param ");
/* 205 */     sb.append(parm.getName());
/* 206 */     sb.append(" the value for ");
/* 207 */     sb.append(introspectedTable.getFullyQualifiedTable());
/* 208 */     sb.append('.');
/* 209 */     sb.append(introspectedColumn.getActualColumnName());
/* 210 */     method.addJavaDocLine(sb.toString());
/*     */     
/*     */ 
/*     */ 
/* 214 */     method.addJavaDocLine(" */");
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\internal\YougouCommentGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */