/*     */ package org.mybatis.generator.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YouGouTableSettingConfiguration
/*     */   extends PropertyHolder
/*     */ {
/*     */   private boolean insertStatementEnabled;
/*     */   private boolean selectByPrimaryKeyStatementEnabled;
/*     */   private boolean selectByExampleStatementEnabled;
/*     */   private boolean updateByPrimaryKeyStatementEnabled;
/*     */   private boolean deleteByPrimaryKeyStatementEnabled;
/*     */   private boolean deleteByExampleStatementEnabled;
/*     */   private boolean countByExampleStatementEnabled;
/*     */   private boolean updateByExampleStatementEnabled;
/*     */   private List<ColumnOverride> columnOverrides;
/*     */   private Map<IgnoredColumn, Boolean> ignoredColumns;
/*     */   private GeneratedKey generatedKey;
/*     */   private String selectByPrimaryKeyQueryId;
/*     */   private String selectByExampleQueryId;
/*     */   private boolean isSchema;
/*     */   private HashMap<String, String> replaceTablePrefixMap;
/*     */   private boolean ignoreGeneratorSchema;
/*     */   private String alias;
/*     */   private ModelType modelType;
/*     */   private boolean wildcardEscapingEnabled;
/*     */   private String configuredModelType;
/*     */   private boolean delimitIdentifiers;
/*     */   private ColumnRenamingRule columnRenamingRule;
/*     */   private boolean isAllColumnDelimitingEnabled;
/*     */   
/*     */   public YouGouTableSettingConfiguration(Context context)
/*     */   {
/*  75 */     this.modelType = context.getDefaultModelType();
/*     */     
/*  77 */     this.columnOverrides = new ArrayList();
/*  78 */     this.ignoredColumns = new HashMap();
/*     */     
/*  80 */     this.insertStatementEnabled = true;
/*  81 */     this.selectByPrimaryKeyStatementEnabled = true;
/*  82 */     this.selectByExampleStatementEnabled = true;
/*  83 */     this.updateByPrimaryKeyStatementEnabled = true;
/*  84 */     this.deleteByPrimaryKeyStatementEnabled = true;
/*  85 */     this.deleteByExampleStatementEnabled = true;
/*  86 */     this.countByExampleStatementEnabled = true;
/*  87 */     this.updateByExampleStatementEnabled = true;
/*     */   }
/*     */   
/*     */   public boolean isDeleteByPrimaryKeyStatementEnabled() {
/*  91 */     return this.deleteByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setDeleteByPrimaryKeyStatementEnabled(boolean deleteByPrimaryKeyStatementEnabled)
/*     */   {
/*  96 */     this.deleteByPrimaryKeyStatementEnabled = deleteByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public boolean isInsertStatementEnabled() {
/* 100 */     return this.insertStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setInsertStatementEnabled(boolean insertStatementEnabled) {
/* 104 */     this.insertStatementEnabled = insertStatementEnabled;
/*     */   }
/*     */   
/*     */   public boolean isSelectByPrimaryKeyStatementEnabled() {
/* 108 */     return this.selectByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setSelectByPrimaryKeyStatementEnabled(boolean selectByPrimaryKeyStatementEnabled)
/*     */   {
/* 113 */     this.selectByPrimaryKeyStatementEnabled = selectByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public boolean isUpdateByPrimaryKeyStatementEnabled() {
/* 117 */     return this.updateByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setUpdateByPrimaryKeyStatementEnabled(boolean updateByPrimaryKeyStatementEnabled)
/*     */   {
/* 122 */     this.updateByPrimaryKeyStatementEnabled = updateByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public boolean isColumnIgnored(String columnName)
/*     */   {
/* 127 */     Iterator localIterator = this.ignoredColumns.entrySet().iterator();
/* 126 */     while (localIterator.hasNext()) {
/* 127 */       Map.Entry<IgnoredColumn, Boolean> entry = (Map.Entry)localIterator.next();
/* 128 */       IgnoredColumn ic = (IgnoredColumn)entry.getKey();
/* 129 */       if (ic.isColumnNameDelimited()) {
/* 130 */         if (columnName.equals(ic.getColumnName())) {
/* 131 */           entry.setValue(Boolean.TRUE);
/* 132 */           return true;
/*     */         }
/*     */       }
/* 135 */       else if (columnName.equalsIgnoreCase(ic.getColumnName())) {
/* 136 */         entry.setValue(Boolean.TRUE);
/* 137 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 142 */     return false;
/*     */   }
/*     */   
/*     */   public void addIgnoredColumn(IgnoredColumn ignoredColumn) {
/* 146 */     this.ignoredColumns.put(ignoredColumn, Boolean.FALSE);
/*     */   }
/*     */   
/*     */   public void addColumnOverride(ColumnOverride columnOverride) {
/* 150 */     this.columnOverrides.add(columnOverride);
/*     */   }
/*     */   
/*     */   public boolean isSelectByExampleStatementEnabled() {
/* 154 */     return this.selectByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setSelectByExampleStatementEnabled(boolean selectByExampleStatementEnabled)
/*     */   {
/* 159 */     this.selectByExampleStatementEnabled = selectByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ColumnOverride getColumnOverride(String columnName)
/*     */   {
/* 169 */     for (ColumnOverride co : this.columnOverrides) {
/* 170 */       if (co.isColumnNameDelimited()) {
/* 171 */         if (columnName.equals(co.getColumnName())) {
/* 172 */           return co;
/*     */         }
/*     */       }
/* 175 */       else if (columnName.equalsIgnoreCase(co.getColumnName())) {
/* 176 */         return co;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 181 */     return null;
/*     */   }
/*     */   
/*     */   public GeneratedKey getGeneratedKey() {
/* 185 */     return this.generatedKey;
/*     */   }
/*     */   
/*     */   public String getSelectByExampleQueryId() {
/* 189 */     return this.selectByExampleQueryId;
/*     */   }
/*     */   
/*     */   public void setSelectByExampleQueryId(String selectByExampleQueryId) {
/* 193 */     this.selectByExampleQueryId = selectByExampleQueryId;
/*     */   }
/*     */   
/*     */   public String getSelectByPrimaryKeyQueryId() {
/* 197 */     return this.selectByPrimaryKeyQueryId;
/*     */   }
/*     */   
/*     */   public void setSelectByPrimaryKeyQueryId(String selectByPrimaryKeyQueryId) {
/* 201 */     this.selectByPrimaryKeyQueryId = selectByPrimaryKeyQueryId;
/*     */   }
/*     */   
/*     */   public boolean isDeleteByExampleStatementEnabled() {
/* 205 */     return this.deleteByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setDeleteByExampleStatementEnabled(boolean deleteByExampleStatementEnabled)
/*     */   {
/* 210 */     this.deleteByExampleStatementEnabled = deleteByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean areAnyStatementsEnabled()
/*     */   {
/* 220 */     return (this.selectByExampleStatementEnabled) || (this.selectByPrimaryKeyStatementEnabled) || (this.insertStatementEnabled) || (this.updateByPrimaryKeyStatementEnabled) || (this.deleteByExampleStatementEnabled) || (this.deleteByPrimaryKeyStatementEnabled) || (this.countByExampleStatementEnabled) || (this.updateByExampleStatementEnabled);
/*     */   }
/*     */   
/*     */   public void setGeneratedKey(GeneratedKey generatedKey) {
/* 224 */     this.generatedKey = generatedKey;
/*     */   }
/*     */   
/*     */   public String getAlias() {
/* 228 */     return this.alias;
/*     */   }
/*     */   
/*     */   public void setAlias(String alias) {
/* 232 */     this.alias = alias;
/*     */   }
/*     */   
/*     */   public List<ColumnOverride> getColumnOverrides()
/*     */   {
/* 237 */     return this.columnOverrides;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getIgnoredColumnsInError()
/*     */   {
/* 249 */     List<String> answer = new ArrayList();
/*     */     
/*     */ 
/* 252 */     Iterator localIterator = this.ignoredColumns.entrySet().iterator();
/* 251 */     while (localIterator.hasNext()) {
/* 252 */       Map.Entry<IgnoredColumn, Boolean> entry = (Map.Entry)localIterator.next();
/* 253 */       if (Boolean.FALSE.equals(entry.getValue())) {
/* 254 */         answer.add(((IgnoredColumn)entry.getKey()).getColumnName());
/*     */       }
/*     */     }
/*     */     
/* 258 */     return answer;
/*     */   }
/*     */   
/*     */   public ModelType getModelType() {
/* 262 */     return this.modelType;
/*     */   }
/*     */   
/*     */   public void setConfiguredModelType(String configuredModelType) {
/* 266 */     this.configuredModelType = configuredModelType;
/* 267 */     this.modelType = ModelType.getModelType(configuredModelType);
/*     */   }
/*     */   
/*     */   public boolean isWildcardEscapingEnabled() {
/* 271 */     return this.wildcardEscapingEnabled;
/*     */   }
/*     */   
/*     */   public void setWildcardEscapingEnabled(boolean wildcardEscapingEnabled) {
/* 275 */     this.wildcardEscapingEnabled = wildcardEscapingEnabled;
/*     */   }
/*     */   
/*     */   public XmlElement toXmlElement() {
/* 279 */     XmlElement xmlElement = new XmlElement("table");
/*     */     
/* 281 */     if (!this.isSchema) {
/* 282 */       xmlElement.addAttribute(new Attribute("isSchema", "false"));
/*     */     }
/*     */     
/* 285 */     if (this.isSchema) {
/* 286 */       xmlElement.addAttribute(new Attribute("isSchema", "true"));
/*     */     }
/*     */     
/* 289 */     if (StringUtility.stringHasValue(this.alias)) {
/* 290 */       xmlElement.addAttribute(new Attribute("alias", this.alias));
/*     */     }
/*     */     
/* 293 */     if (!this.insertStatementEnabled) {
/* 294 */       xmlElement.addAttribute(new Attribute("enableInsert", "false"));
/*     */     }
/*     */     
/* 297 */     if (!this.selectByPrimaryKeyStatementEnabled) {
/* 298 */       xmlElement.addAttribute(new Attribute(
/* 299 */         "enableSelectByPrimaryKey", "false"));
/*     */     }
/*     */     
/* 302 */     if (!this.selectByExampleStatementEnabled) {
/* 303 */       xmlElement.addAttribute(new Attribute(
/* 304 */         "enableSelectByExample", "false"));
/*     */     }
/*     */     
/* 307 */     if (!this.updateByPrimaryKeyStatementEnabled) {
/* 308 */       xmlElement.addAttribute(new Attribute(
/* 309 */         "enableUpdateByPrimaryKey", "false"));
/*     */     }
/*     */     
/* 312 */     if (!this.deleteByPrimaryKeyStatementEnabled) {
/* 313 */       xmlElement.addAttribute(new Attribute(
/* 314 */         "enableDeleteByPrimaryKey", "false"));
/*     */     }
/*     */     
/* 317 */     if (!this.deleteByExampleStatementEnabled) {
/* 318 */       xmlElement.addAttribute(new Attribute(
/* 319 */         "enableDeleteByExample", "false"));
/*     */     }
/*     */     
/* 322 */     if (!this.countByExampleStatementEnabled) {
/* 323 */       xmlElement.addAttribute(new Attribute(
/* 324 */         "enableCountByExample", "false"));
/*     */     }
/*     */     
/* 327 */     if (!this.updateByExampleStatementEnabled) {
/* 328 */       xmlElement.addAttribute(new Attribute(
/* 329 */         "enableUpdateByExample", "false"));
/*     */     }
/*     */     
/* 332 */     if (StringUtility.stringHasValue(this.selectByPrimaryKeyQueryId)) {
/* 333 */       xmlElement.addAttribute(new Attribute(
/* 334 */         "selectByPrimaryKeyQueryId", this.selectByPrimaryKeyQueryId));
/*     */     }
/*     */     
/* 337 */     if (StringUtility.stringHasValue(this.selectByExampleQueryId)) {
/* 338 */       xmlElement.addAttribute(new Attribute(
/* 339 */         "selectByExampleQueryId", this.selectByExampleQueryId));
/*     */     }
/*     */     
/* 342 */     if (this.configuredModelType != null) {
/* 343 */       xmlElement.addAttribute(new Attribute(
/* 344 */         "modelType", this.configuredModelType));
/*     */     }
/*     */     
/* 347 */     if (this.wildcardEscapingEnabled) {
/* 348 */       xmlElement.addAttribute(new Attribute("escapeWildcards", "true"));
/*     */     }
/*     */     
/* 351 */     if (this.isAllColumnDelimitingEnabled) {
/* 352 */       xmlElement.addAttribute(new Attribute("delimitAllColumns", "true"));
/*     */     }
/*     */     
/* 355 */     if (this.delimitIdentifiers)
/*     */     {
/* 357 */       xmlElement.addAttribute(new Attribute("delimitIdentifiers", "true"));
/*     */     }
/*     */     
/* 360 */     addPropertyXmlElements(xmlElement);
/*     */     
/* 362 */     if (this.generatedKey != null) {
/* 363 */       xmlElement.addElement(this.generatedKey.toXmlElement());
/*     */     }
/*     */     
/* 366 */     if (this.columnRenamingRule != null) {
/* 367 */       xmlElement.addElement(this.columnRenamingRule.toXmlElement());
/*     */     }
/*     */     
/* 370 */     if (this.ignoredColumns.size() > 0) {
/* 371 */       for (IgnoredColumn ignoredColumn : this.ignoredColumns.keySet()) {
/* 372 */         xmlElement.addElement(ignoredColumn.toXmlElement());
/*     */       }
/*     */     }
/*     */     
/* 376 */     if (this.columnOverrides.size() > 0) {
/* 377 */       for (ColumnOverride columnOverride : this.columnOverrides) {
/* 378 */         xmlElement.addElement(columnOverride.toXmlElement());
/*     */       }
/*     */     }
/*     */     
/* 382 */     return xmlElement;
/*     */   }
/*     */   
/*     */   public boolean isDelimitIdentifiers() {
/* 386 */     return this.delimitIdentifiers;
/*     */   }
/*     */   
/*     */   public void setDelimitIdentifiers(boolean delimitIdentifiers) {
/* 390 */     this.delimitIdentifiers = delimitIdentifiers;
/*     */   }
/*     */   
/*     */   public boolean isCountByExampleStatementEnabled() {
/* 394 */     return this.countByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setCountByExampleStatementEnabled(boolean countByExampleStatementEnabled)
/*     */   {
/* 399 */     this.countByExampleStatementEnabled = countByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public boolean isUpdateByExampleStatementEnabled() {
/* 403 */     return this.updateByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setUpdateByExampleStatementEnabled(boolean updateByExampleStatementEnabled)
/*     */   {
/* 408 */     this.updateByExampleStatementEnabled = updateByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public void validate(List<String> errors, int listPosition) {}
/*     */   
/*     */   public boolean isSchema()
/*     */   {
/* 415 */     return this.isSchema;
/*     */   }
/*     */   
/*     */   public void setSchema(boolean isSchema) {
/* 419 */     this.isSchema = isSchema;
/*     */   }
/*     */   
/*     */   public HashMap<String, String> getReplaceTablePrefixMap() {
/* 423 */     return this.replaceTablePrefixMap;
/*     */   }
/*     */   
/*     */   public void setReplaceTablePrefixMap(HashMap<String, String> replaceTablePrefixMap)
/*     */   {
/* 428 */     this.replaceTablePrefixMap = replaceTablePrefixMap;
/*     */   }
/*     */   
/*     */   public boolean isIgnoreGeneratorSchema() {
/* 432 */     return this.ignoreGeneratorSchema;
/*     */   }
/*     */   
/*     */   public void setIgnoreGeneratorSchema(boolean ignoreGeneratorSchema) {
/* 436 */     this.ignoreGeneratorSchema = ignoreGeneratorSchema;
/*     */   }
/*     */   
/*     */   public ColumnRenamingRule getColumnRenamingRule() {
/* 440 */     return this.columnRenamingRule;
/*     */   }
/*     */   
/*     */   public void setColumnRenamingRule(ColumnRenamingRule columnRenamingRule) {
/* 444 */     this.columnRenamingRule = columnRenamingRule;
/*     */   }
/*     */   
/*     */   public boolean isAllColumnDelimitingEnabled() {
/* 448 */     return this.isAllColumnDelimitingEnabled;
/*     */   }
/*     */   
/*     */   public void setAllColumnDelimitingEnabled(boolean isAllColumnDelimitingEnabled)
/*     */   {
/* 453 */     this.isAllColumnDelimitingEnabled = isAllColumnDelimitingEnabled;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\YouGouTableSettingConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */