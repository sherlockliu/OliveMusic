/*     */ package org.mybatis.generator.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.internal.util.EqualsUtil;
/*     */ import org.mybatis.generator.internal.util.HashCodeUtil;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableConfiguration
/*     */   extends PropertyHolder
/*     */ {
/*     */   private boolean insertStatementEnabled;
/*     */   private boolean selectByPrimaryKeyStatementEnabled;
/*     */   private boolean selectByExampleStatementEnabled;
/*     */   private boolean updateByPrimaryKeyStatementEnabled;
/*     */   private boolean deleteByPrimaryKeyStatementEnabled;
/*     */   private boolean deleteByExampleStatementEnabled;
/*     */   private boolean countByExampleStatementEnabled;
/*     */   private boolean updateByExampleStatementEnabled;
/*     */   private List<ColumnOverride> columnOverrides;
/*     */   private Map<IgnoredColumn, Boolean> ignoredColumns;
/*     */   private GeneratedKey generatedKey;
/*     */   private String selectByPrimaryKeyQueryId;
/*     */   private String selectByExampleQueryId;
/*     */   private String catalog;
/*     */   private String schema;
/*     */   private String tableName;
/*     */   private String domainObjectName;
/*     */   private String alias;
/*     */   private ModelType modelType;
/*     */   private boolean wildcardEscapingEnabled;
/*     */   private String configuredModelType;
/*     */   private boolean delimitIdentifiers;
/*     */   private ColumnRenamingRule columnRenamingRule;
/*     */   private boolean isAllColumnDelimitingEnabled;
/*     */   
/*     */   public TableConfiguration(Context context)
/*     */   {
/*  81 */     this.modelType = context.getDefaultModelType();
/*     */     
/*  83 */     this.columnOverrides = new ArrayList();
/*  84 */     this.ignoredColumns = new HashMap();
/*     */     
/*  86 */     this.insertStatementEnabled = true;
/*  87 */     this.selectByPrimaryKeyStatementEnabled = true;
/*  88 */     this.selectByExampleStatementEnabled = true;
/*  89 */     this.updateByPrimaryKeyStatementEnabled = true;
/*  90 */     this.deleteByPrimaryKeyStatementEnabled = true;
/*  91 */     this.deleteByExampleStatementEnabled = true;
/*  92 */     this.countByExampleStatementEnabled = true;
/*  93 */     this.updateByExampleStatementEnabled = true;
/*     */   }
/*     */   
/*     */   public boolean isDeleteByPrimaryKeyStatementEnabled() {
/*  97 */     return this.deleteByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setDeleteByPrimaryKeyStatementEnabled(boolean deleteByPrimaryKeyStatementEnabled)
/*     */   {
/* 102 */     this.deleteByPrimaryKeyStatementEnabled = deleteByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public boolean isInsertStatementEnabled() {
/* 106 */     return this.insertStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setInsertStatementEnabled(boolean insertStatementEnabled) {
/* 110 */     this.insertStatementEnabled = insertStatementEnabled;
/*     */   }
/*     */   
/*     */   public boolean isSelectByPrimaryKeyStatementEnabled() {
/* 114 */     return this.selectByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setSelectByPrimaryKeyStatementEnabled(boolean selectByPrimaryKeyStatementEnabled)
/*     */   {
/* 119 */     this.selectByPrimaryKeyStatementEnabled = selectByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public boolean isUpdateByPrimaryKeyStatementEnabled() {
/* 123 */     return this.updateByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setUpdateByPrimaryKeyStatementEnabled(boolean updateByPrimaryKeyStatementEnabled)
/*     */   {
/* 128 */     this.updateByPrimaryKeyStatementEnabled = updateByPrimaryKeyStatementEnabled;
/*     */   }
/*     */   
/*     */   public boolean isColumnIgnored(String columnName)
/*     */   {
/* 133 */     Iterator localIterator = this.ignoredColumns.entrySet().iterator();
/* 132 */     while (localIterator.hasNext()) {
/* 133 */       Map.Entry<IgnoredColumn, Boolean> entry = (Map.Entry)localIterator.next();
/* 134 */       IgnoredColumn ic = (IgnoredColumn)entry.getKey();
/* 135 */       if (ic.isColumnNameDelimited()) {
/* 136 */         if (columnName.equals(ic.getColumnName())) {
/* 137 */           entry.setValue(Boolean.TRUE);
/* 138 */           return true;
/*     */         }
/*     */       }
/* 141 */       else if (columnName.equalsIgnoreCase(ic.getColumnName())) {
/* 142 */         entry.setValue(Boolean.TRUE);
/* 143 */         return true;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 148 */     return false;
/*     */   }
/*     */   
/*     */   public void addIgnoredColumn(IgnoredColumn ignoredColumn) {
/* 152 */     this.ignoredColumns.put(ignoredColumn, Boolean.FALSE);
/*     */   }
/*     */   
/*     */   public void addColumnOverride(ColumnOverride columnOverride) {
/* 156 */     this.columnOverrides.add(columnOverride);
/*     */   }
/*     */   
/*     */   public boolean equals(Object obj)
/*     */   {
/* 161 */     if (this == obj) {
/* 162 */       return true;
/*     */     }
/*     */     
/* 165 */     if (!(obj instanceof TableConfiguration)) {
/* 166 */       return false;
/*     */     }
/*     */     
/* 169 */     TableConfiguration other = (TableConfiguration)obj;
/*     */     
/*     */ 
/*     */ 
/* 173 */     return (EqualsUtil.areEqual(this.catalog, other.catalog)) && (EqualsUtil.areEqual(this.schema, other.schema)) && (EqualsUtil.areEqual(this.tableName, other.tableName));
/*     */   }
/*     */   
/*     */   public int hashCode()
/*     */   {
/* 178 */     int result = 23;
/* 179 */     result = HashCodeUtil.hash(result, this.catalog);
/* 180 */     result = HashCodeUtil.hash(result, this.schema);
/* 181 */     result = HashCodeUtil.hash(result, this.tableName);
/*     */     
/* 183 */     return result;
/*     */   }
/*     */   
/*     */   public boolean isSelectByExampleStatementEnabled() {
/* 187 */     return this.selectByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setSelectByExampleStatementEnabled(boolean selectByExampleStatementEnabled)
/*     */   {
/* 192 */     this.selectByExampleStatementEnabled = selectByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ColumnOverride getColumnOverride(String columnName)
/*     */   {
/* 202 */     for (ColumnOverride co : this.columnOverrides) {
/* 203 */       if (co.isColumnNameDelimited()) {
/* 204 */         if (columnName.equals(co.getColumnName())) {
/* 205 */           return co;
/*     */         }
/*     */       }
/* 208 */       else if (columnName.equalsIgnoreCase(co.getColumnName())) {
/* 209 */         return co;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 214 */     return null;
/*     */   }
/*     */   
/*     */   public GeneratedKey getGeneratedKey() {
/* 218 */     return this.generatedKey;
/*     */   }
/*     */   
/*     */   public String getSelectByExampleQueryId() {
/* 222 */     return this.selectByExampleQueryId;
/*     */   }
/*     */   
/*     */   public void setSelectByExampleQueryId(String selectByExampleQueryId) {
/* 226 */     this.selectByExampleQueryId = selectByExampleQueryId;
/*     */   }
/*     */   
/*     */   public String getSelectByPrimaryKeyQueryId() {
/* 230 */     return this.selectByPrimaryKeyQueryId;
/*     */   }
/*     */   
/*     */   public void setSelectByPrimaryKeyQueryId(String selectByPrimaryKeyQueryId) {
/* 234 */     this.selectByPrimaryKeyQueryId = selectByPrimaryKeyQueryId;
/*     */   }
/*     */   
/*     */   public boolean isDeleteByExampleStatementEnabled() {
/* 238 */     return this.deleteByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setDeleteByExampleStatementEnabled(boolean deleteByExampleStatementEnabled)
/*     */   {
/* 243 */     this.deleteByExampleStatementEnabled = deleteByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean areAnyStatementsEnabled()
/*     */   {
/* 253 */     return (this.selectByExampleStatementEnabled) || (this.selectByPrimaryKeyStatementEnabled) || (this.insertStatementEnabled) || (this.updateByPrimaryKeyStatementEnabled) || (this.deleteByExampleStatementEnabled) || (this.deleteByPrimaryKeyStatementEnabled) || (this.countByExampleStatementEnabled) || (this.updateByExampleStatementEnabled);
/*     */   }
/*     */   
/*     */   public void setGeneratedKey(GeneratedKey generatedKey) {
/* 257 */     this.generatedKey = generatedKey;
/*     */   }
/*     */   
/*     */   public String getAlias() {
/* 261 */     return this.alias;
/*     */   }
/*     */   
/*     */   public void setAlias(String alias) {
/* 265 */     this.alias = alias;
/*     */   }
/*     */   
/*     */   public String getCatalog() {
/* 269 */     return this.catalog;
/*     */   }
/*     */   
/*     */   public void setCatalog(String catalog) {
/* 273 */     this.catalog = catalog;
/*     */   }
/*     */   
/*     */   public String getDomainObjectName() {
/* 277 */     return this.domainObjectName;
/*     */   }
/*     */   
/*     */   public void setDomainObjectName(String domainObjectName) {
/* 281 */     this.domainObjectName = domainObjectName;
/*     */   }
/*     */   
/*     */   public String getSchema() {
/* 285 */     return this.schema;
/*     */   }
/*     */   
/*     */   public void setSchema(String schema) {
/* 289 */     this.schema = schema;
/*     */   }
/*     */   
/*     */   public String getTableName() {
/* 293 */     return this.tableName;
/*     */   }
/*     */   
/*     */   public void setTableName(String tableName) {
/* 297 */     this.tableName = tableName;
/*     */   }
/*     */   
/*     */   public List<ColumnOverride> getColumnOverrides() {
/* 301 */     return this.columnOverrides;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<String> getIgnoredColumnsInError()
/*     */   {
/* 313 */     List<String> answer = new ArrayList();
/*     */     
/*     */ 
/* 316 */     Iterator localIterator = this.ignoredColumns.entrySet().iterator();
/* 315 */     while (localIterator.hasNext()) {
/* 316 */       Map.Entry<IgnoredColumn, Boolean> entry = (Map.Entry)localIterator.next();
/* 317 */       if (Boolean.FALSE.equals(entry.getValue())) {
/* 318 */         answer.add(((IgnoredColumn)entry.getKey()).getColumnName());
/*     */       }
/*     */     }
/*     */     
/* 322 */     return answer;
/*     */   }
/*     */   
/*     */   public ModelType getModelType() {
/* 326 */     return this.modelType;
/*     */   }
/*     */   
/*     */   public void setConfiguredModelType(String configuredModelType) {
/* 330 */     this.configuredModelType = configuredModelType;
/* 331 */     this.modelType = ModelType.getModelType(configuredModelType);
/*     */   }
/*     */   
/*     */   public boolean isWildcardEscapingEnabled() {
/* 335 */     return this.wildcardEscapingEnabled;
/*     */   }
/*     */   
/*     */   public void setWildcardEscapingEnabled(boolean wildcardEscapingEnabled) {
/* 339 */     this.wildcardEscapingEnabled = wildcardEscapingEnabled;
/*     */   }
/*     */   
/*     */   public XmlElement toXmlElement() {
/* 343 */     XmlElement xmlElement = new XmlElement("table");
/* 344 */     xmlElement.addAttribute(new Attribute("tableName", this.tableName));
/*     */     
/* 346 */     if (StringUtility.stringHasValue(this.catalog)) {
/* 347 */       xmlElement.addAttribute(new Attribute("catalog", this.catalog));
/*     */     }
/*     */     
/* 350 */     if (StringUtility.stringHasValue(this.schema)) {
/* 351 */       xmlElement.addAttribute(new Attribute("schema", this.schema));
/*     */     }
/*     */     
/* 354 */     if (StringUtility.stringHasValue(this.alias)) {
/* 355 */       xmlElement.addAttribute(new Attribute("alias", this.alias));
/*     */     }
/*     */     
/* 358 */     if (StringUtility.stringHasValue(this.domainObjectName)) {
/* 359 */       xmlElement.addAttribute(new Attribute(
/* 360 */         "domainObjectName", this.domainObjectName));
/*     */     }
/*     */     
/* 363 */     if (!this.insertStatementEnabled) {
/* 364 */       xmlElement.addAttribute(new Attribute("enableInsert", "false"));
/*     */     }
/*     */     
/* 367 */     if (!this.selectByPrimaryKeyStatementEnabled) {
/* 368 */       xmlElement.addAttribute(new Attribute(
/* 369 */         "enableSelectByPrimaryKey", "false"));
/*     */     }
/*     */     
/* 372 */     if (!this.selectByExampleStatementEnabled) {
/* 373 */       xmlElement.addAttribute(new Attribute(
/* 374 */         "enableSelectByExample", "false"));
/*     */     }
/*     */     
/* 377 */     if (!this.updateByPrimaryKeyStatementEnabled) {
/* 378 */       xmlElement.addAttribute(new Attribute(
/* 379 */         "enableUpdateByPrimaryKey", "false"));
/*     */     }
/*     */     
/* 382 */     if (!this.deleteByPrimaryKeyStatementEnabled) {
/* 383 */       xmlElement.addAttribute(new Attribute(
/* 384 */         "enableDeleteByPrimaryKey", "false"));
/*     */     }
/*     */     
/* 387 */     if (!this.deleteByExampleStatementEnabled) {
/* 388 */       xmlElement.addAttribute(new Attribute(
/* 389 */         "enableDeleteByExample", "false"));
/*     */     }
/*     */     
/* 392 */     if (!this.countByExampleStatementEnabled) {
/* 393 */       xmlElement.addAttribute(new Attribute(
/* 394 */         "enableCountByExample", "false"));
/*     */     }
/*     */     
/* 397 */     if (!this.updateByExampleStatementEnabled) {
/* 398 */       xmlElement.addAttribute(new Attribute(
/* 399 */         "enableUpdateByExample", "false"));
/*     */     }
/*     */     
/* 402 */     if (StringUtility.stringHasValue(this.selectByPrimaryKeyQueryId)) {
/* 403 */       xmlElement.addAttribute(new Attribute(
/* 404 */         "selectByPrimaryKeyQueryId", this.selectByPrimaryKeyQueryId));
/*     */     }
/*     */     
/* 407 */     if (StringUtility.stringHasValue(this.selectByExampleQueryId)) {
/* 408 */       xmlElement.addAttribute(new Attribute(
/* 409 */         "selectByExampleQueryId", this.selectByExampleQueryId));
/*     */     }
/*     */     
/* 412 */     if (this.configuredModelType != null) {
/* 413 */       xmlElement.addAttribute(new Attribute(
/* 414 */         "modelType", this.configuredModelType));
/*     */     }
/*     */     
/* 417 */     if (this.wildcardEscapingEnabled) {
/* 418 */       xmlElement.addAttribute(new Attribute("escapeWildcards", "true"));
/*     */     }
/*     */     
/* 421 */     if (this.isAllColumnDelimitingEnabled) {
/* 422 */       xmlElement.addAttribute(new Attribute("delimitAllColumns", "true"));
/*     */     }
/*     */     
/* 425 */     if (this.delimitIdentifiers)
/*     */     {
/* 427 */       xmlElement.addAttribute(new Attribute("delimitIdentifiers", "true"));
/*     */     }
/*     */     
/* 430 */     addPropertyXmlElements(xmlElement);
/*     */     
/* 432 */     if (this.generatedKey != null) {
/* 433 */       xmlElement.addElement(this.generatedKey.toXmlElement());
/*     */     }
/*     */     
/* 436 */     if (this.columnRenamingRule != null) {
/* 437 */       xmlElement.addElement(this.columnRenamingRule.toXmlElement());
/*     */     }
/*     */     
/* 440 */     if (this.ignoredColumns.size() > 0) {
/* 441 */       for (IgnoredColumn ignoredColumn : this.ignoredColumns.keySet()) {
/* 442 */         xmlElement.addElement(ignoredColumn.toXmlElement());
/*     */       }
/*     */     }
/*     */     
/* 446 */     if (this.columnOverrides.size() > 0) {
/* 447 */       for (ColumnOverride columnOverride : this.columnOverrides) {
/* 448 */         xmlElement.addElement(columnOverride.toXmlElement());
/*     */       }
/*     */     }
/*     */     
/* 452 */     return xmlElement;
/*     */   }
/*     */   
/*     */   public String toString()
/*     */   {
/* 457 */     return StringUtility.composeFullyQualifiedTableName(this.catalog, this.schema, 
/* 458 */       this.tableName, '.');
/*     */   }
/*     */   
/*     */   public boolean isDelimitIdentifiers() {
/* 462 */     return this.delimitIdentifiers;
/*     */   }
/*     */   
/*     */   public void setDelimitIdentifiers(boolean delimitIdentifiers) {
/* 466 */     this.delimitIdentifiers = delimitIdentifiers;
/*     */   }
/*     */   
/*     */   public boolean isCountByExampleStatementEnabled() {
/* 470 */     return this.countByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setCountByExampleStatementEnabled(boolean countByExampleStatementEnabled)
/*     */   {
/* 475 */     this.countByExampleStatementEnabled = countByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public boolean isUpdateByExampleStatementEnabled() {
/* 479 */     return this.updateByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public void setUpdateByExampleStatementEnabled(boolean updateByExampleStatementEnabled)
/*     */   {
/* 484 */     this.updateByExampleStatementEnabled = updateByExampleStatementEnabled;
/*     */   }
/*     */   
/*     */   public void validate(List<String> errors, int listPosition) {
/* 488 */     if (!StringUtility.stringHasValue(this.tableName)) {
/* 489 */       errors.add(Messages.getString(
/* 490 */         "ValidationError.6", Integer.toString(listPosition)));
/*     */     }
/*     */     
/* 493 */     String fqTableName = StringUtility.composeFullyQualifiedTableName(
/* 494 */       this.catalog, this.schema, this.tableName, '.');
/*     */     
/* 496 */     if (this.generatedKey != null) {
/* 497 */       this.generatedKey.validate(errors, fqTableName);
/*     */     }
/*     */     boolean queryId2Set;
/* 500 */     if (StringUtility.isTrue(getProperty("useColumnIndexes")))
/*     */     {
/*     */ 
/* 503 */       if ((this.selectByExampleStatementEnabled) && 
/* 504 */         (this.selectByPrimaryKeyStatementEnabled)) {
/* 505 */         boolean queryId1Set = StringUtility.stringHasValue(this.selectByExampleQueryId);
/* 506 */         queryId2Set = StringUtility.stringHasValue(this.selectByPrimaryKeyQueryId);
/*     */         
/* 508 */         if (queryId1Set != queryId2Set) {
/* 509 */           errors.add(Messages.getString("ValidationError.13", 
/* 510 */             fqTableName));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 515 */     if (this.columnRenamingRule != null) {
/* 516 */       this.columnRenamingRule.validate(errors, fqTableName);
/*     */     }
/*     */     
/* 519 */     for (ColumnOverride columnOverride : this.columnOverrides) {
/* 520 */       columnOverride.validate(errors, fqTableName);
/*     */     }
/*     */     
/* 523 */     for (IgnoredColumn ignoredColumn : this.ignoredColumns.keySet()) {
/* 524 */       ignoredColumn.validate(errors, fqTableName);
/*     */     }
/*     */   }
/*     */   
/*     */   public ColumnRenamingRule getColumnRenamingRule() {
/* 529 */     return this.columnRenamingRule;
/*     */   }
/*     */   
/*     */   public void setColumnRenamingRule(ColumnRenamingRule columnRenamingRule) {
/* 533 */     this.columnRenamingRule = columnRenamingRule;
/*     */   }
/*     */   
/*     */   public boolean isAllColumnDelimitingEnabled() {
/* 537 */     return this.isAllColumnDelimitingEnabled;
/*     */   }
/*     */   
/*     */   public void setAllColumnDelimitingEnabled(boolean isAllColumnDelimitingEnabled)
/*     */   {
/* 542 */     this.isAllColumnDelimitingEnabled = isAllColumnDelimitingEnabled;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\TableConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */