/*     */ package org.mybatis.generator.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YouGouManagerGeneratorConfiguration
/*     */   extends TypedPropertyHolder
/*     */ {
/*     */   private String targetPackage;
/*     */   private String implementationPackage;
/*     */   private String targetProject;
/*     */   private String interfaceExtendSupInterface;
/*     */   private String interfaceExtendSupInterfaceDoMain;
/*     */   private String enableInterfaceSupInterfaceGenericity;
/*     */   private String extendSupClass;
/*     */   private String extendSupClassDoMain;
/*     */   private String enableSupClassGenericity;
/*     */   
/*     */   public String getTargetProject()
/*     */   {
/*  54 */     return this.targetProject;
/*     */   }
/*     */   
/*     */   public void setTargetProject(String targetProject) {
/*  58 */     this.targetProject = targetProject;
/*     */   }
/*     */   
/*     */   public String getTargetPackage() {
/*  62 */     return this.targetPackage;
/*     */   }
/*     */   
/*     */   public void setTargetPackage(String targetPackage) {
/*  66 */     this.targetPackage = targetPackage;
/*     */   }
/*     */   
/*     */   public String getExtendSupClass() {
/*  70 */     return this.extendSupClass;
/*     */   }
/*     */   
/*     */   public void setExtendSupClassDoMain(String extendSupClassDoMain) {
/*  74 */     this.extendSupClassDoMain = extendSupClassDoMain;
/*     */   }
/*     */   
/*     */   public String getExtendSupClassDoMain() {
/*  78 */     int point = -1;
/*  79 */     if ((this.extendSupClass != null) && (!"".equals(this.extendSupClass)))
/*  80 */       point = this.extendSupClass.lastIndexOf(".");
/*  81 */     if ((this.extendSupClass != null) && (this.extendSupClass.length() > point)) {
/*  82 */       this.extendSupClassDoMain = this.extendSupClass.substring(point + 1);
/*     */     } else {
/*  84 */       this.extendSupClassDoMain = "";
/*     */     }
/*  86 */     return this.extendSupClassDoMain;
/*     */   }
/*     */   
/*     */   public void setExtendSupClass(String extendSupClass) {
/*  90 */     this.extendSupClass = extendSupClass;
/*     */   }
/*     */   
/*     */   public String getEnableSupClassGenericity() {
/*  94 */     return this.enableSupClassGenericity;
/*     */   }
/*     */   
/*     */   public void setEnableSupClassGenericity(String enableSupClassGenericity) {
/*  98 */     this.enableSupClassGenericity = enableSupClassGenericity;
/*     */   }
/*     */   
/*     */   public String getInterfaceExtendSupInterface() {
/* 102 */     return this.interfaceExtendSupInterface;
/*     */   }
/*     */   
/*     */   public void setInterfaceExtendSupInterface(String interfaceExtendSupInterface) {
/* 106 */     this.interfaceExtendSupInterface = interfaceExtendSupInterface;
/*     */   }
/*     */   
/*     */   public String getEnableInterfaceSupInterfaceGenericity() {
/* 110 */     return this.enableInterfaceSupInterfaceGenericity;
/*     */   }
/*     */   
/*     */   public void setEnableInterfaceSupInterfaceGenericity(String enableInterfaceSupInterfaceGenericity)
/*     */   {
/* 115 */     this.enableInterfaceSupInterfaceGenericity = enableInterfaceSupInterfaceGenericity;
/*     */   }
/*     */   
/*     */   public String getInterFaceExtendSupInterfaceDoMain() {
/* 119 */     int point = -1;
/* 120 */     if ((this.interfaceExtendSupInterface != null) && (!"".equals(this.interfaceExtendSupInterface)))
/* 121 */       point = this.interfaceExtendSupInterface.lastIndexOf(".");
/* 122 */     if ((this.interfaceExtendSupInterface != null) && (this.interfaceExtendSupInterface.length() > point)) {
/* 123 */       this.interfaceExtendSupInterfaceDoMain = this.interfaceExtendSupInterface.substring(point + 1);
/*     */     } else {
/* 125 */       this.interfaceExtendSupInterfaceDoMain = "";
/*     */     }
/* 127 */     return this.interfaceExtendSupInterfaceDoMain;
/*     */   }
/*     */   
/*     */   public XmlElement toXmlElement() {
/* 131 */     XmlElement answer = new XmlElement("javaManagerGenerator");
/*     */     
/* 133 */     if (this.targetPackage != null) {
/* 134 */       answer.addAttribute(new Attribute("targetPackage", this.targetPackage));
/*     */     }
/*     */     
/* 137 */     if (this.targetProject != null) {
/* 138 */       answer.addAttribute(new Attribute("targetProject", this.targetProject));
/*     */     }
/*     */     
/* 141 */     if (this.extendSupClass != null) {
/* 142 */       answer.addAttribute(new Attribute("extendSupClass", this.extendSupClass));
/*     */     }
/*     */     
/* 145 */     if (this.enableSupClassGenericity != null) {
/* 146 */       answer.addAttribute(new Attribute("enableSupClassGenericity", this.enableSupClassGenericity));
/*     */     }
/* 148 */     if (this.interfaceExtendSupInterface != null) {
/* 149 */       answer.addAttribute(new Attribute("interfaceExtendSupInterface", this.interfaceExtendSupInterface));
/*     */     }
/* 151 */     if (this.enableInterfaceSupInterfaceGenericity != null) {
/* 152 */       answer.addAttribute(new Attribute("enableInterfaceSupInterfaceGenericity", this.enableInterfaceSupInterfaceGenericity));
/*     */     }
/*     */     
/* 155 */     if (this.implementationPackage != null) {
/* 156 */       answer.addAttribute(new Attribute(
/* 157 */         "implementationPackage", this.targetProject));
/*     */     }
/*     */     
/* 160 */     addPropertyXmlElements(answer);
/*     */     
/* 162 */     return answer;
/*     */   }
/*     */   
/*     */   public String getImplementationPackage() {
/* 166 */     return this.implementationPackage;
/*     */   }
/*     */   
/*     */   public void setImplementationPackage(String implementationPackage) {
/* 170 */     this.implementationPackage = implementationPackage;
/*     */   }
/*     */   
/*     */   public void validate(List<String> errors, String contextId) {
/* 174 */     if (!StringUtility.stringHasValue(this.targetProject)) {
/* 175 */       errors.add(Messages.getString("ValidationError.2", contextId));
/*     */     }
/*     */     
/* 178 */     if (!StringUtility.stringHasValue(this.targetPackage)) {
/* 179 */       errors.add(Messages.getString("ValidationError.12", 
/* 180 */         "javaClientGenerator", contextId));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\YouGouManagerGeneratorConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */