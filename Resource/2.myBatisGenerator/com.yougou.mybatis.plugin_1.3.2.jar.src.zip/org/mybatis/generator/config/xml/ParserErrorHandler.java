/*    */ package org.mybatis.generator.config.xml;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.mybatis.generator.internal.util.messages.Messages;
/*    */ import org.xml.sax.ErrorHandler;
/*    */ import org.xml.sax.SAXException;
/*    */ import org.xml.sax.SAXParseException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParserErrorHandler
/*    */   implements ErrorHandler
/*    */ {
/*    */   private List<String> warnings;
/*    */   private List<String> errors;
/*    */   
/*    */   public ParserErrorHandler(List<String> warnings, List<String> errors)
/*    */   {
/* 39 */     this.warnings = warnings;
/* 40 */     this.errors = errors;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void warning(SAXParseException exception)
/*    */     throws SAXException
/*    */   {
/* 49 */     this.warnings.add(Messages.getString("Warning.7", 
/* 50 */       Integer.toString(exception.getLineNumber()), exception
/* 51 */       .getMessage()));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void error(SAXParseException exception)
/*    */     throws SAXException
/*    */   {
/* 60 */     this.errors.add(Messages.getString("RuntimeError.4", 
/* 61 */       Integer.toString(exception.getLineNumber()), exception
/* 62 */       .getMessage()));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void fatalError(SAXParseException exception)
/*    */     throws SAXException
/*    */   {
/* 71 */     this.errors.add(Messages.getString("RuntimeError.4", 
/* 72 */       Integer.toString(exception.getLineNumber()), exception
/* 73 */       .getMessage()));
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\xml\ParserErrorHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */