/*      */ package org.mybatis.generator.config.xml;
/*      */ 
/*      */ import com.yougou.mybatis.plugins.CodeLayoutEnum;
/*      */ import com.yougou.mybatis.plugins.Tools;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.net.URL;
/*      */ import java.net.URLConnection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import org.mybatis.generator.config.ColumnOverride;
/*      */ import org.mybatis.generator.config.ColumnRenamingRule;
/*      */ import org.mybatis.generator.config.CommentGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.Configuration;
/*      */ import org.mybatis.generator.config.Context;
/*      */ import org.mybatis.generator.config.GeneratedKey;
/*      */ import org.mybatis.generator.config.IgnoredColumn;
/*      */ import org.mybatis.generator.config.JDBCConnectionConfiguration;
/*      */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.JavaModelGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.JavaTypeResolverConfiguration;
/*      */ import org.mybatis.generator.config.ModelType;
/*      */ import org.mybatis.generator.config.PluginConfiguration;
/*      */ import org.mybatis.generator.config.PropertyHolder;
/*      */ import org.mybatis.generator.config.SqlMapGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.TableConfiguration;
/*      */ import org.mybatis.generator.config.YouGouControllerGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.YouGouManagerGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.YouGouServiceGeneratorConfiguration;
/*      */ import org.mybatis.generator.config.YouGouSqlMapConfigConfiguration;
/*      */ import org.mybatis.generator.config.YouGouTableSettingConfiguration;
/*      */ import org.mybatis.generator.exception.XMLParserException;
/*      */ import org.mybatis.generator.internal.ObjectFactory;
/*      */ import org.mybatis.generator.internal.util.StringUtility;
/*      */ import org.mybatis.generator.internal.util.messages.Messages;
/*      */ import org.w3c.dom.Element;
/*      */ import org.w3c.dom.NamedNodeMap;
/*      */ import org.w3c.dom.Node;
/*      */ import org.w3c.dom.NodeList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MyBatisGeneratorConfigurationParser
/*      */ {
/*      */   private Properties properties;
/*      */   
/*      */   public MyBatisGeneratorConfigurationParser(Properties properties)
/*      */   {
/*   72 */     if (properties == null) {
/*   73 */       this.properties = System.getProperties();
/*      */     } else {
/*   75 */       this.properties = properties;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Configuration parseConfiguration(Element rootNode, List<String> tableList, Map<CodeLayoutEnum, Boolean> codeLayout, String codeVersion)
/*      */     throws XMLParserException
/*      */   {
/*   91 */     Configuration configuration = new Configuration();
/*      */     
/*   93 */     NodeList nodeList = rootNode.getChildNodes();
/*   94 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*   95 */       Node childNode = nodeList.item(i);
/*      */       
/*   97 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  101 */         if ("properties".equals(childNode.getNodeName())) {
/*  102 */           parseProperties(configuration, childNode);
/*  103 */         } else if ("classPathEntry".equals(childNode.getNodeName())) {
/*  104 */           parseClassPathEntry(configuration, childNode);
/*  105 */         } else if ("context".equals(childNode.getNodeName())) {
/*  106 */           parseContext(configuration, childNode, tableList, codeLayout, codeVersion);
/*      */         }
/*      */       }
/*      */     }
/*  110 */     return configuration;
/*      */   }
/*      */   
/*      */   private void parseProperties(Configuration configuration, Node node) throws XMLParserException
/*      */   {
/*  115 */     Properties attributes = parseAttributes(node);
/*  116 */     String resource = attributes.getProperty("resource");
/*  117 */     String url = attributes.getProperty("url");
/*      */     
/*  119 */     if ((!StringUtility.stringHasValue(resource)) && 
/*  120 */       (!StringUtility.stringHasValue(url))) {
/*  121 */       throw new XMLParserException(Messages.getString("RuntimeError.14"));
/*      */     }
/*      */     
/*  124 */     if ((StringUtility.stringHasValue(resource)) && 
/*  125 */       (StringUtility.stringHasValue(url))) {
/*  126 */       throw new XMLParserException(Messages.getString("RuntimeError.14"));
/*      */     }
/*      */     
/*      */     try
/*      */     {
/*      */       URL resourceUrl;
/*  132 */       if (StringUtility.stringHasValue(resource)) {
/*  133 */         URL resourceUrl = ObjectFactory.getResource(resource);
/*  134 */         if (resourceUrl == null) {
/*  135 */           throw new XMLParserException(Messages.getString(
/*  136 */             "RuntimeError.15", resource));
/*      */         }
/*      */       } else {
/*  139 */         resourceUrl = new URL(url);
/*      */       }
/*      */       
/*  142 */       InputStream inputStream = resourceUrl.openConnection()
/*  143 */         .getInputStream();
/*      */       
/*  145 */       this.properties.load(inputStream);
/*  146 */       inputStream.close();
/*      */     } catch (IOException localIOException) {
/*  148 */       if (StringUtility.stringHasValue(resource)) {
/*  149 */         throw new XMLParserException(Messages.getString(
/*  150 */           "RuntimeError.16", resource));
/*      */       }
/*  152 */       throw new XMLParserException(Messages.getString(
/*  153 */         "RuntimeError.17", url));
/*      */     }
/*      */     URL resourceUrl;
/*      */   }
/*      */   
/*      */   private void parseContext(Configuration configuration, Node node, List<String> tableList, Map<CodeLayoutEnum, Boolean> codeLayout, String codeVersion)
/*      */   {
/*  160 */     Properties attributes = parseAttributes(node);
/*  161 */     String defaultModelType = attributes.getProperty("defaultModelType");
/*  162 */     String targetRuntime = attributes.getProperty("targetRuntime");
/*  163 */     String introspectedColumnImpl = attributes
/*  164 */       .getProperty("introspectedColumnImpl");
/*  165 */     String id = attributes.getProperty("id");
/*      */     
/*  167 */     ModelType mt = defaultModelType == null ? null : 
/*  168 */       ModelType.getModelType(defaultModelType);
/*      */     
/*  170 */     Context context = new Context(mt);
/*  171 */     context.setId(id);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  177 */     context.setCodeVersion(codeVersion);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  183 */     context.setCodingLayer(codeLayout);
/*      */     
/*  185 */     if (StringUtility.stringHasValue(introspectedColumnImpl)) {
/*  186 */       context.setIntrospectedColumnImpl(introspectedColumnImpl);
/*      */     }
/*  188 */     if (StringUtility.stringHasValue(targetRuntime)) {
/*  189 */       context.setTargetRuntime(targetRuntime);
/*      */     }
/*      */     
/*  192 */     configuration.addContext(context);
/*      */     
/*  194 */     NodeList nodeList = node.getChildNodes();
/*  195 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  196 */       Node childNode = nodeList.item(i);
/*      */       
/*  198 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  202 */         if ("property".equals(childNode.getNodeName())) {
/*  203 */           parseProperty(context, childNode);
/*  204 */         } else if ("plugin".equals(childNode.getNodeName())) {
/*  205 */           parsePlugin(context, childNode);
/*  206 */         } else if ("commentGenerator".equals(childNode.getNodeName())) {
/*  207 */           parseCommentGenerator(context, childNode);
/*  208 */         } else if ("jdbcConnection".equals(childNode.getNodeName())) {
/*  209 */           parseJdbcConnection(context, childNode);
/*  210 */         } else if ("javaModelGenerator".equals(childNode.getNodeName())) {
/*  211 */           parseJavaModelGenerator(context, childNode);
/*  212 */         } else if ("javaTypeResolver".equals(childNode.getNodeName())) {
/*  213 */           parseJavaTypeResolver(context, childNode);
/*  214 */         } else if ("sqlMapGenerator".equals(childNode.getNodeName())) {
/*  215 */           parseSqlMapGenerator(context, childNode);
/*  216 */         } else if ("javaClientGenerator".equals(childNode.getNodeName())) {
/*  217 */           parseJavaClientGenerator(context, childNode);
/*  218 */         } else if ("javaServiceGenerator".equals(childNode.getNodeName()))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  224 */           if (getSwitch(codeLayout, CodeLayoutEnum.SERVICE_LAYOUT)) {
/*  225 */             parseJavaServiceGenerator(context, childNode);
/*      */           }
/*  227 */         } else if ("javaManagerGenerator".equals(childNode.getNodeName()))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  233 */           if (getSwitch(codeLayout, CodeLayoutEnum.MANAGER_LAYOUT)) {
/*  234 */             parseJavaManagerGenerator(context, childNode);
/*      */           }
/*  236 */         } else if ("javaControllerGenerator".equals(childNode.getNodeName()))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  242 */           if (getSwitch(codeLayout, CodeLayoutEnum.CONTROLLER_LAYOUT)) {
/*  243 */             parseJavaControllerGenerator(context, childNode);
/*      */           }
/*  245 */         } else if ("table".equals(childNode.getNodeName())) {
/*  246 */           parseTable(context, childNode);
/*  247 */         } else if ("table".equals(childNode.getNodeName())) {
/*  248 */           parseTable(context, childNode);
/*  249 */         } else if ("tableSetting".equals(childNode.getNodeName()))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  255 */           parseYouGouTable(context, childNode, tableList);
/*  256 */         } else if ("sqlMapConfigFileAppend".equals(childNode.getNodeName()))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  262 */           parseYouGouSqlMapConfigConfiguration(context, childNode); }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean getSwitch(Map<CodeLayoutEnum, Boolean> codeLayout, CodeLayoutEnum key) {
/*  268 */     if ((codeLayout == null) || (codeLayout.get(key) == null)) {
/*  269 */       return false;
/*      */     }
/*  271 */     return ((Boolean)codeLayout.get(key)).booleanValue();
/*      */   }
/*      */   
/*      */   private void parseSqlMapGenerator(Context context, Node node) {
/*  275 */     SqlMapGeneratorConfiguration sqlMapGeneratorConfiguration = new SqlMapGeneratorConfiguration();
/*      */     
/*  277 */     context.setSqlMapGeneratorConfiguration(sqlMapGeneratorConfiguration);
/*      */     
/*  279 */     Properties attributes = parseAttributes(node);
/*  280 */     String targetPackage = attributes.getProperty("targetPackage");
/*  281 */     String targetProject = attributes.getProperty("targetProject");
/*      */     
/*  283 */     sqlMapGeneratorConfiguration.setTargetPackage(targetPackage);
/*  284 */     sqlMapGeneratorConfiguration.setTargetProject(targetProject);
/*      */     
/*  286 */     NodeList nodeList = node.getChildNodes();
/*  287 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  288 */       Node childNode = nodeList.item(i);
/*      */       
/*  290 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  294 */         if ("property".equals(childNode.getNodeName())) {
/*  295 */           parseProperty(sqlMapGeneratorConfiguration, childNode);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void addTables(Context context, YouGouTableSettingConfiguration ygtc, List<String> tables)
/*      */   {
/*  309 */     if ((tables == null) || (tables.size() < 1))
/*  310 */       return;
/*  311 */     for (String tableName : tables) {
/*  312 */       TableConfiguration tc = new TableConfiguration(context);
/*  313 */       context.addTableConfiguration(tc);
/*      */       
/*  315 */       String[] tableInfo = tableName.split("\\.");
/*  316 */       if (tableInfo.length < 2) {
/*  317 */         return;
/*      */       }
/*      */       
/*  320 */       if (!ygtc.isSchema()) {
/*  321 */         tc.setCatalog(tableInfo[0]);
/*      */       }
/*      */       
/*  324 */       if (ygtc.isSchema()) {
/*  325 */         tc.setSchema(tableInfo[0]);
/*      */       }
/*      */       
/*  328 */       if (StringUtility.stringHasValue(tableInfo[1])) {
/*  329 */         tc.setTableName(tableInfo[1]);
/*      */       }
/*      */       
/*  332 */       tc.setInsertStatementEnabled(ygtc.isInsertStatementEnabled());
/*      */       
/*  334 */       tc.setSelectByPrimaryKeyStatementEnabled(ygtc.isSelectByPrimaryKeyStatementEnabled());
/*      */       
/*  336 */       tc.setSelectByExampleStatementEnabled(ygtc.isSelectByExampleStatementEnabled());
/*      */       
/*  338 */       tc.setUpdateByPrimaryKeyStatementEnabled(ygtc.isUpdateByPrimaryKeyStatementEnabled());
/*      */       
/*  340 */       tc.setDeleteByPrimaryKeyStatementEnabled(ygtc.isDeleteByPrimaryKeyStatementEnabled());
/*      */       
/*  342 */       tc.setDeleteByExampleStatementEnabled(ygtc.isDeleteByExampleStatementEnabled());
/*      */       
/*  344 */       tc.setCountByExampleStatementEnabled(ygtc.isCountByExampleStatementEnabled());
/*      */       
/*  346 */       tc.setUpdateByExampleStatementEnabled(ygtc.isUpdateByExampleStatementEnabled());
/*      */       
/*  348 */       tc.setDelimitIdentifiers(ygtc.isDelimitIdentifiers());
/*      */       
/*  350 */       tc.setAllColumnDelimitingEnabled(ygtc.isAllColumnDelimitingEnabled());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseTable(Context context, Node node)
/*      */   {
/*  364 */     TableConfiguration tc = new TableConfiguration(context);
/*  365 */     context.addTableConfiguration(tc);
/*      */     
/*  367 */     Properties attributes = parseAttributes(node);
/*  368 */     String catalog = attributes.getProperty("catalog");
/*  369 */     String schema = attributes.getProperty("schema");
/*  370 */     String tableName = attributes.getProperty("tableName");
/*  371 */     String domainObjectName = attributes.getProperty("domainObjectName");
/*  372 */     String alias = attributes.getProperty("alias");
/*  373 */     String enableInsert = attributes.getProperty("enableInsert");
/*  374 */     String enableSelectByPrimaryKey = attributes
/*  375 */       .getProperty("enableSelectByPrimaryKey");
/*  376 */     String enableSelectByExample = attributes
/*  377 */       .getProperty("enableSelectByExample");
/*  378 */     String enableUpdateByPrimaryKey = attributes
/*  379 */       .getProperty("enableUpdateByPrimaryKey");
/*  380 */     String enableDeleteByPrimaryKey = attributes
/*  381 */       .getProperty("enableDeleteByPrimaryKey");
/*  382 */     String enableDeleteByExample = attributes
/*  383 */       .getProperty("enableDeleteByExample");
/*  384 */     String enableCountByExample = attributes
/*  385 */       .getProperty("enableCountByExample");
/*  386 */     String enableUpdateByExample = attributes
/*  387 */       .getProperty("enableUpdateByExample");
/*  388 */     String selectByPrimaryKeyQueryId = attributes
/*  389 */       .getProperty("selectByPrimaryKeyQueryId");
/*  390 */     String selectByExampleQueryId = attributes
/*  391 */       .getProperty("selectByExampleQueryId");
/*  392 */     String modelType = attributes.getProperty("modelType");
/*  393 */     String escapeWildcards = attributes.getProperty("escapeWildcards");
/*  394 */     String delimitIdentifiers = attributes
/*  395 */       .getProperty("delimitIdentifiers");
/*  396 */     String delimitAllColumns = attributes.getProperty("delimitAllColumns");
/*      */     
/*  398 */     if (StringUtility.stringHasValue(catalog)) {
/*  399 */       tc.setCatalog(catalog);
/*      */     }
/*      */     
/*  402 */     if (StringUtility.stringHasValue(schema)) {
/*  403 */       tc.setSchema(schema);
/*      */     }
/*      */     
/*  406 */     if (StringUtility.stringHasValue(tableName)) {
/*  407 */       tc.setTableName(tableName);
/*      */     }
/*      */     
/*  410 */     if (StringUtility.stringHasValue(domainObjectName)) {
/*  411 */       tc.setDomainObjectName(domainObjectName);
/*      */     }
/*      */     
/*  414 */     if (StringUtility.stringHasValue(alias)) {
/*  415 */       tc.setAlias(alias);
/*      */     }
/*      */     
/*  418 */     if (StringUtility.stringHasValue(enableInsert)) {
/*  419 */       tc.setInsertStatementEnabled(StringUtility.isTrue(enableInsert));
/*      */     }
/*      */     
/*  422 */     if (StringUtility.stringHasValue(enableSelectByPrimaryKey)) {
/*  423 */       tc.setSelectByPrimaryKeyStatementEnabled(
/*  424 */         StringUtility.isTrue(enableSelectByPrimaryKey));
/*      */     }
/*      */     
/*  427 */     if (StringUtility.stringHasValue(enableSelectByExample)) {
/*  428 */       tc.setSelectByExampleStatementEnabled(
/*  429 */         StringUtility.isTrue(enableSelectByExample));
/*      */     }
/*      */     
/*  432 */     if (StringUtility.stringHasValue(enableUpdateByPrimaryKey)) {
/*  433 */       tc.setUpdateByPrimaryKeyStatementEnabled(
/*  434 */         StringUtility.isTrue(enableUpdateByPrimaryKey));
/*      */     }
/*      */     
/*  437 */     if (StringUtility.stringHasValue(enableDeleteByPrimaryKey)) {
/*  438 */       tc.setDeleteByPrimaryKeyStatementEnabled(
/*  439 */         StringUtility.isTrue(enableDeleteByPrimaryKey));
/*      */     }
/*      */     
/*  442 */     if (StringUtility.stringHasValue(enableDeleteByExample)) {
/*  443 */       tc.setDeleteByExampleStatementEnabled(
/*  444 */         StringUtility.isTrue(enableDeleteByExample));
/*      */     }
/*      */     
/*  447 */     if (StringUtility.stringHasValue(enableCountByExample)) {
/*  448 */       tc.setCountByExampleStatementEnabled(
/*  449 */         StringUtility.isTrue(enableCountByExample));
/*      */     }
/*      */     
/*  452 */     if (StringUtility.stringHasValue(enableUpdateByExample)) {
/*  453 */       tc.setUpdateByExampleStatementEnabled(
/*  454 */         StringUtility.isTrue(enableUpdateByExample));
/*      */     }
/*      */     
/*  457 */     if (StringUtility.stringHasValue(selectByPrimaryKeyQueryId)) {
/*  458 */       tc.setSelectByPrimaryKeyQueryId(selectByPrimaryKeyQueryId);
/*      */     }
/*      */     
/*  461 */     if (StringUtility.stringHasValue(selectByExampleQueryId)) {
/*  462 */       tc.setSelectByExampleQueryId(selectByExampleQueryId);
/*      */     }
/*      */     
/*  465 */     if (StringUtility.stringHasValue(modelType)) {
/*  466 */       tc.setConfiguredModelType(modelType);
/*      */     }
/*      */     
/*  469 */     if (StringUtility.stringHasValue(escapeWildcards)) {
/*  470 */       tc.setWildcardEscapingEnabled(StringUtility.isTrue(escapeWildcards));
/*      */     }
/*      */     
/*  473 */     if (StringUtility.stringHasValue(delimitIdentifiers)) {
/*  474 */       tc.setDelimitIdentifiers(StringUtility.isTrue(delimitIdentifiers));
/*      */     }
/*      */     
/*  477 */     if (StringUtility.stringHasValue(delimitAllColumns)) {
/*  478 */       tc.setAllColumnDelimitingEnabled(StringUtility.isTrue(delimitAllColumns));
/*      */     }
/*      */     
/*  481 */     NodeList nodeList = node.getChildNodes();
/*  482 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  483 */       Node childNode = nodeList.item(i);
/*      */       
/*  485 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  489 */         if ("property".equals(childNode.getNodeName())) {
/*  490 */           parseProperty(tc, childNode);
/*  491 */         } else if ("columnOverride".equals(childNode.getNodeName())) {
/*  492 */           parseColumnOverride(tc, childNode);
/*  493 */         } else if ("ignoreColumn".equals(childNode.getNodeName())) {
/*  494 */           parseIgnoreColumn(tc, childNode);
/*  495 */         } else if ("generatedKey".equals(childNode.getNodeName())) {
/*  496 */           parseGeneratedKey(tc, childNode);
/*  497 */         } else if ("columnRenamingRule".equals(childNode.getNodeName())) {
/*  498 */           parseColumnRenamingRule(tc, childNode);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseYouGouTable(Context context, Node node, List<String> tableList)
/*      */   {
/*  511 */     YouGouTableSettingConfiguration tc = new YouGouTableSettingConfiguration(context);
/*  512 */     context.setYouGouTableSettingConfiguration(tc);
/*      */     
/*  514 */     Properties attributes = parseAttributes(node);
/*  515 */     String isSchema = attributes.getProperty("isSchema");
/*  516 */     String alias = attributes.getProperty("alias");
/*  517 */     String enableInsert = attributes.getProperty("enableInsert");
/*  518 */     String enableSelectByPrimaryKey = attributes
/*  519 */       .getProperty("enableSelectByPrimaryKey");
/*  520 */     String enableSelectByExample = attributes
/*  521 */       .getProperty("enableSelectByExample");
/*  522 */     String enableUpdateByPrimaryKey = attributes
/*  523 */       .getProperty("enableUpdateByPrimaryKey");
/*  524 */     String enableDeleteByPrimaryKey = attributes
/*  525 */       .getProperty("enableDeleteByPrimaryKey");
/*  526 */     String enableDeleteByExample = attributes
/*  527 */       .getProperty("enableDeleteByExample");
/*  528 */     String enableCountByExample = attributes
/*  529 */       .getProperty("enableCountByExample");
/*  530 */     String enableUpdateByExample = attributes
/*  531 */       .getProperty("enableUpdateByExample");
/*  532 */     String selectByPrimaryKeyQueryId = attributes
/*  533 */       .getProperty("selectByPrimaryKeyQueryId");
/*  534 */     String selectByExampleQueryId = attributes
/*  535 */       .getProperty("selectByExampleQueryId");
/*  536 */     String modelType = attributes.getProperty("modelType");
/*  537 */     String escapeWildcards = attributes.getProperty("escapeWildcards");
/*  538 */     String delimitIdentifiers = attributes
/*  539 */       .getProperty("delimitIdentifiers");
/*  540 */     String delimitAllColumns = attributes.getProperty("delimitAllColumns");
/*      */     
/*  542 */     HashMap<String, String> prefixMap = new HashMap();
/*  543 */     boolean ignoreGeneratorSchema = false;
/*  544 */     NodeList nodeList = node.getChildNodes();
/*      */     
/*  546 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  547 */       Node childNode = nodeList.item(i);
/*  548 */       if ("prop".equals(childNode.getNodeName())) {
/*  549 */         Properties a = parseAttributes(childNode);
/*  550 */         if ("replaceTablePrefix".equals(a.getProperty("name"))) {
/*  551 */           NodeList childNodeList = childNode.getChildNodes();
/*  552 */           for (int j = 0; j < childNodeList.getLength(); j++) {
/*  553 */             Node listNode = childNodeList.item(i);
/*  554 */             if ("list".equals(listNode.getNodeName())) {
/*  555 */               NodeList prefixNodeList = listNode.getChildNodes();
/*  556 */               for (int k = 0; k < prefixNodeList.getLength(); k++) {
/*  557 */                 Node prefixNode = prefixNodeList.item(k);
/*  558 */                 if ("prefix".equals(prefixNode.getNodeName())) {
/*  559 */                   Properties attributes1 = parseAttributes(prefixNode);
/*  560 */                   prefixMap.put(attributes1.getProperty("name"), attributes1.getProperty("value"));
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*  565 */         } else if ("ignoreGeneratorSchema".equals(a.getProperty("name"))) {
/*  566 */           ignoreGeneratorSchema = new Boolean(a.getProperty("value")).booleanValue();
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  571 */     tc.setReplaceTablePrefixMap(prefixMap);
/*  572 */     tc.setIgnoreGeneratorSchema(ignoreGeneratorSchema);
/*      */     
/*  574 */     if (!new Boolean(isSchema).booleanValue()) {
/*  575 */       tc.setSchema(false);
/*      */     }
/*      */     
/*  578 */     if (new Boolean(isSchema).booleanValue()) {
/*  579 */       tc.setSchema(true);
/*      */     }
/*      */     
/*  582 */     if (StringUtility.stringHasValue(alias)) {
/*  583 */       tc.setAlias(alias);
/*      */     }
/*      */     
/*  586 */     if (StringUtility.stringHasValue(enableInsert)) {
/*  587 */       tc.setInsertStatementEnabled(StringUtility.isTrue(enableInsert));
/*      */     }
/*      */     
/*  590 */     if (StringUtility.stringHasValue(enableSelectByPrimaryKey)) {
/*  591 */       tc.setSelectByPrimaryKeyStatementEnabled(
/*  592 */         StringUtility.isTrue(enableSelectByPrimaryKey));
/*      */     }
/*      */     
/*  595 */     if (StringUtility.stringHasValue(enableSelectByExample)) {
/*  596 */       tc.setSelectByExampleStatementEnabled(
/*  597 */         StringUtility.isTrue(enableSelectByExample));
/*      */     }
/*      */     
/*  600 */     if (StringUtility.stringHasValue(enableUpdateByPrimaryKey)) {
/*  601 */       tc.setUpdateByPrimaryKeyStatementEnabled(
/*  602 */         StringUtility.isTrue(enableUpdateByPrimaryKey));
/*      */     }
/*      */     
/*  605 */     if (StringUtility.stringHasValue(enableDeleteByPrimaryKey)) {
/*  606 */       tc.setDeleteByPrimaryKeyStatementEnabled(
/*  607 */         StringUtility.isTrue(enableDeleteByPrimaryKey));
/*      */     }
/*      */     
/*  610 */     if (StringUtility.stringHasValue(enableDeleteByExample)) {
/*  611 */       tc.setDeleteByExampleStatementEnabled(
/*  612 */         StringUtility.isTrue(enableDeleteByExample));
/*      */     }
/*      */     
/*  615 */     if (StringUtility.stringHasValue(enableCountByExample)) {
/*  616 */       tc.setCountByExampleStatementEnabled(
/*  617 */         StringUtility.isTrue(enableCountByExample));
/*      */     }
/*      */     
/*  620 */     if (StringUtility.stringHasValue(enableUpdateByExample)) {
/*  621 */       tc.setUpdateByExampleStatementEnabled(
/*  622 */         StringUtility.isTrue(enableUpdateByExample));
/*      */     }
/*      */     
/*  625 */     if (StringUtility.stringHasValue(selectByPrimaryKeyQueryId)) {
/*  626 */       tc.setSelectByPrimaryKeyQueryId(selectByPrimaryKeyQueryId);
/*      */     }
/*      */     
/*  629 */     if (StringUtility.stringHasValue(selectByExampleQueryId)) {
/*  630 */       tc.setSelectByExampleQueryId(selectByExampleQueryId);
/*      */     }
/*      */     
/*  633 */     if (StringUtility.stringHasValue(modelType)) {
/*  634 */       tc.setConfiguredModelType(modelType);
/*      */     }
/*      */     
/*  637 */     if (StringUtility.stringHasValue(escapeWildcards)) {
/*  638 */       tc.setWildcardEscapingEnabled(StringUtility.isTrue(escapeWildcards));
/*      */     }
/*      */     
/*  641 */     if (StringUtility.stringHasValue(delimitIdentifiers)) {
/*  642 */       tc.setDelimitIdentifiers(StringUtility.isTrue(delimitIdentifiers));
/*      */     }
/*      */     
/*  645 */     if (StringUtility.stringHasValue(delimitAllColumns)) {
/*  646 */       tc.setAllColumnDelimitingEnabled(StringUtility.isTrue(delimitAllColumns));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  654 */     addTables(context, tc, tableList);
/*      */   }
/*      */   
/*      */   private void parseColumnOverride(TableConfiguration tc, Node node) {
/*  658 */     Properties attributes = parseAttributes(node);
/*  659 */     String column = attributes.getProperty("column");
/*  660 */     String property = attributes.getProperty("property");
/*  661 */     String javaType = attributes.getProperty("javaType");
/*  662 */     String jdbcType = attributes.getProperty("jdbcType");
/*  663 */     String typeHandler = attributes.getProperty("typeHandler");
/*  664 */     String delimitedColumnName = attributes
/*  665 */       .getProperty("delimitedColumnName");
/*      */     
/*  667 */     ColumnOverride co = new ColumnOverride(column);
/*      */     
/*  669 */     if (StringUtility.stringHasValue(property)) {
/*  670 */       co.setJavaProperty(property);
/*      */     }
/*      */     
/*  673 */     if (StringUtility.stringHasValue(javaType)) {
/*  674 */       co.setJavaType(javaType);
/*      */     }
/*      */     
/*  677 */     if (StringUtility.stringHasValue(jdbcType)) {
/*  678 */       co.setJdbcType(jdbcType);
/*      */     }
/*      */     
/*  681 */     if (StringUtility.stringHasValue(typeHandler)) {
/*  682 */       co.setTypeHandler(typeHandler);
/*      */     }
/*      */     
/*  685 */     if (StringUtility.stringHasValue(delimitedColumnName)) {
/*  686 */       co.setColumnNameDelimited(StringUtility.isTrue(delimitedColumnName));
/*      */     }
/*      */     
/*  689 */     NodeList nodeList = node.getChildNodes();
/*  690 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  691 */       Node childNode = nodeList.item(i);
/*      */       
/*  693 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  697 */         if ("property".equals(childNode.getNodeName())) {
/*  698 */           parseProperty(co, childNode);
/*      */         }
/*      */       }
/*      */     }
/*  702 */     tc.addColumnOverride(co);
/*      */   }
/*      */   
/*      */   private void parseGeneratedKey(TableConfiguration tc, Node node) {
/*  706 */     Properties attributes = parseAttributes(node);
/*      */     
/*  708 */     String column = attributes.getProperty("column");
/*  709 */     boolean identity = StringUtility.isTrue(attributes
/*  710 */       .getProperty("identity"));
/*  711 */     String sqlStatement = attributes.getProperty("sqlStatement");
/*  712 */     String type = attributes.getProperty("type");
/*      */     
/*  714 */     GeneratedKey gk = new GeneratedKey(column, sqlStatement, identity, type);
/*      */     
/*  716 */     tc.setGeneratedKey(gk);
/*      */   }
/*      */   
/*      */   private void parseIgnoreColumn(TableConfiguration tc, Node node) {
/*  720 */     Properties attributes = parseAttributes(node);
/*  721 */     String column = attributes.getProperty("column");
/*  722 */     String delimitedColumnName = attributes
/*  723 */       .getProperty("delimitedColumnName");
/*      */     
/*  725 */     IgnoredColumn ic = new IgnoredColumn(column);
/*      */     
/*  727 */     if (StringUtility.stringHasValue(delimitedColumnName)) {
/*  728 */       ic.setColumnNameDelimited(StringUtility.isTrue(delimitedColumnName));
/*      */     }
/*      */     
/*  731 */     tc.addIgnoredColumn(ic);
/*      */   }
/*      */   
/*      */   private void parseColumnRenamingRule(TableConfiguration tc, Node node) {
/*  735 */     Properties attributes = parseAttributes(node);
/*  736 */     String searchString = attributes.getProperty("searchString");
/*  737 */     String replaceString = attributes.getProperty("replaceString");
/*      */     
/*  739 */     ColumnRenamingRule crr = new ColumnRenamingRule();
/*      */     
/*  741 */     crr.setSearchString(searchString);
/*      */     
/*  743 */     if (StringUtility.stringHasValue(replaceString)) {
/*  744 */       crr.setReplaceString(replaceString);
/*      */     }
/*      */     
/*  747 */     tc.setColumnRenamingRule(crr);
/*      */   }
/*      */   
/*      */   private void parseJavaTypeResolver(Context context, Node node) {
/*  751 */     JavaTypeResolverConfiguration javaTypeResolverConfiguration = new JavaTypeResolverConfiguration();
/*      */     
/*  753 */     context.setJavaTypeResolverConfiguration(javaTypeResolverConfiguration);
/*      */     
/*  755 */     Properties attributes = parseAttributes(node);
/*  756 */     String type = attributes.getProperty("type");
/*      */     
/*  758 */     if (StringUtility.stringHasValue(type)) {
/*  759 */       javaTypeResolverConfiguration.setConfigurationType(type);
/*      */     }
/*      */     
/*  762 */     NodeList nodeList = node.getChildNodes();
/*  763 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  764 */       Node childNode = nodeList.item(i);
/*      */       
/*  766 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  770 */         if ("property".equals(childNode.getNodeName()))
/*  771 */           parseProperty(javaTypeResolverConfiguration, childNode);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void parsePlugin(Context context, Node node) {
/*  777 */     PluginConfiguration pluginConfiguration = new PluginConfiguration();
/*      */     
/*  779 */     context.addPluginConfiguration(pluginConfiguration);
/*      */     
/*  781 */     Properties attributes = parseAttributes(node);
/*  782 */     String type = attributes.getProperty("type");
/*      */     
/*  784 */     pluginConfiguration.setConfigurationType(type);
/*      */     
/*  786 */     NodeList nodeList = node.getChildNodes();
/*  787 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  788 */       Node childNode = nodeList.item(i);
/*      */       
/*  790 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  794 */         if ("property".equals(childNode.getNodeName()))
/*  795 */           parseProperty(pluginConfiguration, childNode);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void parseJavaModelGenerator(Context context, Node node) {
/*  801 */     JavaModelGeneratorConfiguration javaModelGeneratorConfiguration = new JavaModelGeneratorConfiguration();
/*      */     
/*  803 */     context
/*  804 */       .setJavaModelGeneratorConfiguration(javaModelGeneratorConfiguration);
/*      */     
/*  806 */     Properties attributes = parseAttributes(node);
/*  807 */     String targetPackage = attributes.getProperty("targetPackage");
/*  808 */     String targetProject = attributes.getProperty("targetProject");
/*      */     
/*  810 */     javaModelGeneratorConfiguration.setTargetPackage(targetPackage);
/*  811 */     javaModelGeneratorConfiguration.setTargetProject(targetProject);
/*      */     
/*  813 */     NodeList nodeList = node.getChildNodes();
/*  814 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  815 */       Node childNode = nodeList.item(i);
/*      */       
/*  817 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  821 */         if ("property".equals(childNode.getNodeName()))
/*  822 */           parseProperty(javaModelGeneratorConfiguration, childNode);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void parseJavaClientGenerator(Context context, Node node) {
/*  828 */     JavaClientGeneratorConfiguration javaClientGeneratorConfiguration = new JavaClientGeneratorConfiguration();
/*      */     
/*  830 */     context.setJavaClientGeneratorConfiguration(javaClientGeneratorConfiguration);
/*      */     
/*  832 */     Properties attributes = parseAttributes(node);
/*  833 */     String type = attributes.getProperty("type");
/*  834 */     String targetPackage = attributes.getProperty("targetPackage");
/*  835 */     String targetProject = attributes.getProperty("targetProject");
/*  836 */     String implementationPackage = attributes
/*  837 */       .getProperty("implementationPackage");
/*      */     
/*  839 */     javaClientGeneratorConfiguration.setConfigurationType(type);
/*  840 */     javaClientGeneratorConfiguration.setTargetPackage(targetPackage);
/*  841 */     javaClientGeneratorConfiguration.setTargetProject(targetProject);
/*  842 */     javaClientGeneratorConfiguration
/*  843 */       .setImplementationPackage(implementationPackage);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  850 */     Set<String> exclusionsSet = new HashSet();
/*      */     
/*  852 */     NodeList nodeList = node.getChildNodes();
/*  853 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  854 */       Node childNode = nodeList.item(i);
/*      */       
/*  856 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  860 */         if ("property".equals(childNode.getNodeName()))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  866 */           Properties propertyAttributes = parseAttributes(childNode);
/*  867 */           if ("exclusionsMethods".equals(propertyAttributes.getProperty("name"))) { String[] arrayOfString;
/*  868 */             int j = (arrayOfString = propertyAttributes.getProperty("value").split(",")).length; for (int i = 0; i < j; i++) { String m = arrayOfString[i];
/*  869 */               exclusionsSet.add(m);
/*      */             }
/*  871 */             javaClientGeneratorConfiguration.setExclusionsMethods(exclusionsSet);
/*  872 */           } else if ("interfaceExtendSupInterface".equals(propertyAttributes.getProperty("name"))) {
/*  873 */             javaClientGeneratorConfiguration.setInterfaceExtendSupInterface(propertyAttributes.getProperty("value"));
/*  874 */           } else if ("enableInterfaceSupInterfaceGenericity".equals(propertyAttributes.getProperty("name"))) {
/*  875 */             javaClientGeneratorConfiguration.setEnableInterfaceSupInterfaceGenericity(propertyAttributes.getProperty("value"));
/*      */           } else {
/*  877 */             parseProperty(javaClientGeneratorConfiguration, childNode);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseJavaServiceGenerator(Context context, Node node)
/*      */   {
/*  890 */     YouGouServiceGeneratorConfiguration javaYouGouServiceGeneratorConfiguration = new YouGouServiceGeneratorConfiguration();
/*      */     
/*  892 */     context.setYouGouServiceGeneratorConfiguration(javaYouGouServiceGeneratorConfiguration);
/*      */     
/*  894 */     Properties attributes = parseAttributes(node);
/*  895 */     String targetPackage = attributes.getProperty("targetPackage");
/*  896 */     String targetProject = attributes.getProperty("targetProject");
/*  897 */     String implementationPackage = attributes
/*  898 */       .getProperty("implementationPackage");
/*      */     
/*  900 */     String interfaceExtendSupInterface = attributes.getProperty("interfaceExtendSupInterface");
/*  901 */     String enableInterfaceSupInterfaceGenericity = attributes.getProperty("enableInterfaceSupInterfaceGenericity");
/*  902 */     enableInterfaceSupInterfaceGenericity = (interfaceExtendSupInterface == null) || ("".equals(interfaceExtendSupInterface)) || (enableInterfaceSupInterfaceGenericity == null) || ("".equals(enableInterfaceSupInterfaceGenericity)) ? "false" : enableInterfaceSupInterfaceGenericity;
/*  903 */     javaYouGouServiceGeneratorConfiguration.setInterfaceExtendSupInterface(interfaceExtendSupInterface);
/*  904 */     javaYouGouServiceGeneratorConfiguration.setEnableInterfaceSupInterfaceGenericity(enableInterfaceSupInterfaceGenericity);
/*      */     
/*  906 */     String extendSupClass = attributes.getProperty("extendSupClass");
/*  907 */     String enableSupClassGenericity = attributes.getProperty("enableSupClassGenericity");
/*  908 */     enableSupClassGenericity = (extendSupClass == null) || ("".equals(extendSupClass)) || (enableSupClassGenericity == null) || ("".equals(enableSupClassGenericity)) ? "false" : enableSupClassGenericity;
/*      */     
/*  910 */     javaYouGouServiceGeneratorConfiguration.setExtendSupClass(extendSupClass);
/*  911 */     javaYouGouServiceGeneratorConfiguration.setEnableSupClassGenericity(enableSupClassGenericity);
/*  912 */     javaYouGouServiceGeneratorConfiguration.setTargetPackage(targetPackage);
/*  913 */     javaYouGouServiceGeneratorConfiguration.setTargetProject(targetProject);
/*  914 */     javaYouGouServiceGeneratorConfiguration
/*  915 */       .setImplementationPackage(implementationPackage);
/*      */     
/*      */ 
/*  918 */     NodeList nodeList = node.getChildNodes();
/*  919 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  920 */       Node childNode = nodeList.item(i);
/*      */       
/*  922 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  926 */         if ("property".equals(childNode.getNodeName())) {
/*  927 */           parseProperty(javaYouGouServiceGeneratorConfiguration, childNode);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseJavaManagerGenerator(Context context, Node node)
/*      */   {
/*  938 */     YouGouManagerGeneratorConfiguration javaYouGouManagerGeneratorConfiguration = new YouGouManagerGeneratorConfiguration();
/*      */     
/*  940 */     context.setYouGouManagerGeneratorConfiguration(javaYouGouManagerGeneratorConfiguration);
/*      */     
/*  942 */     Properties attributes = parseAttributes(node);
/*  943 */     String targetPackage = attributes.getProperty("targetPackage");
/*  944 */     String targetProject = attributes.getProperty("targetProject");
/*  945 */     String implementationPackage = attributes
/*  946 */       .getProperty("implementationPackage");
/*      */     
/*      */ 
/*  949 */     String interfaceExtendSupInterface = attributes.getProperty("interfaceExtendSupInterface");
/*  950 */     String enableInterfaceSupInterfaceGenericity = attributes.getProperty("enableInterfaceSupInterfaceGenericity");
/*  951 */     enableInterfaceSupInterfaceGenericity = (interfaceExtendSupInterface == null) || ("".equals(interfaceExtendSupInterface)) || (enableInterfaceSupInterfaceGenericity == null) || ("".equals(enableInterfaceSupInterfaceGenericity)) ? "false" : enableInterfaceSupInterfaceGenericity;
/*  952 */     javaYouGouManagerGeneratorConfiguration.setInterfaceExtendSupInterface(interfaceExtendSupInterface);
/*  953 */     javaYouGouManagerGeneratorConfiguration.setEnableInterfaceSupInterfaceGenericity(enableInterfaceSupInterfaceGenericity);
/*      */     
/*  955 */     String extendSupClass = attributes.getProperty("extendSupClass");
/*  956 */     String enableSupClassGenericity = attributes.getProperty("enableSupClassGenericity");
/*  957 */     javaYouGouManagerGeneratorConfiguration.setExtendSupClass(extendSupClass);
/*  958 */     enableSupClassGenericity = (extendSupClass == null) || ("".equals(extendSupClass)) || (enableSupClassGenericity == null) || ("".equals(enableSupClassGenericity)) ? "false" : enableSupClassGenericity;
/*  959 */     javaYouGouManagerGeneratorConfiguration.setEnableSupClassGenericity(enableSupClassGenericity);
/*  960 */     javaYouGouManagerGeneratorConfiguration.setTargetPackage(targetPackage);
/*  961 */     javaYouGouManagerGeneratorConfiguration.setTargetProject(targetProject);
/*  962 */     javaYouGouManagerGeneratorConfiguration
/*  963 */       .setImplementationPackage(implementationPackage);
/*      */     
/*      */ 
/*  966 */     NodeList nodeList = node.getChildNodes();
/*  967 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  968 */       Node childNode = nodeList.item(i);
/*      */       
/*  970 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/*  974 */         if ("property".equals(childNode.getNodeName())) {
/*  975 */           parseProperty(javaYouGouManagerGeneratorConfiguration, childNode);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseJavaControllerGenerator(Context context, Node node)
/*      */   {
/*  987 */     YouGouControllerGeneratorConfiguration javaYouGouControllerGeneratorConfiguration = new YouGouControllerGeneratorConfiguration();
/*      */     
/*  989 */     context.setYouGouControllerGeneratorConfiguration(javaYouGouControllerGeneratorConfiguration);
/*      */     
/*  991 */     Properties attributes = parseAttributes(node);
/*  992 */     String targetPackage = attributes.getProperty("targetPackage");
/*  993 */     String targetProject = attributes.getProperty("targetProject");
/*  994 */     String implementationPackage = attributes
/*  995 */       .getProperty("implementationPackage");
/*      */     
/*  997 */     String interfaceExtendSupInterface = attributes.getProperty("interfaceExtendSupInterface");
/*  998 */     String enableInterfaceSupInterfaceGenericity = attributes.getProperty("enableInterfaceSupInterfaceGenericity");
/*  999 */     enableInterfaceSupInterfaceGenericity = (interfaceExtendSupInterface == null) || ("".equals(interfaceExtendSupInterface)) || (enableInterfaceSupInterfaceGenericity == null) || ("".equals(enableInterfaceSupInterfaceGenericity)) ? "false" : enableInterfaceSupInterfaceGenericity;
/* 1000 */     javaYouGouControllerGeneratorConfiguration.setInterFaceExtendSupInterface(interfaceExtendSupInterface);
/* 1001 */     javaYouGouControllerGeneratorConfiguration.setEnableInterfaceSupInterfaceGenericity(enableInterfaceSupInterfaceGenericity);
/*      */     
/* 1003 */     String extendSupClass = attributes.getProperty("extendSupClass");
/* 1004 */     String extendSupClassFor3Layer = attributes.getProperty("extendSupClassFor3Layer");
/* 1005 */     if ((Context.getCodingLayer().get(CodeLayoutEnum.MANAGER_LAYOUT) == null) && ((extendSupClassFor3Layer == null) || ("".equals(extendSupClassFor3Layer)))) {
/* 1006 */       Tools.writeLine("选择生成三层代码,未配置extendSupClassFor3Layer属性,请检查!");
/*      */     }
/* 1008 */     String enableSupClassGenericity = attributes.getProperty("enableSupClassGenericity");
/* 1009 */     javaYouGouControllerGeneratorConfiguration.setExtendSupClass(extendSupClass);
/* 1010 */     javaYouGouControllerGeneratorConfiguration.setExtendSupClassFor3Layer(extendSupClassFor3Layer);
/* 1011 */     Boolean flag = Boolean.valueOf((extendSupClass == null) || ("".equals(extendSupClass)) || (extendSupClassFor3Layer == null) || ("".equals(extendSupClassFor3Layer)));
/* 1012 */     enableSupClassGenericity = (flag.booleanValue()) || (enableSupClassGenericity == null) || ("".equals(enableSupClassGenericity)) ? "false" : enableSupClassGenericity;
/* 1013 */     javaYouGouControllerGeneratorConfiguration.setEnableSupClassGenericity(enableSupClassGenericity);
/* 1014 */     javaYouGouControllerGeneratorConfiguration.setTargetPackage(targetPackage);
/* 1015 */     javaYouGouControllerGeneratorConfiguration.setTargetProject(targetProject);
/* 1016 */     javaYouGouControllerGeneratorConfiguration
/* 1017 */       .setImplementationPackage(implementationPackage);
/*      */     
/*      */ 
/* 1020 */     NodeList nodeList = node.getChildNodes();
/* 1021 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 1022 */       Node childNode = nodeList.item(i);
/*      */       
/* 1024 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1028 */         if ("property".equals(childNode.getNodeName())) {
/* 1029 */           parseProperty(javaYouGouControllerGeneratorConfiguration, childNode);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void parseYouGouSqlMapConfigConfiguration(Context context, Node node)
/*      */   {
/* 1044 */     YouGouSqlMapConfigConfiguration youGouSqlMapConfigConfiguration = new YouGouSqlMapConfigConfiguration();
/*      */     
/* 1046 */     Context.setYouGouSqlMapConfigConfiguration(youGouSqlMapConfigConfiguration);
/*      */     
/* 1048 */     Properties attributes = parseAttributes(node);
/* 1049 */     String targetPackage = attributes.getProperty("targetPackage");
/* 1050 */     String targetProject = attributes.getProperty("targetProject");
/* 1051 */     String confileFileName = attributes.getProperty("confileFileName");
/* 1052 */     String confileFilePackagePath = attributes.getProperty("confileFilePackagePath");
/* 1053 */     confileFilePackagePath = confileFilePackagePath == null ? "" : confileFilePackagePath;
/*      */     
/* 1055 */     youGouSqlMapConfigConfiguration.setTargetPackage(targetPackage);
/* 1056 */     youGouSqlMapConfigConfiguration.setTargetProject(targetProject);
/* 1057 */     youGouSqlMapConfigConfiguration.setConfileFileName(confileFileName);
/* 1058 */     youGouSqlMapConfigConfiguration.setConfileFilePackagePath(confileFilePackagePath);
/*      */   }
/*      */   
/*      */   private void parseJdbcConnection(Context context, Node node)
/*      */   {
/* 1063 */     JDBCConnectionConfiguration jdbcConnectionConfiguration = new JDBCConnectionConfiguration();
/*      */     
/* 1065 */     context.setJdbcConnectionConfiguration(jdbcConnectionConfiguration);
/*      */     
/* 1067 */     Properties attributes = parseAttributes(node);
/* 1068 */     String driverClass = attributes.getProperty("driverClass");
/* 1069 */     String connectionURL = attributes.getProperty("connectionURL");
/* 1070 */     String userId = attributes.getProperty("userId");
/* 1071 */     String password = attributes.getProperty("password");
/* 1072 */     String dbmsType = attributes.getProperty("dbmsType");
/*      */     
/* 1074 */     jdbcConnectionConfiguration.setDriverClass(driverClass);
/* 1075 */     jdbcConnectionConfiguration.setConnectionURL(connectionURL);
/* 1076 */     jdbcConnectionConfiguration.setDbmsType(dbmsType);
/*      */     
/* 1078 */     if (StringUtility.stringHasValue(userId)) {
/* 1079 */       jdbcConnectionConfiguration.setUserId(userId);
/*      */     }
/*      */     
/* 1082 */     if (StringUtility.stringHasValue(password)) {
/* 1083 */       jdbcConnectionConfiguration.setPassword(password);
/*      */     }
/*      */     
/* 1086 */     NodeList nodeList = node.getChildNodes();
/* 1087 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 1088 */       Node childNode = nodeList.item(i);
/*      */       
/* 1090 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1094 */         if ("property".equals(childNode.getNodeName()))
/* 1095 */           parseProperty(jdbcConnectionConfiguration, childNode);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void parseClassPathEntry(Configuration configuration, Node node) {
/* 1101 */     Properties attributes = parseAttributes(node);
/*      */     
/* 1103 */     configuration.addClasspathEntry(attributes.getProperty("location"));
/*      */   }
/*      */   
/*      */   private void parseProperty(PropertyHolder propertyHolder, Node node) {
/* 1107 */     Properties attributes = parseAttributes(node);
/*      */     
/* 1109 */     String name = attributes.getProperty("name");
/* 1110 */     String value = attributes.getProperty("value");
/*      */     
/* 1112 */     propertyHolder.addProperty(name, value);
/*      */   }
/*      */   
/*      */   private Properties parseAttributes(Node node) {
/* 1116 */     Properties attributes = new Properties();
/* 1117 */     NamedNodeMap nnm = node.getAttributes();
/* 1118 */     for (int i = 0; i < nnm.getLength(); i++) {
/* 1119 */       Node attribute = nnm.item(i);
/* 1120 */       String value = parsePropertyTokens(attribute.getNodeValue());
/* 1121 */       attributes.put(attribute.getNodeName(), value);
/*      */     }
/*      */     
/* 1124 */     return attributes;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private String parsePropertyTokens(String string)
/*      */   {
/* 1131 */     String newString = string;
/* 1132 */     if (newString != null) {
/* 1133 */       int start = newString.indexOf("${");
/* 1134 */       int end = newString.indexOf("}");
/*      */       
/* 1136 */       while ((start > -1) && (end > start)) {
/* 1137 */         String prepend = newString.substring(0, start);
/* 1138 */         String append = newString.substring(end + "}".length());
/* 1139 */         String propName = newString.substring(start + "${".length(), 
/* 1140 */           end);
/* 1141 */         String propValue = this.properties.getProperty(propName);
/* 1142 */         if (propValue != null) {
/* 1143 */           newString = prepend + propValue + append;
/*      */         }
/*      */         
/* 1146 */         start = newString.indexOf("${", end);
/* 1147 */         end = newString.indexOf("}", end);
/*      */       }
/*      */     }
/*      */     
/* 1151 */     return newString;
/*      */   }
/*      */   
/*      */   private void parseCommentGenerator(Context context, Node node) {
/* 1155 */     CommentGeneratorConfiguration commentGeneratorConfiguration = new CommentGeneratorConfiguration();
/*      */     
/* 1157 */     context.setCommentGeneratorConfiguration(commentGeneratorConfiguration);
/*      */     
/* 1159 */     Properties attributes = parseAttributes(node);
/* 1160 */     String type = attributes.getProperty("type");
/*      */     
/* 1162 */     if (StringUtility.stringHasValue(type)) {
/* 1163 */       commentGeneratorConfiguration.setConfigurationType(type);
/*      */     }
/*      */     
/* 1166 */     NodeList nodeList = node.getChildNodes();
/* 1167 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 1168 */       Node childNode = nodeList.item(i);
/*      */       
/* 1170 */       if (childNode.getNodeType() == 1)
/*      */       {
/*      */ 
/*      */ 
/* 1174 */         if ("property".equals(childNode.getNodeName())) {
/* 1175 */           parseProperty(commentGeneratorConfiguration, childNode);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\xml\MyBatisGeneratorConfigurationParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */