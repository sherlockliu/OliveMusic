/*     */ package org.mybatis.generator.config.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Properties;
/*     */ import org.mybatis.generator.config.ColumnOverride;
/*     */ import org.mybatis.generator.config.ColumnRenamingRule;
/*     */ import org.mybatis.generator.config.CommentGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.Configuration;
/*     */ import org.mybatis.generator.config.Context;
/*     */ import org.mybatis.generator.config.GeneratedKey;
/*     */ import org.mybatis.generator.config.IgnoredColumn;
/*     */ import org.mybatis.generator.config.JDBCConnectionConfiguration;
/*     */ import org.mybatis.generator.config.JavaClientGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.JavaModelGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.JavaTypeResolverConfiguration;
/*     */ import org.mybatis.generator.config.ModelType;
/*     */ import org.mybatis.generator.config.PluginConfiguration;
/*     */ import org.mybatis.generator.config.PropertyHolder;
/*     */ import org.mybatis.generator.config.SqlMapGeneratorConfiguration;
/*     */ import org.mybatis.generator.config.TableConfiguration;
/*     */ import org.mybatis.generator.exception.XMLParserException;
/*     */ import org.mybatis.generator.internal.ObjectFactory;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IbatorConfigurationParser
/*     */ {
/*     */   private Properties properties;
/*     */   
/*     */   public IbatorConfigurationParser(Properties properties)
/*     */   {
/*  61 */     if (properties == null) {
/*  62 */       this.properties = System.getProperties();
/*     */     } else {
/*  64 */       this.properties = properties;
/*     */     }
/*     */   }
/*     */   
/*     */   public Configuration parseIbatorConfiguration(Element rootNode)
/*     */     throws XMLParserException
/*     */   {
/*  71 */     Configuration configuration = new Configuration();
/*     */     
/*  73 */     NodeList nodeList = rootNode.getChildNodes();
/*  74 */     for (int i = 0; i < nodeList.getLength(); i++) {
/*  75 */       Node childNode = nodeList.item(i);
/*     */       
/*  77 */       if (childNode.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/*  81 */         if ("properties".equals(childNode.getNodeName())) {
/*  82 */           parseProperties(configuration, childNode);
/*  83 */         } else if ("classPathEntry".equals(childNode.getNodeName())) {
/*  84 */           parseClassPathEntry(configuration, childNode);
/*  85 */         } else if ("ibatorContext".equals(childNode.getNodeName())) {
/*  86 */           parseIbatorContext(configuration, childNode);
/*     */         }
/*     */       }
/*     */     }
/*  90 */     return configuration;
/*     */   }
/*     */   
/*     */   private void parseProperties(Configuration configuration, Node node) throws XMLParserException
/*     */   {
/*  95 */     Properties attributes = parseAttributes(node);
/*  96 */     String resource = attributes.getProperty("resource");
/*  97 */     String url = attributes.getProperty("url");
/*     */     
/*  99 */     if ((!StringUtility.stringHasValue(resource)) && 
/* 100 */       (!StringUtility.stringHasValue(url))) {
/* 101 */       throw new XMLParserException(Messages.getString("RuntimeError.14"));
/*     */     }
/*     */     
/* 104 */     if ((StringUtility.stringHasValue(resource)) && 
/* 105 */       (StringUtility.stringHasValue(url))) {
/* 106 */       throw new XMLParserException(Messages.getString("RuntimeError.14"));
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*     */       URL resourceUrl;
/* 112 */       if (StringUtility.stringHasValue(resource)) {
/* 113 */         URL resourceUrl = ObjectFactory.getResource(resource);
/* 114 */         if (resourceUrl == null) {
/* 115 */           throw new XMLParserException(Messages.getString(
/* 116 */             "RuntimeError.15", resource));
/*     */         }
/*     */       } else {
/* 119 */         resourceUrl = new URL(url);
/*     */       }
/*     */       
/* 122 */       InputStream inputStream = resourceUrl.openConnection()
/* 123 */         .getInputStream();
/*     */       
/* 125 */       this.properties.load(inputStream);
/* 126 */       inputStream.close();
/*     */     } catch (IOException localIOException) {
/* 128 */       if (StringUtility.stringHasValue(resource)) {
/* 129 */         throw new XMLParserException(Messages.getString(
/* 130 */           "RuntimeError.16", resource));
/*     */       }
/* 132 */       throw new XMLParserException(Messages.getString(
/* 133 */         "RuntimeError.17", url));
/*     */     }
/*     */     URL resourceUrl;
/*     */   }
/*     */   
/*     */   private void parseIbatorContext(Configuration configuration, Node node)
/*     */   {
/* 140 */     Properties attributes = parseAttributes(node);
/* 141 */     String defaultModelType = attributes.getProperty("defaultModelType");
/* 142 */     String targetRuntime = attributes.getProperty("targetRuntime");
/* 143 */     String introspectedColumnImpl = attributes
/* 144 */       .getProperty("introspectedColumnImpl");
/* 145 */     String id = attributes.getProperty("id");
/*     */     
/* 147 */     ModelType mt = defaultModelType == null ? null : 
/* 148 */       ModelType.getModelType(defaultModelType);
/*     */     
/* 150 */     Context context = new Context(mt);
/* 151 */     context.setId(id);
/* 152 */     if (StringUtility.stringHasValue(introspectedColumnImpl)) {
/* 153 */       context.setIntrospectedColumnImpl(introspectedColumnImpl);
/*     */     }
/* 155 */     if (StringUtility.stringHasValue(targetRuntime)) {
/* 156 */       context.setTargetRuntime(targetRuntime);
/*     */     }
/*     */     
/* 159 */     configuration.addContext(context);
/*     */     
/* 161 */     NodeList nodeList = node.getChildNodes();
/* 162 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 163 */       Node childNode = nodeList.item(i);
/*     */       
/* 165 */       if (childNode.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 169 */         if ("property".equals(childNode.getNodeName())) {
/* 170 */           parseProperty(context, childNode);
/* 171 */         } else if ("ibatorPlugin".equals(childNode.getNodeName())) {
/* 172 */           parseIbatorPlugin(context, childNode);
/* 173 */         } else if ("commentGenerator".equals(childNode.getNodeName())) {
/* 174 */           parseCommentGenerator(context, childNode);
/* 175 */         } else if ("jdbcConnection".equals(childNode.getNodeName())) {
/* 176 */           parseJdbcConnection(context, childNode);
/* 177 */         } else if ("javaModelGenerator".equals(childNode.getNodeName())) {
/* 178 */           parseJavaModelGenerator(context, childNode);
/* 179 */         } else if ("javaTypeResolver".equals(childNode.getNodeName())) {
/* 180 */           parseJavaTypeResolver(context, childNode);
/* 181 */         } else if ("sqlMapGenerator".equals(childNode.getNodeName())) {
/* 182 */           parseSqlMapGenerator(context, childNode);
/* 183 */         } else if ("daoGenerator".equals(childNode.getNodeName())) {
/* 184 */           parseDaoGenerator(context, childNode);
/* 185 */         } else if ("table".equals(childNode.getNodeName()))
/* 186 */           parseTable(context, childNode);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseSqlMapGenerator(Context context, Node node) {
/* 192 */     SqlMapGeneratorConfiguration sqlMapGeneratorConfiguration = new SqlMapGeneratorConfiguration();
/*     */     
/* 194 */     context.setSqlMapGeneratorConfiguration(sqlMapGeneratorConfiguration);
/*     */     
/* 196 */     Properties attributes = parseAttributes(node);
/* 197 */     String targetPackage = attributes.getProperty("targetPackage");
/* 198 */     String targetProject = attributes.getProperty("targetProject");
/*     */     
/* 200 */     sqlMapGeneratorConfiguration.setTargetPackage(targetPackage);
/* 201 */     sqlMapGeneratorConfiguration.setTargetProject(targetProject);
/*     */     
/* 203 */     NodeList nodeList = node.getChildNodes();
/* 204 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 205 */       Node childNode = nodeList.item(i);
/*     */       
/* 207 */       if (childNode.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 211 */         if ("property".equals(childNode.getNodeName()))
/* 212 */           parseProperty(sqlMapGeneratorConfiguration, childNode);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseTable(Context context, Node node) {
/* 218 */     TableConfiguration tc = new TableConfiguration(context);
/* 219 */     context.addTableConfiguration(tc);
/*     */     
/* 221 */     Properties attributes = parseAttributes(node);
/* 222 */     String catalog = attributes.getProperty("catalog");
/* 223 */     String schema = attributes.getProperty("schema");
/* 224 */     String tableName = attributes.getProperty("tableName");
/* 225 */     String domainObjectName = attributes.getProperty("domainObjectName");
/* 226 */     String alias = attributes.getProperty("alias");
/* 227 */     String enableInsert = attributes.getProperty("enableInsert");
/* 228 */     String enableSelectByPrimaryKey = attributes
/* 229 */       .getProperty("enableSelectByPrimaryKey");
/* 230 */     String enableSelectByExample = attributes
/* 231 */       .getProperty("enableSelectByExample");
/* 232 */     String enableUpdateByPrimaryKey = attributes
/* 233 */       .getProperty("enableUpdateByPrimaryKey");
/* 234 */     String enableDeleteByPrimaryKey = attributes
/* 235 */       .getProperty("enableDeleteByPrimaryKey");
/* 236 */     String enableDeleteByExample = attributes
/* 237 */       .getProperty("enableDeleteByExample");
/* 238 */     String enableCountByExample = attributes
/* 239 */       .getProperty("enableCountByExample");
/* 240 */     String enableUpdateByExample = attributes
/* 241 */       .getProperty("enableUpdateByExample");
/* 242 */     String selectByPrimaryKeyQueryId = attributes
/* 243 */       .getProperty("selectByPrimaryKeyQueryId");
/* 244 */     String selectByExampleQueryId = attributes
/* 245 */       .getProperty("selectByExampleQueryId");
/* 246 */     String modelType = attributes.getProperty("modelType");
/* 247 */     String escapeWildcards = attributes.getProperty("escapeWildcards");
/* 248 */     String delimitIdentifiers = attributes
/* 249 */       .getProperty("delimitIdentifiers");
/* 250 */     String delimitAllColumns = attributes.getProperty("delimitAllColumns");
/*     */     
/* 252 */     if (StringUtility.stringHasValue(catalog)) {
/* 253 */       tc.setCatalog(catalog);
/*     */     }
/*     */     
/* 256 */     if (StringUtility.stringHasValue(schema)) {
/* 257 */       tc.setSchema(schema);
/*     */     }
/*     */     
/* 260 */     if (StringUtility.stringHasValue(tableName)) {
/* 261 */       tc.setTableName(tableName);
/*     */     }
/*     */     
/* 264 */     if (StringUtility.stringHasValue(domainObjectName)) {
/* 265 */       tc.setDomainObjectName(domainObjectName);
/*     */     }
/*     */     
/* 268 */     if (StringUtility.stringHasValue(alias)) {
/* 269 */       tc.setAlias(alias);
/*     */     }
/*     */     
/* 272 */     if (StringUtility.stringHasValue(enableInsert)) {
/* 273 */       tc.setInsertStatementEnabled(StringUtility.isTrue(enableInsert));
/*     */     }
/*     */     
/* 276 */     if (StringUtility.stringHasValue(enableSelectByPrimaryKey)) {
/* 277 */       tc.setSelectByPrimaryKeyStatementEnabled(StringUtility.isTrue(enableSelectByPrimaryKey));
/*     */     }
/*     */     
/* 280 */     if (StringUtility.stringHasValue(enableSelectByExample)) {
/* 281 */       tc.setSelectByExampleStatementEnabled(StringUtility.isTrue(enableSelectByExample));
/*     */     }
/*     */     
/* 284 */     if (StringUtility.stringHasValue(enableUpdateByPrimaryKey)) {
/* 285 */       tc.setUpdateByPrimaryKeyStatementEnabled(StringUtility.isTrue(enableUpdateByPrimaryKey));
/*     */     }
/*     */     
/* 288 */     if (StringUtility.stringHasValue(enableDeleteByPrimaryKey)) {
/* 289 */       tc.setDeleteByPrimaryKeyStatementEnabled(StringUtility.isTrue(enableDeleteByPrimaryKey));
/*     */     }
/*     */     
/* 292 */     if (StringUtility.stringHasValue(enableDeleteByExample)) {
/* 293 */       tc.setDeleteByExampleStatementEnabled(StringUtility.isTrue(enableDeleteByExample));
/*     */     }
/*     */     
/* 296 */     if (StringUtility.stringHasValue(enableCountByExample)) {
/* 297 */       tc.setCountByExampleStatementEnabled(StringUtility.isTrue(enableCountByExample));
/*     */     }
/*     */     
/* 300 */     if (StringUtility.stringHasValue(enableUpdateByExample)) {
/* 301 */       tc.setUpdateByExampleStatementEnabled(StringUtility.isTrue(enableUpdateByExample));
/*     */     }
/*     */     
/* 304 */     if (StringUtility.stringHasValue(selectByPrimaryKeyQueryId)) {
/* 305 */       tc.setSelectByPrimaryKeyQueryId(selectByPrimaryKeyQueryId);
/*     */     }
/*     */     
/* 308 */     if (StringUtility.stringHasValue(selectByExampleQueryId)) {
/* 309 */       tc.setSelectByExampleQueryId(selectByExampleQueryId);
/*     */     }
/*     */     
/* 312 */     if (StringUtility.stringHasValue(modelType)) {
/* 313 */       tc.setConfiguredModelType(modelType);
/*     */     }
/*     */     
/* 316 */     if (StringUtility.stringHasValue(escapeWildcards)) {
/* 317 */       tc.setWildcardEscapingEnabled(StringUtility.isTrue(escapeWildcards));
/*     */     }
/*     */     
/* 320 */     if (StringUtility.stringHasValue(delimitIdentifiers)) {
/* 321 */       tc.setDelimitIdentifiers(StringUtility.isTrue(delimitIdentifiers));
/*     */     }
/*     */     
/* 324 */     if (StringUtility.stringHasValue(delimitAllColumns)) {
/* 325 */       tc.setAllColumnDelimitingEnabled(StringUtility.isTrue(delimitAllColumns));
/*     */     }
/*     */     
/* 328 */     NodeList nodeList = node.getChildNodes();
/* 329 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 330 */       Node childNode = nodeList.item(i);
/*     */       
/* 332 */       if (childNode.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 336 */         if ("property".equals(childNode.getNodeName())) {
/* 337 */           parseProperty(tc, childNode);
/* 338 */         } else if ("columnOverride".equals(childNode.getNodeName())) {
/* 339 */           parseColumnOverride(tc, childNode);
/* 340 */         } else if ("ignoreColumn".equals(childNode.getNodeName())) {
/* 341 */           parseIgnoreColumn(tc, childNode);
/* 342 */         } else if ("generatedKey".equals(childNode.getNodeName())) {
/* 343 */           parseGeneratedKey(tc, childNode);
/* 344 */         } else if ("columnRenamingRule".equals(childNode.getNodeName()))
/* 345 */           parseColumnRenamingRule(tc, childNode);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseColumnOverride(TableConfiguration tc, Node node) {
/* 351 */     Properties attributes = parseAttributes(node);
/* 352 */     String column = attributes.getProperty("column");
/* 353 */     String property = attributes.getProperty("property");
/* 354 */     String javaType = attributes.getProperty("javaType");
/* 355 */     String jdbcType = attributes.getProperty("jdbcType");
/* 356 */     String typeHandler = attributes.getProperty("typeHandler");
/* 357 */     String delimitedColumnName = attributes
/* 358 */       .getProperty("delimitedColumnName");
/*     */     
/* 360 */     ColumnOverride co = new ColumnOverride(column);
/*     */     
/* 362 */     if (StringUtility.stringHasValue(property)) {
/* 363 */       co.setJavaProperty(property);
/*     */     }
/*     */     
/* 366 */     if (StringUtility.stringHasValue(javaType)) {
/* 367 */       co.setJavaType(javaType);
/*     */     }
/*     */     
/* 370 */     if (StringUtility.stringHasValue(jdbcType)) {
/* 371 */       co.setJdbcType(jdbcType);
/*     */     }
/*     */     
/* 374 */     if (StringUtility.stringHasValue(typeHandler)) {
/* 375 */       co.setTypeHandler(typeHandler);
/*     */     }
/*     */     
/* 378 */     if (StringUtility.stringHasValue(delimitedColumnName)) {
/* 379 */       co.setColumnNameDelimited(StringUtility.isTrue(delimitedColumnName));
/*     */     }
/*     */     
/* 382 */     NodeList nodeList = node.getChildNodes();
/* 383 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 384 */       Node childNode = nodeList.item(i);
/*     */       
/* 386 */       if (childNode.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 390 */         if ("property".equals(childNode.getNodeName())) {
/* 391 */           parseProperty(co, childNode);
/*     */         }
/*     */       }
/*     */     }
/* 395 */     tc.addColumnOverride(co);
/*     */   }
/*     */   
/*     */   private void parseGeneratedKey(TableConfiguration tc, Node node) {
/* 399 */     Properties attributes = parseAttributes(node);
/*     */     
/* 401 */     String column = attributes.getProperty("column");
/* 402 */     boolean identity = StringUtility.isTrue(attributes
/* 403 */       .getProperty("identity"));
/* 404 */     String sqlStatement = attributes.getProperty("sqlStatement");
/* 405 */     String type = attributes.getProperty("type");
/*     */     
/* 407 */     GeneratedKey gk = new GeneratedKey(column, sqlStatement, identity, type);
/*     */     
/* 409 */     tc.setGeneratedKey(gk);
/*     */   }
/*     */   
/*     */   private void parseIgnoreColumn(TableConfiguration tc, Node node) {
/* 413 */     Properties attributes = parseAttributes(node);
/* 414 */     String column = attributes.getProperty("column");
/* 415 */     String delimitedColumnName = attributes
/* 416 */       .getProperty("delimitedColumnName");
/*     */     
/* 418 */     IgnoredColumn ic = new IgnoredColumn(column);
/*     */     
/* 420 */     if (StringUtility.stringHasValue(delimitedColumnName)) {
/* 421 */       ic.setColumnNameDelimited(StringUtility.isTrue(delimitedColumnName));
/*     */     }
/*     */     
/* 424 */     tc.addIgnoredColumn(ic);
/*     */   }
/*     */   
/*     */   private void parseColumnRenamingRule(TableConfiguration tc, Node node) {
/* 428 */     Properties attributes = parseAttributes(node);
/* 429 */     String searchString = attributes.getProperty("searchString");
/* 430 */     String replaceString = attributes.getProperty("replaceString");
/*     */     
/* 432 */     ColumnRenamingRule crr = new ColumnRenamingRule();
/*     */     
/* 434 */     crr.setSearchString(searchString);
/*     */     
/* 436 */     if (StringUtility.stringHasValue(replaceString)) {
/* 437 */       crr.setReplaceString(replaceString);
/*     */     }
/*     */     
/* 440 */     tc.setColumnRenamingRule(crr);
/*     */   }
/*     */   
/*     */   private void parseJavaTypeResolver(Context context, Node node) {
/* 444 */     JavaTypeResolverConfiguration javaTypeResolverConfiguration = new JavaTypeResolverConfiguration();
/*     */     
/* 446 */     context.setJavaTypeResolverConfiguration(javaTypeResolverConfiguration);
/*     */     
/* 448 */     Properties attributes = parseAttributes(node);
/* 449 */     String type = attributes.getProperty("type");
/*     */     
/* 451 */     if (StringUtility.stringHasValue(type)) {
/* 452 */       javaTypeResolverConfiguration.setConfigurationType(type);
/*     */     }
/*     */     
/* 455 */     NodeList nodeList = node.getChildNodes();
/* 456 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 457 */       Node childNode = nodeList.item(i);
/*     */       
/* 459 */       if (childNode.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 463 */         if ("property".equals(childNode.getNodeName()))
/* 464 */           parseProperty(javaTypeResolverConfiguration, childNode);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseIbatorPlugin(Context context, Node node) {
/* 470 */     PluginConfiguration pluginConfiguration = new PluginConfiguration();
/*     */     
/* 472 */     context.addPluginConfiguration(pluginConfiguration);
/*     */     
/* 474 */     Properties attributes = parseAttributes(node);
/* 475 */     String type = attributes.getProperty("type");
/*     */     
/* 477 */     pluginConfiguration.setConfigurationType(type);
/*     */     
/* 479 */     NodeList nodeList = node.getChildNodes();
/* 480 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 481 */       Node childNode = nodeList.item(i);
/*     */       
/* 483 */       if (childNode.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 487 */         if ("property".equals(childNode.getNodeName()))
/* 488 */           parseProperty(pluginConfiguration, childNode);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseJavaModelGenerator(Context context, Node node) {
/* 494 */     JavaModelGeneratorConfiguration javaModelGeneratorConfiguration = new JavaModelGeneratorConfiguration();
/*     */     
/* 496 */     context
/* 497 */       .setJavaModelGeneratorConfiguration(javaModelGeneratorConfiguration);
/*     */     
/* 499 */     Properties attributes = parseAttributes(node);
/* 500 */     String targetPackage = attributes.getProperty("targetPackage");
/* 501 */     String targetProject = attributes.getProperty("targetProject");
/*     */     
/* 503 */     javaModelGeneratorConfiguration.setTargetPackage(targetPackage);
/* 504 */     javaModelGeneratorConfiguration.setTargetProject(targetProject);
/*     */     
/* 506 */     NodeList nodeList = node.getChildNodes();
/* 507 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 508 */       Node childNode = nodeList.item(i);
/*     */       
/* 510 */       if (childNode.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 514 */         if ("property".equals(childNode.getNodeName()))
/* 515 */           parseProperty(javaModelGeneratorConfiguration, childNode);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseDaoGenerator(Context context, Node node) {
/* 521 */     JavaClientGeneratorConfiguration javaClientGeneratorConfiguration = new JavaClientGeneratorConfiguration();
/*     */     
/* 523 */     context.setJavaClientGeneratorConfiguration(javaClientGeneratorConfiguration);
/*     */     
/* 525 */     Properties attributes = parseAttributes(node);
/* 526 */     String type = attributes.getProperty("type");
/* 527 */     String targetPackage = attributes.getProperty("targetPackage");
/* 528 */     String targetProject = attributes.getProperty("targetProject");
/* 529 */     String implementationPackage = attributes
/* 530 */       .getProperty("implementationPackage");
/*     */     
/* 532 */     javaClientGeneratorConfiguration.setConfigurationType(type);
/* 533 */     javaClientGeneratorConfiguration.setTargetPackage(targetPackage);
/* 534 */     javaClientGeneratorConfiguration.setTargetProject(targetProject);
/* 535 */     javaClientGeneratorConfiguration
/* 536 */       .setImplementationPackage(implementationPackage);
/*     */     
/* 538 */     NodeList nodeList = node.getChildNodes();
/* 539 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 540 */       Node childNode = nodeList.item(i);
/*     */       
/* 542 */       if (childNode.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 546 */         if ("property".equals(childNode.getNodeName()))
/* 547 */           parseProperty(javaClientGeneratorConfiguration, childNode);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseJdbcConnection(Context context, Node node) {
/* 553 */     JDBCConnectionConfiguration jdbcConnectionConfiguration = new JDBCConnectionConfiguration();
/*     */     
/* 555 */     context.setJdbcConnectionConfiguration(jdbcConnectionConfiguration);
/*     */     
/* 557 */     Properties attributes = parseAttributes(node);
/* 558 */     String driverClass = attributes.getProperty("driverClass");
/* 559 */     String connectionURL = attributes.getProperty("connectionURL");
/* 560 */     String userId = attributes.getProperty("userId");
/* 561 */     String password = attributes.getProperty("password");
/*     */     
/* 563 */     jdbcConnectionConfiguration.setDriverClass(driverClass);
/* 564 */     jdbcConnectionConfiguration.setConnectionURL(connectionURL);
/*     */     
/* 566 */     if (StringUtility.stringHasValue(userId)) {
/* 567 */       jdbcConnectionConfiguration.setUserId(userId);
/*     */     }
/*     */     
/* 570 */     if (StringUtility.stringHasValue(password)) {
/* 571 */       jdbcConnectionConfiguration.setPassword(password);
/*     */     }
/*     */     
/* 574 */     NodeList nodeList = node.getChildNodes();
/* 575 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 576 */       Node childNode = nodeList.item(i);
/*     */       
/* 578 */       if (childNode.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 582 */         if ("property".equals(childNode.getNodeName()))
/* 583 */           parseProperty(jdbcConnectionConfiguration, childNode);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void parseClassPathEntry(Configuration configuration, Node node) {
/* 589 */     Properties attributes = parseAttributes(node);
/*     */     
/* 591 */     configuration.addClasspathEntry(attributes.getProperty("location"));
/*     */   }
/*     */   
/*     */   private void parseProperty(PropertyHolder propertyHolder, Node node) {
/* 595 */     Properties attributes = parseAttributes(node);
/*     */     
/* 597 */     String name = attributes.getProperty("name");
/* 598 */     String value = attributes.getProperty("value");
/*     */     
/* 600 */     propertyHolder.addProperty(name, value);
/*     */   }
/*     */   
/*     */   private Properties parseAttributes(Node node) {
/* 604 */     Properties attributes = new Properties();
/* 605 */     NamedNodeMap nnm = node.getAttributes();
/* 606 */     for (int i = 0; i < nnm.getLength(); i++) {
/* 607 */       Node attribute = nnm.item(i);
/* 608 */       String value = parsePropertyTokens(attribute.getNodeValue());
/* 609 */       attributes.put(attribute.getNodeName(), value);
/*     */     }
/*     */     
/* 612 */     return attributes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String parsePropertyTokens(String string)
/*     */   {
/* 619 */     String newString = string;
/* 620 */     if (newString != null) {
/* 621 */       int start = newString.indexOf("${");
/* 622 */       int end = newString.indexOf("}");
/*     */       
/* 624 */       while ((start > -1) && (end > start)) {
/* 625 */         String prepend = newString.substring(0, start);
/* 626 */         String append = newString.substring(end + "}".length());
/* 627 */         String propName = newString.substring(start + "${".length(), 
/* 628 */           end);
/* 629 */         String propValue = this.properties.getProperty(propName);
/* 630 */         if (propValue != null) {
/* 631 */           newString = prepend + propValue + append;
/*     */         }
/*     */         
/* 634 */         start = newString.indexOf("${", end);
/* 635 */         end = newString.indexOf("}", end);
/*     */       }
/*     */     }
/*     */     
/* 639 */     return newString;
/*     */   }
/*     */   
/*     */   private void parseCommentGenerator(Context context, Node node) {
/* 643 */     CommentGeneratorConfiguration commentGeneratorConfiguration = new CommentGeneratorConfiguration();
/*     */     
/* 645 */     context.setCommentGeneratorConfiguration(commentGeneratorConfiguration);
/*     */     
/* 647 */     Properties attributes = parseAttributes(node);
/* 648 */     String type = attributes.getProperty("type");
/*     */     
/* 650 */     if (StringUtility.stringHasValue(type)) {
/* 651 */       commentGeneratorConfiguration.setConfigurationType(type);
/*     */     }
/*     */     
/* 654 */     NodeList nodeList = node.getChildNodes();
/* 655 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 656 */       Node childNode = nodeList.item(i);
/*     */       
/* 658 */       if (childNode.getNodeType() == 1)
/*     */       {
/*     */ 
/*     */ 
/* 662 */         if ("property".equals(childNode.getNodeName())) {
/* 663 */           parseProperty(commentGeneratorConfiguration, childNode);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\xml\IbatorConfigurationParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */