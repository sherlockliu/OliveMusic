/*     */ package org.mybatis.generator.config.xml;
/*     */ 
/*     */ import com.yougou.mybatis.plugins.CodeLayoutEnum;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.mybatis.generator.config.Configuration;
/*     */ import org.mybatis.generator.exception.XMLParserException;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.Element;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigurationParser
/*     */ {
/*     */   private List<String> warnings;
/*     */   private List<String> parseErrors;
/*     */   private Properties properties;
/*     */   
/*     */   public ConfigurationParser(List<String> warnings)
/*     */   {
/*  52 */     this(null, warnings);
/*     */   }
/*     */   
/*     */   public ConfigurationParser(Properties properties, List<String> warnings)
/*     */   {
/*  57 */     if (properties == null) {
/*  58 */       this.properties = System.getProperties();
/*     */     } else {
/*  60 */       this.properties = properties;
/*     */     }
/*     */     
/*  63 */     if (warnings == null) {
/*  64 */       this.warnings = new ArrayList();
/*     */     } else {
/*  66 */       this.warnings = warnings;
/*     */     }
/*     */     
/*  69 */     this.parseErrors = new ArrayList();
/*     */   }
/*     */   
/*     */   public Configuration parseConfiguration(File inputFile)
/*     */     throws IOException, XMLParserException
/*     */   {
/*  75 */     FileReader fr = new FileReader(inputFile);
/*     */     
/*  77 */     return parseConfiguration(fr);
/*     */   }
/*     */   
/*     */   public Configuration parseConfiguration(Reader reader)
/*     */     throws IOException, XMLParserException
/*     */   {
/*  83 */     InputSource is = new InputSource(reader);
/*     */     
/*  85 */     return parseConfiguration(is, null, null, "");
/*     */   }
/*     */   
/*     */   public Configuration parseConfiguration(InputStream inputStream)
/*     */     throws IOException, XMLParserException
/*     */   {
/*  91 */     InputSource is = new InputSource(inputStream);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */     return parseConfiguration(is, null, null, "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Configuration parseConfiguration(InputSource inputSource, List<String> tableList, Map<CodeLayoutEnum, Boolean> codeLayout, String codeVersion)
/*     */     throws IOException, XMLParserException
/*     */   {
/* 111 */     this.parseErrors.clear();
/* 112 */     DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
/* 113 */     factory.setValidating(true);
/*     */     try
/*     */     {
/* 116 */       DocumentBuilder builder = factory.newDocumentBuilder();
/* 117 */       builder.setEntityResolver(new ParserEntityResolver());
/*     */       
/* 119 */       ParserErrorHandler handler = new ParserErrorHandler(this.warnings, 
/* 120 */         this.parseErrors);
/* 121 */       builder.setErrorHandler(handler);
/*     */       
/* 123 */       Document document = null;
/*     */       try {
/* 125 */         document = builder.parse(inputSource);
/*     */       } catch (SAXParseException localSAXParseException) {
/* 127 */         throw new XMLParserException(this.parseErrors);
/*     */       } catch (SAXException e) {
/* 129 */         if (e.getException() == null) {
/* 130 */           this.parseErrors.add(e.getMessage());
/*     */         } else {
/* 132 */           this.parseErrors.add(e.getException().getMessage());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 142 */       if (this.parseErrors.size() > 0) {
/* 143 */         throw new XMLParserException(this.parseErrors);
/*     */       }
/*     */       
/*     */ 
/* 147 */       Element rootNode = document.getDocumentElement();
/* 148 */       DocumentType docType = document.getDoctype();
/* 149 */       Configuration config; if ((rootNode.getNodeType() == 1) && 
/* 150 */         (docType.getPublicId().equals(
/* 151 */         "-//Apache Software Foundation//DTD Apache iBATIS Ibator Configuration 1.0//EN"))) {
/* 152 */         config = parseIbatorConfiguration(rootNode); } else { Configuration config;
/* 153 */         if ((rootNode.getNodeType() == 1) && 
/* 154 */           (docType.getPublicId().equals(
/* 155 */           "-//mybatis.org//DTD MyBatis Generator Configuration 1.0//EN"))) {
/* 156 */           config = parseMyBatisGeneratorConfiguration(rootNode, tableList, codeLayout, codeVersion);
/*     */         } else
/* 158 */           throw new XMLParserException(Messages.getString("RuntimeError.5"));
/*     */       }
/*     */       Configuration config;
/* 161 */       if (this.parseErrors.size() > 0) {
/* 162 */         throw new XMLParserException(this.parseErrors);
/*     */       }
/*     */       
/* 165 */       return config;
/*     */     } catch (ParserConfigurationException e) {
/* 167 */       this.parseErrors.add(e.getMessage());
/* 168 */       throw new XMLParserException(this.parseErrors);
/*     */     }
/*     */   }
/*     */   
/*     */   private Configuration parseIbatorConfiguration(Element rootNode) throws XMLParserException
/*     */   {
/* 174 */     IbatorConfigurationParser parser = new IbatorConfigurationParser(
/* 175 */       this.properties);
/* 176 */     return parser.parseIbatorConfiguration(rootNode);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Configuration parseMyBatisGeneratorConfiguration(Element rootNode, List<String> tableList, Map<CodeLayoutEnum, Boolean> codeLayout, String codeVersion)
/*     */     throws XMLParserException
/*     */   {
/* 190 */     MyBatisGeneratorConfigurationParser parser = new MyBatisGeneratorConfigurationParser(
/* 191 */       this.properties);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 196 */     return parser.parseConfiguration(rootNode, tableList, codeLayout, codeVersion);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\xml\ConfigurationParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */