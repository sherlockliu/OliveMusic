/*     */ package org.mybatis.generator.config;
/*     */ 
/*     */ import com.yougou.mybatis.plugins.CodeLayoutEnum;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.mybatis.generator.api.CommentGenerator;
/*     */ import org.mybatis.generator.api.GeneratedJavaFile;
/*     */ import org.mybatis.generator.api.GeneratedXmlFile;
/*     */ import org.mybatis.generator.api.IntrospectedTable;
/*     */ import org.mybatis.generator.api.JavaFormatter;
/*     */ import org.mybatis.generator.api.Plugin;
/*     */ import org.mybatis.generator.api.ProgressCallback;
/*     */ import org.mybatis.generator.api.XmlFormatter;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.internal.ObjectFactory;
/*     */ import org.mybatis.generator.internal.PluginAggregator;
/*     */ import org.mybatis.generator.internal.db.ConnectionFactory;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Context
/*     */   extends PropertyHolder
/*     */ {
/*     */   private String id;
/*     */   private static String codeVersion;
/*     */   private static Map<CodeLayoutEnum, Boolean> codingLayer;
/*     */   private JDBCConnectionConfiguration jdbcConnectionConfiguration;
/*     */   private SqlMapGeneratorConfiguration sqlMapGeneratorConfiguration;
/*     */   private JavaTypeResolverConfiguration javaTypeResolverConfiguration;
/*     */   private JavaModelGeneratorConfiguration javaModelGeneratorConfiguration;
/*     */   private JavaClientGeneratorConfiguration javaClientGeneratorConfiguration;
/*     */   private YouGouServiceGeneratorConfiguration youGouServiceGeneratorConfiguration;
/*     */   private YouGouManagerGeneratorConfiguration youGouManagerGeneratorConfiguration;
/*     */   private YouGouControllerGeneratorConfiguration youGouControllerGeneratorConfiguration;
/*     */   private YouGouTableSettingConfiguration youGouTableSettingConfiguration;
/*     */   private static YouGouSqlMapConfigConfiguration youGouSqlMapConfigConfiguration;
/*     */   private ArrayList<TableConfiguration> tableConfigurations;
/*     */   private ModelType defaultModelType;
/* 112 */   private String beginningDelimiter = "\"";
/*     */   
/* 114 */   private String endingDelimiter = "\"";
/*     */   
/*     */ 
/*     */   private CommentGeneratorConfiguration commentGeneratorConfiguration;
/*     */   
/*     */ 
/*     */   private CommentGenerator commentGenerator;
/*     */   
/*     */ 
/*     */   private PluginAggregator pluginAggregator;
/*     */   
/*     */ 
/*     */   private List<PluginConfiguration> pluginConfigurations;
/*     */   
/*     */   private String targetRuntime;
/*     */   
/*     */   private String introspectedColumnImpl;
/*     */   
/*     */   private Boolean autoDelimitKeywords;
/*     */   
/*     */   private JavaFormatter javaFormatter;
/*     */   
/*     */   private XmlFormatter xmlFormatter;
/*     */   
/*     */   private List<IntrospectedTable> introspectedTables;
/*     */   
/*     */ 
/*     */   public Context(ModelType defaultModelType)
/*     */   {
/* 143 */     if (defaultModelType == null) {
/* 144 */       this.defaultModelType = ModelType.CONDITIONAL;
/*     */     } else {
/* 146 */       this.defaultModelType = defaultModelType;
/*     */     }
/*     */     
/* 149 */     this.tableConfigurations = new ArrayList();
/* 150 */     this.pluginConfigurations = new ArrayList();
/*     */   }
/*     */   
/*     */   public void addTableConfiguration(TableConfiguration tc) {
/* 154 */     this.tableConfigurations.add(tc);
/*     */   }
/*     */   
/*     */   public JDBCConnectionConfiguration getJdbcConnectionConfiguration() {
/* 158 */     return this.jdbcConnectionConfiguration;
/*     */   }
/*     */   
/*     */   public JavaClientGeneratorConfiguration getJavaClientGeneratorConfiguration() {
/* 162 */     return this.javaClientGeneratorConfiguration;
/*     */   }
/*     */   
/*     */   public JavaModelGeneratorConfiguration getJavaModelGeneratorConfiguration() {
/* 166 */     return this.javaModelGeneratorConfiguration;
/*     */   }
/*     */   
/*     */   public JavaTypeResolverConfiguration getJavaTypeResolverConfiguration() {
/* 170 */     return this.javaTypeResolverConfiguration;
/*     */   }
/*     */   
/*     */   public SqlMapGeneratorConfiguration getSqlMapGeneratorConfiguration() {
/* 174 */     return this.sqlMapGeneratorConfiguration;
/*     */   }
/*     */   
/*     */   public void addPluginConfiguration(PluginConfiguration pluginConfiguration)
/*     */   {
/* 179 */     this.pluginConfigurations.add(pluginConfiguration);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate(List<String> errors)
/*     */   {
/* 189 */     if (!StringUtility.stringHasValue(this.id)) {
/* 190 */       errors.add(Messages.getString("ValidationError.16"));
/*     */     }
/*     */     
/* 193 */     if (this.jdbcConnectionConfiguration == null) {
/* 194 */       errors.add(Messages.getString("ValidationError.10", this.id));
/*     */     } else {
/* 196 */       this.jdbcConnectionConfiguration.validate(errors);
/*     */     }
/*     */     
/* 199 */     if (this.javaModelGeneratorConfiguration == null) {
/* 200 */       errors.add(Messages.getString("ValidationError.8", this.id));
/*     */     } else {
/* 202 */       this.javaModelGeneratorConfiguration.validate(errors, this.id);
/*     */     }
/*     */     
/* 205 */     if (this.javaClientGeneratorConfiguration != null) {
/* 206 */       this.javaClientGeneratorConfiguration.validate(errors, this.id);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 213 */     if (this.youGouServiceGeneratorConfiguration != null) {
/* 214 */       this.youGouServiceGeneratorConfiguration.validate(errors, this.id);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 221 */     if (this.youGouManagerGeneratorConfiguration != null) {
/* 222 */       this.youGouManagerGeneratorConfiguration.validate(errors, this.id);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 229 */     if (this.youGouControllerGeneratorConfiguration != null) {
/* 230 */       this.youGouControllerGeneratorConfiguration.validate(errors, this.id);
/*     */     }
/*     */     
/* 233 */     IntrospectedTable it = null;
/*     */     try {
/* 235 */       it = ObjectFactory.createIntrospectedTableForValidation(this);
/*     */     } catch (Exception localException) {
/* 237 */       errors.add(Messages.getString("ValidationError.25", this.id));
/*     */     }
/*     */     
/* 240 */     if ((it != null) && (it.requiresXMLGenerator())) {
/* 241 */       if (this.sqlMapGeneratorConfiguration == null) {
/* 242 */         errors.add(Messages.getString("ValidationError.9", this.id));
/*     */       } else {
/* 244 */         this.sqlMapGeneratorConfiguration.validate(errors, this.id);
/*     */       }
/*     */     }
/*     */     TableConfiguration tc;
/* 248 */     if (this.tableConfigurations.size() == 0) {
/* 249 */       errors.add(Messages.getString("ValidationError.3", this.id));
/*     */     } else {
/* 251 */       for (int i = 0; i < this.tableConfigurations.size(); i++) {
/* 252 */         tc = (TableConfiguration)this.tableConfigurations.get(i);
/*     */         
/* 254 */         tc.validate(errors, i);
/*     */       }
/*     */     }
/*     */     
/* 258 */     for (PluginConfiguration pluginConfiguration : this.pluginConfigurations) {
/* 259 */       pluginConfiguration.validate(errors, this.id);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getId() {
/* 264 */     return this.id;
/*     */   }
/*     */   
/*     */   public void setId(String id) {
/* 268 */     this.id = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getCodeVersion()
/*     */   {
/* 277 */     return codeVersion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCodeVersion(String codeVersion)
/*     */   {
/* 287 */     codeVersion = codeVersion;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Map<CodeLayoutEnum, Boolean> getCodingLayer()
/*     */   {
/* 296 */     return codingLayer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCodingLayer(Map<CodeLayoutEnum, Boolean> codingLayer)
/*     */   {
/* 305 */     codingLayer = codingLayer;
/*     */   }
/*     */   
/*     */   public void setJavaClientGeneratorConfiguration(JavaClientGeneratorConfiguration javaClientGeneratorConfiguration)
/*     */   {
/* 310 */     this.javaClientGeneratorConfiguration = javaClientGeneratorConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public YouGouServiceGeneratorConfiguration getYouGouServiceGeneratorConfiguration()
/*     */   {
/* 320 */     return this.youGouServiceGeneratorConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYouGouServiceGeneratorConfiguration(YouGouServiceGeneratorConfiguration youGouServiceGeneratorConfiguration)
/*     */   {
/* 330 */     this.youGouServiceGeneratorConfiguration = youGouServiceGeneratorConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public YouGouManagerGeneratorConfiguration getYouGouManagerGeneratorConfiguration()
/*     */   {
/* 340 */     return this.youGouManagerGeneratorConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYouGouManagerGeneratorConfiguration(YouGouManagerGeneratorConfiguration youGouManagerGeneratorConfiguration)
/*     */   {
/* 351 */     this.youGouManagerGeneratorConfiguration = youGouManagerGeneratorConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public YouGouControllerGeneratorConfiguration getYouGouControllerGeneratorConfiguration()
/*     */   {
/* 361 */     return this.youGouControllerGeneratorConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYouGouControllerGeneratorConfiguration(YouGouControllerGeneratorConfiguration youGouControllerGeneratorConfiguration)
/*     */   {
/* 371 */     this.youGouControllerGeneratorConfiguration = youGouControllerGeneratorConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public YouGouTableSettingConfiguration getYouGouTableSettingConfiguration()
/*     */   {
/* 381 */     return this.youGouTableSettingConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setYouGouTableSettingConfiguration(YouGouTableSettingConfiguration youGouTableSettingConfiguration)
/*     */   {
/* 392 */     this.youGouTableSettingConfiguration = youGouTableSettingConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static YouGouSqlMapConfigConfiguration getYouGouSqlMapConfigConfiguration()
/*     */   {
/* 403 */     return youGouSqlMapConfigConfiguration;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setYouGouSqlMapConfigConfiguration(YouGouSqlMapConfigConfiguration youGouSqlMapConfigConfiguration)
/*     */   {
/* 414 */     youGouSqlMapConfigConfiguration = youGouSqlMapConfigConfiguration;
/*     */   }
/*     */   
/*     */   public void setJavaModelGeneratorConfiguration(JavaModelGeneratorConfiguration javaModelGeneratorConfiguration)
/*     */   {
/* 419 */     this.javaModelGeneratorConfiguration = javaModelGeneratorConfiguration;
/*     */   }
/*     */   
/*     */   public void setJavaTypeResolverConfiguration(JavaTypeResolverConfiguration javaTypeResolverConfiguration)
/*     */   {
/* 424 */     this.javaTypeResolverConfiguration = javaTypeResolverConfiguration;
/*     */   }
/*     */   
/*     */   public void setJdbcConnectionConfiguration(JDBCConnectionConfiguration jdbcConnectionConfiguration)
/*     */   {
/* 429 */     this.jdbcConnectionConfiguration = jdbcConnectionConfiguration;
/*     */   }
/*     */   
/*     */   public void setSqlMapGeneratorConfiguration(SqlMapGeneratorConfiguration sqlMapGeneratorConfiguration)
/*     */   {
/* 434 */     this.sqlMapGeneratorConfiguration = sqlMapGeneratorConfiguration;
/*     */   }
/*     */   
/*     */   public ModelType getDefaultModelType() {
/* 438 */     return this.defaultModelType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public XmlElement toXmlElement()
/*     */   {
/* 449 */     XmlElement xmlElement = new XmlElement("context");
/*     */     
/* 451 */     xmlElement.addAttribute(new Attribute("id", this.id));
/*     */     
/* 453 */     if (this.defaultModelType != ModelType.CONDITIONAL) {
/* 454 */       xmlElement.addAttribute(new Attribute(
/* 455 */         "defaultModelType", this.defaultModelType.getModelType()));
/*     */     }
/*     */     
/* 458 */     if (StringUtility.stringHasValue(this.introspectedColumnImpl)) {
/* 459 */       xmlElement.addAttribute(new Attribute(
/* 460 */         "introspectedColumnImpl", this.introspectedColumnImpl));
/*     */     }
/*     */     
/* 463 */     if (StringUtility.stringHasValue(this.targetRuntime)) {
/* 464 */       xmlElement.addAttribute(new Attribute(
/* 465 */         "targetRuntime", this.targetRuntime));
/*     */     }
/*     */     
/* 468 */     addPropertyXmlElements(xmlElement);
/*     */     
/* 470 */     for (PluginConfiguration pluginConfiguration : this.pluginConfigurations) {
/* 471 */       xmlElement.addElement(pluginConfiguration.toXmlElement());
/*     */     }
/*     */     
/* 474 */     if (this.commentGeneratorConfiguration != null) {
/* 475 */       xmlElement.addElement(this.commentGeneratorConfiguration.toXmlElement());
/*     */     }
/*     */     
/* 478 */     if (this.jdbcConnectionConfiguration != null) {
/* 479 */       xmlElement.addElement(this.jdbcConnectionConfiguration.toXmlElement());
/*     */     }
/*     */     
/* 482 */     if (this.javaTypeResolverConfiguration != null) {
/* 483 */       xmlElement.addElement(this.javaTypeResolverConfiguration.toXmlElement());
/*     */     }
/*     */     
/* 486 */     if (this.javaModelGeneratorConfiguration != null) {
/* 487 */       xmlElement.addElement(this.javaModelGeneratorConfiguration
/* 488 */         .toXmlElement());
/*     */     }
/*     */     
/* 491 */     if (this.sqlMapGeneratorConfiguration != null) {
/* 492 */       xmlElement.addElement(this.sqlMapGeneratorConfiguration.toXmlElement());
/*     */     }
/*     */     
/* 495 */     if (this.javaClientGeneratorConfiguration != null) {
/* 496 */       xmlElement.addElement(this.javaClientGeneratorConfiguration.toXmlElement());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 503 */     if (this.youGouServiceGeneratorConfiguration != null) {
/* 504 */       xmlElement.addElement(this.youGouServiceGeneratorConfiguration.toXmlElement());
/*     */     }
/*     */     
/* 507 */     for (TableConfiguration tableConfiguration : this.tableConfigurations) {
/* 508 */       xmlElement.addElement(tableConfiguration.toXmlElement());
/*     */     }
/*     */     
/* 511 */     return xmlElement;
/*     */   }
/*     */   
/*     */   public List<TableConfiguration> getTableConfigurations() {
/* 515 */     return this.tableConfigurations;
/*     */   }
/*     */   
/*     */   public String getBeginningDelimiter() {
/* 519 */     return this.beginningDelimiter;
/*     */   }
/*     */   
/*     */   public String getEndingDelimiter() {
/* 523 */     return this.endingDelimiter;
/*     */   }
/*     */   
/*     */   public void addProperty(String name, String value)
/*     */   {
/* 528 */     super.addProperty(name, value);
/*     */     
/* 530 */     if ("beginningDelimiter".equals(name)) {
/* 531 */       this.beginningDelimiter = value;
/* 532 */     } else if ("endingDelimiter".equals(name)) {
/* 533 */       this.endingDelimiter = value;
/* 534 */     } else if (("autoDelimitKeywords".equals(name)) && 
/* 535 */       (StringUtility.stringHasValue(value))) {
/* 536 */       this.autoDelimitKeywords = new Boolean(StringUtility.isTrue(value));
/*     */     }
/*     */   }
/*     */   
/*     */   public CommentGenerator getCommentGenerator()
/*     */   {
/* 542 */     if (this.commentGenerator == null) {
/* 543 */       this.commentGenerator = ObjectFactory.createCommentGenerator(this);
/*     */     }
/*     */     
/* 546 */     return this.commentGenerator;
/*     */   }
/*     */   
/*     */   public JavaFormatter getJavaFormatter() {
/* 550 */     if (this.javaFormatter == null) {
/* 551 */       this.javaFormatter = ObjectFactory.createJavaFormatter(this);
/*     */     }
/*     */     
/* 554 */     return this.javaFormatter;
/*     */   }
/*     */   
/*     */   public XmlFormatter getXmlFormatter() {
/* 558 */     if (this.xmlFormatter == null) {
/* 559 */       this.xmlFormatter = ObjectFactory.createXmlFormatter(this);
/*     */     }
/*     */     
/* 562 */     return this.xmlFormatter;
/*     */   }
/*     */   
/*     */   public CommentGeneratorConfiguration getCommentGeneratorConfiguration() {
/* 566 */     return this.commentGeneratorConfiguration;
/*     */   }
/*     */   
/*     */   public void setCommentGeneratorConfiguration(CommentGeneratorConfiguration commentGeneratorConfiguration)
/*     */   {
/* 571 */     this.commentGeneratorConfiguration = commentGeneratorConfiguration;
/*     */   }
/*     */   
/*     */   public Plugin getPlugins() {
/* 575 */     return this.pluginAggregator;
/*     */   }
/*     */   
/*     */   public String getTargetRuntime() {
/* 579 */     return this.targetRuntime;
/*     */   }
/*     */   
/*     */   public void setTargetRuntime(String targetRuntime) {
/* 583 */     this.targetRuntime = targetRuntime;
/*     */   }
/*     */   
/*     */   public String getIntrospectedColumnImpl() {
/* 587 */     return this.introspectedColumnImpl;
/*     */   }
/*     */   
/*     */   public void setIntrospectedColumnImpl(String introspectedColumnImpl) {
/* 591 */     this.introspectedColumnImpl = introspectedColumnImpl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getIntrospectionSteps()
/*     */   {
/* 607 */     int steps = 0;
/*     */     
/* 609 */     steps++;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 615 */     steps += this.tableConfigurations.size() * 1;
/*     */     
/* 617 */     return steps;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void introspectTables(ProgressCallback callback, List<String> warnings, java.util.Set<String> fullyQualifiedTableNames)
/*     */     throws SQLException, InterruptedException
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: new 77	java/util/ArrayList
/*     */     //   4: dup
/*     */     //   5: invokespecial 79	java/util/ArrayList:<init>	()V
/*     */     //   8: putfield 418	org/mybatis/generator/config/Context:introspectedTables	Ljava/util/List;
/*     */     //   11: aload_0
/*     */     //   12: aload_2
/*     */     //   13: invokestatic 420	org/mybatis/generator/internal/ObjectFactory:createJavaTypeResolver	(Lorg/mybatis/generator/config/Context;Ljava/util/List;)Lorg/mybatis/generator/api/JavaTypeResolver;
/*     */     //   16: astore 4
/*     */     //   18: aconst_null
/*     */     //   19: astore 5
/*     */     //   21: aload_1
/*     */     //   22: ldc_w 424
/*     */     //   25: invokestatic 137	org/mybatis/generator/internal/util/messages/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   28: invokeinterface 426 2 0
/*     */     //   33: aload_0
/*     */     //   34: invokespecial 431	org/mybatis/generator/config/Context:getConnection	()Ljava/sql/Connection;
/*     */     //   37: astore 5
/*     */     //   39: new 435	org/mybatis/generator/internal/db/DatabaseIntrospector
/*     */     //   42: dup
/*     */     //   43: aload_0
/*     */     //   44: aload 5
/*     */     //   46: invokeinterface 437 1 0
/*     */     //   51: aload 4
/*     */     //   53: aload_2
/*     */     //   54: invokespecial 443	org/mybatis/generator/internal/db/DatabaseIntrospector:<init>	(Lorg/mybatis/generator/config/Context;Ljava/sql/DatabaseMetaData;Lorg/mybatis/generator/api/JavaTypeResolver;Ljava/util/List;)V
/*     */     //   57: astore 6
/*     */     //   59: aload_0
/*     */     //   60: getfield 80	org/mybatis/generator/config/Context:tableConfigurations	Ljava/util/ArrayList;
/*     */     //   63: invokevirtual 339	java/util/ArrayList:iterator	()Ljava/util/Iterator;
/*     */     //   66: astore 8
/*     */     //   68: goto +136 -> 204
/*     */     //   71: aload 8
/*     */     //   73: invokeinterface 215 1 0
/*     */     //   78: checkcast 206	org/mybatis/generator/config/TableConfiguration
/*     */     //   81: astore 7
/*     */     //   83: aload 7
/*     */     //   85: invokevirtual 446	org/mybatis/generator/config/TableConfiguration:getCatalog	()Ljava/lang/String;
/*     */     //   88: aload 7
/*     */     //   90: invokevirtual 449	org/mybatis/generator/config/TableConfiguration:getSchema	()Ljava/lang/String;
/*     */     //   93: aload 7
/*     */     //   95: invokevirtual 452	org/mybatis/generator/config/TableConfiguration:getTableName	()Ljava/lang/String;
/*     */     //   98: bipush 46
/*     */     //   100: invokestatic 455	org/mybatis/generator/internal/util/StringUtility:composeFullyQualifiedTableName	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;
/*     */     //   103: astore 9
/*     */     //   105: aload_3
/*     */     //   106: ifnull +26 -> 132
/*     */     //   109: aload_3
/*     */     //   110: invokeinterface 459 1 0
/*     */     //   115: ifle +17 -> 132
/*     */     //   118: aload_3
/*     */     //   119: aload 9
/*     */     //   121: invokeinterface 462 2 0
/*     */     //   126: ifne +6 -> 132
/*     */     //   129: goto +75 -> 204
/*     */     //   132: aload 7
/*     */     //   134: invokevirtual 465	org/mybatis/generator/config/TableConfiguration:areAnyStatementsEnabled	()Z
/*     */     //   137: ifne +21 -> 158
/*     */     //   140: aload_2
/*     */     //   141: ldc_w 468
/*     */     //   144: aload 9
/*     */     //   146: invokestatic 145	org/mybatis/generator/internal/util/messages/Messages:getString	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   149: invokeinterface 119 2 0
/*     */     //   154: pop
/*     */     //   155: goto +49 -> 204
/*     */     //   158: aload_1
/*     */     //   159: ldc_w 470
/*     */     //   162: aload 9
/*     */     //   164: invokestatic 145	org/mybatis/generator/internal/util/messages/Messages:getString	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   167: invokeinterface 426 2 0
/*     */     //   172: aload 6
/*     */     //   174: aload 7
/*     */     //   176: invokevirtual 472	org/mybatis/generator/internal/db/DatabaseIntrospector:introspectTables	(Lorg/mybatis/generator/config/TableConfiguration;)Ljava/util/List;
/*     */     //   179: astore 10
/*     */     //   181: aload 10
/*     */     //   183: ifnull +15 -> 198
/*     */     //   186: aload_0
/*     */     //   187: getfield 418	org/mybatis/generator/config/Context:introspectedTables	Ljava/util/List;
/*     */     //   190: aload 10
/*     */     //   192: invokeinterface 475 2 0
/*     */     //   197: pop
/*     */     //   198: aload_1
/*     */     //   199: invokeinterface 479 1 0
/*     */     //   204: aload 8
/*     */     //   206: invokeinterface 224 1 0
/*     */     //   211: ifne -140 -> 71
/*     */     //   214: goto +14 -> 228
/*     */     //   217: astore 11
/*     */     //   219: aload_0
/*     */     //   220: aload 5
/*     */     //   222: invokespecial 482	org/mybatis/generator/config/Context:closeConnection	(Ljava/sql/Connection;)V
/*     */     //   225: aload 11
/*     */     //   227: athrow
/*     */     //   228: aload_0
/*     */     //   229: aload 5
/*     */     //   231: invokespecial 482	org/mybatis/generator/config/Context:closeConnection	(Ljava/sql/Connection;)V
/*     */     //   234: return
/*     */     // Line number table:
/*     */     //   Java source line #648	-> byte code offset #0
/*     */     //   Java source line #650	-> byte code offset #11
/*     */     //   Java source line #649	-> byte code offset #16
/*     */     //   Java source line #652	-> byte code offset #18
/*     */     //   Java source line #655	-> byte code offset #21
/*     */     //   Java source line #656	-> byte code offset #33
/*     */     //   Java source line #658	-> byte code offset #39
/*     */     //   Java source line #659	-> byte code offset #43
/*     */     //   Java source line #658	-> byte code offset #54
/*     */     //   Java source line #661	-> byte code offset #59
/*     */     //   Java source line #662	-> byte code offset #83
/*     */     //   Java source line #663	-> byte code offset #90
/*     */     //   Java source line #662	-> byte code offset #100
/*     */     //   Java source line #665	-> byte code offset #105
/*     */     //   Java source line #666	-> byte code offset #109
/*     */     //   Java source line #667	-> byte code offset #118
/*     */     //   Java source line #668	-> byte code offset #129
/*     */     //   Java source line #672	-> byte code offset #132
/*     */     //   Java source line #673	-> byte code offset #140
/*     */     //   Java source line #674	-> byte code offset #155
/*     */     //   Java source line #677	-> byte code offset #158
/*     */     //   Java source line #678	-> byte code offset #172
/*     */     //   Java source line #679	-> byte code offset #174
/*     */     //   Java source line #678	-> byte code offset #179
/*     */     //   Java source line #681	-> byte code offset #181
/*     */     //   Java source line #682	-> byte code offset #186
/*     */     //   Java source line #685	-> byte code offset #198
/*     */     //   Java source line #661	-> byte code offset #204
/*     */     //   Java source line #687	-> byte code offset #217
/*     */     //   Java source line #688	-> byte code offset #219
/*     */     //   Java source line #689	-> byte code offset #225
/*     */     //   Java source line #688	-> byte code offset #228
/*     */     //   Java source line #690	-> byte code offset #234
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	235	0	this	Context
/*     */     //   0	235	1	callback	ProgressCallback
/*     */     //   0	235	2	warnings	List<String>
/*     */     //   0	235	3	fullyQualifiedTableNames	java.util.Set<String>
/*     */     //   16	36	4	javaTypeResolver	org.mybatis.generator.api.JavaTypeResolver
/*     */     //   19	211	5	connection	Connection
/*     */     //   57	116	6	databaseIntrospector	org.mybatis.generator.internal.db.DatabaseIntrospector
/*     */     //   81	94	7	tc	TableConfiguration
/*     */     //   66	139	8	localIterator	java.util.Iterator
/*     */     //   103	60	9	tableName	String
/*     */     //   179	12	10	tables	List<IntrospectedTable>
/*     */     //   217	9	11	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   21	217	217	finally
/*     */   }
/*     */   
/*     */   public int getGenerationSteps()
/*     */   {
/* 693 */     int steps = 0;
/*     */     
/* 695 */     if (this.introspectedTables != null) {
/* 696 */       for (IntrospectedTable introspectedTable : this.introspectedTables) {
/* 697 */         steps += introspectedTable.getGenerationSteps();
/*     */       }
/*     */     }
/*     */     
/* 701 */     return steps;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void generateFiles(ProgressCallback callback, List<GeneratedJavaFile> generatedJavaFiles, List<GeneratedXmlFile> generatedXmlFiles, List<String> warnings)
/*     */     throws InterruptedException
/*     */   {
/* 709 */     this.pluginAggregator = new PluginAggregator();
/* 710 */     for (PluginConfiguration pluginConfiguration : this.pluginConfigurations) {
/* 711 */       Plugin plugin = ObjectFactory.createPlugin(this, 
/* 712 */         pluginConfiguration);
/* 713 */       if (plugin.validate(warnings)) {
/* 714 */         this.pluginAggregator.addPlugin(plugin);
/*     */       } else {
/* 716 */         warnings.add(Messages.getString("Warning.24", 
/* 717 */           pluginConfiguration.getConfigurationType(), this.id));
/*     */       }
/*     */     }
/*     */     
/* 721 */     if (this.introspectedTables != null) {
/* 722 */       for (IntrospectedTable introspectedTable : this.introspectedTables) {
/* 723 */         callback.checkCancel();
/*     */         
/* 725 */         introspectedTable.initialize();
/* 726 */         introspectedTable.calculateGenerators(warnings, callback);
/* 727 */         generatedJavaFiles.addAll(introspectedTable
/* 728 */           .getGeneratedJavaFiles());
/* 729 */         generatedXmlFiles.addAll(introspectedTable
/* 730 */           .getGeneratedXmlFiles());
/*     */         
/* 732 */         generatedJavaFiles.addAll(this.pluginAggregator
/* 733 */           .contextGenerateAdditionalJavaFiles(introspectedTable));
/* 734 */         generatedXmlFiles.addAll(this.pluginAggregator
/* 735 */           .contextGenerateAdditionalXmlFiles(introspectedTable));
/*     */       }
/*     */     }
/*     */     
/* 739 */     generatedJavaFiles.addAll(this.pluginAggregator
/* 740 */       .contextGenerateAdditionalJavaFiles());
/* 741 */     generatedXmlFiles.addAll(this.pluginAggregator
/* 742 */       .contextGenerateAdditionalXmlFiles());
/*     */   }
/*     */   
/*     */   private Connection getConnection() throws SQLException {
/* 746 */     Connection connection = ConnectionFactory.getInstance().getConnection(
/* 747 */       this.jdbcConnectionConfiguration);
/*     */     
/* 749 */     return connection;
/*     */   }
/*     */   
/*     */   private void closeConnection(Connection connection) {
/* 753 */     if (connection != null) {
/*     */       try {
/* 755 */         connection.close();
/*     */       }
/*     */       catch (SQLException localSQLException) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean autoDelimitKeywords()
/*     */   {
/* 765 */     return (this.autoDelimitKeywords != null) && (this.autoDelimitKeywords.booleanValue());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDbmsType()
/*     */   {
/* 775 */     Connection connection = null;
/*     */     try { String str;
/* 777 */       if ((this.jdbcConnectionConfiguration.getDbmsType() == null) || ("".equals(this.jdbcConnectionConfiguration.getDbmsType()))) {
/* 778 */         connection = getConnection();
/* 779 */         DatabaseMetaData databaseMetaData = connection.getMetaData();
/* 780 */         return databaseMetaData.getDatabaseProductName();
/*     */       }
/* 782 */       return this.jdbcConnectionConfiguration.getDbmsType();
/*     */     }
/*     */     catch (Exception e) {
/* 785 */       e.printStackTrace();
/* 786 */       return null;
/*     */     } finally {
/* 788 */       closeConnection(connection);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\Context.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */