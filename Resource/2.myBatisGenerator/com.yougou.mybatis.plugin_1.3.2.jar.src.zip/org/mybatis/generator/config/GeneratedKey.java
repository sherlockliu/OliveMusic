/*     */ package org.mybatis.generator.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.internal.db.DatabaseDialects;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GeneratedKey
/*     */ {
/*     */   private String column;
/*     */   private String configuredSqlStatement;
/*     */   private String runtimeSqlStatement;
/*     */   private boolean isIdentity;
/*     */   private String type;
/*     */   
/*     */   public GeneratedKey(String column, String configuredSqlStatement, boolean isIdentity, String type)
/*     */   {
/*  50 */     this.column = column;
/*  51 */     this.type = type;
/*  52 */     this.isIdentity = isIdentity;
/*  53 */     this.configuredSqlStatement = configuredSqlStatement;
/*     */     
/*  55 */     DatabaseDialects dialect = 
/*  56 */       DatabaseDialects.getDatabaseDialect(configuredSqlStatement);
/*  57 */     if (dialect == null) {
/*  58 */       this.runtimeSqlStatement = configuredSqlStatement;
/*     */     } else {
/*  60 */       this.runtimeSqlStatement = dialect.getIdentityRetrievalStatement();
/*     */     }
/*     */   }
/*     */   
/*     */   public String getColumn() {
/*  65 */     return this.column;
/*     */   }
/*     */   
/*     */   public boolean isIdentity() {
/*  69 */     return this.isIdentity;
/*     */   }
/*     */   
/*     */   public String getRuntimeSqlStatement() {
/*  73 */     return this.runtimeSqlStatement;
/*     */   }
/*     */   
/*     */   public String getType() {
/*  77 */     return this.type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isPlacedBeforeInsertInIbatis2()
/*     */   {
/*     */     boolean rc;
/*     */     
/*     */ 
/*     */     boolean rc;
/*     */     
/*     */ 
/*  90 */     if (StringUtility.stringHasValue(this.type)) {
/*  91 */       rc = true;
/*     */     } else {
/*  93 */       rc = !this.isIdentity;
/*     */     }
/*     */     
/*  96 */     return rc;
/*     */   }
/*     */   
/*     */   public String getMyBatis3Order() {
/* 100 */     return this.isIdentity ? "AFTER" : "BEFORE";
/*     */   }
/*     */   
/*     */   public XmlElement toXmlElement() {
/* 104 */     XmlElement xmlElement = new XmlElement("generatedKey");
/* 105 */     xmlElement.addAttribute(new Attribute("column", this.column));
/* 106 */     xmlElement.addAttribute(new Attribute(
/* 107 */       "sqlStatement", this.configuredSqlStatement));
/* 108 */     if (StringUtility.stringHasValue(this.type)) {
/* 109 */       xmlElement.addAttribute(new Attribute("type", this.type));
/*     */     }
/* 111 */     xmlElement.addAttribute(new Attribute("identity", 
/* 112 */       this.isIdentity ? "true" : "false"));
/*     */     
/* 114 */     return xmlElement;
/*     */   }
/*     */   
/*     */   public void validate(List<String> errors, String tableName) {
/* 118 */     if (!StringUtility.stringHasValue(this.runtimeSqlStatement)) {
/* 119 */       errors.add(Messages.getString("ValidationError.7", 
/* 120 */         tableName));
/*     */     }
/*     */     
/* 123 */     if ((StringUtility.stringHasValue(this.type)) && 
/* 124 */       (!"pre".equals(this.type)) && (!"post".equals(this.type))) {
/* 125 */       errors.add(Messages.getString("ValidationError.15", 
/* 126 */         tableName));
/*     */     }
/*     */     
/*     */ 
/* 130 */     if (("pre".equals(this.type)) && (this.isIdentity)) {
/* 131 */       errors.add(Messages.getString("ValidationError.23", 
/* 132 */         tableName));
/*     */     }
/*     */     
/* 135 */     if (("post".equals(this.type)) && (!this.isIdentity)) {
/* 136 */       errors.add(Messages.getString("ValidationError.24", 
/* 137 */         tableName));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isJdbcStandard() {
/* 142 */     return "JDBC".equals(this.runtimeSqlStatement);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\GeneratedKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */