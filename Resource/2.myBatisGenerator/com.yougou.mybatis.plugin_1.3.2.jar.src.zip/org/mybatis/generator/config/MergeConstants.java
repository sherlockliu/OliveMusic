/*    */ package org.mybatis.generator.config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MergeConstants
/*    */ {
/* 33 */   public static final String[] OLD_XML_ELEMENT_PREFIXES = {
/* 34 */     "ibatorgenerated_", "abatorgenerated_" };
/*    */   
/*    */   public static final String NEW_ELEMENT_TAG = "@mbggenerated";
/* 37 */   public static final String[] OLD_ELEMENT_TAGS = {
/* 38 */     "@ibatorgenerated", "@abatorgenerated", "@mbggenerated" };
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\MergeConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */