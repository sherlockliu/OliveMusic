/*     */ package org.mybatis.generator.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.Document;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.exception.InvalidConfigurationException;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Configuration
/*     */ {
/*     */   private List<Context> contexts;
/*     */   private List<String> classPathEntries;
/*     */   
/*     */   public Configuration()
/*     */   {
/*  41 */     this.contexts = new ArrayList();
/*  42 */     this.classPathEntries = new ArrayList();
/*     */   }
/*     */   
/*     */   public void addClasspathEntry(String entry) {
/*  46 */     this.classPathEntries.add(entry);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<String> getClassPathEntries()
/*     */   {
/*  53 */     return this.classPathEntries;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void validate()
/*     */     throws InvalidConfigurationException
/*     */   {
/*  64 */     List<String> errors = new ArrayList();
/*     */     
/*  66 */     for (String classPathEntry : this.classPathEntries) {
/*  67 */       if (!StringUtility.stringHasValue(classPathEntry)) {
/*  68 */         errors.add(Messages.getString("ValidationError.19"));
/*     */         
/*  70 */         break;
/*     */       }
/*     */     }
/*     */     
/*  74 */     if (this.contexts.size() == 0) {
/*  75 */       errors.add(Messages.getString("ValidationError.11"));
/*     */     } else {
/*  77 */       for (Context context : this.contexts) {
/*  78 */         context.validate(errors);
/*     */       }
/*     */     }
/*     */     
/*  82 */     if (errors.size() > 0) {
/*  83 */       throw new InvalidConfigurationException(errors);
/*     */     }
/*     */   }
/*     */   
/*     */   public List<Context> getContexts() {
/*  88 */     return this.contexts;
/*     */   }
/*     */   
/*     */   public void addContext(Context context) {
/*  92 */     this.contexts.add(context);
/*     */   }
/*     */   
/*     */   public Context getContext(String id) {
/*  96 */     for (Context context : this.contexts) {
/*  97 */       if (id.equals(context.getId())) {
/*  98 */         return context;
/*     */       }
/*     */     }
/*     */     
/* 102 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document toDocument()
/*     */   {
/* 115 */     Document document = new Document(
/* 116 */       "-//mybatis.org//DTD MyBatis Generator Configuration 1.0//EN", 
/* 117 */       "http://mybatis.org/dtd/mybatis-generator-config_1_0.dtd");
/* 118 */     XmlElement rootElement = new XmlElement("generatorConfiguration");
/* 119 */     document.setRootElement(rootElement);
/*     */     
/* 121 */     for (String classPathEntry : this.classPathEntries) {
/* 122 */       XmlElement cpeElement = new XmlElement("classPathEntry");
/* 123 */       cpeElement.addAttribute(new Attribute("location", classPathEntry));
/* 124 */       rootElement.addElement(cpeElement);
/*     */     }
/*     */     
/* 127 */     for (Context context : this.contexts) {
/* 128 */       rootElement.addElement(context.toXmlElement());
/*     */     }
/*     */     
/* 131 */     return document;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\Configuration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */