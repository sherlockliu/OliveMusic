/*     */ package org.mybatis.generator.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YouGouServiceGeneratorConfiguration
/*     */   extends TypedPropertyHolder
/*     */ {
/*     */   private String targetPackage;
/*     */   private String implementationPackage;
/*     */   private String targetProject;
/*     */   private String interfaceExtendSupInterface;
/*     */   private String interfaceExtendSupInterfaceDoMain;
/*     */   private String enableInterfaceSupInterfaceGenericity;
/*     */   private String extendSupClass;
/*     */   private String extendSupClassDoMain;
/*     */   private String enableSupClassGenericity;
/*     */   
/*     */   public String getTargetProject()
/*     */   {
/*  51 */     return this.targetProject;
/*     */   }
/*     */   
/*     */   public void setTargetProject(String targetProject) {
/*  55 */     this.targetProject = targetProject;
/*     */   }
/*     */   
/*     */   public String getTargetPackage() {
/*  59 */     return this.targetPackage;
/*     */   }
/*     */   
/*     */   public void setTargetPackage(String targetPackage) {
/*  63 */     this.targetPackage = targetPackage;
/*     */   }
/*     */   
/*     */   public String getExtendSupClass() {
/*  67 */     return this.extendSupClass;
/*     */   }
/*     */   
/*     */   public void setExtendSupClass(String extendSupClass) {
/*  71 */     this.extendSupClass = extendSupClass;
/*     */   }
/*     */   
/*     */   public String getExtendSupClassDoMain() {
/*  75 */     int point = -1;
/*  76 */     if ((this.extendSupClass != null) && (!"".equals(this.extendSupClass)))
/*  77 */       point = this.extendSupClass.lastIndexOf(".");
/*  78 */     if ((this.extendSupClass != null) && (this.extendSupClass.length() > point)) {
/*  79 */       this.extendSupClassDoMain = this.extendSupClass.substring(point + 1);
/*     */     } else {
/*  81 */       this.extendSupClassDoMain = "";
/*     */     }
/*  83 */     return this.extendSupClassDoMain;
/*     */   }
/*     */   
/*     */   public String getEnableSupClassGenericity() {
/*  87 */     return this.enableSupClassGenericity;
/*     */   }
/*     */   
/*     */   public void setEnableSupClassGenericity(String enableSupClassGenericity) {
/*  91 */     this.enableSupClassGenericity = enableSupClassGenericity;
/*     */   }
/*     */   
/*     */   public String getInterfaceExtendSupInterface() {
/*  95 */     return this.interfaceExtendSupInterface;
/*     */   }
/*     */   
/*     */   public void setInterfaceExtendSupInterface(String interfaceExtendSupInterface) {
/*  99 */     this.interfaceExtendSupInterface = interfaceExtendSupInterface;
/*     */   }
/*     */   
/*     */   public void setInterfaceExtendSupInterfaceDoMain(String interFaceExtendSupInterfaceDoMain)
/*     */   {
/* 104 */     this.interfaceExtendSupInterfaceDoMain = interFaceExtendSupInterfaceDoMain;
/*     */   }
/*     */   
/*     */   public String getEnableInterfaceSupInterfaceGenericity() {
/* 108 */     return this.enableInterfaceSupInterfaceGenericity;
/*     */   }
/*     */   
/*     */   public void setEnableInterfaceSupInterfaceGenericity(String enableInterfaceSupInterfaceGenericity)
/*     */   {
/* 113 */     this.enableInterfaceSupInterfaceGenericity = enableInterfaceSupInterfaceGenericity;
/*     */   }
/*     */   
/*     */   public String getInterFaceExtendSupInterfaceDoMain() {
/* 117 */     int point = -1;
/* 118 */     if ((this.interfaceExtendSupInterface != null) && (!"".equals(this.interfaceExtendSupInterface)))
/* 119 */       point = this.interfaceExtendSupInterface.lastIndexOf(".");
/* 120 */     if ((this.interfaceExtendSupInterface != null) && (this.interfaceExtendSupInterface.length() > point)) {
/* 121 */       this.interfaceExtendSupInterfaceDoMain = this.interfaceExtendSupInterface.substring(point + 1);
/*     */     } else {
/* 123 */       this.interfaceExtendSupInterfaceDoMain = "";
/*     */     }
/* 125 */     return this.interfaceExtendSupInterfaceDoMain;
/*     */   }
/*     */   
/*     */   public XmlElement toXmlElement() {
/* 129 */     XmlElement answer = new XmlElement("javaServiceGenerator");
/*     */     
/* 131 */     if (this.targetPackage != null) {
/* 132 */       answer.addAttribute(new Attribute("targetPackage", this.targetPackage));
/*     */     }
/*     */     
/* 135 */     if (this.targetProject != null) {
/* 136 */       answer.addAttribute(new Attribute("targetProject", this.targetProject));
/*     */     }
/*     */     
/* 139 */     if (this.extendSupClass != null) {
/* 140 */       answer.addAttribute(new Attribute("extendSupClass", this.extendSupClass));
/*     */     }
/*     */     
/* 143 */     if (this.enableSupClassGenericity != null) {
/* 144 */       answer.addAttribute(new Attribute("enableSupClassGenericity", this.enableSupClassGenericity));
/*     */     }
/*     */     
/* 147 */     if (this.interfaceExtendSupInterface != null) {
/* 148 */       answer.addAttribute(new Attribute("interfaceExtendSupInterface", this.interfaceExtendSupInterface));
/*     */     }
/*     */     
/* 151 */     if (this.enableInterfaceSupInterfaceGenericity != null) {
/* 152 */       answer.addAttribute(new Attribute("enableInterfaceSupInterfaceGenericity", this.enableInterfaceSupInterfaceGenericity));
/*     */     }
/*     */     
/* 155 */     if (this.implementationPackage != null) {
/* 156 */       answer.addAttribute(new Attribute(
/* 157 */         "implementationPackage", this.targetProject));
/*     */     }
/*     */     
/* 160 */     addPropertyXmlElements(answer);
/*     */     
/* 162 */     return answer;
/*     */   }
/*     */   
/*     */   public String getImplementationPackage() {
/* 166 */     return this.implementationPackage;
/*     */   }
/*     */   
/*     */   public void setImplementationPackage(String implementationPackage) {
/* 170 */     this.implementationPackage = implementationPackage;
/*     */   }
/*     */   
/*     */   public void validate(List<String> errors, String contextId) {
/* 174 */     if (!StringUtility.stringHasValue(this.targetProject)) {
/* 175 */       errors.add(Messages.getString("ValidationError.2", contextId));
/*     */     }
/*     */     
/* 178 */     if (!StringUtility.stringHasValue(this.targetPackage)) {
/* 179 */       errors.add(Messages.getString("ValidationError.12", 
/* 180 */         "javaClientGenerator", contextId));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\YouGouServiceGeneratorConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */