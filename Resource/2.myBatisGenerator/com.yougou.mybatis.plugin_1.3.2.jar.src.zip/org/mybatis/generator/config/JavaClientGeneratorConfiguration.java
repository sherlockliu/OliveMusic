/*     */ package org.mybatis.generator.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaClientGeneratorConfiguration
/*     */   extends TypedPropertyHolder
/*     */ {
/*     */   private String targetPackage;
/*     */   private String implementationPackage;
/*     */   private String targetProject;
/*     */   private String interfaceExtendSupInterface;
/*     */   private String interfaceExtendSupInterfaceDoMain;
/*     */   private String enableInterfaceSupInterfaceGenericity;
/*     */   public Set<String> exclusionsMethods;
/*     */   
/*     */   public String getInterfaceExtendSupInterface()
/*     */   {
/*  46 */     return this.interfaceExtendSupInterface;
/*     */   }
/*     */   
/*     */   public void setInterfaceExtendSupInterface(String interfaceExtendSupInterface) {
/*  50 */     this.interfaceExtendSupInterface = interfaceExtendSupInterface;
/*     */   }
/*     */   
/*     */   public void setInterfaceExtendSupInterfaceDoMain(String interfaceExtendSupInterfaceDoMain)
/*     */   {
/*  55 */     this.interfaceExtendSupInterfaceDoMain = interfaceExtendSupInterfaceDoMain;
/*     */   }
/*     */   
/*     */   public String getEnableInterfaceSupInterfaceGenericity() {
/*  59 */     return this.enableInterfaceSupInterfaceGenericity;
/*     */   }
/*     */   
/*     */   public void setEnableInterfaceSupInterfaceGenericity(String enableInterfaceSupInterfaceGenericity)
/*     */   {
/*  64 */     this.enableInterfaceSupInterfaceGenericity = enableInterfaceSupInterfaceGenericity;
/*     */   }
/*     */   
/*     */   public String getInterFaceExtendSupInterfaceDoMain() {
/*  68 */     int point = -1;
/*  69 */     if ((this.interfaceExtendSupInterface != null) && (!"".equals(this.interfaceExtendSupInterface)))
/*  70 */       point = this.interfaceExtendSupInterface.lastIndexOf(".");
/*  71 */     if ((this.interfaceExtendSupInterface != null) && (this.interfaceExtendSupInterface.length() > point)) {
/*  72 */       this.interfaceExtendSupInterfaceDoMain = this.interfaceExtendSupInterface.substring(point + 1);
/*     */     } else {
/*  74 */       this.interfaceExtendSupInterfaceDoMain = "";
/*     */     }
/*  76 */     return this.interfaceExtendSupInterfaceDoMain;
/*     */   }
/*     */   
/*     */   public Set<String> getExclusionsMethods()
/*     */   {
/*  81 */     return this.exclusionsMethods;
/*     */   }
/*     */   
/*     */   public void setExclusionsMethods(Set<String> exclusionsMethods) {
/*  85 */     this.exclusionsMethods = exclusionsMethods;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTargetProject()
/*     */   {
/*  96 */     return this.targetProject;
/*     */   }
/*     */   
/*     */   public void setTargetProject(String targetProject) {
/* 100 */     this.targetProject = targetProject;
/*     */   }
/*     */   
/*     */   public String getTargetPackage() {
/* 104 */     return this.targetPackage;
/*     */   }
/*     */   
/*     */   public void setTargetPackage(String targetPackage) {
/* 108 */     this.targetPackage = targetPackage;
/*     */   }
/*     */   
/*     */   public XmlElement toXmlElement() {
/* 112 */     XmlElement answer = new XmlElement("javaClientGenerator");
/* 113 */     if (getConfigurationType() != null) {
/* 114 */       answer.addAttribute(new Attribute("type", getConfigurationType()));
/*     */     }
/*     */     
/* 117 */     if (this.targetPackage != null) {
/* 118 */       answer.addAttribute(new Attribute("targetPackage", this.targetPackage));
/*     */     }
/*     */     
/* 121 */     if (this.targetProject != null) {
/* 122 */       answer.addAttribute(new Attribute("targetProject", this.targetProject));
/*     */     }
/*     */     
/* 125 */     if (this.implementationPackage != null) {
/* 126 */       answer.addAttribute(new Attribute(
/* 127 */         "implementationPackage", this.targetProject));
/*     */     }
/*     */     
/* 130 */     addPropertyXmlElements(answer);
/*     */     
/* 132 */     return answer;
/*     */   }
/*     */   
/*     */   public String getImplementationPackage() {
/* 136 */     return this.implementationPackage;
/*     */   }
/*     */   
/*     */   public void setImplementationPackage(String implementationPackage) {
/* 140 */     this.implementationPackage = implementationPackage;
/*     */   }
/*     */   
/*     */   public void validate(List<String> errors, String contextId) {
/* 144 */     if (!StringUtility.stringHasValue(this.targetProject)) {
/* 145 */       errors.add(Messages.getString("ValidationError.2", contextId));
/*     */     }
/*     */     
/* 148 */     if (!StringUtility.stringHasValue(this.targetPackage)) {
/* 149 */       errors.add(Messages.getString("ValidationError.12", 
/* 150 */         "javaClientGenerator", contextId));
/*     */     }
/*     */     
/* 153 */     if (!StringUtility.stringHasValue(getConfigurationType())) {
/* 154 */       errors.add(Messages.getString("ValidationError.20", 
/* 155 */         contextId));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\JavaClientGeneratorConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */