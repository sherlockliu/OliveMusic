/*    */ package org.mybatis.generator.config;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ import org.mybatis.generator.internal.util.StringUtility;
/*    */ import org.mybatis.generator.internal.util.messages.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JavaModelGeneratorConfiguration
/*    */   extends PropertyHolder
/*    */ {
/*    */   private String targetPackage;
/*    */   private String targetProject;
/*    */   
/*    */   public String getTargetProject()
/*    */   {
/* 43 */     return this.targetProject;
/*    */   }
/*    */   
/*    */   public void setTargetProject(String targetProject) {
/* 47 */     this.targetProject = targetProject;
/*    */   }
/*    */   
/*    */   public String getTargetPackage() {
/* 51 */     return this.targetPackage;
/*    */   }
/*    */   
/*    */   public void setTargetPackage(String targetPackage) {
/* 55 */     this.targetPackage = targetPackage;
/*    */   }
/*    */   
/*    */   public XmlElement toXmlElement() {
/* 59 */     XmlElement answer = new XmlElement("javaModelGenerator");
/*    */     
/* 61 */     if (this.targetPackage != null) {
/* 62 */       answer.addAttribute(new Attribute("targetPackage", this.targetPackage));
/*    */     }
/*    */     
/* 65 */     if (this.targetProject != null) {
/* 66 */       answer.addAttribute(new Attribute("targetProject", this.targetProject));
/*    */     }
/*    */     
/* 69 */     addPropertyXmlElements(answer);
/*    */     
/* 71 */     return answer;
/*    */   }
/*    */   
/*    */   public void validate(List<String> errors, String contextId) {
/* 75 */     if (!StringUtility.stringHasValue(this.targetProject)) {
/* 76 */       errors.add(Messages.getString("ValidationError.0", contextId));
/*    */     }
/*    */     
/* 79 */     if (!StringUtility.stringHasValue(this.targetPackage)) {
/* 80 */       errors.add(Messages.getString("ValidationError.12", 
/* 81 */         "JavaModelGenerator", contextId));
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\JavaModelGeneratorConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */