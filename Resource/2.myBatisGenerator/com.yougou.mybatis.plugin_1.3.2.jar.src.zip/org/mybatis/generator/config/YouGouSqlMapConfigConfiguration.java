/*    */ package org.mybatis.generator.config;
/*    */ 
/*    */ import org.mybatis.generator.api.dom.xml.Attribute;
/*    */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class YouGouSqlMapConfigConfiguration
/*    */   extends PropertyHolder
/*    */ {
/*    */   private String targetPackage;
/*    */   private String targetProject;
/*    */   private String confileFileName;
/*    */   private String confileFilePackagePath;
/*    */   
/*    */   public XmlElement toXmlElement()
/*    */   {
/* 38 */     XmlElement answer = new XmlElement("javaServiceGenerator");
/*    */     
/* 40 */     if (this.targetPackage != null) {
/* 41 */       answer.addAttribute(new Attribute("targetPackage", this.targetPackage));
/*    */     }
/*    */     
/* 44 */     if (this.targetProject != null) {
/* 45 */       answer.addAttribute(new Attribute("targetProject", this.targetProject));
/*    */     }
/*    */     
/* 48 */     if (this.confileFileName != null) {
/* 49 */       answer.addAttribute(new Attribute("confileFileName", ""));
/*    */     }
/*    */     
/* 52 */     if (this.confileFilePackagePath != null) {
/* 53 */       answer.addAttribute(new Attribute("confileFilePackagePath", ""));
/*    */     }
/*    */     
/* 56 */     addPropertyXmlElements(answer);
/*    */     
/* 58 */     return answer;
/*    */   }
/*    */   
/*    */   public String getTargetPackage() {
/* 62 */     return this.targetPackage;
/*    */   }
/*    */   
/*    */   public void setTargetPackage(String targetPackage) {
/* 66 */     this.targetPackage = targetPackage;
/*    */   }
/*    */   
/*    */   public String getTargetProject() {
/* 70 */     return this.targetProject;
/*    */   }
/*    */   
/*    */   public void setTargetProject(String targetProject) {
/* 74 */     this.targetProject = targetProject;
/*    */   }
/*    */   
/*    */   public String getConfileFileName() {
/* 78 */     return this.confileFileName;
/*    */   }
/*    */   
/*    */   public void setConfileFileName(String confileFileName) {
/* 82 */     this.confileFileName = confileFileName;
/*    */   }
/*    */   
/*    */   public String getConfileFilePackagePath() {
/* 86 */     return this.confileFilePackagePath;
/*    */   }
/*    */   
/*    */   public void setConfileFilePackagePath(String confileFilePackagePath) {
/* 90 */     this.confileFilePackagePath = confileFilePackagePath;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\YouGouSqlMapConfigConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */