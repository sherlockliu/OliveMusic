/*     */ package org.mybatis.generator.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class YouGouControllerGeneratorConfiguration
/*     */   extends TypedPropertyHolder
/*     */ {
/*     */   private String targetPackage;
/*     */   private String implementationPackage;
/*     */   private String targetProject;
/*     */   private String interfaceExtendSupInterface;
/*     */   private String interfaceExtendSupInterfaceDoMain;
/*     */   private String enableInterfaceSupInterfaceGenericity;
/*     */   private String extendSupClass;
/*     */   private String extendSupClassFor3Layer;
/*     */   private String extendSupClassDoMain;
/*     */   private String extendSupClassDoMainFor3Layer;
/*     */   private String enableSupClassGenericity;
/*     */   
/*     */   public String getTargetProject()
/*     */   {
/*  53 */     return this.targetProject;
/*     */   }
/*     */   
/*     */   public void setTargetProject(String targetProject) {
/*  57 */     this.targetProject = targetProject;
/*     */   }
/*     */   
/*     */   public String getTargetPackage() {
/*  61 */     return this.targetPackage;
/*     */   }
/*     */   
/*     */   public void setTargetPackage(String targetPackage) {
/*  65 */     this.targetPackage = targetPackage;
/*     */   }
/*     */   
/*     */   public String getExtendSupClass() {
/*  69 */     return this.extendSupClass;
/*     */   }
/*     */   
/*     */   public void setExtendSupClass(String extendSupClass) {
/*  73 */     this.extendSupClass = extendSupClass;
/*     */   }
/*     */   
/*     */   public String getExtendSupClassFor3Layer() {
/*  77 */     return this.extendSupClassFor3Layer;
/*     */   }
/*     */   
/*     */   public void setExtendSupClassFor3Layer(String extendSupClassFor3Layer) {
/*  81 */     this.extendSupClassFor3Layer = extendSupClassFor3Layer;
/*     */   }
/*     */   
/*     */   public String getExtendSupClassDoMainFor3Layer() {
/*  85 */     int point = -1;
/*  86 */     if ((this.extendSupClassFor3Layer != null) && (!"".equals(this.extendSupClassFor3Layer))) {
/*  87 */       point = this.extendSupClassFor3Layer.lastIndexOf(".");
/*     */     }
/*  89 */     if ((this.extendSupClassFor3Layer != null) && (this.extendSupClassFor3Layer.length() > point)) {
/*  90 */       this.extendSupClassDoMainFor3Layer = this.extendSupClassFor3Layer.substring(point + 1);
/*     */     } else {
/*  92 */       this.extendSupClassDoMainFor3Layer = "";
/*     */     }
/*  94 */     return this.extendSupClassDoMainFor3Layer;
/*     */   }
/*     */   
/*     */   public String getExtendSupClassDoMain() {
/*  98 */     int point = -1;
/*  99 */     if ((this.extendSupClass != null) && (!"".equals(this.extendSupClass))) {
/* 100 */       point = this.extendSupClass.lastIndexOf(".");
/*     */     }
/* 102 */     if ((this.extendSupClass != null) && (this.extendSupClass.length() > point)) {
/* 103 */       this.extendSupClassDoMain = this.extendSupClass.substring(point + 1);
/*     */     } else {
/* 105 */       this.extendSupClassDoMain = "";
/*     */     }
/* 107 */     return this.extendSupClassDoMain;
/*     */   }
/*     */   
/*     */   public String getEnableSupClassGenericity() {
/* 111 */     return this.enableSupClassGenericity;
/*     */   }
/*     */   
/*     */   public void setEnableSupClassGenericity(String enableSupClassGenericity) {
/* 115 */     this.enableSupClassGenericity = enableSupClassGenericity;
/*     */   }
/*     */   
/*     */   public String getInterfaceExtendSupInterface() {
/* 119 */     return this.interfaceExtendSupInterface;
/*     */   }
/*     */   
/*     */   public void setInterFaceExtendSupInterface(String interfaceExtendSupInterface) {
/* 123 */     this.interfaceExtendSupInterface = interfaceExtendSupInterface;
/*     */   }
/*     */   
/*     */   public String getEnableInterfaceSupInterfaceGenericity() {
/* 127 */     return this.enableInterfaceSupInterfaceGenericity;
/*     */   }
/*     */   
/*     */   public void setEnableInterfaceSupInterfaceGenericity(String enableInterfaceSupInterfaceGenericity)
/*     */   {
/* 132 */     this.enableInterfaceSupInterfaceGenericity = enableInterfaceSupInterfaceGenericity;
/*     */   }
/*     */   
/*     */   public String getInterFaceExtendSupInterfaceDoMain() {
/* 136 */     int point = -1;
/* 137 */     if ((this.interfaceExtendSupInterface != null) && (!"".equals(this.interfaceExtendSupInterface)))
/* 138 */       point = this.interfaceExtendSupInterface.lastIndexOf(".");
/* 139 */     if ((this.interfaceExtendSupInterface != null) && (this.interfaceExtendSupInterface.length() > point)) {
/* 140 */       this.interfaceExtendSupInterfaceDoMain = this.interfaceExtendSupInterface.substring(point + 1);
/*     */     } else {
/* 142 */       this.interfaceExtendSupInterfaceDoMain = "";
/*     */     }
/* 144 */     return this.interfaceExtendSupInterfaceDoMain;
/*     */   }
/*     */   
/*     */   public XmlElement toXmlElement() {
/* 148 */     XmlElement answer = new XmlElement("javaControllerGenerator");
/*     */     
/* 150 */     if (this.targetPackage != null) {
/* 151 */       answer.addAttribute(new Attribute("targetPackage", this.targetPackage));
/*     */     }
/*     */     
/* 154 */     if (this.targetProject != null) {
/* 155 */       answer.addAttribute(new Attribute("targetProject", this.targetProject));
/*     */     }
/*     */     
/* 158 */     if (this.extendSupClass != null) {
/* 159 */       answer.addAttribute(new Attribute("extendSupClass", this.extendSupClass));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */     if (this.enableSupClassGenericity != null) {
/* 167 */       answer.addAttribute(new Attribute("enableSupClassGenericity", this.enableSupClassGenericity));
/*     */     }
/*     */     
/* 170 */     if (this.interfaceExtendSupInterface != null) {
/* 171 */       answer.addAttribute(new Attribute("interfaceExtendSupInterface", this.interfaceExtendSupInterface));
/*     */     }
/* 173 */     if (this.enableInterfaceSupInterfaceGenericity != null) {
/* 174 */       answer.addAttribute(new Attribute("enableInterfaceSupInterfaceGenericity", this.enableInterfaceSupInterfaceGenericity));
/*     */     }
/*     */     
/* 177 */     if (this.implementationPackage != null) {
/* 178 */       answer.addAttribute(new Attribute(
/* 179 */         "implementationPackage", this.targetProject));
/*     */     }
/*     */     
/* 182 */     addPropertyXmlElements(answer);
/*     */     
/* 184 */     return answer;
/*     */   }
/*     */   
/*     */   public String getImplementationPackage() {
/* 188 */     return this.implementationPackage;
/*     */   }
/*     */   
/*     */   public void setImplementationPackage(String implementationPackage) {
/* 192 */     this.implementationPackage = implementationPackage;
/*     */   }
/*     */   
/*     */   public void validate(List<String> errors, String contextId) {
/* 196 */     if (!StringUtility.stringHasValue(this.targetProject)) {
/* 197 */       errors.add(Messages.getString("ValidationError.2", contextId));
/*     */     }
/*     */     
/* 200 */     if (!StringUtility.stringHasValue(this.targetPackage)) {
/* 201 */       errors.add(Messages.getString("ValidationError.12", 
/* 202 */         "javaClientGenerator", contextId));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\YouGouControllerGeneratorConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */