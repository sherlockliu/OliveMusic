/*     */ package org.mybatis.generator.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.mybatis.generator.api.dom.xml.Attribute;
/*     */ import org.mybatis.generator.api.dom.xml.XmlElement;
/*     */ import org.mybatis.generator.internal.util.StringUtility;
/*     */ import org.mybatis.generator.internal.util.messages.Messages;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBCConnectionConfiguration
/*     */   extends PropertyHolder
/*     */ {
/*     */   private String driverClass;
/*     */   private String connectionURL;
/*     */   private String userId;
/*     */   private String password;
/*     */   private String dbmsType;
/*     */   
/*     */   public String getDbmsType()
/*     */   {
/*  47 */     return this.dbmsType;
/*     */   }
/*     */   
/*     */   public void setDbmsType(String dbmsType) {
/*  51 */     this.dbmsType = dbmsType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getConnectionURL()
/*     */   {
/*  59 */     return this.connectionURL;
/*     */   }
/*     */   
/*     */   public void setConnectionURL(String connectionURL) {
/*  63 */     this.connectionURL = connectionURL;
/*     */   }
/*     */   
/*     */   public String getPassword() {
/*  67 */     return this.password;
/*     */   }
/*     */   
/*     */   public void setPassword(String password) {
/*  71 */     this.password = password;
/*     */   }
/*     */   
/*     */   public String getUserId() {
/*  75 */     return this.userId;
/*     */   }
/*     */   
/*     */   public void setUserId(String userId) {
/*  79 */     this.userId = userId;
/*     */   }
/*     */   
/*     */   public String getDriverClass() {
/*  83 */     return this.driverClass;
/*     */   }
/*     */   
/*     */   public void setDriverClass(String driverClass) {
/*  87 */     this.driverClass = driverClass;
/*     */   }
/*     */   
/*     */   public XmlElement toXmlElement() {
/*  91 */     XmlElement xmlElement = new XmlElement("jdbcConnection");
/*  92 */     xmlElement.addAttribute(new Attribute("driverClass", this.driverClass));
/*  93 */     xmlElement.addAttribute(new Attribute("connectionURL", this.connectionURL));
/*     */     
/*  95 */     if (StringUtility.stringHasValue(this.userId)) {
/*  96 */       xmlElement.addAttribute(new Attribute("userId", this.userId));
/*     */     }
/*     */     
/*  99 */     if (StringUtility.stringHasValue(this.password)) {
/* 100 */       xmlElement.addAttribute(new Attribute("password", this.password));
/*     */     }
/*     */     
/* 103 */     addPropertyXmlElements(xmlElement);
/*     */     
/* 105 */     return xmlElement;
/*     */   }
/*     */   
/*     */   public void validate(List<String> errors) {
/* 109 */     if (!StringUtility.stringHasValue(this.driverClass)) {
/* 110 */       errors.add(Messages.getString("ValidationError.4"));
/*     */     }
/*     */     
/* 113 */     if (!StringUtility.stringHasValue(this.connectionURL)) {
/* 114 */       errors.add(Messages.getString("ValidationError.5"));
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\config\JDBCConnectionConfiguration.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */