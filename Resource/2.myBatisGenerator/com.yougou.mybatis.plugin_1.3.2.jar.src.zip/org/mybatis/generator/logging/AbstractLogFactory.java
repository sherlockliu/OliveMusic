package org.mybatis.generator.logging;

public abstract interface AbstractLogFactory
{
  public abstract Log getLog(Class<?> paramClass);
}


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\logging\AbstractLogFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */