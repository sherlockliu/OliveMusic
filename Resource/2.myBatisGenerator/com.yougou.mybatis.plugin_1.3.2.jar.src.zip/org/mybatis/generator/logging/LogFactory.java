/*    */ package org.mybatis.generator.logging;
/*    */ 
/*    */ import org.mybatis.generator.internal.ObjectFactory;
/*    */ import org.mybatis.generator.internal.util.messages.Messages;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogFactory
/*    */ {
/*    */   private static AbstractLogFactory logFactory;
/*    */   
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 34 */       ObjectFactory.internalClassForName("org.apache.log4j.Logger");
/* 35 */       logFactory = new Log4jLoggingLogFactory(null);
/*    */     } catch (Exception localException) {
/* 37 */       logFactory = new JdkLoggingLogFactory(null);
/*    */     }
/*    */   }
/*    */   
/*    */   public static Log getLog(Class<?> clazz) {
/*    */     try {
/* 43 */       return logFactory.getLog(clazz);
/*    */     } catch (Throwable t) {
/* 45 */       throw new RuntimeException(Messages.getString("RuntimeError.21", 
/* 46 */         clazz.getName(), t.getMessage()), t);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static synchronized void forceJavaLogging()
/*    */   {
/* 59 */     logFactory = new JdkLoggingLogFactory(null);
/*    */   }
/*    */   
/*    */   private static class JdkLoggingLogFactory implements AbstractLogFactory {
/*    */     public Log getLog(Class<?> clazz) {
/* 64 */       return new JdkLoggingImpl(clazz);
/*    */     }
/*    */   }
/*    */   
/*    */   private static class Log4jLoggingLogFactory implements AbstractLogFactory {
/*    */     public Log getLog(Class<?> clazz) {
/* 70 */       return new Log4jImpl(clazz);
/*    */     }
/*    */   }
/*    */   
/*    */   public static void setLogFactory(AbstractLogFactory logFactory) {
/* 75 */     logFactory = logFactory;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\logging\LogFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */