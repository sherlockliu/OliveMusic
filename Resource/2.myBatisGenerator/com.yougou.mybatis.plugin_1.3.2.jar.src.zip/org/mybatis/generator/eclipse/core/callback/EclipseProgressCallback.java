/*    */ package org.mybatis.generator.eclipse.core.callback;
/*    */ 
/*    */ import org.eclipse.core.runtime.IProgressMonitor;
/*    */ import org.eclipse.core.runtime.SubMonitor;
/*    */ import org.mybatis.generator.api.ProgressCallback;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EclipseProgressCallback
/*    */   implements ProgressCallback
/*    */ {
/*    */   private static final int INTROSPECTION_FACTOR = 2000;
/*    */   private static final int GENERATION_FACTOR = 4000;
/*    */   private static final int SAVE_FACTOR = 4000;
/*    */   private SubMonitor parentProgress;
/*    */   private SubMonitor currentChildProgress;
/*    */   private int currentTick;
/*    */   
/*    */   public EclipseProgressCallback(IProgressMonitor progressMonitor)
/*    */   {
/* 39 */     this.parentProgress = SubMonitor.convert(progressMonitor, 
/* 40 */       10000);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void checkCancel()
/*    */     throws InterruptedException
/*    */   {
/* 48 */     if (this.currentChildProgress.isCanceled()) {
/* 49 */       throw new InterruptedException();
/*    */     }
/*    */   }
/*    */   
/*    */   public void generationStarted(int totalTasks) {
/* 54 */     this.currentChildProgress = this.parentProgress.newChild(4000);
/* 55 */     this.currentTick = (totalTasks <= 0 ? 4000 : 4000 / totalTasks);
/* 56 */     if (this.currentTick == 0) {
/* 57 */       this.currentTick = 1;
/*    */     }
/*    */     
/* 60 */     this.currentChildProgress.beginTask("Generating Files", 4000);
/*    */   }
/*    */   
/*    */   public void introspectionStarted(int totalTasks) {
/* 64 */     this.currentChildProgress = this.parentProgress.newChild(2000);
/* 65 */     this.currentTick = (totalTasks <= 0 ? 2000 : 2000 / totalTasks);
/* 66 */     if (this.currentTick == 0) {
/* 67 */       this.currentTick = 1;
/*    */     }
/*    */     
/* 70 */     this.currentChildProgress.beginTask("Introspecting Tables", 2000);
/*    */   }
/*    */   
/*    */   public void saveStarted(int totalTasks) {
/* 74 */     this.currentChildProgress = this.parentProgress.newChild(4000);
/* 75 */     this.currentTick = (totalTasks <= 0 ? 4000 : 4000 / totalTasks);
/* 76 */     if (this.currentTick == 0) {
/* 77 */       this.currentTick = 1;
/*    */     }
/*    */     
/* 80 */     this.currentChildProgress.beginTask("Saving Generated Files", 4000);
/*    */   }
/*    */   
/*    */   public void startTask(String taskName) {
/* 84 */     this.currentChildProgress.subTask(taskName);
/* 85 */     this.currentChildProgress.worked(this.currentTick);
/*    */   }
/*    */   
/*    */   public void done() {}
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\eclipse\core\callback\EclipseProgressCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */