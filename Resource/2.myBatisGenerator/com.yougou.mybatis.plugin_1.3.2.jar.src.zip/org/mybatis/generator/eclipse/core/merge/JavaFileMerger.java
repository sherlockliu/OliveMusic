/*     */ package org.mybatis.generator.eclipse.core.merge;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.eclipse.jdt.core.dom.AST;
/*     */ import org.eclipse.jdt.core.dom.ASTNode;
/*     */ import org.eclipse.jdt.core.dom.ASTParser;
/*     */ import org.eclipse.jdt.core.dom.Annotation;
/*     */ import org.eclipse.jdt.core.dom.BodyDeclaration;
/*     */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*     */ import org.eclipse.jdt.core.dom.FieldDeclaration;
/*     */ import org.eclipse.jdt.core.dom.ImportDeclaration;
/*     */ import org.eclipse.jdt.core.dom.MethodDeclaration;
/*     */ import org.eclipse.jdt.core.dom.Name;
/*     */ import org.eclipse.jdt.core.dom.SimpleName;
/*     */ import org.eclipse.jdt.core.dom.Type;
/*     */ import org.eclipse.jdt.core.dom.TypeDeclaration;
/*     */ import org.eclipse.jdt.core.dom.rewrite.ASTRewrite;
/*     */ import org.eclipse.jdt.core.dom.rewrite.ListRewrite;
/*     */ import org.eclipse.jface.text.BadLocationException;
/*     */ import org.eclipse.jface.text.Document;
/*     */ import org.eclipse.jface.text.IDocument;
/*     */ import org.eclipse.text.edits.TextEdit;
/*     */ import org.mybatis.generator.exception.ShellException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JavaFileMerger
/*     */ {
/*     */   private String newJavaSource;
/*     */   private String existingFilePath;
/*     */   private String[] javaDocTags;
/*     */   private String fileEncoding;
/*     */   
/*     */   public JavaFileMerger(String newJavaSource, String existingFilePath, String[] javaDocTags, String fileEncoding)
/*     */   {
/*  77 */     this.newJavaSource = newJavaSource;
/*  78 */     this.existingFilePath = existingFilePath;
/*  79 */     this.javaDocTags = javaDocTags;
/*  80 */     this.fileEncoding = fileEncoding;
/*     */   }
/*     */   
/*     */   public String getMergedSource() throws ShellException
/*     */   {
/*  85 */     ASTParser astParser = ASTParser.newParser(3);
/*  86 */     NewJavaFileVisitor newJavaFileVisitor = visitNewJavaFile(astParser);
/*     */     
/*  88 */     String existingFile = getExistingFileContents();
/*  89 */     IDocument document = new Document(existingFile);
/*     */     
/*     */ 
/*  92 */     ExistingJavaFileVisitor visitor = new ExistingJavaFileVisitor(
/*  93 */       this.javaDocTags);
/*     */     
/*  95 */     astParser.setSource(existingFile.toCharArray());
/*  96 */     CompilationUnit cu = (CompilationUnit)astParser.createAST(null);
/*  97 */     AST ast = cu.getAST();
/*  98 */     cu.recordModifications();
/*  99 */     cu.accept(visitor);
/*     */     
/* 101 */     TypeDeclaration typeDeclaration = visitor.getTypeDeclaration();
/* 102 */     if (typeDeclaration == null) {
/* 103 */       StringBuffer sb = new StringBuffer();
/* 104 */       sb.append("No types defined in the file ");
/* 105 */       sb.append(this.existingFilePath);
/*     */       
/* 107 */       throw new ShellException(sb.toString());
/*     */     }
/*     */     
/*     */ 
/* 111 */     List<Type> newSuperInterfaces = getNewSuperInterfaces(
/* 112 */       typeDeclaration.superInterfaceTypes(), newJavaFileVisitor);
/* 113 */     for (Type newSuperInterface : newSuperInterfaces) {
/* 114 */       typeDeclaration.superInterfaceTypes().add(
/* 115 */         ASTNode.copySubtree(ast, newSuperInterface));
/*     */     }
/*     */     
/*     */ 
/* 119 */     if (newJavaFileVisitor.getSuperclass() != null) {
/* 120 */       typeDeclaration.setSuperclassType((Type)ASTNode.copySubtree(ast, 
/* 121 */         newJavaFileVisitor.getSuperclass()));
/*     */     } else {
/* 123 */       typeDeclaration.setSuperclassType(null);
/*     */     }
/*     */     
/*     */ 
/* 127 */     if (newJavaFileVisitor.isInterface()) {
/* 128 */       typeDeclaration.setInterface(true);
/*     */     } else {
/* 130 */       typeDeclaration.setInterface(false);
/*     */     }
/*     */     
/*     */ 
/* 134 */     List<ImportDeclaration> newImports = getNewImports(cu.imports(), 
/* 135 */       newJavaFileVisitor);
/* 136 */     for (ImportDeclaration newImport : newImports) {
/* 137 */       Name name = ast
/* 138 */         .newName(newImport.getName().getFullyQualifiedName());
/* 139 */       ImportDeclaration newId = ast.newImportDeclaration();
/* 140 */       newId.setName(name);
/* 141 */       cu.imports().add(newId);
/*     */     }
/*     */     
/* 144 */     TextEdit textEdit = cu.rewrite(document, null);
/*     */     try {
/* 146 */       textEdit.apply(document);
/*     */     } catch (BadLocationException localBadLocationException1) {
/* 148 */       throw new ShellException(
/* 149 */         "BadLocationException removing prior fields and methods");
/*     */     }
/*     */     
/*     */ 
/* 153 */     astParser.setSource(document.get().toCharArray());
/* 154 */     CompilationUnit strippedCu = (CompilationUnit)astParser
/* 155 */       .createAST(null);
/*     */     
/*     */ 
/* 158 */     TypeDeclaration topLevelType = null;
/* 159 */     Iterator iter = strippedCu.types().iterator();
/* 160 */     while (iter.hasNext()) {
/* 161 */       TypeDeclaration td = (TypeDeclaration)iter.next();
/* 162 */       if ((td.getParent().equals(strippedCu)) && 
/* 163 */         ((td.getModifiers() & 0x1) > 0)) {
/* 164 */         topLevelType = td;
/* 165 */         break;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 171 */     if (topLevelType == null)
/* 172 */       return "";
/* 173 */     ASTRewrite rewrite = ASTRewrite.create(topLevelType.getRoot().getAST());
/* 174 */     ListRewrite listRewrite = rewrite.getListRewrite(topLevelType, 
/* 175 */       TypeDeclaration.BODY_DECLARATIONS_PROPERTY);
/*     */     
/* 177 */     Iterator<ASTNode> astIter = newJavaFileVisitor.getNewNodes().iterator();
/* 178 */     int i = 0;
/* 179 */     while (astIter.hasNext()) {
/* 180 */       ASTNode node = (ASTNode)astIter.next();
/*     */       
/* 182 */       if (node.getNodeType() == 55) {
/* 183 */         String name = ((TypeDeclaration)node).getName()
/* 184 */           .getFullyQualifiedName();
/* 185 */         if (visitor.containsInnerClass(name)) {
/*     */           continue;
/*     */         }
/* 188 */       } else if ((node instanceof FieldDeclaration)) {
/* 189 */         addExistsAnnotations((BodyDeclaration)node, 
/* 190 */           visitor.getFieldAnnotations((FieldDeclaration)node));
/* 191 */       } else if ((node instanceof MethodDeclaration)) {
/* 192 */         addExistsAnnotations((BodyDeclaration)node, 
/* 193 */           visitor.getMethodAnnotations((MethodDeclaration)node));
/*     */       }
/*     */       
/* 196 */       listRewrite.insertAt(node, i++, null);
/*     */     }
/*     */     
/* 199 */     textEdit = rewrite.rewriteAST(document, JavaCore.getOptions());
/*     */     try {
/* 201 */       textEdit.apply(document);
/*     */     } catch (BadLocationException localBadLocationException2) {
/* 203 */       throw new ShellException(
/* 204 */         "BadLocationException adding new fields and methods");
/*     */     }
/*     */     
/* 207 */     String newSource = document.get();
/* 208 */     return newSource;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private List<Type> getNewSuperInterfaces(List<Type> existingSuperInterfaces, NewJavaFileVisitor newJavaFileVisitor)
/*     */   {
/* 215 */     List<Type> answer = new ArrayList();
/*     */     
/*     */ 
/* 218 */     Iterator localIterator1 = newJavaFileVisitor.getSuperInterfaceTypes().iterator();
/* 217 */     while (localIterator1.hasNext()) {
/* 218 */       Type newSuperInterface = (Type)localIterator1.next();
/* 219 */       boolean found = false;
/* 220 */       for (Type existingSuperInterface : existingSuperInterfaces) {
/* 221 */         found = EclipseDomUtils.typesMatch(newSuperInterface, 
/* 222 */           existingSuperInterface);
/* 223 */         if (found) {
/*     */           break;
/*     */         }
/*     */       }
/*     */       
/* 228 */       if (!found) {
/* 229 */         answer.add(newSuperInterface);
/*     */       }
/*     */     }
/*     */     
/* 233 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */   private List<ImportDeclaration> getNewImports(List<ImportDeclaration> existingImports, NewJavaFileVisitor newJavaFileVisitor)
/*     */   {
/* 239 */     List<ImportDeclaration> answer = new ArrayList();
/*     */     
/* 241 */     for (ImportDeclaration newImport : newJavaFileVisitor.getImports()) {
/* 242 */       boolean found = false;
/* 243 */       for (ImportDeclaration existingImport : existingImports) {
/* 244 */         found = EclipseDomUtils.importDeclarationsMatch(newImport, 
/* 245 */           existingImport);
/* 246 */         if (found) {
/*     */           break;
/*     */         }
/*     */       }
/*     */       
/* 251 */       if (!found) {
/* 252 */         answer.add(newImport);
/*     */       }
/*     */     }
/*     */     
/* 256 */     return answer;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private NewJavaFileVisitor visitNewJavaFile(ASTParser astParser)
/*     */   {
/* 269 */     astParser.setSource(this.newJavaSource.toCharArray());
/* 270 */     CompilationUnit cu = (CompilationUnit)astParser.createAST(null);
/* 271 */     NewJavaFileVisitor newVisitor = new NewJavaFileVisitor();
/* 272 */     cu.accept(newVisitor);
/*     */     
/* 274 */     return newVisitor;
/*     */   }
/*     */   
/*     */   private String getExistingFileContents() throws ShellException {
/* 278 */     File file = new File(this.existingFilePath);
/*     */     
/* 280 */     if (!file.exists())
/*     */     {
/*     */ 
/*     */ 
/* 284 */       StringBuilder sb = new StringBuilder();
/* 285 */       sb.append("The file ");
/* 286 */       sb.append(this.existingFilePath);
/* 287 */       sb.append(" does not exist");
/* 288 */       throw new ShellException(sb.toString());
/*     */     }
/*     */     try
/*     */     {
/* 292 */       StringBuilder sb = new StringBuilder();
/* 293 */       FileInputStream fis = new FileInputStream(file);
/*     */       InputStreamReader isr;
/* 295 */       InputStreamReader isr; if (this.fileEncoding == null) {
/* 296 */         isr = new InputStreamReader(fis);
/*     */       } else {
/* 298 */         isr = new InputStreamReader(fis, this.fileEncoding);
/*     */       }
/* 300 */       BufferedReader br = new BufferedReader(isr);
/* 301 */       char[] buffer = new char['Ѐ'];
/* 302 */       int returnedBytes = br.read(buffer);
/* 303 */       while (returnedBytes != -1) {
/* 304 */         sb.append(buffer, 0, returnedBytes);
/* 305 */         returnedBytes = br.read(buffer);
/*     */       }
/*     */       
/* 308 */       br.close();
/* 309 */       return sb.toString();
/*     */     } catch (IOException e) {
/* 311 */       StringBuilder sb = new StringBuilder();
/* 312 */       sb.append("IOException reading the file ");
/* 313 */       sb.append(this.existingFilePath);
/* 314 */       throw new ShellException(sb.toString(), e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void addExistsAnnotations(BodyDeclaration node, List<Annotation> oldAnnotations)
/*     */   {
/* 321 */     Set<String> newAnnotationTypes = new HashSet();
/* 322 */     int lastAnnotationIndex = 0;
/* 323 */     int idx = 0;
/* 324 */     for (Object modifier : node.modifiers()) {
/* 325 */       if ((modifier instanceof Annotation)) {
/* 326 */         Annotation newAnnotation = (Annotation)modifier;
/* 327 */         newAnnotationTypes.add(newAnnotation.getTypeName()
/* 328 */           .getFullyQualifiedName());
/* 329 */         lastAnnotationIndex = idx;
/*     */       }
/* 331 */       idx++;
/*     */     }
/*     */     
/* 334 */     if (oldAnnotations != null) {
/* 335 */       for (Annotation oldAnnotation : oldAnnotations) {
/* 336 */         if (!newAnnotationTypes.contains(oldAnnotation.getTypeName()
/* 337 */           .getFullyQualifiedName()))
/*     */         {
/*     */ 
/* 340 */           AST nodeAst = node.getAST();
/* 341 */           node.modifiers().add(lastAnnotationIndex++, 
/* 342 */             ASTNode.copySubtree(nodeAst, oldAnnotation));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\eclipse\core\merge\JavaFileMerger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */