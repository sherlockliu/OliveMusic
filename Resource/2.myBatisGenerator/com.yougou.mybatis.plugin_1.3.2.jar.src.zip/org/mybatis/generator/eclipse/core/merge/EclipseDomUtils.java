/*     */ package org.mybatis.generator.eclipse.core.merge;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.dom.ArrayType;
/*     */ import org.eclipse.jdt.core.dom.ImportDeclaration;
/*     */ import org.eclipse.jdt.core.dom.MethodDeclaration;
/*     */ import org.eclipse.jdt.core.dom.Name;
/*     */ import org.eclipse.jdt.core.dom.ParameterizedType;
/*     */ import org.eclipse.jdt.core.dom.PrimitiveType;
/*     */ import org.eclipse.jdt.core.dom.PrimitiveType.Code;
/*     */ import org.eclipse.jdt.core.dom.QualifiedType;
/*     */ import org.eclipse.jdt.core.dom.SimpleName;
/*     */ import org.eclipse.jdt.core.dom.SimpleType;
/*     */ import org.eclipse.jdt.core.dom.SingleVariableDeclaration;
/*     */ import org.eclipse.jdt.core.dom.Type;
/*     */ import org.eclipse.jdt.core.dom.UnionType;
/*     */ import org.eclipse.jdt.core.dom.WildcardType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EclipseDomUtils
/*     */ {
/*     */   public static boolean importDeclarationsMatch(ImportDeclaration import1, ImportDeclaration import2)
/*     */   {
/*  42 */     if ((import1 == null) || (import2 == null)) {
/*  43 */       return (import1 == null) && (import2 == null);
/*     */     }
/*     */     
/*  46 */     boolean rc = import1.isStatic() == import2.isStatic();
/*     */     
/*  48 */     if (rc) {
/*  49 */       if ((import1.isOnDemand()) && (import2.isOnDemand())) {
/*  50 */         rc = 
/*  51 */           import1.getName().getFullyQualifiedName().equals(import2.getName().getFullyQualifiedName());
/*  52 */       } else if ((!import1.isOnDemand()) && (!import2.isOnDemand())) {
/*  53 */         rc = 
/*  54 */           import1.getName().getFullyQualifiedName().equals(import2.getName().getFullyQualifiedName());
/*  55 */       } else if (import1.isOnDemand()) {
/*  56 */         rc = checkOndemandImport(import1, import2);
/*     */       }
/*     */       else {
/*  59 */         rc = checkOndemandImport(import2, import1);
/*     */       }
/*     */     }
/*     */     
/*  63 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean checkOndemandImport(ImportDeclaration onDemandImport, ImportDeclaration singleImport)
/*     */   {
/*  69 */     String fullName = singleImport.getName().getFullyQualifiedName();
/*  70 */     int index = fullName.lastIndexOf('.');
/*  71 */     if (index == -1)
/*     */     {
/*  73 */       return onDemandImport.getName().getFullyQualifiedName().length() == 0;
/*     */     }
/*     */     
/*  76 */     return 
/*  77 */       onDemandImport.getName().getFullyQualifiedName().equals(fullName.substring(0, index));
/*     */   }
/*     */   
/*     */   public static boolean typesMatch(Type type1, Type type2)
/*     */   {
/*  82 */     if ((type1 == null) || (type2 == null)) {
/*  83 */       return (type1 == null) && (type2 == null);
/*     */     }
/*     */     
/*  86 */     boolean rc = false;
/*     */     
/*  88 */     if ((type1.isSimpleType()) && (type2.isSimpleType()))
/*  89 */       return simpleTypesMatch((SimpleType)type1, (SimpleType)type2);
/*  90 */     if ((type1.isParameterizedType()) && (type2.isParameterizedType()))
/*  91 */       return parameterizedTypesMatch((ParameterizedType)type1, 
/*  92 */         (ParameterizedType)type2);
/*  93 */     if ((type1.isPrimitiveType()) && (type2.isPrimitiveType()))
/*  94 */       return primitiveTypesMatch((PrimitiveType)type1, 
/*  95 */         (PrimitiveType)type2);
/*  96 */     if ((type1.isArrayType()) && (type2.isArrayType()))
/*  97 */       return arrayTypesMatch((ArrayType)type1, (ArrayType)type2);
/*  98 */     if ((type1.isUnionType()) && (type2.isUnionType()))
/*  99 */       return unionTypesMatch((UnionType)type1, (UnionType)type2);
/* 100 */     if ((type1.isQualifiedType()) && (type2.isQualifiedType()))
/* 101 */       return qualifiedTypesMatch((QualifiedType)type1, 
/* 102 */         (QualifiedType)type2);
/* 103 */     if ((type1.isWildcardType()) && (type2.isWildcardType())) {
/* 104 */       return wildcardTypesMatch((WildcardType)type1, 
/* 105 */         (WildcardType)type2);
/*     */     }
/*     */     
/* 108 */     return rc;
/*     */   }
/*     */   
/*     */   public static boolean wildcardTypesMatch(WildcardType type1, WildcardType type2)
/*     */   {
/* 113 */     boolean rc = type1.isUpperBound() == type2.isUpperBound();
/*     */     
/* 115 */     if (rc) {
/* 116 */       rc = typesMatch(type1.getBound(), type2.getBound());
/*     */     }
/*     */     
/* 119 */     return rc;
/*     */   }
/*     */   
/*     */   public static boolean simpleTypesMatch(SimpleType type1, SimpleType type2) {
/* 123 */     return 
/* 124 */       type1.getName().getFullyQualifiedName().equals(type2.getName().getFullyQualifiedName());
/*     */   }
/*     */   
/*     */   public static boolean primitiveTypesMatch(PrimitiveType type1, PrimitiveType type2)
/*     */   {
/* 129 */     return 
/* 130 */       type1.getPrimitiveTypeCode().toString().equals(type2.getPrimitiveTypeCode().toString());
/*     */   }
/*     */   
/*     */   public static boolean arrayTypesMatch(ArrayType type1, ArrayType type2) {
/* 134 */     boolean rc = type1.getDimensions() == type2.getDimensions();
/*     */     
/* 136 */     if (rc) {
/* 137 */       rc = typesMatch(type1.getComponentType(), type2.getComponentType());
/*     */     }
/*     */     
/* 140 */     return rc;
/*     */   }
/*     */   
/*     */   public static boolean unionTypesMatch(UnionType type1, UnionType type2)
/*     */   {
/* 145 */     boolean rc = type1.types().size() == type2.types().size();
/*     */     
/* 147 */     if (rc) {
/* 148 */       for (int i = 0; i < type1.types().size(); i++) {
/* 149 */         rc = typesMatch((Type)type1.types().get(i), 
/* 150 */           (Type)type2.types().get(i));
/* 151 */         if (!rc) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 157 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean qualifiedTypesMatch(QualifiedType type1, QualifiedType type2)
/*     */   {
/* 163 */     boolean rc = type1.getName().getFullyQualifiedName()
/* 164 */       .equals(type2.getName().getFullyQualifiedName());
/*     */     
/* 166 */     if (rc) {
/* 167 */       rc = typesMatch(type1.getQualifier(), type2.getQualifier());
/*     */     }
/*     */     
/* 170 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */   public static boolean parameterizedTypesMatch(ParameterizedType type1, ParameterizedType type2)
/*     */   {
/* 176 */     boolean rc = typesMatch(type1.getType(), type2.getType());
/*     */     
/* 178 */     if (rc)
/*     */     {
/* 180 */       rc = type1.typeArguments().size() == type2.typeArguments().size();
/*     */       
/*     */ 
/* 183 */       if (rc) {
/* 184 */         for (int i = 0; i < type1.typeArguments().size(); i++) {
/* 185 */           rc = typesMatch((Type)type1.typeArguments().get(i), 
/* 186 */             (Type)type2.typeArguments().get(i));
/* 187 */           if (!rc) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 194 */     return rc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getTypeName(Type type)
/*     */   {
/* 205 */     if (type == null) {
/* 206 */       return "";
/*     */     }
/*     */     
/* 209 */     if (type.isSimpleType())
/* 210 */       return getSimpleTypeName((SimpleType)type);
/* 211 */     if (type.isParameterizedType())
/* 212 */       return getParameterizedTypeName((ParameterizedType)type);
/* 213 */     if (type.isPrimitiveType())
/* 214 */       return getPrimitiveTypeName((PrimitiveType)type);
/* 215 */     if (type.isArrayType())
/* 216 */       return getArrayTypeName((ArrayType)type);
/* 217 */     if (type.isUnionType())
/* 218 */       return getUnionTypeName((UnionType)type);
/* 219 */     if (type.isQualifiedType())
/* 220 */       return getQualifiedTypeName((QualifiedType)type);
/* 221 */     if (type.isWildcardType()) {
/* 222 */       return getWildcardTypeName((WildcardType)type);
/*     */     }
/* 224 */     return "";
/*     */   }
/*     */   
/*     */   public static String getWildcardTypeName(WildcardType type)
/*     */   {
/* 229 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 231 */     sb.append('?');
/* 232 */     if (type.getBound() != null) {
/* 233 */       if (type.isUpperBound()) {
/* 234 */         sb.append(" extends ");
/*     */       } else {
/* 236 */         sb.append(" super ");
/*     */       }
/* 238 */       sb.append(getTypeName(type.getBound()));
/*     */     }
/*     */     
/* 241 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String getQualifiedTypeName(QualifiedType type) {
/* 245 */     StringBuilder sb = new StringBuilder();
/* 246 */     sb.append(getTypeName(type.getQualifier()));
/* 247 */     sb.append('.');
/* 248 */     sb.append(type.getName().getFullyQualifiedName());
/*     */     
/* 250 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String getUnionTypeName(UnionType type)
/*     */   {
/* 255 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 257 */     boolean or = false;
/* 258 */     for (Type type2 : type.types()) {
/* 259 */       if (or) {
/* 260 */         sb.append('|');
/*     */       } else {
/* 262 */         or = true;
/*     */       }
/*     */       
/* 265 */       sb.append(getTypeName(type2));
/*     */     }
/*     */     
/* 268 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String getArrayTypeName(ArrayType type) {
/* 272 */     StringBuilder sb = new StringBuilder();
/* 273 */     sb.append(getTypeName(type.getComponentType()));
/* 274 */     for (int i = 0; i < type.getDimensions(); i++) {
/* 275 */       sb.append("[]");
/*     */     }
/* 277 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String getPrimitiveTypeName(PrimitiveType type) {
/* 281 */     return type.getPrimitiveTypeCode().toString();
/*     */   }
/*     */   
/*     */   public static String getParameterizedTypeName(ParameterizedType type)
/*     */   {
/* 286 */     StringBuilder sb = new StringBuilder();
/* 287 */     sb.append(getTypeName(type.getType()));
/* 288 */     sb.append('<');
/*     */     
/* 290 */     boolean comma = false;
/* 291 */     for (Type typeArgument : type.typeArguments()) {
/* 292 */       if (comma) {
/* 293 */         sb.append(',');
/*     */       } else {
/* 295 */         comma = true;
/*     */       }
/*     */       
/* 298 */       sb.append(getTypeName(typeArgument));
/*     */     }
/* 300 */     sb.append('>');
/*     */     
/* 302 */     return sb.toString();
/*     */   }
/*     */   
/*     */   public static String getSimpleTypeName(SimpleType type) {
/* 306 */     return type.getName().getFullyQualifiedName();
/*     */   }
/*     */   
/*     */   public static String getMethodSignature(MethodDeclaration node)
/*     */   {
/* 311 */     StringBuilder sb = new StringBuilder();
/* 312 */     sb.append(node.getName().getIdentifier());
/* 313 */     sb.append('(');
/* 314 */     boolean comma = false;
/*     */     
/* 316 */     Iterator localIterator = node.parameters().iterator();
/* 315 */     while (localIterator.hasNext()) {
/* 316 */       SingleVariableDeclaration parameter = (SingleVariableDeclaration)localIterator.next();
/* 317 */       if (comma) {
/* 318 */         sb.append(',');
/*     */       } else {
/* 320 */         comma = true;
/*     */       }
/*     */       
/* 323 */       sb.append(getTypeName(parameter.getType()));
/*     */     }
/* 325 */     sb.append(')');
/*     */     
/* 327 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\eclipse\core\merge\EclipseDomUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */