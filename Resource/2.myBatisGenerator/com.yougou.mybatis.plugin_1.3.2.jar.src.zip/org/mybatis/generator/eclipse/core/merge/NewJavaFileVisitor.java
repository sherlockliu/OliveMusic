/*     */ package org.mybatis.generator.eclipse.core.merge;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.eclipse.jdt.core.dom.ASTNode;
/*     */ import org.eclipse.jdt.core.dom.ASTVisitor;
/*     */ import org.eclipse.jdt.core.dom.CompilationUnit;
/*     */ import org.eclipse.jdt.core.dom.EnumDeclaration;
/*     */ import org.eclipse.jdt.core.dom.FieldDeclaration;
/*     */ import org.eclipse.jdt.core.dom.ImportDeclaration;
/*     */ import org.eclipse.jdt.core.dom.MethodDeclaration;
/*     */ import org.eclipse.jdt.core.dom.Type;
/*     */ import org.eclipse.jdt.core.dom.TypeDeclaration;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NewJavaFileVisitor
/*     */   extends ASTVisitor
/*     */ {
/*     */   private List<ASTNode> newNodes;
/*     */   private List<ImportDeclaration> imports;
/*     */   private Type superclass;
/*     */   private boolean isInterface;
/*     */   private List<Type> superInterfaceTypes;
/*     */   
/*     */   public NewJavaFileVisitor()
/*     */   {
/*  48 */     this.newNodes = new ArrayList();
/*     */   }
/*     */   
/*     */   public boolean visit(FieldDeclaration node) {
/*  52 */     this.newNodes.add(node);
/*     */     
/*  54 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(EnumDeclaration node) {
/*  58 */     this.newNodes.add(node);
/*     */     
/*  60 */     return false;
/*     */   }
/*     */   
/*     */   public boolean visit(MethodDeclaration node) {
/*  64 */     this.newNodes.add(node);
/*     */     
/*  66 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean visit(TypeDeclaration node)
/*     */   {
/*  72 */     if (node.getParent().getNodeType() == 15) {
/*  73 */       this.isInterface = node.isInterface();
/*     */       
/*  75 */       this.superclass = node.getSuperclassType();
/*     */       
/*  77 */       this.superInterfaceTypes = node.superInterfaceTypes();
/*     */       
/*  79 */       return true;
/*     */     }
/*  81 */     this.newNodes.add(node);
/*  82 */     return false;
/*     */   }
/*     */   
/*     */   public List<ASTNode> getNewNodes()
/*     */   {
/*  87 */     return this.newNodes;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean visit(CompilationUnit node)
/*     */   {
/*  93 */     this.imports = node.imports();
/*     */     
/*  95 */     return true;
/*     */   }
/*     */   
/*     */   public List<ImportDeclaration> getImports() {
/*  99 */     return this.imports;
/*     */   }
/*     */   
/*     */   public Type getSuperclass() {
/* 103 */     return this.superclass;
/*     */   }
/*     */   
/*     */   public boolean isInterface() {
/* 107 */     return this.isInterface;
/*     */   }
/*     */   
/*     */   public List<Type> getSuperInterfaceTypes() {
/* 111 */     return this.superInterfaceTypes;
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\eclipse\core\merge\NewJavaFileVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */