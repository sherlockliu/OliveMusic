/*     */ package org.mybatis.generator.eclipse.core.callback;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.eclipse.core.resources.IFolder;
/*     */ import org.eclipse.core.resources.IProject;
/*     */ import org.eclipse.core.resources.IResource;
/*     */ import org.eclipse.core.resources.IWorkspace;
/*     */ import org.eclipse.core.resources.IWorkspaceRoot;
/*     */ import org.eclipse.core.resources.ResourcesPlugin;
/*     */ import org.eclipse.core.runtime.CoreException;
/*     */ import org.eclipse.core.runtime.IPath;
/*     */ import org.eclipse.core.runtime.IStatus;
/*     */ import org.eclipse.core.runtime.Path;
/*     */ import org.eclipse.jdt.core.IJavaProject;
/*     */ import org.eclipse.jdt.core.IPackageFragment;
/*     */ import org.eclipse.jdt.core.IPackageFragmentRoot;
/*     */ import org.eclipse.jdt.core.JavaCore;
/*     */ import org.mybatis.generator.api.ShellCallback;
/*     */ import org.mybatis.generator.eclipse.core.merge.JavaFileMerger;
/*     */ import org.mybatis.generator.exception.ShellException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EclipseShellCallback
/*     */   implements ShellCallback
/*     */ {
/*     */   private Map<String, IJavaProject> projects;
/*     */   private Map<String, IFolder> folders;
/*     */   private Map<String, IPackageFragmentRoot> sourceFolders;
/*     */   
/*     */   public EclipseShellCallback()
/*     */   {
/*  52 */     this.projects = new HashMap();
/*  53 */     this.folders = new HashMap();
/*  54 */     this.sourceFolders = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public File getDirectory(String targetProject, String targetPackage)
/*     */     throws ShellException
/*     */   {
/*  62 */     if ((targetProject.startsWith("/")) || (targetProject.startsWith("\\"))) {
/*  63 */       StringBuffer sb = new StringBuffer();
/*  64 */       sb.append("targetProject ");
/*  65 */       sb.append(targetProject);
/*  66 */       sb.append(" is invalid - it cannot start with / or \\");
/*     */       
/*  68 */       throw new ShellException(sb.toString());
/*     */     }
/*     */     
/*  71 */     IFolder folder = getFolder(targetProject, targetPackage);
/*     */     
/*  73 */     return folder.getRawLocation().toFile();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void refreshProject(String project)
/*     */   {
/*     */     try
/*     */     {
/*  82 */       IPackageFragmentRoot root = getSourceFolder(project);
/*  83 */       root.getCorrespondingResource().refreshLocal(
/*  84 */         2, null);
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */ 
/*     */   private IJavaProject getJavaProject(String javaProjectName)
/*     */     throws ShellException
/*     */   {
/*  93 */     IJavaProject javaProject = (IJavaProject)this.projects.get(javaProjectName);
/*  94 */     if (javaProject == null) {
/*  95 */       IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
/*  96 */       IProject project = root.getProject(javaProjectName);
/*     */       
/*  98 */       if (project.exists())
/*     */       {
/*     */         try {
/* 101 */           isJavaProject = project.hasNature("org.eclipse.jdt.core.javanature");
/*     */         } catch (CoreException e) { boolean isJavaProject;
/* 103 */           throw new ShellException(e.getStatus().getMessage(), e); }
/*     */         boolean isJavaProject;
/* 105 */         if (isJavaProject) {
/* 106 */           javaProject = JavaCore.create(project);
/*     */         } else {
/* 108 */           StringBuffer sb = new StringBuffer();
/* 109 */           sb.append("Project ");
/* 110 */           sb.append(javaProjectName);
/* 111 */           sb.append(" is not a Java project");
/*     */           
/* 113 */           throw new ShellException(sb.toString());
/*     */         }
/*     */       } else {
/* 116 */         StringBuffer sb = new StringBuffer();
/* 117 */         sb.append("Project ");
/* 118 */         sb.append(javaProjectName);
/* 119 */         sb.append(" does not exist");
/*     */         
/* 121 */         throw new ShellException(sb.toString());
/*     */       }
/*     */       
/* 124 */       this.projects.put(javaProjectName, javaProject);
/*     */     }
/*     */     
/* 127 */     return javaProject;
/*     */   }
/*     */   
/*     */   private IFolder getFolder(String targetProject, String targetPackage) throws ShellException
/*     */   {
/* 132 */     String key = targetProject + targetPackage;
/* 133 */     IFolder folder = (IFolder)this.folders.get(key);
/* 134 */     if (folder == null) {
/* 135 */       IPackageFragmentRoot root = getSourceFolder(targetProject);
/* 136 */       IPackageFragment packageFragment = getPackage(root, targetPackage);
/*     */       try
/*     */       {
/* 139 */         folder = (IFolder)packageFragment.getCorrespondingResource();
/*     */         
/* 141 */         this.folders.put(key, folder);
/*     */       } catch (CoreException e) {
/* 143 */         throw new ShellException(e.getStatus().getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/* 147 */     return folder;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private IPackageFragmentRoot getFirstSourceFolder(IJavaProject javaProject)
/*     */     throws ShellException
/*     */   {
/*     */     try
/*     */     {
/* 163 */       roots = javaProject.getPackageFragmentRoots();
/*     */     } catch (CoreException e) { IPackageFragmentRoot[] roots;
/* 165 */       throw new ShellException(e.getStatus().getMessage(), e);
/*     */     }
/*     */     IPackageFragmentRoot[] roots;
/* 168 */     IPackageFragmentRoot srcFolder = null;
/* 169 */     for (int i = 0; i < roots.length; i++) {
/* 170 */       if ((!roots[i].isArchive()) && (!roots[i].isReadOnly()) && 
/* 171 */         (!roots[i].isExternal()))
/*     */       {
/*     */ 
/* 174 */         srcFolder = roots[i];
/* 175 */         break;
/*     */       }
/*     */     }
/*     */     
/* 179 */     if (srcFolder == null) {
/* 180 */       StringBuffer sb = new StringBuffer();
/* 181 */       sb.append("Cannot find source folder for project ");
/* 182 */       sb.append(javaProject.getElementName());
/*     */       
/* 184 */       throw new ShellException(sb.toString());
/*     */     }
/*     */     
/* 187 */     return srcFolder;
/*     */   }
/*     */   
/*     */   private IPackageFragmentRoot getSpecificSourceFolder(IJavaProject javaProject, String targetProject)
/*     */     throws ShellException
/*     */   {
/*     */     try
/*     */     {
/* 195 */       Path path = new Path("/" + targetProject);
/* 196 */       IPackageFragmentRoot pfr = javaProject
/* 197 */         .findPackageFragmentRoot(path);
/* 198 */       if (pfr == null) {
/* 199 */         StringBuffer sb = new StringBuffer();
/* 200 */         sb.append("Cannot find source folder ");
/* 201 */         sb.append(targetProject);
/*     */         
/* 203 */         throw new ShellException(sb.toString());
/*     */       }
/*     */       
/* 206 */       return pfr;
/*     */     } catch (CoreException e) {
/* 208 */       throw new ShellException(e.getStatus().getMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   private IPackageFragment getPackage(IPackageFragmentRoot srcFolder, String packageName)
/*     */     throws ShellException
/*     */   {
/* 215 */     IPackageFragment fragment = srcFolder.getPackageFragment(packageName);
/*     */     try
/*     */     {
/* 218 */       if (!fragment.exists()) {
/* 219 */         fragment = srcFolder.createPackageFragment(packageName, true, 
/* 220 */           null);
/*     */       }
/*     */       
/* 223 */       fragment.getCorrespondingResource().refreshLocal(
/* 224 */         1, null);
/*     */     } catch (CoreException e) {
/* 226 */       throw new ShellException(e.getStatus().getMessage(), e);
/*     */     }
/*     */     
/* 229 */     return fragment;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMergeSupported()
/*     */   {
/* 239 */     return false;
/*     */   }
/*     */   
/*     */   private IPackageFragmentRoot getSourceFolder(String targetProject) throws ShellException
/*     */   {
/* 244 */     IPackageFragmentRoot answer = (IPackageFragmentRoot)this.sourceFolders.get(targetProject);
/* 245 */     if (answer == null)
/*     */     {
/*     */ 
/* 248 */       int index = targetProject.indexOf('/');
/* 249 */       if (index == -1) {
/* 250 */         index = targetProject.indexOf('\\');
/*     */       }
/*     */       
/* 253 */       if (index == -1)
/*     */       {
/* 255 */         IJavaProject javaProject = getJavaProject(targetProject);
/* 256 */         answer = getFirstSourceFolder(javaProject);
/*     */       } else {
/* 258 */         IJavaProject javaProject = getJavaProject(targetProject
/* 259 */           .substring(0, index));
/* 260 */         answer = getSpecificSourceFolder(javaProject, targetProject);
/*     */       }
/*     */       
/* 263 */       this.sourceFolders.put(targetProject, answer);
/*     */     }
/*     */     
/* 266 */     return answer;
/*     */   }
/*     */   
/*     */   public boolean isOverwriteEnabled() {
/* 270 */     return true;
/*     */   }
/*     */   
/*     */   public String mergeJavaFile(String newFileSource, String existingFileFullPath, String[] javadocTags, String fileEncoding)
/*     */     throws ShellException
/*     */   {
/* 276 */     JavaFileMerger merger = new JavaFileMerger(newFileSource, existingFileFullPath, javadocTags, fileEncoding);
/* 277 */     return merger.getMergedSource();
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\eclipse\core\callback\EclipseShellCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */