/*     */ package org.mybatis.generator.eclipse.core.merge;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.eclipse.jdt.core.dom.ASTNode;
/*     */ import org.eclipse.jdt.core.dom.ASTVisitor;
/*     */ import org.eclipse.jdt.core.dom.Annotation;
/*     */ import org.eclipse.jdt.core.dom.BodyDeclaration;
/*     */ import org.eclipse.jdt.core.dom.EnumDeclaration;
/*     */ import org.eclipse.jdt.core.dom.FieldDeclaration;
/*     */ import org.eclipse.jdt.core.dom.Javadoc;
/*     */ import org.eclipse.jdt.core.dom.MethodDeclaration;
/*     */ import org.eclipse.jdt.core.dom.SimpleName;
/*     */ import org.eclipse.jdt.core.dom.TagElement;
/*     */ import org.eclipse.jdt.core.dom.TypeDeclaration;
/*     */ import org.eclipse.jdt.core.dom.VariableDeclarationFragment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExistingJavaFileVisitor
/*     */   extends ASTVisitor
/*     */ {
/*     */   private TypeDeclaration typeDeclaration;
/*     */   private String[] javadocTags;
/*     */   private List<String> generatedInnerClassesToKeep;
/*     */   private Map<String, List<Annotation>> fieldAnnotations;
/*     */   private Map<String, List<Annotation>> methodAnnotations;
/*     */   
/*     */   public ExistingJavaFileVisitor(String[] javadocTags)
/*     */   {
/*  52 */     this.javadocTags = javadocTags;
/*  53 */     this.generatedInnerClassesToKeep = new ArrayList();
/*  54 */     this.fieldAnnotations = new HashMap();
/*  55 */     this.methodAnnotations = new HashMap();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean visit(FieldDeclaration node)
/*     */   {
/*  63 */     if (isGenerated(node)) {
/*  64 */       List<Annotation> annotations = retrieveAnnotations(node);
/*  65 */       if (!annotations.isEmpty()) {
/*  66 */         VariableDeclarationFragment variable = 
/*  67 */           (VariableDeclarationFragment)node.fragments().get(0);
/*  68 */         this.fieldAnnotations.put(variable.getName().getIdentifier(), 
/*  69 */           annotations);
/*     */       }
/*  71 */       node.delete();
/*     */     }
/*     */     
/*  74 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean visit(MethodDeclaration node)
/*     */   {
/*  82 */     if (isGenerated(node)) {
/*  83 */       List<Annotation> annotations = retrieveAnnotations(node);
/*  84 */       if (!annotations.isEmpty()) {
/*  85 */         String methodSignature = 
/*  86 */           EclipseDomUtils.getMethodSignature(node);
/*  87 */         this.methodAnnotations.put(methodSignature, annotations);
/*     */       }
/*  89 */       node.delete();
/*     */     }
/*     */     
/*  92 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean visit(TypeDeclaration node)
/*     */   {
/* 101 */     if (node.getParent().getNodeType() == 15) {
/* 102 */       this.typeDeclaration = node;
/* 103 */       return true;
/*     */     }
/*     */     
/* 106 */     if (isGenerated(node)) {
/* 107 */       node.delete();
/*     */     }
/*     */     
/* 110 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean visit(EnumDeclaration node)
/*     */   {
/* 116 */     if (isGenerated(node)) {
/* 117 */       node.delete();
/*     */     }
/*     */     
/* 120 */     return false;
/*     */   }
/*     */   
/*     */   public TypeDeclaration getTypeDeclaration() {
/* 124 */     return this.typeDeclaration;
/*     */   }
/*     */   
/*     */   private boolean isGenerated(BodyDeclaration node)
/*     */   {
/* 129 */     boolean rc = false;
/* 130 */     Javadoc jd = node.getJavadoc();
/* 131 */     if (jd != null) {
/* 132 */       List<TagElement> tags = jd.tags();
/* 133 */       for (TagElement tag : tags) {
/* 134 */         String tagName = tag.getTagName();
/* 135 */         if (tagName != null)
/*     */         {
/*     */           String[] arrayOfString;
/* 138 */           int j = (arrayOfString = this.javadocTags).length; for (int i = 0; i < j; i++) { String javadocTag = arrayOfString[i];
/* 139 */             if (tagName.equals(javadocTag)) {
/* 140 */               String string = tag.toString();
/* 141 */               if (string.contains("do_not_delete_during_merge")) {
/* 142 */                 if (node.getNodeType() != 55) break;
/* 143 */                 String name = ((TypeDeclaration)node)
/* 144 */                   .getName().getFullyQualifiedName();
/* 145 */                 this.generatedInnerClassesToKeep.add(name); break;
/*     */               }
/*     */               
/* 148 */               rc = true;
/*     */               
/* 150 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 156 */     return rc;
/*     */   }
/*     */   
/*     */   public boolean containsInnerClass(String name) {
/* 160 */     return this.generatedInnerClassesToKeep.contains(name);
/*     */   }
/*     */   
/*     */   private List<Annotation> retrieveAnnotations(BodyDeclaration node) {
/* 164 */     List<?> modifiers = node.modifiers();
/* 165 */     List<Annotation> annotations = new ArrayList();
/* 166 */     for (Object modifier : modifiers) {
/* 167 */       if ((modifier instanceof Annotation)) {
/* 168 */         annotations.add((Annotation)modifier);
/*     */       }
/*     */     }
/* 171 */     return annotations;
/*     */   }
/*     */   
/*     */   public List<Annotation> getFieldAnnotations(FieldDeclaration fieldDeclaration)
/*     */   {
/* 176 */     VariableDeclarationFragment variable = 
/* 177 */       (VariableDeclarationFragment)fieldDeclaration.fragments().get(0);
/* 178 */     return (List)this.fieldAnnotations.get(variable.getName().getIdentifier());
/*     */   }
/*     */   
/*     */   public List<Annotation> getMethodAnnotations(MethodDeclaration methodDeclaration)
/*     */   {
/* 183 */     return (List)this.methodAnnotations.get(EclipseDomUtils.getMethodSignature(methodDeclaration));
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\eclipse\core\merge\ExistingJavaFileVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */