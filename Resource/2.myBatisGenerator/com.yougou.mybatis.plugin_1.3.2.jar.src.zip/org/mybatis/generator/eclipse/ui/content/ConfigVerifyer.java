/*     */ package org.mybatis.generator.eclipse.ui.content;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.StringReader;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConfigVerifyer
/*     */   extends DefaultHandler
/*     */ {
/*     */   private InputStream inputStream;
/*     */   private boolean isConfig;
/*     */   private boolean rootElementRead;
/*     */   
/*     */   public ConfigVerifyer(InputStream inputStream)
/*     */   {
/*  54 */     this.inputStream = inputStream;
/*  55 */     this.isConfig = false;
/*     */   }
/*     */   
/*     */   public boolean isConfigFile() {
/*     */     try {
/*  60 */       SAXParserFactory factory = SAXParserFactory.newInstance();
/*  61 */       factory.setValidating(false);
/*  62 */       SAXParser parser = factory.newSAXParser();
/*     */       
/*  64 */       parser.parse(this.inputStream, this);
/*     */     }
/*     */     catch (Exception localException) {}
/*     */     
/*     */ 
/*     */ 
/*  70 */     return this.isConfig;
/*     */   }
/*     */   
/*     */   public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
/*  74 */     if (this.rootElementRead) {
/*  75 */       throw new SAXException("Root element was not correct");
/*     */     }
/*     */     
/*  78 */     this.rootElementRead = true;
/*     */     
/*  80 */     if ("ibatorConfiguration".equals(qName)) {
/*  81 */       this.isConfig = true;
/*  82 */       throw new SAXException("Ignore the rest of the file"); }
/*  83 */     if ("generatorConfiguration".equals(qName)) {
/*  84 */       this.isConfig = true;
/*  85 */       throw new SAXException("Ignore the rest of the file");
/*     */     }
/*     */   }
/*     */   
/*     */   public InputSource resolveEntity(String publicId, String systemId) throws SAXException {
/*  90 */     boolean hasCorrectDocType = false;
/*     */     
/*  92 */     if ("-//Apache Software Foundation//DTD Apache iBATIS Ibator Configuration 1.0//EN".equals(publicId)) {
/*  93 */       hasCorrectDocType = true;
/*  94 */     } else if ("-//mybatis.org//DTD MyBatis Generator Configuration 1.0//EN".equals(publicId)) {
/*  95 */       hasCorrectDocType = true;
/*     */     }
/*     */     
/*  98 */     if (!hasCorrectDocType) {
/*  99 */       throw new SAXException("Not a configuration file");
/*     */     }
/*     */     
/*     */ 
/* 103 */     StringReader nullStringReader = new StringReader("");
/* 104 */     return new InputSource(nullStringReader);
/*     */   }
/*     */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\eclipse\ui\content\ConfigVerifyer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */