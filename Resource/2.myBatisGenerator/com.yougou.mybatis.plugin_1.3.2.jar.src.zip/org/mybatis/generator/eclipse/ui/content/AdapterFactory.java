/*    */ package org.mybatis.generator.eclipse.ui.content;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.eclipse.core.resources.IFile;
/*    */ import org.eclipse.core.runtime.CoreException;
/*    */ import org.eclipse.core.runtime.IAdapterFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AdapterFactory
/*    */   implements IAdapterFactory
/*    */ {
/*    */   public Object getAdapter(Object adaptableObject, Class adapterType)
/*    */   {
/* 40 */     if (((adaptableObject instanceof IFile)) && 
/* 41 */       (adapterType == ConfigurationFileAdapter.class) && 
/* 42 */       (isConfigurationFile((IFile)adaptableObject))) {
/* 43 */       return new ConfigurationFileAdapter(
/* 44 */         (IFile)adaptableObject);
/*    */     }
/*    */     
/*    */ 
/* 48 */     return null;
/*    */   }
/*    */   
/*    */   public Class[] getAdapterList()
/*    */   {
/* 53 */     return new Class[] { ConfigurationFileAdapter.class };
/*    */   }
/*    */   
/*    */   private boolean isConfigurationFile(IFile file) {
/* 57 */     String fileName = file.getName();
/* 58 */     if (fileName.length() > 4) {
/* 59 */       String extension = fileName.substring(fileName.length() - 4);
/* 60 */       if (!extension.equalsIgnoreCase(".xml")) {
/* 61 */         return false;
/*    */       }
/*    */     } else {
/* 64 */       return false;
/*    */     }
/*    */     
/*    */     try
/*    */     {
/* 69 */       is = file.getContents();
/*    */     } catch (CoreException localCoreException) { InputStream is;
/* 71 */       return false;
/*    */     }
/*    */     InputStream is;
/* 74 */     ConfigVerifyer verifyer = new ConfigVerifyer(is);
/*    */     
/* 76 */     boolean rc = verifyer.isConfigFile();
/*    */     try
/*    */     {
/* 79 */       is.close();
/*    */     }
/*    */     catch (IOException localIOException) {}
/*    */     
/*    */ 
/*    */ 
/* 85 */     return rc;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\eclipse\ui\content\AdapterFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */