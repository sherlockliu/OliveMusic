/*    */ package org.mybatis.generator.eclipse.ui.content;
/*    */ 
/*    */ import org.eclipse.core.resources.IFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigurationFileAdapter
/*    */ {
/*    */   private IFile baseFile;
/*    */   
/*    */   public ConfigurationFileAdapter(IFile baseFile)
/*    */   {
/* 31 */     this.baseFile = baseFile;
/*    */   }
/*    */   
/*    */   public IFile getBaseFile() {
/* 35 */     return this.baseFile;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\org\mybatis\generator\eclipse\ui\content\ConfigurationFileAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */