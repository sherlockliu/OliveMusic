/*    */ package com.yougou.mybatis.plugins;
/*    */ 
/*    */ import org.eclipse.jface.wizard.IWizard;
/*    */ import org.eclipse.jface.wizard.WizardDialog;
/*    */ import org.eclipse.swt.widgets.Shell;
/*    */ 
/*    */ public class WizardDialogExt extends WizardDialog
/*    */ {
/*    */   public WizardDialogExt(Shell parentShell, IWizard newWizard)
/*    */   {
/* 11 */     super(parentShell, newWizard);
/*    */     
/* 13 */     setShellStyle(67680);
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\com\yougou\mybatis\plugins\WizardDialogExt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */