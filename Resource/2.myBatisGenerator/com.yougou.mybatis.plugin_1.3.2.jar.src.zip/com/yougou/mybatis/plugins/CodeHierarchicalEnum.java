/*    */ package com.yougou.mybatis.plugins;
/*    */ 
/*    */ public enum CodeHierarchicalEnum {
/*  4 */   THREE(0, "三层"),  FOUR(1, "四层");
/*    */   
/*    */   public int point;
/*    */   public String name;
/*    */   
/*    */   private CodeHierarchicalEnum(int point, String name) {
/* 10 */     this.point = point;
/* 11 */     this.name = name;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\com\yougou\mybatis\plugins\CodeHierarchicalEnum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */