/*    */ package com.yougou.mybatis.plugins;
/*    */ 
/*    */ import org.eclipse.ui.plugin.AbstractUIPlugin;
/*    */ import org.osgi.framework.BundleContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Activator
/*    */   extends AbstractUIPlugin
/*    */ {
/*    */   public static final String PLUGIN_ID = "org.mybatis.generator.eclipse.ui";
/*    */   private static Activator plugin;
/*    */   
/*    */   public void start(BundleContext context)
/*    */     throws Exception
/*    */   {
/* 31 */     super.start(context);
/* 32 */     plugin = this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void stop(BundleContext context)
/*    */     throws Exception
/*    */   {
/* 43 */     plugin = null;
/* 44 */     super.stop(context);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static Activator getDefault()
/*    */   {
/* 53 */     return plugin;
/*    */   }
/*    */ }


/* Location:              C:\Users\user\Desktop\com.yougou.mybatis.plugin_1.3.2.jar!\com\yougou\mybatis\plugins\Activator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */